﻿using System;
using System.Linq;
using System.ServiceProcess;
using AutoMapper;
using Mandara.Business;
using Mandara.Business.Bus;
using Ninject;
using Ninject.Extensions.Logging;
using Topshelf;
using Topshelf.HostConfigurators;
using Topshelf.ServiceConfigurators;

namespace Mandara.AdminAlertService
{
    internal class Program
    {
        private static readonly ILogger _logger = new NLogLoggerFactory().GetCurrentClassLogger();

        private static void Main(string[] args)
        {
            AppDomain.CurrentDomain.UnhandledException += CurrentDomain_UnhandledException;

            HostFactory.Run(hostConfig =>
            {
                hostConfig.Service<AdminAlertTopshelf>(svcConfig => SetUpAdminAlertServiceExecution(svcConfig));
                hostConfig.SetDisplayName("Mandara Admin Alert Service");
                hostConfig.SetServiceName("Mandara.AdminAlertService");
                hostConfig.OnException(UnhandledTopShelfException);
                hostConfig.UseNLog();
                hostConfig.RunAsLocalSystem();
            });
        }

        private static void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs unhandled)
        {
            if (unhandled.ExceptionObject is Exception exception)
            {
                _logger.Error(exception, "Unhandled top level exception, terminating");
            }
        }

        private static void SetUpAdminAlertServiceExecution(ServiceConfigurator<AdminAlertTopshelf> svcConfig)
        {
            svcConfig.ConstructUsing(name => new AdminAlertTopshelf());

            svcConfig.WhenStarted(
                (adminAlertSvc, hostCtrl) =>
                {
                    adminAlertSvc.Start(hostCtrl);
                    return true;
                });

            svcConfig.WhenStopped(
                (adminAlertSvc, hostCtrl) =>
                {
                    adminAlertSvc.Stop(hostCtrl);
                    return true;
                });
        }

        private static void UnhandledTopShelfException(Exception topshelfEx)
        {
            _logger.Error(topshelfEx, "TopShelf exception\n");
        }
    }
}
