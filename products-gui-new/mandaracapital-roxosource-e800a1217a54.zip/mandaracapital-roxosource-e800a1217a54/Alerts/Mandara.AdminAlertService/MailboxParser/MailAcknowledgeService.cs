﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using MailKit;
using MailKit.Net.Imap;
using MailKit.Search;
using Mandara.AdminAlertService.Configuration;
using Mandara.AdminAlertService.Messaging.Configuration;
using Mandara.Business.AdministrativeAlerts;
using Mandara.Business.AsyncServices.Base;
using Mandara.Business.Bus.Messages.AdmAlerts;
using Mandara.Business.PublishSubscribe;
using Mandara.Entities;
using Mandara.Entities.ErrorReporting;
using Ninject.Extensions.Logging;
using Email = Mandara.AdminAlertService.Messaging.Configuration.Email;

namespace Mandara.AdminAlertService.MailboxParser
{
    internal class MailAcknowledgeService : AsyncService
    {
        private const string CHILKAT_IMAPCODE = "MIKHAIIMAPMAILQ_k3AgYk0V2J2e";

        private bool _ssl;
        private int _port = 143;
        private static readonly Email _emailConfig = Email.GetSection();
        private readonly string _server = _emailConfig.AlertAck.Connection.Server;
        private readonly string _login = _emailConfig.AlertAck.Credentials.Name;
        private readonly string _password = _emailConfig.AlertAck.Credentials.Password;
        private readonly string _mailbox = _emailConfig.AlertAck.MailBox.Box;
        private bool _removeProcessedEmails;
        private readonly TimeSpan _sleepOnErrorInterval = TimeSpan.FromMinutes(1);
        private const string LastCheckDateSettingName = "AlertService_LastEmailCheck";

        private ImapClient _imapClient;
        private readonly IFormatProvider _culture = CultureInfo.InvariantCulture;
        private static readonly object _imapLock = new object();

        /// <summary>
        /// Constructor. Initializebasic settings and variables
        /// </summary>
        public MailAcknowledgeService(ILogger log) : base(log)
        {
            CreateIncomingMailServer();

            _sleepOnErrorInterval = AlertsCheck.GetSection().SleepOnError.Interval;
            GetIncomingEmailServerConfig();
        }

        private void CreateIncomingMailServer()
        {
            _imapClient = new ImapClient();
        }

        private void GetIncomingEmailServerConfig()
        {
            Acknowledge emailConfig = Email.GetSection().AlertAck;

            _ssl = emailConfig.Connection.UseSsl;
            _port = emailConfig.Connection.Port;
            _removeProcessedEmails = emailConfig.RemoveMail.Remove;
        }

        /// <summary>
        /// Error reporting
        /// </summary>
        /// <param name="error">Error message content</param>
        private void ReportError(string error)
        {
            ErrorReportingHelper.ReportError(
                "Alerts Service",
                ErrorType.Exception,
                "MailAcknoledgeService encounter an error: " + error,
                null,
                null,
                ErrorLevel.Critical);
        }

        /// <summary>
        /// Error reporting
        /// </summary>
        /// <param name="ex">Error as exception</param>
        private void ReportError(Exception ex)
        {
            ErrorReportingHelper.ReportError(
                "Mail Acknowledge Service",
                ErrorType.Exception,
                "MailAcknoledgeService encounter an error.",
                null,
                ex,
                ErrorLevel.Critical);
        }

        /// <summary>
        /// On service start. Initialize mailbox connection
        /// </summary>
        protected override void OnStarted()
        {
            base.OnStarted();
            lock (_imapLock)
            {
                Connect();
            }
        }

        /// <summary>
        /// Connect to imap
        /// </summary>
        private void Connect()
        {
            try
            {
                _imapClient.Connect(_server, _port, _ssl);
                _imapClient.Authenticate(Encoding.UTF8,_login,_password);
                _imapClient.Inbox.Open (FolderAccess.ReadWrite);
            }
            catch (Exception e)
            {
                _log.Error(e,"Exception during connection");
                ReportError(e.Message);
            }

        }

        /// <summary>
        /// Service job. Periodical scan for emails
        /// </summary>
        protected override void DoWork()
        {
            try
            {
                ScanAndAcknowledge();
            }
            catch (Exception ex)
            {
                ReportError(ex);
                // on error we suspend service execution
                Thread.Sleep(_sleepOnErrorInterval);
            }
        }

        /// <summary>
        /// Scan and acknowledge if any email fit criteria
        /// </summary>
        private void ScanAndAcknowledge()
        {
            var acknowledgedTriggerKeys = ScanEmailsForTriggerKeys();
            AcknowledgeTriggers(acknowledgedTriggerKeys);
        }

        /// <summary>
        /// Expression to search mail box for specified subjected emails
        /// </summary>
        private const string SearchString = "SUBJECT \"(id:\" SINCE \"{0}\"";

        /// <summary>
        /// Expression to get trigger key
        /// </summary>
        private const string TriggerKeyRegex = @"\(id:(.+)\srecord:(.+)\)$";

        /// <summary>
        /// Scan mailbox for messages with specified subject and retrieve trigger key
        /// </summary>
        /// <returns>List of pairs trigger key - email adderss of sender</returns>
        private IEnumerable<KeyValuePair<string, string>> ScanEmailsForTriggerKeys()
        {
            var result = new List<KeyValuePair<string, string>>();

            try
            {
                lock (_imapLock)
                {
                    if (!_imapClient.IsConnected || !_imapClient.IsAuthenticated)
                    {
                        Connect();
                    }
                }

                // Get the message IDs of all the emails in the mailbox
                var lastEmailCheckDate = GetLastEmailCheckDate();
                
                SearchQuery query = new DateSearchQuery(SearchTerm.All, lastEmailCheckDate.AddDays(-1));
                var folder = _imapClient.Inbox;
                var messageIds = folder.Search(query);

                if (messageIds == null)
                {
                    throw new ApplicationException("Error fetching messages");
                }

                foreach (var uid in messageIds) {
                    var message = _imapClient.Inbox.GetMessage (uid);

                    // write the message to a file
                    message.WriteTo (string.Format ("{0}.eml", uid));
                    
                    if (message.Date > lastEmailCheckDate)
                    {
                        
                        StoreLastEmailCheckDate(message.Date.LocalDateTime);
                        

                        var subj = message.Subject;
                        var match = Regex.Match(subj, TriggerKeyRegex);
                        if (match.Success)
                        {
                            var triggerKey = match.Groups[1].Value;
                            if (int.TryParse(match.Groups[2].Value, out int historyID)
                                && AdmAlertHelper.IfAlertToAcknowledge(historyID))
                            {
                                result.Add(new KeyValuePair<string, string>(triggerKey, message.From.ToString()));
                            }
                        }

                        if (_removeProcessedEmails)
                        {
                            folder.AddFlags (uid, MessageFlags.Deleted, true);
                        }
                    }
                    folder.Expunge();
                }
            }
            catch (Exception ex)
            {
                ReportError(ex);
            }

            return result;
        }

        /// <summary>
        /// Retrieve date from db to specify search email recieved since this date time passed
        /// </summary>
        /// <returns></returns>
        private DateTime GetLastEmailCheckDate()
        {
            var defaultValue = DateTime.UtcNow.Date;
            using (MandaraEntities ctx = new MandaraEntities())
            {
                var setting = ctx.AppSettings.SingleOrDefault(s => s.Name == LastCheckDateSettingName);
                if (setting == null)
                {
                    return defaultValue;
                }

                var lastEmailCheckDate = DateTime.FromFileTimeUtc(Convert.ToInt64(setting.Value));
                return lastEmailCheckDate < defaultValue ? defaultValue : lastEmailCheckDate;
            }
        }

        /// <summary>
        /// Store last processed datetime to db
        /// </summary>
        /// <param name="date"></param>
        private void StoreLastEmailCheckDate(DateTime date)
        {
            string dateString = date.ToFileTimeUtc().ToString();
            using (MandaraEntities ctx = new MandaraEntities())
            {
                var setting = ctx.AppSettings.SingleOrDefault(s => s.Name == LastCheckDateSettingName);
                if (setting == null)
                {
                    setting = new AppSetting { Name = LastCheckDateSettingName, Value = dateString };
                    ctx.AppSettings.Add(setting);
                }
                else
                {
                    setting.Value = dateString;
                }

                ctx.SaveChanges();
            }
        }

        /// <summary>
        /// Send bus message to acknowledge alerts by recieved trigger keys
        /// </summary>
        /// <param name="triggerKeys">List of pairs trigger key - email adderss of sender</param>
        private void AcknowledgeTriggers(IEnumerable<KeyValuePair<string, string>> triggerKeys)
        {
            foreach (var triggerKey in triggerKeys)
            {
                PubSub.SendMessage(
                    new AcknowledgeAlertRequestMessage { TriggerKey = triggerKey.Key, UserName = triggerKey.Value });
            }
        }

        /// <summary>
        /// Serve stopped event (Disconnect from imap server)
        /// </summary>
        protected override void OnStopped()
        {
            Disconnect();
            base.OnStopped();
        }

        /// <summary>
        /// Disconnect from imap server
        /// </summary>
        private void Disconnect()
        {
            _imapClient.Disconnect(true);
        }
    }
}