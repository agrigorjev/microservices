﻿using System;
using AutoMapper;
using Mandara.Business;
using Mandara.Business.Bus;
using Ninject;
using Ninject.Extensions.Logging;
using Topshelf;

namespace Mandara.AdminAlertService
{
    internal class AdminAlertTopshelf : ServiceControl, IDisposable
    {
        private static readonly ILogger _logger = new NLogLoggerFactory().GetCurrentClassLogger();
        private AdminAlertService _alertSvc;
        private HostControl _serviceHost;

        public bool Start(HostControl hostControl)
        {
            try
            {
                _serviceHost = hostControl;
                InitAutomapper();
                IoC.Initialize(CreateKernel());

                _alertSvc = new AdminAlertService(new NLogLogger(typeof(AdminAlertService)), _serviceHost);
                _alertSvc.Start();
                return true;
            }
            catch (Exception ex)
            {
                _logger.Error(ex, "Error while trying to start Admin Alert Service\n");
                return false;
            }
        }

        private static void InitAutomapper()
        {
            _logger.Trace("Starting Automapper initialisation");
            Mapper.Initialize(cfg =>
            {
                cfg.AddProfile<BusClientProfile>();
                cfg.Advanced.AllowAdditiveTypeMapCreation = true;
            });
            Mapper.AssertConfigurationIsValid();
            _logger.Trace("Automapper initialised succesfully");
        }

        private static IKernel CreateKernel()
        {
            var kernel = new StandardKernel();

            kernel.Load(new NLogModule(), new MainModule());

            return kernel;
        }

        public bool Stop(HostControl hostControl)
        {
            StopAlertService();
            return true;
        }

        private void StopAlertService()
        {
            _alertSvc?.Stop();
            _alertSvc?.Dispose();
            _alertSvc = null;
        }

        public void Dispose()
        {
            StopAlertService();
        }
    }
}
