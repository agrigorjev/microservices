﻿using System;
using System.Configuration;
using System.Net;
using System.Net.Mail;
using Mandara.AdminAlertService.Messaging.Configuration;
using Mandara.Entities.ErrorReporting;

namespace Mandara.AdminAlertService.Messaging
{
    /// <summary>
    /// An IEmailSender implementation for sending emails using default .NET utils.
    /// </summary>
    public class EmailSender : IEmailSender
    {
        public void Send(string toAddress, string fromAddress, string subject, string body)
        {
            MailMessage mailMessage = GetMessage(toAddress, fromAddress, subject, body);
            SmtpClient smtpClient = GetSmtpClient();

            try
            {
                using (mailMessage)
                {
                    smtpClient.Send(mailMessage);
                }
            }
            catch (Exception ex)
            {
                ErrorReportingHelper.ReportError(
                    "Alerts Service",
                    ErrorType.Exception,
                    $"Error sending an email, subject [{mailMessage.Subject}]",
                    null,
                    ex,
                    ErrorLevel.Normal);
            }
        }

        private static MailMessage GetMessage(string toAddress, string fromAddress, string subject, string body)
        {
            return new MailMessage(fromAddress, toAddress, TrimSubject(subject), body) { IsBodyHtml = true, };
        }

        private static string TrimSubject(string subject)
        {
            int rnIndex = subject.IndexOf("\r\n");
            int nIndex = subject.IndexOf("\n");
            string trimmedSubject = subject;

            if (rnIndex > -1 || nIndex > -1)
            {
                rnIndex = rnIndex > -1 ? rnIndex : int.MaxValue;
                nIndex = nIndex > -1 ? nIndex : int.MaxValue;

                int newLineIndex = Math.Min(rnIndex, nIndex);

                trimmedSubject = subject.Substring(0, newLineIndex);
            }

            return trimmedSubject;
        }

        private static SmtpClient GetSmtpClient()
        {
            Out smtpConfig = Email.GetSection().Outgoing;

            return new SmtpClient
            {
                Host = smtpConfig.Connection.Server,
                Port = smtpConfig.Connection.Port,
                EnableSsl = smtpConfig.Connection.UseSsl,
                DeliveryMethod = SmtpDeliveryMethod.Network,
                Credentials = new NetworkCredential(smtpConfig.Credentials.Name, smtpConfig.Credentials.Password)
            };
        }
    }
}