﻿using Mandara.Entities;

namespace Mandara.AdminAlertService.Messaging
{
    /// <summary>
    /// Defines methods for sending alerts notifications.
    /// </summary>
    interface IMessagingService
    {
        void SendSms(string phone, string message);
        void SendMail(string address, string subject, string message);
        void SendBusMessage(string key, string userName, string subject, string message, string actualValue, string serializedValue, AdministrativeAlert alert);
    }
}
