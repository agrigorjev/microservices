﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Mandara.Entities;

namespace Mandara.AdminAlertService.Messaging
{
    /// <summary>
    /// Test messaging service for writing all the messages in the Console.
    /// </summary>
    class ConsoleMessagingService : IMessagingService
    {
        public void SendSms(string phone, string message)
        {
            Console.WriteLine(string.Format("Sending sms: phone='{0}' text='{1}'", phone, message));
        }

        public void SendMail(string address, string subject, string message)
        {
            Console.WriteLine(string.Format("Sending email: to='{0}' subj='{1}' text='{2}'", address, subject, message));
        }

        public void SendBusMessage(string key, string userName, string subject, string message, string actualValue, string serializedValue, AdministrativeAlert alert)
        {
            Console.WriteLine(string.Format("Sending bus msg: key='{3}' user='{0}' subj='{1}' text='{2}'", userName, subject, message, key));
        }
    }
}
