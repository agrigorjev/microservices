﻿namespace Mandara.AdminAlertService.Messaging
{
    /// <summary>
    /// Defines method for sending email messages.
    /// </summary>
    public interface IEmailSender
    {
        void Send(string toAddress, string fromAddress, string subject, string body);
    }
}