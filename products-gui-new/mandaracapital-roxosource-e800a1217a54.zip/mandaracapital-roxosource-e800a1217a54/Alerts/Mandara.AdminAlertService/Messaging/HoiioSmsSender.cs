﻿using Newtonsoft.Json;
using NLog;
using HoiioSDK.NET;
using Mandara.AdminAlertService.Messaging.Configuration;

namespace Mandara.AdminAlertService.Messaging
{
    /// <summary>
    /// An ISmsSender implementation for the Hoiio sms service.
    /// </summary>
    public class HoiioSmsSender :  ISmsSender
    {
        private static readonly Logger Log = LogManager.GetCurrentClassLogger();
        private static readonly Hoiio HoiioConfig = Sms.GetSection().HoiioSettings;
        private static readonly string AppId = HoiioConfig.Id;
        private static readonly string AccessToken = HoiioConfig.Token;
        private static readonly string SenderName = HoiioConfig.Sender;
        private static readonly string NotifyUrl = HoiioConfig.NotificationUrl;
        
        public void Send(string phoneNumber, string message)
        {
            //Format phone number
            if (!phoneNumber.StartsWith("+"))
            {
                phoneNumber = "+" + phoneNumber;
            }

            HoiioService service = new HoiioService(AppId, AccessToken);
            HoiioResponse result = service.smsSend(phoneNumber, SenderName, message, null, NotifyUrl);

            Log.Debug(JsonConvert.SerializeObject(result));
        }
    }

}