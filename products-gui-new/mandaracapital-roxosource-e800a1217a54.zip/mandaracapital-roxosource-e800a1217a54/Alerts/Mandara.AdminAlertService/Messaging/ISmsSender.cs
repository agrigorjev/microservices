﻿namespace Mandara.AdminAlertService.Messaging
{
    /// <summary>
    /// Defines method for sending sms messages.
    /// </summary>
    public interface ISmsSender
    {
        void Send(string phoneNumber, string message);
    }
}