﻿ //#define DEVTEST

using System;
using Mandara.AdminAlertService.Messaging.Configuration;
using Mandara.Business.Bus;
using Mandara.Business.Bus.Commands;
using Mandara.Business.Bus.Commands.Base;
using Mandara.Business.Bus.Messages.AdmAlerts;
using Mandara.Entities;
using Mandara.Extensions.Collections;

namespace Mandara.AdminAlertService.Messaging
{
    /// <summary>
    /// An IMessagingService implementation for the production messaging service with email, sms and 
    /// message bus components.
    /// </summary>
    public class MessagingService : IMessagingService
    {
        private readonly CommandManager _commandManager;
        private readonly IEmailSender _emailSender;
        private readonly ISmsSender _smsSender;
        private readonly static Email emailConfig = Email.GetSection();

        public MessagingService(CommandManager commandManager, IEmailSender emailSender, ISmsSender smsSender)
        {
            _commandManager = commandManager
                              ?? throw new ArgumentNullException("commandManager", "commandManager should not be null");
#if DEVTEST
            return;
#endif
            _emailSender = emailSender
                           ?? throw new ArgumentNullException("emailSender", "emailSender should not be null");
            _smsSender = smsSender ?? throw new ArgumentNullException("smsSender", "smsSender should not be null");
        }

        public void SendSms(string phone, string message)
        {
            _smsSender.Send(phone, message);
        }

        public void SendMail(string address, string subject, string message)
        {
#if DEVTEST
            return;
#endif
            string fromAddress =  emailConfig.Outgoing.Source.Address;
            
            _emailSender.Send(address, fromAddress, subject, message);
        }

        public void SendBusMessage(
            string key,
            string userName,
            string subject,
            string message,
            string actualValue,
            string serializedValue,
            AdministrativeAlert alert)
        {
#if DEVTEST
            message = $"DEV TESTING - IGNORE {message}";
#endif
            AdmAlertMessage msg = new AdmAlertMessage
            {
                UserName = userName,
                AdmAlert = AdmAlertDto.Compose(key, subject, message, actualValue, serializedValue, alert)
            };

            InformaticaHelper.GetAllServerAwareTopicNames(InformaticaHelper.AdmAlertTopic).ForEach(
                topic =>
                {
                    _commandManager.AddCommand(new SendMessageCommand<AdmAlertMessage>(topic, msg));
                });
        }
    }
}