﻿using System;
using System.Configuration;
using System.Text.RegularExpressions;
using Mandara.AdminAlertService.Configuration;
using Mandara.AdminAlertService.Configuration.Validation;

namespace Mandara.AdminAlertService.Messaging.Configuration
{
    internal class Out : ConfigurationElement
    {
        public const string ElemName = "out";

        [ConfigurationProperty(ServerConnection.ElemName, IsRequired = true)]
        public ServerConnection Connection
        {
            get => (ServerConnection)this[ServerConnection.ElemName];
            set => this[ServerConnection.ElemName] = value;
        }

        [ConfigurationProperty(FromAddress.ElemName, IsRequired = true)]
        public FromAddress Source
        {
            get => (FromAddress)this[FromAddress.ElemName];
            set => this[FromAddress.ElemName] = value;
        }

        [ConfigurationProperty(User.ElemName, IsRequired = true)]
        public User Credentials
        {
            get => (User)this[User.ElemName];
            set => this[User.ElemName] = value;
        }
    }

    internal class ServerConnection : ConfigurationElement
    {
        public const string ElemName = "connection";
        public const string ServerName = "server";
        public const string PortName = "port";
        public const string UseSslName = "ssl";

        public const int MinPort = 0;
        public const int MaxPort = 65535;
        private static readonly IntegerRangeCheck RangeCheck = new IntegerRangeCheck(MinPort, MaxPort);
        private static readonly StringLengthCheck AtLeastOneChar = new StringLengthCheck(
            1,
            StringLengthCheck.DefaultMax);

        [ConfigurationProperty(ServerName, IsRequired = true)]
        public string Server
        {
            get => (string)this[ServerName];
            set
            {
                AtLeastOneChar.CheckValue(value, ServerName);
                this[ServerName] = value;
            }
        }

        [ConfigurationProperty(PortName, IsRequired = true)]
        public int Port
        {
            get => (int)this[PortName];
            set
            {
                RangeCheck.CheckValue(value, PortName);
                this[PortName] = value;
            }
        }

        [ConfigurationProperty(UseSslName, DefaultValue = false)]
        public bool UseSsl
        {
            get => (bool)this[UseSslName];
            set => this[UseSslName] = value;
        }
    }

    internal class FromAddress : ConfigurationElement
    {
        public const string ElemName = "from";
        public const string AddressName = "address";

        private static readonly RegexCheck AddressCheck =
            new RegexCheck("^[A-Za-z0-9_.]+@[A-Za-z0-9_.]+$", 0, RegexCheck.DefaultMax);

        [ConfigurationProperty(AddressName, IsRequired = true)]
        public string Address
        {
            get => (string)this[AddressName];
            set
            {
                AddressCheck.CheckValue(value, AddressName);
                this[AddressName] = value;
            }
        }
    }

    internal class Acknowledge : ConfigurationElement
    {
        public const string ElemName = "ack";

        [ConfigurationProperty(ServerConnection.ElemName, IsRequired = true)]
        public ServerConnection Connection
        {
            get => (ServerConnection)this[ServerConnection.ElemName];
            set => this[ServerConnection.ElemName] = value;
        }

        [ConfigurationProperty(IncomingMailBox.ElemName, IsRequired = true)]
        public IncomingMailBox MailBox
        {
            get => (IncomingMailBox)this[IncomingMailBox.ElemName];
            set => this[IncomingMailBox.ElemName] = value;
        }

        [ConfigurationProperty(User.ElemName, IsRequired = true)]
        public User Credentials
        {
            get => (User)this[User.ElemName];
            set => this[User.ElemName] = value;
        }

        [ConfigurationProperty(ProcessedEmailAction.ElemName, IsRequired = false)]
        public ProcessedEmailAction RemoveMail
        {
            get => (this[ProcessedEmailAction.ElemName] as ProcessedEmailAction) ?? ProcessedEmailAction.Default;
            set => this[ProcessedEmailAction.ElemName] = value;
        }
    }

    internal class IncomingMailBox : ConfigurationElement
    {
        public const string ElemName = "mailbox";
        public const string BoxName = "name";
        private static readonly StringLengthCheck AtLeastOneChar = new StringLengthCheck(
            1,
            StringLengthCheck.DefaultMax);

        [ConfigurationProperty(BoxName, DefaultValue = "Inbox")]
        public string Box
        {
            get => (string)this[BoxName];
            set
            {
                AtLeastOneChar.CheckValue(value, BoxName);
                this[BoxName] = value;
            }
        }
    }

    internal class ProcessedEmailAction : ConfigurationElement
    {
        public const string ElemName = "processedEmails";
        public const string RemoveName = "remove";

        [ConfigurationProperty(RemoveName, DefaultValue = false)]
        public bool Remove
        {
            get => (bool)this[RemoveName];
            set => this[RemoveName] = value;
        }

        public static ProcessedEmailAction Default => new ProcessedEmailAction() { Remove = false };
    }

    internal class Email : ConfigurationSection
    {
        public const string SectionName = "email";

        [ConfigurationProperty(Out.ElemName, IsRequired = true)]
        public Out Outgoing
        {
            get => (Out)this[Out.ElemName];
            set => this[Out.ElemName] = value;
        }

        [ConfigurationProperty(Acknowledge.ElemName, IsRequired = true)]
        public Acknowledge AlertAck
        {
            get => (Acknowledge)this[Acknowledge.ElemName];
            set => this[Acknowledge.ElemName] = value;
        }

        public static Email GetSection()
        {
            return ConfigurationManager.GetSection(SectionName) as Email;
        }
    }
}
