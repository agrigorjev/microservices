﻿using System.Configuration;
using Mandara.AdminAlertService.Configuration;
using Mandara.AdminAlertService.Configuration.Validation;

namespace Mandara.AdminAlertService.Messaging.Configuration
{
    internal class Url : ConfigurationElement
    {
        public const string ElemName = "url";
        public const string AddressName = "address";

        private static readonly RegexCheck UrlCheck =
            new RegexCheck("(file|http)://[A-Za-z0-9_-.]:(/[A-Za-z0-9_-./]*)?");

        [ConfigurationProperty(AddressName, IsRequired = true)]
        public string Address
        {
            get => (string)this[AddressName];
            set
            {
                UrlCheck.CheckValue(value, AddressName);
                this[AddressName] = value;
            }
        }
    }

    internal class BulkSms : ConfigurationSection
    {
        public const string SectionName = "bulkSms";

        [ConfigurationProperty(Url.ElemName, IsRequired = true)]
        public Url Address
        {
            get => (Url)this[Url.ElemName];
            set => this[Url.ElemName] = value;
        }

        [ConfigurationProperty(User.ElemName, IsRequired = true)]
        public User Credentials
        {
            get => (User)this[User.ElemName];
            set => this[User.ElemName] = value;
        }

        public static BulkSms GetSection()
        {
            return ConfigurationManager.GetSection(SectionName) as BulkSms;
        }
    }
}
