﻿using System;
using System.Configuration;
using Mandara.AdminAlertService.Configuration;
using Mandara.AdminAlertService.Configuration.Validation;

namespace Mandara.AdminAlertService.Messaging.Configuration
{
    internal class Hoiio : ConfigurationElement
    {
        public const string ElemName = "hoiio";
        public const string IdName = "id";
        public const string TokenName = "token";
        public const string SenderName = "sender";
        public const string NotificationUrlName = "notifyUrl";
        private static readonly StringLengthCheck AtLeastOneChar = new StringLengthCheck(
            1,
            StringLengthCheck.DefaultMax);

        [ConfigurationProperty(IdName, DefaultValue = "u352sQCPwI1KgOnp")]
        public string Id
        {
            get => (string)this[IdName];
            set
            {
                AtLeastOneChar.CheckValue(value, IdName);
                this[IdName] = value;
            }
        }

        [ConfigurationProperty(TokenName, DefaultValue = "Qd2y6ycNdKZse9Rs")]
        public string Token
        {
            get => (string)this[TokenName];
            set
            {
                AtLeastOneChar.CheckValue(value, TokenName);
                this[TokenName] = value;
            }
        }

        [ConfigurationProperty(SenderName, DefaultValue = "Noone")]
        public string Sender
        {
            get => (string)this[SenderName];
            set
            {
                AtLeastOneChar.CheckValue(value, SenderName);
                this[SenderName] = value;
            }
        }

        [ConfigurationProperty(NotificationUrlName, DefaultValue = "")]
        public string NotificationUrl
        {
            get => (string)this[NotificationUrlName];
            set => this[NotificationUrlName] = value;
        }

        public static Hoiio Default => new Hoiio();
    }

    internal class Sms : ConfigurationSection
    {
        public const string SectionName = "sms";
        public const string MethodName = "method";
        public const string MethodHoiio = "Hoiio";
        private static readonly StringLengthCheck AtLeastOneChar = new StringLengthCheck(
            1,
            StringLengthCheck.DefaultMax);

        [ConfigurationProperty(MethodName, DefaultValue = MethodHoiio)]
        public string Method
        {
            get => (string)this[MethodName];
            set
            {
                AtLeastOneChar.CheckValue(value, MethodName);
                this[MethodName] = value;
            }
        }

        [ConfigurationProperty(Hoiio.ElemName, IsRequired = false)]
        public Hoiio HoiioSettings
        {
            get => (this[Hoiio.ElemName] as Hoiio) ?? Hoiio.Default;
            set => this[Hoiio.ElemName] = value;
        }

        public static Sms GetSection()
        {
            return ConfigurationManager.GetSection(SectionName) as Sms;
        }
    }
}
