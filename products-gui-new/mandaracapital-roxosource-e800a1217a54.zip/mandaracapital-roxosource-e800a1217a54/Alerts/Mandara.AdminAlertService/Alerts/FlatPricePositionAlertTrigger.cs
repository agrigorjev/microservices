﻿using System;
using Mandara.AdminAlertService.ValueProviders;
using Mandara.Entities;

namespace Mandara.AdminAlertService.Alerts
{
    class FlatPricePositionAlertTrigger : KeyValueAlertTrigger<FlatPriceValueKey, decimal?>
    {
        public FlatPricePositionAlertTrigger(AdministrativeAlert alert,
                                             Func<AdministrativeAlert, decimal?> thresholdSelector,
                                             IKeyValueProvider<FlatPriceValueKey, decimal?> valueProvider,
                                             FlatPriceValueKey key)
            : base(alert, thresholdSelector, valueProvider, key,nameof(FlatPricePositionAlertTrigger))
        {}
    }
}