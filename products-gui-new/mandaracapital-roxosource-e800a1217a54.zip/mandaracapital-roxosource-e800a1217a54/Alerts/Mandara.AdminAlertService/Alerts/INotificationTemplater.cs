﻿using System;
using System.Collections.Generic;

namespace Mandara.AdminAlertService.Alerts
{
    internal interface INotificationTemplater
    {
        string ApplyTemplate(string template, AlertNotification notification);
    }

    internal class EmailNotificationTemplater : INotificationTemplater
    {
        protected readonly Dictionary<string, Func<AlertNotification, string>> _parameters =
            new Dictionary<string, Func<AlertNotification, string>>();

        public EmailNotificationTemplater()
        {
            _parameters.Add("{subject}", x => x.AlertSubject);
            _parameters.Add("{message}", x => x.AlertMessage);
            _parameters.Add("{actual_value}", x => x.ActualValue);

            _parameters.Add("{threshold}", x => x.AdministrativeAlert.ThresholdValueString);
            _parameters.Add("{book}", x => x.AdministrativeAlert.Portfolio != null ? x.AdministrativeAlert.Portfolio.Name : "n/a");

            _parameters.Add("{trade_id}", x => x.NotificationInfo.TradeId);
            _parameters.Add("{product}", x => x.NotificationInfo.Product);
            _parameters.Add("{trader}", x => x.NotificationInfo.Trader);
        }

        public virtual string ApplyTemplate(string template, AlertNotification notification)
        {
            if (string.IsNullOrEmpty(template) || notification == null)
                return null;

            foreach (var pair in _parameters)
            {
                string substitution = pair.Value(notification) ?? string.Empty;
                template = template.Replace(pair.Key, substitution);
            }

            return template;
        }
    }
}