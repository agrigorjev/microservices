﻿using System;
using Mandara.Entities;

namespace Mandara.AdminAlertService.Alerts
{
    internal static class BoundaryCheck
    {
        public static bool IsConditionMet(int comparableResult, AdministrativeAlert.BoundaryType boundaryType)
        {
            switch (boundaryType)
            {
                case AdministrativeAlert.BoundaryType.LessThan:
                {
                    return comparableResult <= 0;
                }

                case AdministrativeAlert.BoundaryType.GreaterThan:
                {
                    return comparableResult >= 0;
                }

                default:
                {
                    throw new InvalidOperationException();
                }
            }
        }
    }
}
