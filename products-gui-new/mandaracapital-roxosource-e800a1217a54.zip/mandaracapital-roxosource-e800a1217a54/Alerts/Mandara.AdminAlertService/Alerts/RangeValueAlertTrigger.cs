//using System;
//using System.Collections.Generic;
//using System.Linq;
//using Mandara.AdminAlertService.ValueProviders;
//using Mandara.Entities;
//
//namespace Mandara.AdminAlertService.Alerts
//{
//    /// <summary>
//    /// Alert trigger for the value provider inherited from IMultiValueProvider interface.
//    /// </summary>
//    /// <typeparam name="T">Type of the value in value provider.</typeparam>
//    class RangeValueAlertTrigger<T> : AlertTrigger
//    {
//        private readonly Func<AdministrativeAlert, T> _thresholdSelector;
//        private readonly IMultiValueProvider<T> _valueProvider;
//
//        public RangeValueAlertTrigger(AdministrativeAlert alert, Func<AdministrativeAlert, T> thresholdSelector, IMultiValueProvider<T> valueProvider)
//            : base(alert)
//        {
//            _thresholdSelector = thresholdSelector;
//            _valueProvider = valueProvider;
//        }
//
//        protected override bool ConditionMet()
//        {
//            string stringedValue;
//            T[] values = _valueProvider.GetValues(AdministrativeAlert.Portfolio.PortfolioId/*, out stringedValue*/);
//
//            if (values == null || !values.Any())
//                return false;
//
//            var comparer = Comparer<T>.Default;
//
//            List<string> actualValues = new List<string>();
//
//            T threshold = _thresholdSelector(AdministrativeAlert);
//
//            foreach (T value in values)
//            {
//                if (ConditionMet(comparer.Compare(value, threshold)))
//                    actualValues.Add(value.ToString());
//            }
//
//            ActualValue = /*stringedValue +*/ string.Join(", ", actualValues);
//
//            return actualValues.Count > 0;
//        }
//
//        private bool ConditionMet(int comparableResult)
//        {
//            if (AdministrativeAlert.BoundaryType == AdministrativeAlert.BoundaryTypeEnum.LessThan)
//                return comparableResult < 0;
//            else if (AdministrativeAlert.BoundaryType == AdministrativeAlert.BoundaryTypeEnum.GreaterThan)
//                return comparableResult > 0;
//            else
//                throw new InvalidOperationException();
//        }
//    }
//}