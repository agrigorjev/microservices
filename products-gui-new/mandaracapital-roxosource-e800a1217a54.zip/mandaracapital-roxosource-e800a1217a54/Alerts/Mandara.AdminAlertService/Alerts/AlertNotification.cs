﻿using System;
using System.Text;
using Mandara.AdminAlertService.Messaging;
using Mandara.Business.AdministrativeAlerts;
using Mandara.Entities;

namespace Mandara.AdminAlertService.Alerts
{
    /// <summary>
    /// Alert notification wrapper, contains helper methods and properties for working with AdministrativeAlert
    /// with different escalation levels.
    /// </summary>
    internal class AlertNotification
    {
        protected INotificationTemplater _emailTemplater;

        /// <summary>
        /// Reference to the AdministrativeAlert for which notifiations should be sent.
        /// </summary>
        public AdministrativeAlert AdministrativeAlert { get; set; }

        /// <summary>
        /// Notification current escalation level.
        /// </summary>
        public EscalationLevel EscalationLevel { get; set; }

        public AlertTriggerNotificationInfo NotificationInfo { get; set; }

        /// <summary>
        /// Alert computed value (from the corresponding ValueProvider).
        /// </summary>
        public string ActualValue => NotificationInfo.ActualValue;

        /// <summary>
        /// Alert computed value (from the corresponding ValueProvider).
        /// </summary>
        public string SerializedValue => NotificationInfo.SerializedValue;

        protected AdministrativeAlertGroup AlertGroup
        {
            get
            {
                switch (EscalationLevel)
                {
                    case EscalationLevel.Level0:
                        {
                            throw ThrowForAlertLevel0("group");
                        }

                    case EscalationLevel.Level1:
                        {
                            return AdministrativeAlert.AlertGroup1;
                        }

                    case EscalationLevel.Level2:
                        {
                            return AdministrativeAlert.AlertGroup2;
                        }

                    case EscalationLevel.Level3:
                        {
                            return AdministrativeAlert.AlertGroup3;
                        }

                    case EscalationLevel.Level4:
                        {
                            return AdministrativeAlert.AlertGroup4;
                        }

                    default:
                        {
                            throw ThrowForInvalidAlertLevel("group");
                        }
                }
            }
        }

        private InvalidOperationException ThrowForAlertLevel0(string unavailableValue)
        {
            return new InvalidOperationException($"Cannot get alert {unavailableValue} for  escalation level 0.");
        }

        private InvalidOperationException ThrowForInvalidAlertLevel(string unavailableValue)
        {
            return new InvalidOperationException(
                $"Cannot get an alert {unavailableValue} for invalid escalation level {EscalationLevel}.");
        }

        public string AlertSubject
        {
            get
            {
                switch (EscalationLevel)
                {
                    case EscalationLevel.Level0:
                        {
                            throw ThrowForAlertLevel0("subject");
                        }

                    case EscalationLevel.Level1:
                        {
                            return AdministrativeAlert.Level1Subject;
                        }

                    case EscalationLevel.Level2:
                        {
                            return AdministrativeAlert.Level2Subject;
                        }

                    case EscalationLevel.Level3:
                        {
                            return AdministrativeAlert.Level3Subject;
                        }

                    case EscalationLevel.Level4:
                        {
                            return AdministrativeAlert.Level4Subject;
                        }

                    default:
                        {
                            throw ThrowForInvalidAlertLevel("subject");
                        }
                }
            }
        }

        public string AlertMessage
        {
            get
            {
                switch (EscalationLevel)
                {
                    case EscalationLevel.Level0:
                        {
                            throw ThrowForAlertLevel0("message");
                        }

                    case EscalationLevel.Level1:
                        {
                            return AdministrativeAlert.Level1Message;
                        }

                    case EscalationLevel.Level2:
                        {
                            return AdministrativeAlert.Level2Message;
                        }

                    case EscalationLevel.Level3:
                        {
                            return AdministrativeAlert.Level3Message;
                        }

                    case EscalationLevel.Level4:
                        {
                            return AdministrativeAlert.Level4Message;
                        }

                    default:
                        {
                            throw ThrowForInvalidAlertLevel("message");
                        }
                }
            }
        }

        /// <summary>
        /// Reference history Id if any. Used for voice calls
        /// </summary>
        public int HistoryId { get; set; }

        protected string DetailedAlertMessage
        {
            get
            {
                string book = AdministrativeAlert.Portfolio != null ? AdministrativeAlert.Portfolio.Name : "n/a";

                return string.Format(
                    "{0}\nActualValue: {1}\nThreshold: {2}\nBook: {3}",
                    AlertMessage,
                    ActualValue,
                    AdministrativeAlert.ThresholdValueString,
                    book);
            }
        }

        public AlertNotification(
            string triggerKey,
            AdministrativeAlert administrativeAlert,
            EscalationLevel escalationLevel,
            AlertTriggerNotificationInfo notificationInfo,
            int historyId = 0)
        {
            AdministrativeAlert = administrativeAlert ?? throw new ArgumentNullException(nameof(administrativeAlert));
            HistoryId = historyId;
            TriggerKey = triggerKey;
            EscalationLevel = escalationLevel;
            NotificationInfo = notificationInfo;
            _emailTemplater = new EmailNotificationTemplater();
        }

        /// <summary>
        /// Send notification using given messaging service.
        /// </summary>
        /// <param name="messagingService">Messaging service for notifications sending.</param>
        public void Send(IMessagingService messagingService)
        {

            foreach (User user in AlertGroup.Users)
            {
                messagingService.SendBusMessage(
                    TriggerKey,
                    user.UserName,
                    AlertSubject,
                    AlertMessage,
                    ActualValue,
                    SerializedValue,
                    AdministrativeAlert);
            }

            if (HistoryId > 0)
            {
                SendAlertEmails(messagingService, AlertGroup);
                MakeVoiceCalls();
            }

            SendSms(messagingService);
        }

        private void SendAlertEmails(IMessagingService messagingService, AdministrativeAlertGroup @group)
        {
            string emailSubject = GetEmailSubject();
            string emailBody = GetEmailBody();

            foreach (AlertEmailAddress email in @group.Emails)
            {
                messagingService.SendMail(email.Email, emailSubject, emailBody);
            }
        }

        private string GetEmailSubject()
        {
            string emailSubject;
            string subjectFromTemplate = _emailTemplater.ApplyTemplate(AdministrativeAlert.EmailSubjectTemplate, this);

            if (subjectFromTemplate == null)
            {
                emailSubject = EmailSubject;
            }
            else
            {
                emailSubject = subjectFromTemplate + string.Format(" (id:{0} record:{1})", TriggerKey, HistoryId);
            }

            return emailSubject;
        }

        private string EmailSubject
        {
            get
            {
                StringBuilder subject = new StringBuilder($"'{AdministrativeAlert.Title}'");

                if (!string.IsNullOrEmpty(NotificationInfo.TradeId))
                {
                    subject.Append($" TradeID: {NotificationInfo.TradeId}, Product: {NotificationInfo.Product}");
                }

                return subject.Append($" (id:{TriggerKey} record:{HistoryId})").ToString();
            }
        }

        private string GetEmailBody()
        {
            return _emailTemplater.ApplyTemplate(AdministrativeAlert.EmailMessageTemplate, this) ?? EmailBody;
        }

        private string EmailBody =>
            new StringBuilder(GetViolationDescription())
                .Append(GetTradeIdentification()).Append($"Book: {GetPortfolioName()}").ToString();

        private string GetViolationDescription()
        {
            // TODO: refactor to return only time in ActualValue so we wouldn't need to cut trade time from ValueString
            return $"ActualValue: {GetTriggeringValue()}\nThreshold: {AdministrativeAlert.ThresholdValueString}\n";
        }

        private string GetTriggeringValue()
        {
            return string.IsNullOrEmpty(NotificationInfo.TradeId)
                ? NotificationInfo.ActualValue
                : NotificationInfo.ActualValue.Substring(NotificationInfo.ActualValue.Length - 8);
        }

        private string GetTradeIdentification()
        {
            if (!string.IsNullOrEmpty(NotificationInfo.TradeId))
            {
                return string.Format(
                    "TradeID: {0}\nProduct: {1}\nTrader: {2}\n",
                    NotificationInfo.TradeId,
                    NotificationInfo.Product,
                    NotificationInfo.Trader);
            }

            return string.Empty;
        }

        private string GetPortfolioName()
        {
            return AdministrativeAlert.Portfolio != null ? AdministrativeAlert.Portfolio.Name : "n/a";
        }

        private void MakeVoiceCalls()
        {
            if (AlertGroup.VoicePhones != null)
            {
                foreach (AlertVoicePhone phone in AlertGroup.VoicePhones)
                {
                    AdmAlertHelper.SubmitVoiceCall(
                        TriggerKey,
                        HistoryId,
                        phone.Phone,
                        AlertSubject + " " + AlertMessage,
                        ActualValue);
                }
            }
        }

        private void SendSms(IMessagingService messagingService)
        {
            foreach (AlertPhone phone in AlertGroup.Phones)
            {
                messagingService.SendSms(phone.Phone, AlertSubject + "\n" + DetailedAlertMessage);
            }
        }

        public string TriggerKey { get; set; }
    }
}