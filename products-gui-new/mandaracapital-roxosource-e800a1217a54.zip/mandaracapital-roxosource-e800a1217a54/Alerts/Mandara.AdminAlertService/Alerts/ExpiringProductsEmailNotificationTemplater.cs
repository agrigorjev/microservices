﻿using System.Collections.Generic;
using Mandara.Business;
using Newtonsoft.Json;

namespace Mandara.AdminAlertService.Alerts
{
    internal class ExpiringProductsEmailNotificationTemplater : EmailNotificationTemplater
    {
        public ExpiringProductsEmailNotificationTemplater() : base()
        {
            _parameters.Add("{table_expiring_products}",
                x =>
                {
                    string html = "<table cellpadding='2' cellspacing='0' border='1' width='100%'>";

                    html +=
                        "<thead><tr><th align='left'>Product Name</th><th align='left'>Strip Name</th><th align='left'>Quantity</th><th align='left'>Expiry Date</th></tr></thead>";

                    html += "<tbody>";

                    List<ExpiringProductWarning> productWarnings =
                        JsonConvert.DeserializeObject<List<ExpiringProductWarning>>(x.SerializedValue);

                    foreach (ExpiringProductWarning warning in productWarnings)
                    {
                        html += string.Format("<tr><td align='left'>{0}</td><td align='left'>{1}</td><td align='left'>{2:f2}</td><td align='left'>{3:dd/MM/yyyy}</td></tr>",
                            warning.ProductDescription, warning.StripName, warning.Quantity, warning.ExpiryDate);
                    }

                    html += "</tbody></table>";

                    return html; 
                });
        }

        public override string ApplyTemplate(string template, AlertNotification notification)
        {
            template = base.ApplyTemplate(template, notification);

            if (string.IsNullOrEmpty(template))
                return null;

            return template.Replace(@"\r\n", "<br />");
        }
    }
}