﻿using Mandara.AdminAlertService.ValueProviders;
using Mandara.Business;
using Mandara.Entities;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace Mandara.AdminAlertService.Alerts
{
    class ExpiringProductsAlertTrigger : SingleValueAlertTrigger<List<ExpiringProductWarning>>
    {
        public ExpiringProductsAlertTrigger(AdministrativeAlert alert,
            IValueProvider<List<ExpiringProductWarning>> valueProvider)
            : base(alert, null, valueProvider,nameof(ExpiringProductsAlertTrigger))
        {
        }

        public override string Key => DateTime.Today.ToString("MMdd");

        protected override AlertCheckResult ConditionMet()
        {
            int daysToExpire = Convert.ToInt32(AdministrativeAlert.ThresholdValue);
            CheckValue<List<ExpiringProductWarning>> expiringProductWarnings = ValueProvider.GetValue(daysToExpire);

            if (expiringProductWarnings.ValueToCheck.Count == 0)
            {
                return new AlertCheckResult(false, expiringProductWarnings.Displayable);
            }

            SerializedValue = JsonConvert.SerializeObject(expiringProductWarnings);
            return new AlertCheckResult(true, expiringProductWarnings.Displayable);

        }

        public override AlertNotification GetAlertNotification(EscalationLevel level, int historyReference)
        {
            return new ExpiringProductsAlertNotification(
                Key,
                AdministrativeAlert,
                level,
                AlertTriggerNotificationInfo.FromAlertTrigger(this),
                historyReference);
        }
    }
}