using Mandara.Business.Bus;

namespace Mandara.AdminAlertService.Alerts
{
    /// <summary>
    /// Alerts service context - contains service shared resources.
    /// </summary>
    internal class AdminAlertServiceContext
    {
        public BusClient BusClient { get; set; }
    }
}