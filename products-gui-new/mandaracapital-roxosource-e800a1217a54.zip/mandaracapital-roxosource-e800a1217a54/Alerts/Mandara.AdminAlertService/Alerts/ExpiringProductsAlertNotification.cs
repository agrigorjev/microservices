﻿using Mandara.Entities;

namespace Mandara.AdminAlertService.Alerts
{
    class ExpiringProductsAlertNotification : AlertNotification
    {
        public ExpiringProductsAlertNotification(string triggerKey, AdministrativeAlert administrativeAlert, EscalationLevel escalationLevel, AlertTriggerNotificationInfo notificationInfo, int historyId = 0) : base(triggerKey, administrativeAlert, escalationLevel, notificationInfo, historyId)
        {
            _emailTemplater = new ExpiringProductsEmailNotificationTemplater();
        }
    }
}