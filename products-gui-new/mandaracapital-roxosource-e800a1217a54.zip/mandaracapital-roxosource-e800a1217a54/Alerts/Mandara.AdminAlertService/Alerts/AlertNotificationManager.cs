﻿using Mandara.AdminAlertService.Messaging;
using Mandara.Business.AsyncServices.Base;
using Ninject.Extensions.Logging;
using System;
using System.Collections.Concurrent;
using System.Threading;
using System.Threading.Tasks;
using Mandara.Common.TaskSchedulers;

namespace Mandara.AdminAlertService.Alerts
{
    /// <summary>
    /// An async service for sending alerts notifications.
    /// </summary>
    class AlertNotificationManager : AsyncService
    {
        private readonly IMessagingService _messagingService;
        private readonly ConcurrentQueue<AlertNotification> _notificationQueue = new ConcurrentQueue<AlertNotification>();
        private readonly LimitedConcurrencyLevelTaskScheduler _scheduler;

        public AlertNotificationManager(IMessagingService messagingService, ILogger log)
            : base(log)
        {
            _messagingService = messagingService;

            _scheduler = new LimitedConcurrencyLevelTaskScheduler(10);
            SleepTime = TimeSpan.FromMilliseconds(50);
        }


        public void AddAlertNotification(AlertNotification alertNotification)
        {
            _notificationQueue.Enqueue(alertNotification);
        }

        protected override void DoWork()
        {
            AlertNotification alertNotification;

            if (!_notificationQueue.TryDequeue(out alertNotification))
                return;

            Task.Factory.StartNew(() =>
            {
                alertNotification.Send(_messagingService);
            }, CancellationToken.None, TaskCreationOptions.None, _scheduler);

        }
    }
}
