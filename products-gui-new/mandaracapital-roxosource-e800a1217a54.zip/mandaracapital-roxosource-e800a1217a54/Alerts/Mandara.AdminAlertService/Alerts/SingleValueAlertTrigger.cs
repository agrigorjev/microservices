using System;
using System.Collections.Generic;
using Mandara.AdminAlertService.ValueProviders;
using Mandara.Entities;

namespace Mandara.AdminAlertService.Alerts
{
    /// <summary>
    /// Alert trigger for the value provider inherited from IValueProvider interface.
    /// </summary>
    /// <typeparam name="T">Type of the value in value provider.</typeparam>
    class SingleValueAlertTrigger<T> : AlertTrigger
    {
        private readonly Func<AdministrativeAlert, T> _thresholdSelector;
        protected IValueProvider<T> ValueProvider { get; private set; }

        public SingleValueAlertTrigger(AdministrativeAlert alert, Func<AdministrativeAlert, T> thresholdSelector, IValueProvider<T> valueProvider,String triggerName)
            : base(alert, triggerName)
        {
            _thresholdSelector = thresholdSelector;
            ValueProvider = valueProvider;
        }

        public override string Key
        {
            get { return AdministrativeAlert.AlertId.ToString(); }
        }

        protected override AlertCheckResult ConditionMet()
        {
            CheckValue<T> valueToCheck = ValueProvider.GetValue(AdministrativeAlert.Portfolio.PortfolioId);
            T threshold = _thresholdSelector(AdministrativeAlert);
            Comparer<T> comparer = Comparer<T>.Default;
            SetLastAlertTrace(
                valueToCheck.ValueToCheck?.ToString(),
                AdministrativeAlert.TypeOfBoundary.ToString(),
                threshold.ToString());

            if (valueToCheck.ValueToCheck == null)
            {
                return new AlertCheckResult(false, valueToCheck.Displayable);
            }

            return new AlertCheckResult(
                BoundaryCheck.IsConditionMet(
                    comparer.Compare(valueToCheck.ValueToCheck, threshold),
                    AdministrativeAlert.TypeOfBoundary),
                valueToCheck.Displayable);
        }

    }
}