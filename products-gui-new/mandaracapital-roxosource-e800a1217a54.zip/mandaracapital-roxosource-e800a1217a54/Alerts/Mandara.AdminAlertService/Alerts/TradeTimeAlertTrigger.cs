﻿using System;
using Mandara.AdminAlertService.ValueProviders;
using Mandara.Entities;

namespace Mandara.AdminAlertService.Alerts
{
    internal class TradeTimeAlertTrigger : KeyValueAlertTrigger<TradeTimeKey, TimeSpan?>
    {
        public TradeTimeAlertTrigger(
            AdministrativeAlert alert,
            Func<AdministrativeAlert, TimeSpan?> thresholdSelector,
            IKeyValueProvider<TradeTimeKey, TimeSpan?> valueProvider,
            TradeTimeKey key) : base(alert, thresholdSelector, valueProvider, key, nameof(TradeTimeAlertTrigger))
        {
        }

        protected override AlertCheckResult ConditionMet()
        {
            if (AdministrativeAlert.TypeOfBoundary != AdministrativeAlert.BoundaryType.InRange)
            {
                return base.ConditionMet();
            }

            TimeSpan? tradeTime = GetValue();
            string timeForDisplay = GetDisplayValue(tradeTime);
            bool isInAlertRange = tradeTime.HasValue && AdministrativeAlert.TradeTimeRange.Contains(tradeTime.Value);

            return new AlertCheckResult(isInAlertRange, timeForDisplay);
        }

        public TradeTimeKey TradeTimeKey => KeyObject;
    }
}