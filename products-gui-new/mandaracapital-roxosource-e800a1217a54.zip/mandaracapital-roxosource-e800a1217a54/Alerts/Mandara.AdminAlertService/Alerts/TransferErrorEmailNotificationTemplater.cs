﻿using System;
using Mandara.Business.Bus.Messages.TransferErrors;

namespace Mandara.AdminAlertService.Alerts
{
    internal class TransferErrorEmailNotificationTemplater : EmailNotificationTemplater
    {
        public TransferErrorEmailNotificationTemplater(TradeTransferErrorDto transferError)
        {
            _parameters.Add("{error_details}", x =>
            {
                if (x.SerializedValue == null)
                    return string.Empty;

                return x.SerializedValue.Replace(Environment.NewLine, "<br />");
            });

            _parameters.Add("{error_details_raw}", x =>
            {
                if (transferError.ErrorMessage == null)
                    return string.Empty;

                return transferError.ErrorMessage.Replace(Environment.NewLine, "<br />");
            });

            _parameters.Add("{error_type}", x =>
            {
                return transferError.ErrorType.ToString();
            });

            _parameters.Add("{entity_type}", x =>
            {
                return transferError.EntityType.ToString();
            });
        }

        public override string ApplyTemplate(string template, AlertNotification notification)
        {
            template = base.ApplyTemplate(template, notification);

            if (string.IsNullOrEmpty(template))
                return null;

            return template.Replace(@"\r\n", "<br />");
        }
    } 
}