using System;
using Mandara.AdminAlertService.ValueProviders;
using Mandara.Business.Bus.Messages.TransferErrors;
using Mandara.Entities;

namespace Mandara.AdminAlertService.Alerts
{
    internal class AlertCheckResult
    {
        public bool IsConditionMet { get; }
        public string Value { get; }

        public AlertCheckResult(bool isCondMet, string val)
        {
            IsConditionMet = isCondMet;
            Value = val;
        }

        private const string DefaultValue = "NoValue";
        public static readonly AlertCheckResult Default = new AlertCheckResult(false, DefaultValue);

        public bool IsDefault() => !IsConditionMet && DefaultValue == Value;
    }

    /// <summary>
    /// Contains reference to the AdministrativeAlert as well as ValueRepository for alert conditions check. 
    /// </summary>
    internal class AlertTrigger
    {
        /// <summary>
        /// Creates an AlertTrigger from AdministrativeAlert and corresponding ValueProvider.
        /// </summary>
        /// <param name="alert">Administrative alert.</param>
        /// <param name="key">Value key</param>
        /// <param name="valueProviderRepository">Value providers repository.</param>
        /// <returns>Alert trigger.</returns>
        public static AlertTrigger Create(
            AdministrativeAlert alert,
            ValueProviderRepository valueProviderRepository,
            TradeTimeKey key = null,
            TradeTransferErrorDto transferError = null)
        {
            switch (alert.TypeOfAlert)
            {
                case AdministrativeAlert.AdmAlertType.NaN:
                {
                    throw new ArgumentException("Alert type is not a number.", nameof(alert));
                }

                case AdministrativeAlert.AdmAlertType.PnL:
                {
                    return CreateDecimalValueAlertTrigger(alert, valueProviderRepository.PnlValueProvider);
                }

                case AdministrativeAlert.AdmAlertType.VaR:
                {
                    return CreateDecimalValueAlertTrigger(alert, valueProviderRepository.VarValueProvider);
                }

                case AdministrativeAlert.AdmAlertType.Flat_Price_Position:
                {
                    return GetFlatPricePositionTrigger(alert, valueProviderRepository);
                }

                case AdministrativeAlert.AdmAlertType.Trade_Time:
                {
                    return new TradeTimeAlertTrigger(
                        alert,
                        alertConfig => alertConfig.TradeTime,
                        valueProviderRepository.TradeTimeKeyValueProvider,
                        key);
                }

                case AdministrativeAlert.AdmAlertType.Expiring_Products:
                {
                    return GetExpiringProductAlert(alert, valueProviderRepository);
                }

                case AdministrativeAlert.AdmAlertType.TransferServiceErrors:
                {
                    return new TransferErrorAlertTrigger(alert, transferError);
                }

                case AdministrativeAlert.AdmAlertType.TradeInPortfolio:
                {
                    return new TradeInBookAlertTrigger(alert, valueProviderRepository.TradeInPortfolioValueProvider);
                }

                default:
                {
                    throw new ArgumentOutOfRangeException($"Alert type {alert.AlertType} is not valid.");
                }
            }
        }

        private static SingleValueAlertTrigger<decimal?> CreateDecimalValueAlertTrigger(
            AdministrativeAlert alert,
            IValueProvider<decimal?> valueProvider)
        {
            return new SingleValueAlertTrigger<decimal?>(
                alert,
                a => a.ThresholdValue,
                valueProvider,
                alert.TypeOfAlert.ToString());
        }

        private static AlertTrigger GetFlatPricePositionTrigger(
            AdministrativeAlert alert,
            ValueProviderRepository valueProviderRepository)
        {
            FlatPriceValueKey productValueKey = FlatPriceValueKey.FromAlert(alert);

            return new FlatPricePositionAlertTrigger(
                alert,
                a => a.ThresholdValue,
                valueProviderRepository.FlatPriceKeyValueValueProvider,
                productValueKey);
        }

        private static AlertTrigger GetExpiringProductAlert(
            AdministrativeAlert alert,
            ValueProviderRepository valueProviderRepository)
        {
            return alert.ShouldStartNow()
                ? new ExpiringProductsAlertTrigger(alert, valueProviderRepository.ExpiringProductsValueProvider)
                : null;
        }

        /// <summary>
        /// Administrative alert.
        /// </summary>
        public AdministrativeAlert AdministrativeAlert { get; private set; }

        protected AlertTrigger(AdministrativeAlert administrativeAlert, string triggerName)
        {
            AdministrativeAlert = administrativeAlert;
            _triggerName = triggerName;
        }

        /// <summary>
        /// Whether or not the alert condition is met and should be handled.
        /// </summary>
        /// <returns></returns>
        public bool Triggered()
        {
            // check trigger condition only on level 0 or when it's acknowledged
            if (EscalationLevel == EscalationLevel.Level0 || IsAcknowledged)
            {
                ConditionChecked = ConditionMet();
                ActualValue = ConditionChecked.Value;
                return IsConditionMet;
            }

            // on any other level we didn't check trigger condition - it's already triggered
            return true;
        }

        protected virtual AlertCheckResult ConditionMet()
        {
            throw new NotImplementedException("Subclasses must implement this and not call the base class.");
        }

        private readonly string _triggerName;

        protected string GetLastAlertTrace()
        {
            return LastCheckTrace;
        }

        protected void SetLastAlertTrace(string value, string op, string threshold)
        {
            LastCheckTrace = $"Name {_triggerName} Value: {value} op {op} threshold {threshold}";
        }

        private const string DummyAcknowledge = "Dummy";
        private const string DummyDatum = "";

        public static readonly AlertTrigger Default = new AlertTrigger()
        {
            AcknowledgedBy = DummyAcknowledge,
            IsConditionMet = false,
            AcknowledgedIp = DummyDatum,
            ActualValue = DummyDatum,
            LastCheckTrace = DummyDatum,
            NumFiresAtLevel0 = int.MaxValue,
            SerializedValue = DummyDatum,
            LastTriggeredAt = DateTime.MaxValue,
            EscalatedAt = DateTime.MaxValue,
            EscalationLevel = EscalationLevel.Level0,
            IsAcknowledged = false,
            AdministrativeAlert = AdministrativeAlert.Default,
        };

        public bool IsDefault()
        {
            return DummyAcknowledge == AcknowledgedBy && !IsAcknowledged && AdministrativeAlert.IsDefault();
        }

        protected AlertTrigger() { }

        public AlertCheckResult ConditionChecked { get; set;} = AlertCheckResult.Default;

        public bool IsConditionMet
        {
            get => !ConditionChecked.IsDefault() && ConditionChecked.IsConditionMet;
            set =>
                ConditionChecked = new AlertCheckResult(
                    value,
                    ConditionChecked.IsDefault() ? String.Empty : ConditionChecked.Value);
        }

        /// <summary>
        /// Get/set last time trigger was escalated at.
        /// </summary>
        public DateTime? EscalatedAt { get; set; }

        /// <summary>
        /// Get/set trigger current escalation level.
        /// </summary>
        public EscalationLevel EscalationLevel { get; set; }

        /// <summary>
        /// Get/set trigger acknowledged state.
        /// </summary>
        public bool IsAcknowledged { get; set; }

        /// <summary>
        /// Get/set username who acknowledged this alert.
        /// </summary>
        public string AcknowledgedBy { get; set; }

        /// <summary>
        /// Get/set user ip address who acknowledged this alert.
        /// </summary>
        public string AcknowledgedIp { get; set; }

        /// <summary>
        /// Get/set trigger current value as string from the corresponding value provider.
        /// </summary>
        public string ActualValue { get; set; }

        /// <summary>
        /// Get/set trigger serialized full value as string from the corresponding value provider.
        /// </summary>
        public string SerializedValue { get; set; }

        /// <summary>
        /// Number of times the alert was triggered successively.
        /// </summary>
        public uint NumFiresAtLevel0 { get; set; }

        public void SetProperties(bool isConditionMet, EscalationLevel escalationLevel, bool isAcknowledged, string acknowledgedBy, uint numFires, DateTime? escalatedAt, DateTime? lastTriggeredAt, string actualValue = null, string serializedValue = null)
        {
            IsConditionMet = isConditionMet;
            EscalationLevel = escalationLevel;
            IsAcknowledged = isAcknowledged;
            AcknowledgedBy = acknowledgedBy;
            NumFiresAtLevel0 = numFires;
            EscalatedAt = escalatedAt;
            LastTriggeredAt = lastTriggeredAt;

            if (actualValue != null)
            {
                ActualValue = actualValue;
            }

            if (serializedValue != null)
            {
                SerializedValue = serializedValue;
            }
        }

        /// <summary>
        /// Get/set datetime when it was triggered last time.
        /// </summary>
        public DateTime? LastTriggeredAt { get; set; }

        public string Subject
        {
            get
            {
                if (AdministrativeAlert == null)
                {
                    return string.Empty;
                }

                switch (EscalationLevel)
                {
                    case EscalationLevel.Level1:
                        return AdministrativeAlert.Level1Subject;
                    case EscalationLevel.Level2:
                        return AdministrativeAlert.Level2Subject;
                    case EscalationLevel.Level3:
                        return AdministrativeAlert.Level3Subject;
                    case EscalationLevel.Level4:
                        return AdministrativeAlert.Level4Subject;
                }

                return string.Empty;
            }
        }

        public string Message
        {
            get
            {
                if (AdministrativeAlert == null)
                {
                    return string.Empty;
                }

                switch (EscalationLevel)
                {
                    case EscalationLevel.Level1:
                        return AdministrativeAlert.Level1Message;
                    case EscalationLevel.Level2:
                        return AdministrativeAlert.Level2Message;
                    case EscalationLevel.Level3:
                        return AdministrativeAlert.Level3Message;
                    case EscalationLevel.Level4:
                        return AdministrativeAlert.Level4Message;
                }

                return string.Empty;
            }
        }

        public virtual string Key { get; }
        public string LastCheckTrace { get; private set; }

        public virtual AlertNotification GetAlertNotification(EscalationLevel level, int historyReference)
        {
            return new AlertNotification(Key, AdministrativeAlert, level,
                AlertTriggerNotificationInfo.FromAlertTrigger(this), historyReference);
        }

        public EscalationLevel GetTopLevel()
        {
            if (!AdministrativeAlert.IsLevel1Active)
            {
                return EscalationLevel.Level0;
            }

            if (!AdministrativeAlert.IsLevel2Active)
            {
                return EscalationLevel.Level1;
            }

            if (!AdministrativeAlert.IsLevel3Active)
            {
                return EscalationLevel.Level2;
            }

            if (!AdministrativeAlert.IsLevel4Active)
            {
                return EscalationLevel.Level3;
            }

            return EscalationLevel.Level4;
        }

        public bool ShouldSkipAtWeekends()
        {
            DateTime now = DateTime.Now;

            bool isWeekend = now.DayOfWeek == DayOfWeek.Saturday || now.DayOfWeek == DayOfWeek.Sunday;

            if (AdministrativeAlert.DoNotTriggerOnWeekends && isWeekend)
            {
                return true;
            }

            return false;
        }
    }
}