using System;
using System.Collections.Generic;
using System.Linq;
using Mandara.AdminAlertService.ValueProviders;
using Mandara.Business.Bus.Messages.TransferErrors;
using Mandara.Business.Client.Managers;
using Mandara.Entities;

namespace Mandara.AdminAlertService.Alerts
{
    class TransferErrorsAlertsSource
    {
        private ValueProviderRepository _valueProviderRepository;

        public TransferErrorsAlertsSource(ValueProviderRepository valueProviderRepository)
        {
            if (valueProviderRepository == null)
                throw new ArgumentNullException("valueProviderRepository");

            _valueProviderRepository = valueProviderRepository;
        }

        public AlertTrigger[] CreateTriggers(AdministrativeAlert admAlert)
        {
            if (!FeatureManager.IsFeatureEnabled(FeatureManager.TransferErrorsAlerts))
                return null;

            string ids = admAlert[AdministrativeAlert.CustomProperty.TransferErrorsTypes];

            if (ids != null)
            {
                List<int> idsList = ids.Split(',').Select(x => Convert.ToInt32(x)).ToList();
                TradeTransferErrorDto[] tradeTransferErrorDtos = _valueProviderRepository.TransferErrorsValueProvider.GetValues(idsList);

                List<AlertTrigger> alertTriggers = new List<AlertTrigger>();
                foreach (TradeTransferErrorDto error in tradeTransferErrorDtos)
                {
                    AlertTrigger alertTrigger = AlertTrigger.Create(admAlert, _valueProviderRepository, transferError: error);

                    if (alertTrigger.Triggered())
                    {
                        alertTrigger.NumFiresAtLevel0 = 0;
                        alertTriggers.Add(alertTrigger);
                    }
                }

                return alertTriggers.ToArray();
            }

            return null;
        }
    }
}