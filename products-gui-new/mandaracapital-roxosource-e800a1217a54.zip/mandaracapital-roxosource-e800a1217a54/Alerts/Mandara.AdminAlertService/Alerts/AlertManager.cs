﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using Mandara.AdminAlertService.Alerts;
using Mandara.AdminAlertService.Bus;
using Mandara.AdminAlertService.Configuration;
using Mandara.AdminAlertService.ValueProviders;
using Mandara.Business.AdministrativeAlerts;
using Mandara.Business.AsyncServices.Base;
using Mandara.Business.Bus.Messages.AdmAlerts;
using Mandara.Business.Bus.Messages.Audit;
using Mandara.Business.PublishSubscribe;
using Mandara.Business.PublishSubscribe.Events.Alerts;
using Mandara.Entities;
using Mandara.Entities.ErrorReporting;
using Mandara.Extensions.Collections;
using Ninject.Extensions.Logging;
using Optional.Collections;

namespace Mandara.AdminAlertService
{
    /// <summary>
    /// An async service responsible for alerts management: escalation, conditions checks, triggering alerts notifications.
    /// </summary>
    internal class AlertManager : AsyncService
    {
        private readonly AdminAlertServiceContext _adminAlertServiceContext;
        private readonly AlertNotificationManager _alertNotificationManager;

        private readonly ConcurrentDictionary<string, AlertTrigger> _level0Alerts =
            new ConcurrentDictionary<string, AlertTrigger>();

        private readonly ConcurrentDictionary<string, AlertTrigger> _level1Alerts =
            new ConcurrentDictionary<string, AlertTrigger>();

        private readonly ConcurrentDictionary<string, AlertTrigger> _level2Alerts =
            new ConcurrentDictionary<string, AlertTrigger>();

        private readonly ConcurrentDictionary<string, AlertTrigger> _level3Alerts =
            new ConcurrentDictionary<string, AlertTrigger>();

        private readonly ConcurrentDictionary<string, AlertTrigger> _level4Alerts =
            new ConcurrentDictionary<string, AlertTrigger>();

        private List<ConcurrentDictionary<string, AlertTrigger>> _alertsByLevelCollection;
        private readonly Dictionary<EscalationLevel, ConcurrentDictionary<string, AlertTrigger>> AlertsByLevel =
            new Dictionary<EscalationLevel, ConcurrentDictionary<string, AlertTrigger>>();

        private ValueProviderRepository _valueProviderRepository;
        private TradeRepository _tradeRepository;
        private TradeTimeAlertsSource _tradeTimeAlertsSource;
        private TransferErrorsAlertsSource _transferErrorsAlertsSource;
        private TradeInBookAlertSource _tradeInBookAlertSource;

        private TimeSpan _updateTriggersFromDatabaseInterval;
        private DateTime _lastTriggersUpdatedAt = DateTime.Now;

        private int _triggersCheckingInterval;
        private DateTime _lastTriggersCheck = DateTime.MinValue;

        private TimeSpan _sleepOnErrorInterval;

        private int _failuresBeforeEscalationToLevel1;

        private IDisposable _acknowledgedEventHandler;
        private IDisposable _alertsSnapshotEventHandler;

        public AlertManager(
            AdminAlertServiceContext adminAlertServiceContext,
            AlertNotificationManager alertNotificationManager,
            ILogger log) : base(log)
        {
            _adminAlertServiceContext = adminAlertServiceContext
                                        ?? throw new ArgumentNullException(nameof(adminAlertServiceContext));
            _alertNotificationManager = alertNotificationManager
                                        ?? throw new ArgumentNullException(nameof(alertNotificationManager));

            CollectAlertLevelCollections();
            GetCheckConfig();
            InitialiseAlertsByLevel();
        }

        private void CollectAlertLevelCollections()
        {
            _alertsByLevelCollection = new List<ConcurrentDictionary<string, AlertTrigger>>()
            {
                _level0Alerts,
                _level1Alerts,
                _level2Alerts,
                _level3Alerts,
                _level4Alerts,
            };
        }

        private void GetCheckConfig()
        {
            AlertsCheck alertsCheckConfig = AlertsCheck.GetSection();

            _triggersCheckingInterval = alertsCheckConfig.TriggersCheck.Minutes;
            _updateTriggersFromDatabaseInterval = alertsCheckConfig.TriggersUpdate.Interval;
            _sleepOnErrorInterval = alertsCheckConfig.SleepOnError.Interval;
            _failuresBeforeEscalationToLevel1 = alertsCheckConfig.FailuresBeforeEscalation.Count;
        }

        private void InitialiseAlertsByLevel()
        {
            AlertsByLevel[EscalationLevel.Level0] = _level0Alerts;
            AlertsByLevel[EscalationLevel.Level1] = _level1Alerts;
            AlertsByLevel[EscalationLevel.Level2] = _level2Alerts;
            AlertsByLevel[EscalationLevel.Level3] = _level3Alerts;
            AlertsByLevel[EscalationLevel.Level4] = _level4Alerts;
        }

        private List<AdmAlertDto> GetUserAlerts(string username)
        {
            if (string.IsNullOrEmpty(username))
            {
                return null;
            }

            List<AlertTrigger> level1 = _level1Alerts.Values.ToList();
            List<AlertTrigger> level2 = _level2Alerts.Values.ToList();
            List<AlertTrigger> level3 = _level3Alerts.Values.ToList();
            List<AlertTrigger> level4 = _level4Alerts.Values.ToList();

            List<AdmAlertDto> alerts = level1
                                       .Where(
                                           a => !a.IsAcknowledged
                                                && a.AdministrativeAlert.AlertGroup1.Users.Any(
                                                    u => u.UserName.Equals(username))).Select(
                                           t => AdmAlertDto.Compose(
                                               t.Key,
                                               t.AdministrativeAlert.Level1Subject,
                                               t.AdministrativeAlert.Level1Message,
                                               t.ActualValue,
                                               t.SerializedValue,
                                               t.AdministrativeAlert)).ToList();

            alerts = alerts.Union(
                level2.Where(
                    a => !a.IsAcknowledged
                         && a.AdministrativeAlert.AlertGroup2.Users.Any(
                             u => u.UserName.Equals(username))).Select(
                    t => AdmAlertDto.Compose(
                        t.Key,
                        t.AdministrativeAlert.Level2Subject,
                        t.AdministrativeAlert.Level2Message,
                        t.ActualValue,
                        t.SerializedValue,
                        t.AdministrativeAlert))).ToList();

            alerts = alerts.Union(
                level3.Where(
                    a => !a.IsAcknowledged
                         && a.AdministrativeAlert.AlertGroup3.Users.Any(
                             u => u.UserName.Equals(username))).Select(
                    t => AdmAlertDto.Compose(
                        t.Key,
                        t.AdministrativeAlert.Level3Subject,
                        t.AdministrativeAlert.Level3Message,
                        t.ActualValue,
                        t.SerializedValue,
                        t.AdministrativeAlert))).ToList();

            alerts = alerts.Union(
                level4.Where(
                    a => !a.IsAcknowledged
                         && a.AdministrativeAlert.AlertGroup4.Users.Any(
                             u => u.UserName.Equals(username))).Select(
                    t => AdmAlertDto.Compose(
                        t.Key,
                        t.AdministrativeAlert.Level4Subject,
                        t.AdministrativeAlert.Level4Message,
                        t.ActualValue,
                        t.SerializedValue,
                        t.AdministrativeAlert))).ToList();

            return alerts;
        }

        private void AcknowledgeAlert(string triggerKey, string userName, string userIp)
        {
            AlertTrigger alertToAcknowledge = TryGetTrigger(triggerKey);

            if (!alertToAcknowledge.IsDefault())
            {
                MarkAlertAsAcknowledged(triggerKey, userName, userIp, alertToAcknowledge);
            }
        }

        private AlertTrigger TryGetTrigger(string triggerKey)
        {
            AlertTrigger trigger = null;

            _alertsByLevelCollection.FirstOrNone(alerts => alerts.TryGetValue(triggerKey, out trigger));
            return trigger ?? AlertTrigger.Default;
        }

        private void MarkAlertAsAcknowledged(string triggerKey, string userName, string userIp, AlertTrigger trigger)
        {
            trigger.IsAcknowledged = true;
            trigger.AcknowledgedBy = userName;
            trigger.AcknowledgedIp = userIp;

            AdmAlertHelper.DeactivateHistoryEntry(trigger.Key, trigger.AcknowledgedBy, trigger.AcknowledgedIp);

            BroadcastAcknowledgement(triggerKey);
            LogAcknowledgement(userName, trigger);
        }

        private void BroadcastAcknowledgement(string triggerKey)
        {
            AlertsInformaticaHelper.GetAllServerAwareTopicNames(AlertsInformaticaHelper.AdmAlertAcknowledgeDoneTopic).ForEach(
                serverTopicName => _adminAlertServiceContext.BusClient.SendMessage(
                    serverTopicName,
                    new AcknowledgeDoneMessage
                    {
                        TriggerKey = triggerKey
                    }));
        }

        private void LogAcknowledgement(string userName, AlertTrigger trigger)
        {
            WriteAuditRequestMessage auditMessage = new WriteAuditRequestMessage
            {
                ContextName = "AcknowledgeAlert",
                MessageType = "Alert Acknowledged",
                ObjectDescription = string.Format(
                    "Alert [{0}], id [{1}] is acknowledged",
                    trigger.AdministrativeAlert.Title,
                    trigger.AdministrativeAlert.AlertId),
                Source = "Alerts service",
                UserName = userName
            };

            _adminAlertServiceContext.BusClient.WriteAudit(auditMessage, message => { }, info => { });
        }

        protected override void OnStarted()
        {
            base.OnStarted();

            _tradeRepository = new TradeRepository(_adminAlertServiceContext.BusClient);
            _valueProviderRepository = new ValueProviderRepository(
                _adminAlertServiceContext.BusClient,
                _tradeRepository);

            _tradeTimeAlertsSource = new TradeTimeAlertsSource(_valueProviderRepository);
            _transferErrorsAlertsSource = new TransferErrorsAlertsSource(_valueProviderRepository);
            _tradeInBookAlertSource = new TradeInBookAlertSource(_valueProviderRepository);

            _alertNotificationManager.Start();

            _acknowledgedEventHandler = PubSub.Listen<AcknowledgeAlertRequestMessage>().Subscribe(
                message => AcknowledgeAlert(message.TriggerKey, message.UserName, message.UserIp));

            _alertsSnapshotEventHandler = PubSub.Listen<AlertsSnapshotEvent<List<AdmAlertDto>>>().Subscribe(
                e =>
                {
                    List<AdmAlertDto> userAlerts = GetUserAlerts(e.Username);

                    e.Callback(userAlerts);
                });

            ClearAdmAlertsOnAllLevels();
            UpdateAdmAlerts();

            ApplyHistoryEntries();
        }

        private void ApplyHistoryEntries()
        {
            foreach (AlertHistory entry in AdmAlertHelper.GetActiveHistoryEntries())
            {
                if (_level0Alerts.TryGetValue(entry.TriggerKey, out AlertTrigger trigger))
                {
                    trigger.IsConditionMet = true;
                    trigger.ActualValue = entry.ActualValue;
                    trigger.SerializedValue = entry.SerializedValue;

                    if (entry.Level > 0)
                    {
                        AlertsByLevel[EscalationLevel.Level0].TryRemove(trigger.Key, out AlertTrigger t);
                        MoveUpToLevel((EscalationLevel)entry.Level, trigger, false, true, entry.AlertHistoryId);
                    }

                    trigger.IsAcknowledged = !string.IsNullOrEmpty(entry.AcknowledgedBy);
                    trigger.AcknowledgedBy = entry.AcknowledgedBy;
                    trigger.AcknowledgedIp = entry.AcknowledgedIp;
                }
            }

            Dictionary<string, object> handledTriggerKeys = new Dictionary<string, object>();

            foreach (AlertHistory entry in AdmAlertHelper.GetTodayTradeTimeHistoryEntries())
            {
                if (handledTriggerKeys.ContainsKey(entry.TriggerKey))
                {
                    continue;
                }

                handledTriggerKeys.Add(entry.TriggerKey, null);

                if (_level0Alerts.TryGetValue(entry.TriggerKey, out AlertTrigger trigger))
                {
                    trigger.ActualValue = entry.ActualValue;

                    if (entry.Level > 0)
                    {
                        AlertsByLevel[EscalationLevel.Level0].TryRemove(trigger.Key, out AlertTrigger t);
                        MoveUpToLevel((EscalationLevel)entry.Level, trigger, false, false);
                    }

                    trigger.IsAcknowledged = !string.IsNullOrEmpty(entry.AcknowledgedBy);
                    trigger.AcknowledgedBy = entry.AcknowledgedBy;
                    trigger.AcknowledgedIp = entry.AcknowledgedIp;
                }
            }
        }

        private void ClearAdmAlertsOnAllLevels()
        {
            _level0Alerts.Clear();
            _level1Alerts.Clear();
            _level2Alerts.Clear();
            _level3Alerts.Clear();
            _level4Alerts.Clear();
        }

        protected override void OnStopped()
        {
            base.OnStopped();

            _alertNotificationManager?.Stop();
            _acknowledgedEventHandler?.Dispose();
            _acknowledgedEventHandler = null;
            _alertsSnapshotEventHandler?.Dispose();
            _alertsSnapshotEventHandler = null;
            _valueProviderRepository?.Dispose();
            _valueProviderRepository = null;
        }

        private static AlertHistory BuildAlertHistory(AlertTrigger trigger)
        {
            AlertHistory entry = new AlertHistory
            {
                IsActive = true,
                AcknowledgedBy = trigger.AcknowledgedBy,
                AcknowledgedIp = trigger.AcknowledgedIp,
                TriggerKey = trigger.Key,
                AlertId = trigger.AdministrativeAlert.AlertId,
                Level = (int)trigger.EscalationLevel,
                Subject = trigger.Subject,
                Message = trigger.Message,
                AlertType = trigger.AdministrativeAlert.TypeAlertString,
                BookName = trigger.AdministrativeAlert.Portfolio.Name,
                ThresholdValue = trigger.AdministrativeAlert.ThresholdValueString,
                ActualValue = trigger.ActualValue,
                SerializedValue = trigger.SerializedValue,
                TriggeredAt = trigger.LastTriggeredAt == null ? DateTime.MinValue : trigger.LastTriggeredAt.Value
            };
            return entry;
        }

        protected override void DoWork()
        {
            try
            {
                _log.Trace("Alert manager main loop");
                if (DateTime.Now - _lastTriggersUpdatedAt > _updateTriggersFromDatabaseInterval)
                {
                    _lastTriggersUpdatedAt = DateTime.Now;

                    UpdateAdmAlerts();
                }

                if ((DateTime.Now - _lastTriggersCheck).TotalMinutes > _triggersCheckingInterval)
                {
                    _log.Info("Alert manager checking for alerts");
                    HandleLevel0();
                    _lastTriggersCheck = DateTime.Now;
                }

                HandleLevel(EscalationLevel.Level1);
                HandleLevel(EscalationLevel.Level2);
                HandleLevel(EscalationLevel.Level3);
                HandleLevel(EscalationLevel.Level4);
            }
            catch (Exception ex)
            {
                ErrorReportingHelper.ReportError(
                    "Alerts Service",
                    ErrorType.Exception,
                    "AlertManager encounter an error during initialization. Alert Service will be paused for a while.",
                    null,
                    ex,
                    ErrorLevel.Critical);

                // on error we suspend service execution
                Thread.Sleep(_sleepOnErrorInterval);
            }
        }

        private void UpdateAdmAlerts()
        {
            Dictionary<string, AlertTrigger> newTriggers = new Dictionary<string, AlertTrigger>();

            foreach (AdministrativeAlert a in AdmAlertHelper.GetActiveAlerts())
            {
                List<AlertTrigger> triggers = CreateTriggersForAdmAlert(a);

                triggers.ForEach(
                    t =>
                    {
                        if (!newTriggers.ContainsKey(t.Key))
                        {
                            newTriggers.Add(t.Key, t);
                        }
                    });
            }

            UpdateTriggersOnLevel(newTriggers, _level4Alerts);
            UpdateTriggersOnLevel(newTriggers, _level3Alerts);
            UpdateTriggersOnLevel(newTriggers, _level2Alerts);
            UpdateTriggersOnLevel(newTriggers, _level1Alerts);
            UpdateTriggersOnLevel(newTriggers, _level0Alerts);

            foreach (AlertTrigger trigger in newTriggers.Values.ToList())
            {
                _level0Alerts.TryAdd(trigger.Key, trigger);
            }
        }

        private void UpdateTriggersOnLevel(
            Dictionary<string, AlertTrigger> newTriggers,
            ConcurrentDictionary<string, AlertTrigger> triggersOnLevel)
        {
            foreach (string key in triggersOnLevel.Keys.ToList())
            {
                triggersOnLevel.TryRemove(key, out AlertTrigger oldTrigger);

                if (oldTrigger.GetType() == typeof(TransferErrorAlertTrigger))
                {
                    triggersOnLevel.TryAdd(key, oldTrigger);
                }

                if (newTriggers.ContainsKey(key))
                {
                    AlertTrigger newTrigger = newTriggers[key];

                    newTrigger.SetProperties(
                        oldTrigger.IsConditionMet,
                        oldTrigger.EscalationLevel,
                        oldTrigger.IsAcknowledged,
                        oldTrigger.AcknowledgedBy,
                        oldTrigger.NumFiresAtLevel0,
                        oldTrigger.EscalatedAt,
                        oldTrigger.LastTriggeredAt,
                        oldTrigger.ActualValue,
                        oldTrigger.SerializedValue);

                    triggersOnLevel.TryAdd(key, newTrigger);
                    newTriggers.Remove(key);
                }
            }
        }

        private List<AlertTrigger> CreateTriggersForAdmAlert(AdministrativeAlert alertConfig)
        {
            List<AlertTrigger> triggers = new List<AlertTrigger>();

            switch (alertConfig.TypeOfAlert)
            {
                case AdministrativeAlert.AdmAlertType.Trade_Time:
                    AlertTrigger[] alertTriggers = _tradeTimeAlertsSource.CreateTriggers(alertConfig);

                    if (alertTriggers != null)
                    {
                        triggers.AddRange(alertTriggers);
                    }

                    break;

                case AdministrativeAlert.AdmAlertType.TransferServiceErrors:
                    AlertTrigger[] transferErrorsTriggers = _transferErrorsAlertsSource.CreateTriggers(alertConfig);

                    if (transferErrorsTriggers != null)
                    {
                        triggers.AddRange(transferErrorsTriggers);
                    }

                    break;

                case AdministrativeAlert.AdmAlertType.TradeInPortfolio:
                    AlertTrigger[] tradeInTriggers = _tradeInBookAlertSource.CreateTriggers(alertConfig);

                    if (tradeInTriggers != null)
                    {
                        triggers.AddRange(tradeInTriggers);
                    }

                    break;

                default:
                    triggers.Add(AlertTrigger.Create(alertConfig, _valueProviderRepository));
                    break;
            }

            return triggers.Where(t => t != null).ToList();
        }

        private void HandleLevel0()
        {
            foreach (AlertTrigger trigger in AlertsByLevel[EscalationLevel.Level0].Values.ToList())
            {
                trigger.EscalationLevel = EscalationLevel.Level0;
                ProcessEscalation(trigger, MoveUpToLevel1, t => { });
            }
        }

        private void ProcessEscalation(
            AlertTrigger trigger,
            Action<AlertTrigger, bool, bool> escalationAction,
            Action<AlertTrigger> deescalationAction)
        {
            if (trigger.ShouldSkipAtWeekends())
            {
                return;
            }

            bool isTriggered = trigger.Triggered();
            bool isAcknowledged = trigger.IsAcknowledged;
            _log.Trace("Check trigger result {0}, trace {1}", isTriggered, trigger.LastCheckTrace);
            switch (trigger.EscalationLevel)
            {
                case EscalationLevel.Level0:
                    if (isTriggered)
                    {
                        trigger.NumFiresAtLevel0++;

                        if (trigger.NumFiresAtLevel0
                            >= (trigger.AdministrativeAlert.ConditionCheckCount ?? _failuresBeforeEscalationToLevel1))
                        {
                            escalationAction(trigger, true, true);
                            trigger.EscalatedAt = null;
                        }
                    }
                    else
                    {
                        // if trigger condition wasn't met (and trigger was at 0 level) we start a new count
                        trigger.NumFiresAtLevel0 = 0;
                    }

                    break;

                case EscalationLevel.Level1:
                case EscalationLevel.Level2:
                case EscalationLevel.Level3:
                case EscalationLevel.Level4:
                    if (isAcknowledged && !isTriggered)
                    {
                        trigger.EscalatedAt = null;
                        deescalationAction(trigger);
                    }

                    if (isAcknowledged)
                    {
                        return;
                    }

                    if (trigger.EscalatedAt == null)
                    {
                        trigger.EscalatedAt = DateTime.Now;
                    }

                    if (DateTime.Now - trigger.EscalatedAt > GetEscalationTime(trigger))
                    {
                        escalationAction(trigger, true, true);
                        trigger.EscalatedAt = null;
                    }

                    break;
            }
        }

        private TimeSpan GetEscalationTime(AlertTrigger trigger)
        {
            switch (trigger.EscalationLevel)
            {
                case EscalationLevel.Level0:
                    throw new InvalidOperationException("There are no escalation time for level 0");
                case EscalationLevel.Level1:
                    return trigger.AdministrativeAlert.Level1Escalation ?? trigger.AdministrativeAlert.Escalation;
                case EscalationLevel.Level2:
                    return trigger.AdministrativeAlert.Level2Escalation ?? trigger.AdministrativeAlert.Escalation;
                case EscalationLevel.Level3:
                    return trigger.AdministrativeAlert.Level3Escalation ?? trigger.AdministrativeAlert.Escalation;
                case EscalationLevel.Level4:
                    return trigger.AdministrativeAlert.Level4Escalation ?? trigger.AdministrativeAlert.Escalation;
                default:
                    throw new ArgumentOutOfRangeException("level");
            }
        }

        private void MoveUpToLevel1(AlertTrigger trigger, bool writeHistory, bool sendNotification)
        {
            MoveUpToLevel(EscalationLevel.Level1, trigger, writeHistory, sendNotification);
        }

        private void NotifyAlertTriggered(AlertTrigger trigger, EscalationLevel level, int historyReference)
        {
            if (historyReference == 0)
            {
                historyReference = AdmAlertHelper.IdentifyHistory(trigger.Key, (int)trigger.EscalationLevel);
            }

            trigger.LastTriggeredAt = DateTime.Now;
            _alertNotificationManager.AddAlertNotification(trigger.GetAlertNotification(level, historyReference));
        }

        private void HandleLevel(EscalationLevel level)
        {
            foreach (AlertTrigger trigger in AlertsByLevel[level].Values.ToList())
            {
                ProcessEscalation(
                    trigger,
                    level != trigger.GetTopLevel()
                        ? ((t, w, s) => MoveUpToLevel(level + 1, t, w, s))
                        : (Action<AlertTrigger, bool, bool>)((t, w, s) => NotifyAlertTriggered(t, level, 0)),
                    t => MoveDownToLevel0(level, t));
            }
        }

        private void MoveUpToLevel(
            EscalationLevel toLevel,
            AlertTrigger trigger,
            bool writeHistory,
            bool sendNotification,
            int refHistory = 0)
        {
            trigger.SetProperties(true, toLevel, false, string.Empty, 0, null, DateTime.Now);
            EscalationLevel fromLevel = toLevel - 1;

            AlertsByLevel[fromLevel].TryRemove(trigger.Key, out AlertTrigger t);
            AlertsByLevel[toLevel].TryAdd(trigger.Key, trigger);
            int historyReference = refHistory;
            if (writeHistory)
            {
                AdmAlertHelper.UpdateHistoryEntry(BuildAlertHistory(trigger), out historyReference);
            }

            if (sendNotification)
            {
                NotifyAlertTriggered(trigger, toLevel, historyReference);
            }
        }

        private void MoveDownToLevel0(EscalationLevel levelFrom, AlertTrigger trigger)
        {
            trigger.SetProperties(false, EscalationLevel.Level0, false, string.Empty, 0, null, null);

            AlertTrigger _;
            AlertsByLevel[levelFrom].TryRemove(trigger.Key, out _);
            AlertsByLevel[EscalationLevel.Level0].TryAdd(trigger.Key, trigger);

            AdmAlertHelper.DeactivateHistoryEntry(trigger.Key, trigger.AcknowledgedBy, trigger.AcknowledgedIp);
        }
    }

    internal enum EscalationLevel
    {
        Level0 = 0,
        Level1 = 1,
        Level2 = 2,
        Level3 = 3,
        Level4 = 4
    }
}