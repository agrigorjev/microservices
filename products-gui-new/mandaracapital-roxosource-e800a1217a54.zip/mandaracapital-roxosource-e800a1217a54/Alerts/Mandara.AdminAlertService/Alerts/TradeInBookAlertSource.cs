﻿using Mandara.AdminAlertService.ValueProviders;
using Mandara.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mandara.AdminAlertService.Alerts
{
    class TradeInBookAlertSource
    {
        private readonly ValueProviderRepository _valueProviderRepository;

        public TradeInBookAlertSource(ValueProviderRepository valueProviderRepository)
        {
            if (valueProviderRepository == null)
                throw new ArgumentNullException("valueProviderRepository");

            _valueProviderRepository = valueProviderRepository;
        }

        public AlertTrigger[] CreateTriggers(AdministrativeAlert admAlert)
        {
            if (admAlert == null || admAlert.Portfolio == null)
                return null;

            int portfolioId = admAlert.Portfolio.PortfolioId;

            LiveTrade[] liveTrades =
                _valueProviderRepository.TradeInPortfolioValueProvider.GetValues(portfolioId);

            List<AlertTrigger> alertTriggers = new List<AlertTrigger>();
            foreach (LiveTrade value in liveTrades)
            {
                AlertTrigger alertTrigger = AlertTrigger.Create(admAlert, _valueProviderRepository,
                    new TradeTimeKey(portfolioId, value));

                if (alertTrigger.Triggered())
                {
                    alertTrigger.NumFiresAtLevel0 = 0;
                    alertTriggers.Add(alertTrigger);
                }
            }

            return alertTriggers.ToArray();
        }
    }
}
