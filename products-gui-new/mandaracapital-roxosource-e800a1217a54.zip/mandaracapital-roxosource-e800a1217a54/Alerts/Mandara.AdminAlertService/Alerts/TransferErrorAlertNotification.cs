﻿using Mandara.Business.Bus.Messages.TransferErrors;
using Mandara.Entities;

namespace Mandara.AdminAlertService.Alerts
{
    class TransferErrorAlertNotification : AlertNotification
    {
        public TransferErrorAlertNotification(TradeTransferErrorDto transferError, string triggerKey, AdministrativeAlert administrativeAlert, EscalationLevel escalationLevel, AlertTriggerNotificationInfo notificationInfo, int historyId = 0)
            : base(triggerKey, administrativeAlert, escalationLevel, notificationInfo, historyId)
        {
            _emailTemplater = new TransferErrorEmailNotificationTemplater(transferError);
        }
    }
}