﻿using Mandara.AdminAlertService.ValueProviders;
using Mandara.Entities;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Mandara.AdminAlertService.Alerts
{
    class TradeInBookAlertTrigger : AlertTrigger
    {
        private IMultiValueProvider<LiveTrade> _trades;

        public TradeInBookAlertTrigger(
            AdministrativeAlert admAlert,
            IMultiValueProvider<LiveTrade> tradesProvider)
            : base(admAlert,nameof(TradeInBookAlertTrigger))
        {
            _trades = tradesProvider;
        }

        public override string Key => AdministrativeAlert.PortfolioId.ToString();

        protected override AlertCheckResult ConditionMet()
        {
            return new AlertCheckResult(
                _trades.GetValues(AdministrativeAlert.PortfolioId.GetValueOrDefault()).Any(),
                "Trade in alert trigger.");
        }
    }
}
