using Mandara.Business.Bus.Messages.TransferErrors;
using Mandara.Entities;

namespace Mandara.AdminAlertService.Alerts
{
    class TransferErrorAlertTrigger : AlertTrigger
    {
        private readonly AdministrativeAlert _alert;
        private readonly TradeTransferErrorDto _transferError;

        public TransferErrorAlertTrigger(AdministrativeAlert alert, TradeTransferErrorDto transferError) : base(
            alert,
            nameof(TransferErrorAlertTrigger))
        {
            _alert = alert;
            _transferError = transferError;
        }

        protected override AlertCheckResult ConditionMet()
        {
            SerializedValue = _transferError.Details;

            return new AlertCheckResult(true, $"{_transferError.ErrorMessage} Entity Id: [{_transferError.EntityId}]");
        }

        public override string Key => $"{_transferError.EntityId}_{(int)_transferError.ErrorType}";

        public override AlertNotification GetAlertNotification(EscalationLevel level, int historyReference)
        {
            return new TransferErrorAlertNotification(
                _transferError,
                Key,
                AdministrativeAlert,
                level,
                AlertTriggerNotificationInfo.FromAlertTrigger(this),
                historyReference);
        }
    }
}