using System;
using System.Collections.Generic;
using Mandara.AdminAlertService.ValueProviders;
using Mandara.Entities;

namespace Mandara.AdminAlertService.Alerts
{
    internal class KeyValueAlertTrigger<TValueKey, TValue> : AlertTrigger where TValueKey : ValueKey<TValue>
    {
        private readonly Func<AdministrativeAlert, TValue> _thresholdSelector;
        private readonly IKeyValueProvider<TValueKey, TValue> _valueProvider;
        private readonly TValueKey _valueKey;

        public KeyValueAlertTrigger(
            AdministrativeAlert alert,
            Func<AdministrativeAlert, TValue> thresholdSelector,
            IKeyValueProvider<TValueKey, TValue> valueProvider,
            TValueKey valueKey,
            string triggerName)
            : base(alert, triggerName)
        {
            _thresholdSelector = thresholdSelector;
            _valueProvider = valueProvider;
            _valueKey = valueKey;
        }

        public override string Key => $"{AdministrativeAlert.AlertId}_{_valueKey}";

        protected TValueKey KeyObject => _valueKey;

        protected override AlertCheckResult ConditionMet()
        {
            TValue valueToCheck = GetValue();
            string displayValue = GetDisplayValue(valueToCheck);

            if (valueToCheck == null)
            {
                return new AlertCheckResult(false, displayValue);
            }

            TValue threshold = _thresholdSelector(AdministrativeAlert);
            Comparer<TValue> comparer = Comparer<TValue>.Default;

            SetLastAlertTrace(
                valueToCheck.ToString(),
                AdministrativeAlert.TypeOfBoundary.ToString(),
                threshold.ToString());
            return new AlertCheckResult(
                BoundaryCheck.IsConditionMet(
                    comparer.Compare(valueToCheck, threshold),
                    AdministrativeAlert.TypeOfBoundary),
                displayValue);
        }

        protected TValue GetValue()
        {
            return _valueProvider.GetValue(_valueKey);
        }

        protected string GetDisplayValue(TValue value)
        {
            return value == null ? "" : _valueKey.GetDisplayValue(value);
        }
    }
}