namespace Mandara.AdminAlertService.Alerts
{
    class AlertTriggerNotificationInfo
    {
        public static AlertTriggerNotificationInfo FromAlertTrigger(AlertTrigger trigger)
        {
            var info = new AlertTriggerNotificationInfo
            {
                ActualValue = trigger.ActualValue,
                SerializedValue = trigger.SerializedValue,
            };

            if (trigger is TradeTimeAlertTrigger)
            {
                var tradeTimeTrigger = trigger as TradeTimeAlertTrigger;
                info.TradeId = tradeTimeTrigger.TradeTimeKey.TradeId.ToString();
                info.Product = tradeTimeTrigger.TradeTimeKey.StripName + " " + tradeTimeTrigger.TradeTimeKey.ProductDescription;
                info.Trader = tradeTimeTrigger.TradeTimeKey.Trader;
            }

            return info;
        }

        public string ActualValue { get; private set; }
        public string SerializedValue { get; private set; }
        public string TradeId { get; private set; }
        public string Product { get; private set; }
        public string Trader { get; private set; }
    }
}