﻿namespace Mandara.AdminAlertService.PubSubEvents
{
    public class StopServiceEvent
    {
        public bool IsAbnormalStop { get; }

        public StopServiceEvent(bool isStopAbnormal)
        {
            IsAbnormalStop = isStopAbnormal;
        }
    }
}