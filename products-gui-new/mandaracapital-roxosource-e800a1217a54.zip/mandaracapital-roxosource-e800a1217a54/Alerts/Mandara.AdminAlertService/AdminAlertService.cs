﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Reactive.Linq;
using System.Threading;
using com.latencybusters.lbm;
using Mandara.AdminAlertService.Alerts;
using Mandara.AdminAlertService.Bus;
using Mandara.AdminAlertService.MailboxParser;
using Mandara.AdminAlertService.Messaging;
using Mandara.AdminAlertService.Messaging.Configuration;
using Mandara.AdminAlertService.PubSubEvents;
using Mandara.Bus.Common.Server;
using Mandara.Bus.Common.Server.AsyncServices;
using Mandara.Business;
using Mandara.Business.AsyncServices.Base;
using Mandara.Business.Bus;
using Mandara.Business.Bus.Handlers.Base;
using Mandara.Business.Config.Client;
using Mandara.Business.PublishSubscribe;
using Ninject.Extensions.Logging;
using Topshelf;

namespace Mandara.AdminAlertService
{
    /// <summary>
    /// Administrative alerts service host.
    /// </summary>
    public partial class AdminAlertService : ServerBase
    {
        private List<string> _serverPrefixes;
        private BusClient _busClient;
        private AlertManager _alertManager;
        private MailAcknowledgeService _mailAcknowledgeService;
        private IDisposable _stopEvent;
        private HostControl _serviceHost;

        private static AdminAlertService _instance;
        public static AdminAlertService Instance => _instance;

        public AdminAlertService(ILogger log, HostControl svcHost)
            : base(log)
        {
            _serviceHost = svcHost;
            _instance = this;
            _serverPrefixes = GetServerPrefixes();
            PrepareBusClient();

            _stopEvent = PubSub.Listen<StopServiceEvent>().ObserveOn(SynchronizationContext.Current)
                               .Subscribe<StopServiceEvent>(Stop);
        }

        private List<string> GetServerPrefixes()
        {
            ServersConfigurationSection serversSection =
                ConfigurationManager.GetSection("ServersSection") as ServersConfigurationSection;
            string defaultPrefix = serversSection.DefaultPrefix;

            return serversSection.Servers.Where(prefixConfig => defaultPrefix != prefixConfig.Prefix)
                                 .Aggregate(
                                     new List<string>() { defaultPrefix },
                                     (prefixes, prefixConfig) =>
                                     {
                                         prefixes.Add(prefixConfig.Prefix);
                                         return prefixes;
                                     });
        }

        private void PrepareBusClient()
        {
            _busClient = IoC.Get<BusClient>();
            _busClient.TurnOnErrorsReceiver = false;
            _busClient.TurnOnMatchingDummies = false;
            Business.Bus.InformaticaHelper.ServerPrefixes = _serverPrefixes.ToArray();

            _busClient.Start();
            _busClient.SequenceReset -= BusClientOnSequenceReset;
            _busClient.SequenceReset += BusClientOnSequenceReset;
        }

        private void BusClientOnSequenceReset(object sender, EventArgs eventArgs)
        {
            if (_alertManager == null)
            {
                return;
            }

            _alertManager.Stop();

            while (_alertManager.IsRunning)
            {
                Thread.Sleep(200);
            }

            InformaticaHelper.CloseSources();
            InformaticaHelper.CreateReceivers();
            InformaticaHelper.CreateSources();

            _busClient.InformaticaHelper.CreateSources();

            _alertManager.Start();
        }

        protected override AsyncService[] CreateAsyncServices()
        {
            try
            {
                if (_alertManager == null)
                {
                    _alertManager = CreateAlertManager();
                }

                if (_mailAcknowledgeService == null)
                {
                    _mailAcknowledgeService = new MailAcknowledgeService(_logger);
                }

                LogErrorsService logErrorsService = new LogErrorsService(_logger);

                return
                    base.CreateAsyncServices()
                        .Concat(new AsyncService[] { _alertManager, logErrorsService })
                        .ToArray();

            }
            catch (Exception whatException)
            {
                _logger.Error(whatException, "Exiting.");
                _serviceHost.Stop(TopshelfExitCode.AbnormalExit);
                return new AsyncService[] { };
            }
        }

        private AlertManager CreateAlertManager()
        {
            while (!_busClient.PositionsReceived)
            {
                Thread.Sleep(200);
            }

            AdminAlertServiceContext context = new AdminAlertServiceContext { BusClient = _busClient };
            EmailSender emailSender = new EmailSender();
            ISmsSender smsSender = Sms.GetSection().Method == Sms.MethodHoiio
                ? new HoiioSmsSender()
                : (ISmsSender)new BulksmsSmsSender();

            return new AlertManager(
                context,
                new AlertNotificationManager(new MessagingService(CommandManager, emailSender, smsSender), _logger),
                _logger);
        }

        protected override string ServerName => "Admin Alert Service";

        private void Stop(StopServiceEvent reasonForStop)
        {
            Stop();

            if (reasonForStop.IsAbnormalStop)
            {
                _serviceHost.Stop(reasonForStop.IsAbnormalStop ? TopshelfExitCode.AbnormalExit : TopshelfExitCode.Ok);
            }
        }

        public override void Stop()
        {
            if (_busClient != null)
            {
                _busClient.SequenceReset -= BusClientOnSequenceReset;
                _busClient.Stop();
            }

            _stopEvent?.Dispose();
            base.Stop();
        }

        protected override ServerInformaticaHelperBase CreateInformaticaHelper(
            LBMContext lbmContext,
            HandlerManager handlerManager)
        {
            return new AlertsInformaticaHelper(lbmContext, handlerManager);
        }
    }
}
