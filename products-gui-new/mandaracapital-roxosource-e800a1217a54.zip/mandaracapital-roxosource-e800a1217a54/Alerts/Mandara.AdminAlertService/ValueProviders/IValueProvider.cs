﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mandara.AdminAlertService.ValueProviders
{
    public class CheckValue<T>
    {
        public T ValueToCheck { get; }
        public string Displayable { get; }

        public CheckValue(T valToCheck, string displayable)
        {
            ValueToCheck = valToCheck;
            Displayable = displayable;
        }
    }

    interface IValueProvider<T> : IDisposable
    {
        CheckValue<T> GetValue(int portfolioId);
    }
}
