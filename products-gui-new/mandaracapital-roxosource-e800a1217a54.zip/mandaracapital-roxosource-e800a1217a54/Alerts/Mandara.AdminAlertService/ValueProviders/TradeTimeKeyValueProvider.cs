﻿using System;

namespace Mandara.AdminAlertService.ValueProviders
{
    internal class TradeTimeKeyValueProvider : IKeyValueProvider<TradeTimeKey, TimeSpan?>
    {
        private readonly TradeRepository _tradeRepository;
        private static readonly TimeSpan _offsetToEnsureTradeInCurrentDay = TimeSpan.FromSeconds(1);

        private static readonly TimeSpan _startOfDay =
            Configuration.ValueProviders.GetSection().StartOfDay.Time.Add(_offsetToEnsureTradeInCurrentDay);

        public TradeTimeKeyValueProvider(TradeRepository tradeRepository)
        {
            _tradeRepository = tradeRepository ?? throw new ArgumentNullException(nameof(tradeRepository));
        }

        public TimeSpan? GetValue(TradeTimeKey key)
        {
            LiveTrade trade = _tradeRepository.GetTrade(key.TradeId);

            if (trade.IsDefault())
            {
                return trade.LocalTransactTime.TimeOfDay;
            }

            return !IsTasTradeOnSunday(trade)
                ? trade.LocalTransactTime.TimeOfDay
                : trade.TradeDate.TimeOfDay.Add(_startOfDay);
        }

        private bool IsTasTradeOnSunday(LiveTrade trade)
        {
            return trade.IsTas && (IsOnSundayAfter2300() || IsOnMondayBeforeStartOfDay());

            bool IsOnSundayAfter2300()
            {
                return trade.TransactTime.TimeOfDay > TimeSpan.FromHours(23)
                       && DayOfWeek.Monday == trade.TradeDate.DayOfWeek;
            }

            bool IsOnMondayBeforeStartOfDay()
            {
                return trade.TransactTime.TimeOfDay <= _startOfDay
                       && DayOfWeek.Monday == trade.LocalTransactTime.DayOfWeek;
            }
        }
    }
}
