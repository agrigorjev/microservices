﻿using System;

namespace Mandara.AdminAlertService.ValueProviders
{
    abstract class NullableDecimalProvider : IValueProvider<decimal?>
    {
        public virtual CheckValue<decimal?> GetValue(int portfolioId)
        {
            decimal? portfolioValue = GetPortfolioValue(portfolioId);

            return new CheckValue<decimal?>(portfolioValue, portfolioValue?.ToString("F2") ?? String.Empty);
        }

        protected abstract decimal? GetPortfolioValue(int portfolioId);

        public abstract void Dispose();
    }
}
