﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Mandara.Business.Bus;
using Mandara.Business.Bus.Messages.Trades;
using Mandara.Entities;
using PortfolioManager = Mandara.Business.Client.Managers.PortfolioManager;

namespace Mandara.AdminAlertService.ValueProviders
{
    class TradeRepository
    {
        private readonly BusClient _busClient;

        private readonly object _lockTodayTrades = new object();
        private readonly Dictionary<int, LiveTrade> _todayTrades = new Dictionary<int, LiveTrade>();

        private readonly ManualResetEvent _event = new ManualResetEvent(false);

        public TradeRepository(BusClient busClient)
        {
            _busClient = busClient;

            DateTime today = DateTime.Today;

            _busClient.TradesChanged -= BusClientOnTradesChanged;
            _busClient.TradesChanged += BusClientOnTradesChanged;

            _busClient.GetTradesSnapshot(today, today.AddDays(1), Callback);

            _event.WaitOne(TimeSpan.FromSeconds(30.0));
        }

        private void Callback(List<TradesSnapshotMessage> messages)
        {
            if (messages == null)
            {
                _event.Set();
                return;
            }

            List<TradeCapture> tradeCaptures =
                messages.Where(m => m.TradeCaptures != null).SelectMany(m => m.TradeCaptures).ToList();

            lock (_lockTodayTrades)
            {
                foreach (TradeCapture tradeCapture in tradeCaptures)
                {
                    UpdateTradeInCache(tradeCapture);
                }
            }

            foreach (KeyValuePair<int, LiveTrade> trade in _todayTrades)
                RaiseOnTradesAdded(trade.Value);

            _event.Set();
        }

        /// <summary>
        /// Returns true if trade was added
        /// </summary>
        /// <param name="tradeCapture"></param>
        /// <returns></returns>
        private bool UpdateTradeInCache(TradeCapture tradeCapture)
        {
            bool tradeExists = _todayTrades.ContainsKey(tradeCapture.TradeId);
            if (tradeExists)
            {
                _todayTrades.Remove(tradeCapture.TradeId);
            }

            if (!Business.Client.Managers.LiveDataManager.IsTradeCancelled(tradeCapture))
            {
                _todayTrades.Add(tradeCapture.TradeId, LiveTrade.From(tradeCapture));
                return !tradeExists;
            }
            else
                return false;
        }

        private void BusClientOnTradesChanged(object sender, TradesChangedEventArgs args)
        {
            if (args?.TradeCapture == null)
            {
                return;
            }

            bool tradeAdded;

            lock (_lockTodayTrades)
            {
                tradeAdded = UpdateTradeInCache(args.TradeCapture);
            }

            if (tradeAdded)
            {
                RaiseOnTradesAdded(LiveTrade.From(args.TradeCapture));
            }
        }

        public void Dispose()
        {
            _busClient.TradesChanged -= BusClientOnTradesChanged;
        }

        public List<LiveTrade> Trades => _todayTrades.Values.ToList();

        public LiveTrade GetTrade(int tradeId)
        {
            lock (_lockTodayTrades)
            {
                if (_todayTrades.TryGetValue(tradeId, out LiveTrade trade))
                {
                    return trade;
                }

                return LiveTrade.Default;
            }
        }

        public event EventHandler<TradeAddedArgs> TradeAdded;
        private void RaiseOnTradesAdded(LiveTrade trade)
        {
            // TODO: event should take list of added trades
            TradeAdded?.Invoke(this, new TradeAddedArgs(trade));
        }

        public LiveTrade[] GetTradesForPortfolio(int portfolioId)
        {
            Portfolio firstOrDefault = _busClient.Portfolios.Values.FirstOrDefault(p => p.PortfolioId == portfolioId);
            List<int> ids = new List<int>();

            if (firstOrDefault != null)
            {
                ids = PortfolioManager.GetHierarchyPortfolioIds(firstOrDefault).ToList();
            }

            LiveTrade[] portfolioTrades;

            lock (_lockTodayTrades)
            {
                portfolioTrades = _todayTrades.Values.Where(x => x.PortfolioId.HasValue && ids.Contains(x.PortfolioId.Value)).ToArray();
            }

            return portfolioTrades;
        }

    }

    struct LiveTrade
    {
        public int TradeId { get; private set; }
        public DateTime TransactTime { get; private set; }
        public DateTime LocalTransactTime { get; private set; }
        public DateTime TradeDate { get; private set; }
        public int? PortfolioId { get; private set; }
        public string StripName { get; private set; }
        public string ProductDescription { get; private set; }
        public string Trader { get; private set; }
        public bool IsTas { get; private set; }

        public static LiveTrade From(TradeCapture tradeCapture)
        {
            return new LiveTrade
            {
                TradeId = tradeCapture.TradeId,
                TransactTime = tradeCapture.ConvertedTransactTime(),
                LocalTransactTime = tradeCapture.UtcTransactTime.ToLocalTime(),
                TradeDate = tradeCapture.TradeDate ?? DateTime.MinValue,
                PortfolioId = tradeCapture.Portfolio?.PortfolioId,
                ProductDescription =
                    tradeCapture.SecurityDefinition == null
                        ? ""
                        : tradeCapture.SecurityDefinition.ProductDescription,
                StripName =
                    tradeCapture.SecurityDefinition == null ? "" : tradeCapture.SecurityDefinition.StripName,
                Trader = tradeCapture.OriginationTrader,
                IsTas = tradeCapture?.SecurityDefinition?.Product?.IsTasDb ?? false,
            };
        }

        public override string ToString()
        {
            return $"Portfolio: [{PortfolioId}], TransactTime: [{TransactTime:g}]";
        }

        private const int DefaultId = -1;
        private static readonly DateTime DefaultTransactionTime = DateTime.MinValue;
        private const string DefaultProductDescription = "";
        private const string DefaultStrip = "";
        private const string DefaultTrader = "";

        public static LiveTrade Default = new LiveTrade()
        {
                TradeId = DefaultId,
                TransactTime = DefaultTransactionTime,
                LocalTransactTime = DefaultTransactionTime,
                TradeDate = DefaultTransactionTime,
                PortfolioId = DefaultId,
                ProductDescription = DefaultProductDescription,
                StripName = DefaultStrip,
                Trader = DefaultTrader,
                IsTas = false,
        };

        public bool IsDefault()
        {
            return DefaultId == TradeId
                   && DefaultId == PortfolioId
                   && DefaultTransactionTime == TransactTime
                   && DefaultTransactionTime == LocalTransactTime
                   && DefaultTransactionTime == TradeDate
                   && DefaultProductDescription == ProductDescription
                   && DefaultStrip == StripName
                   && DefaultTrader == Trader;
        }
    }

    class TradeAddedArgs : EventArgs
    {
        public LiveTrade Trade { get; private set; }

        public TradeAddedArgs(LiveTrade trade)
        {
            Trade = trade;
        }
    }
}
