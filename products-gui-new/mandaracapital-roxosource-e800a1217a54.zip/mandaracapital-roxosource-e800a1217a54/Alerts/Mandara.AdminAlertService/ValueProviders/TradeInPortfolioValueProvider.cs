﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Mandara.Business;
using Mandara.Business.Bus;
using Mandara.Business.Bus.Messages.Trades;
using Mandara.Entities;
using Mandara.Entities.Extensions;

namespace Mandara.AdminAlertService.ValueProviders
{
    /// <summary>
    /// Value provider for the portfolio trades times.
    /// </summary>
    class TradeInPortfolioValueProvider : IMultiValueProvider<LiveTrade>
    {
        private readonly TradeRepository _repository;

        public TradeInPortfolioValueProvider(TradeRepository repository)
        {
            _repository = repository;
        }

        public void Dispose()
        {
        }

        public LiveTrade[] GetValues(int portfolioId)
        {
            return _repository.GetTradesForPortfolio(portfolioId).ToArray();
        }

    }    
}
