﻿using System;
using System.Collections.Generic;
using Mandara.Business.Bus;
using Mandara.Entities.Calculation;
using Mandara.Entities.Enums;
using NLog;

namespace Mandara.AdminAlertService.ValueProviders
{
    /// <summary>
    /// Value provider for the portfolio current live pnl value.
    /// </summary>
    class PnlValueProvider : NullableDecimalProvider
    {
        private readonly BusClient _busClient;
        private Logger _logger = LogManager.GetCurrentClassLogger();

        public PnlValueProvider(BusClient busClient)
        {
            _busClient = busClient;
        }

        protected override decimal? GetPortfolioValue(int portfolioId)
        {
            if (_busClient.PnlDictionary.Count == 0)
            {
                _logger.Warn("Missing PnL dictionary");
                return default(decimal?);
            }

            _busClient.PnlDictionary.TryGetValue(portfolioId, out Dictionary<string, PnlData> portfolioPnL);

            return portfolioPnL?[CurrencyCodes.USD].NetPnl;
        }

        public override void Dispose()
        {
        }
    }
}
