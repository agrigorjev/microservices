using Mandara.Business.AsyncServices.Base;
using Mandara.Business.Bus;
using Mandara.Business.Bus.Messages.TransferErrors;
using Mandara.Entities.ErrorDetails;
using Ninject.Extensions.Logging;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace Mandara.AdminAlertService.ValueProviders
{
    internal class TransferErrorsValueProvider : IMultiValueProvider<TradeTransferErrorDto>
    {
        private BusClient _busClient;
        private TimeSpan _updateInterval;
        private AsyncService _updateService;
        private DateTime? _lastDate;
        private ManualResetEvent _event = new ManualResetEvent(false);
        private ConcurrentBag<TradeTransferErrorDto> _tradeTransferErrors = new ConcurrentBag<TradeTransferErrorDto>();

        public TransferErrorsValueProvider(BusClient busClient)
        {
            _busClient = busClient;

            _updateInterval = TimeSpan.FromMinutes(Configuration.ValueProviders.GetSection().TransferErrors.Interval);
            _updateService = AsyncServiceFactory.FromAction(UpdateData, new NLogLogger(typeof(TransferErrorsValueProvider)));
            _updateService.SleepTime = _updateInterval;
            _updateService.Start();
        }

        private void UpdateData()
        {
            _busClient.GetTransferErrors(_lastDate, UpdateData_Callback, OnTransferErrorsRequestFailure);

            _event.WaitOne(TimeSpan.FromSeconds(20));
            _event.Reset();
        }

        private void OnTransferErrorsRequestFailure(FailureCallbackInfo failureCallbackInfo)
        {
            _event.Set();
        }

        private void UpdateData_Callback(TransferErrorsResponseMessage message)
        {
            if (message?.TransferErrors?.Count > 0)
            {
                message.TransferErrors.ForEach(_tradeTransferErrors.Add);
                _lastDate = message.TransferErrors.Max(x => x.ErrorDate);
            }

            _event.Set();
        }

        public TradeTransferErrorDto[] GetValues(int portfolioId)
        {
            return null;
        }

        public TradeTransferErrorDto[] GetValues(List<int> ids)
        {
            List<TradeTransferErrorDto> errors = new List<TradeTransferErrorDto>();

            TradeTransferErrorDto item;
            while (_tradeTransferErrors.TryTake(out item))
            {
                if (ids.Contains((int)item.ErrorType))
                {
                    errors.Add(item);
                }
            }

            return errors.ToArray();
        }

        public void Dispose()
        {
            _updateService.Stop();
            _updateService.Dispose();
        }
    }
}