﻿namespace Mandara.AdminAlertService.ValueProviders
{
    class ValueKey<TValue>
    {
        private readonly int _portfolioId;
        public int PortfolioId
        {
            get { return _portfolioId; }
        }

        public ValueKey(int portfolioId)
        {
            _portfolioId = portfolioId;
        }

        public virtual string ActualValue
        {
            get { return string.Empty; }
        }

        public override string ToString()
        {
            return PortfolioId.ToString();
        }

        public virtual string GetDisplayValue(TValue value)
        {
            return value.ToString();
        }
    }
}
