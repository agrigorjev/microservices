﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mandara.AdminAlertService.ValueProviders
{
    interface IMultiValueProvider<T> : IDisposable
    {
        T[] GetValues(int portfolioId);
    }
}
