﻿using System;
using System.Collections.Generic;
using System.Linq;
using Mandara.Business.AsyncServices.Base;
using Mandara.Business.Bus;
using Mandara.VarCalcEngine;
using Mandara.VarCalcEngine.Impl;
using Mandara.VarCalcEngine.Interfaces;
using Ninject.Extensions.Logging;

namespace Mandara.AdminAlertService.ValueProviders
{
    /// <summary>
    /// Value provider for the portfolio current var value.
    /// </summary>
    class VarValueProvider : NullableDecimalProvider
    {
        private readonly BusClient _busClient;
        private readonly int _varConfidence;
        private readonly Dictionary<int, decimal?> _varValues = new Dictionary<int,decimal?>();
        private readonly Dictionary<int, VarCalculator> _varCalculators;
        private readonly List<int> _portfolioIds;
        private readonly TimeSpan _updateInterval;
        private readonly AsyncService _updateService;

        public VarValueProvider(BusClient busClient)
        {
            Configuration.ValueProviders intervalsConfig = Configuration.ValueProviders.GetSection();

            _updateInterval = TimeSpan.FromMinutes(intervalsConfig.Var.Interval);
            _varConfidence = intervalsConfig.Var.Confidence;
            _busClient = busClient;
            _portfolioIds = busClient.Portfolios.Keys.ToList();
            _varCalculators = CreateVarCalculators(_portfolioIds, _varConfidence, _busClient);
            
            _updateService = AsyncServiceFactory.FromAction(UpdateVarValues, new NLogLogger(typeof(VarValueProvider)));
            _updateService.SleepTime = _updateInterval;
            _updateService.Start();
        }

        private static Dictionary<int, VarCalculator> CreateVarCalculators(
            List<int> portfolioIds,
            int varConfidence,
            BusClient busClient)
        {
            return portfolioIds
                   .Select(
                       p => new { PortfolioId = p, VarCalculator = ComposeVarCalculator(busClient, varConfidence, p) })
                   .ToDictionary(x => x.PortfolioId, x => x.VarCalculator);
        }

        private static VarCalculator ComposeVarCalculator(BusClient busClient, int confidenceLevel, int portfolioId)
        {
            IVarCache varCache = new DbVarCache();

            IPricesGetter pricesGetter = new DbPricesGetter();
            IPositionsGetter positionsGetter = new LivePositionsGetter(busClient, varCache);

            return new VarCalculator(pricesGetter, positionsGetter, varCache, confidenceLevel, portfolioId);
        }
        
        private void UpdateVarValues()
        {
            lock(_varValues)
            {
                foreach(var portfolioId in _portfolioIds)
                {
                    _varValues[portfolioId] = Convert.ToDecimal(_varCalculators[portfolioId].CalculateVar());
                }
            }
        }

        protected override decimal? GetPortfolioValue(int portfolioId)
        {
            _varValues.TryGetValue(portfolioId, out decimal? varValue);
            return varValue;
        }

        public override void Dispose()
        {
            _updateService.Dispose();
        }
    }
}
