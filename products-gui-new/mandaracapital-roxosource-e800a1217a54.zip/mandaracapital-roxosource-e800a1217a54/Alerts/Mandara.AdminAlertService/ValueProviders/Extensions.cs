﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using Mandara.Date;
using Mandara.Entities;

namespace Mandara.AdminAlertService.ValueProviders
{
    internal static class TradeCaptureExtensions
    {
        public static DateTime ConvertedTransactTime(this TradeCapture self)
        {
            if (self == null || !self.TransactTime.HasValue)
            {
                return DateTime.MinValue;
            }

            string exchanges = ConfigurationManager.AppSettings["ExchangesToConvert"] ?? "nymex";

            List<string> exchangesList =
                exchanges.ToLowerInvariant().Split(new[] { "|" }, StringSplitOptions.RemoveEmptyEntries).ToList();

            // This is incorrect - it should use the exchange timezone since not all non-ICE exchanges are on Central
            // Standard Time.
            if (exchangesList.Contains((self.Exchange ?? string.Empty).ToLowerInvariant()))
            {
                // return self.TransactTime.Value.FromCstToLocalTime();
            }

            return self.TransactTime.Value;
        }
    }
}