﻿using System;
using System.Configuration;
using Mandara.AdminAlertService.Configuration.Validation;

namespace Mandara.AdminAlertService.ValueProviders.Configuration
{
    internal class ValueProviderInterval : ConfigurationElement
    {
        public const string IntervalName = "interval";
        private static readonly IntegerRangeCheck AtLeastOne = new IntegerRangeCheck(1, IntegerRangeCheck.DefaultMax); 

        [ConfigurationProperty(IntervalName, IsRequired = true, DefaultValue = 1)]
        public int Interval
        {
            get => (int)this[IntervalName];
            set
            {
                AtLeastOne.CheckValue(value, IntervalName);
                this[IntervalName] = value;
            }
        }
    }

    internal class VarProviderInterval : ValueProviderInterval
    {
        public const string ElemName = "var";
        public const string ConfidenceName = "confidence";
        private static readonly IntegerRangeCheck Percentage = new IntegerRangeCheck(0, 100); 

        [ConfigurationProperty(ConfidenceName, DefaultValue = 95)]
        public int Confidence
        {
            get => (int)this[ConfidenceName];
            set
            {
                Percentage.CheckValue(value, ConfidenceName);
                this[IntervalName] = value;
            }
        }
    }

    internal class StartOfNewTradingDay : ConfigurationElement
    {
        public const string ElemName = "startOfTradingDay";
        public const string StartOfDayName = "time";
        private static readonly TimeSpanRangeCheck TwentyFourHoursOnly =
            TimeSpanRangeCheck.UpperBound(TimeSpan.Parse("23:59:59.999"));

        [ConfigurationProperty(StartOfDayName, DefaultValue = "00:00:00")]
        public TimeSpan Time
        {
            get => (TimeSpan)this[StartOfDayName];
            set
            {
                TwentyFourHoursOnly.CheckValue(value, StartOfDayName);
                this[StartOfDayName] = value.ToString();
            }
        }
    }

    internal class ValueProviders : ConfigurationSection
    {
        public const string SectionName = "valueProviders";
        public const string FlatPriceName = "flatPrice";
        public const string TransferErrorsName = "transferError";
        public const string VarName = VarProviderInterval.ElemName;

        private static readonly ValueProviderInterval DefaultInterval = new ValueProviderInterval() { Interval = 1 };

        [ConfigurationProperty(FlatPriceName, IsRequired = true)]
        public ValueProviderInterval FlatPrice
        {
            get => (this[FlatPriceName] as ValueProviderInterval) ?? DefaultInterval;
            set => this[FlatPriceName] = value;
        }

        [ConfigurationProperty(TransferErrorsName, IsRequired = false)]
        public ValueProviderInterval TransferErrors
        {
            get => (this[TransferErrorsName] as ValueProviderInterval) ?? new ValueProviderInterval() { Interval = 1 };
            set => this[TransferErrorsName] = value;
        }

        [ConfigurationProperty(VarName, IsRequired = false)]
        public VarProviderInterval Var
        {
            get =>
                (this[VarProviderInterval.ElemName] as VarProviderInterval)
                ?? new VarProviderInterval() { Interval = 1 };
            set => this[VarProviderInterval.ElemName] = value;
        }

        [ConfigurationProperty(StartOfNewTradingDay.ElemName, IsRequired = false)]
        public StartOfNewTradingDay StartOfDay
        {
            get => (this[StartOfNewTradingDay.ElemName] as StartOfNewTradingDay) ?? new StartOfNewTradingDay();
            set => this[StartOfNewTradingDay.ElemName] = value;
        }

        public static ValueProviders GetSection()
        {
            return ConfigurationManager.GetSection(SectionName) as ValueProviders;
        }
    }
}
