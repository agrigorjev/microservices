﻿using System;

namespace Mandara.AdminAlertService.ValueProviders
{
    class TradeTimeKey : ValueKey<TimeSpan?>
    {
        private readonly LiveTrade _trade;

        public TradeTimeKey(int portfolioId, LiveTrade trade) 
            : base(portfolioId)
        {
            _trade = trade;
        }

        public int TradeId => _trade.TradeId;

        public string StripName => _trade.StripName;
        public string ProductDescription => _trade.ProductDescription;
        public string Trader => _trade.Trader;

        public override string ActualValue => TradeId + " @ ";

        public override string ToString()
        {
            return $"{PortfolioId}_{TradeId}";
        }

        public override string GetDisplayValue(TimeSpan? value)
        {
            return $"Trade Id: {TradeId} - {value:hh\\:mm\\:ss}";
        }
    }
}