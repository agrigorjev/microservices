﻿using Mandara.Business;
using Mandara.Business.AsyncServices.Base;
using Mandara.Business.Bus;
using Mandara.Entities;
using Mandara.Entities.Calculation;
using Ninject.Extensions.Logging;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;

namespace Mandara.AdminAlertService.ValueProviders
{
    class FlatPricePositionKeyValueProvider : IKeyValueProvider<FlatPriceValueKey, decimal?>
    {
        private readonly BusClient _busClient;
        private readonly TimeSpan _updateInterval;
        private readonly ConcurrentDictionary<string, decimal?> _flatPriceValues;
        private readonly AsyncService _updateService;

        private readonly object _lockUpdateCache = new object();

        public FlatPricePositionKeyValueProvider(BusClient busClient)
        {
            _updateInterval = TimeSpan.FromMinutes(Configuration.ValueProviders.GetSection().FlatPrice.Interval);
            _busClient = busClient;
            _flatPriceValues = new ConcurrentDictionary<string, decimal?>();
            _updateService = AsyncServiceFactory.FromAction(
                UpdateFlatPriceValues,
                new NLogLogger(typeof(FlatPricePositionKeyValueProvider)));
            _updateService.SleepTime = _updateInterval;
            _updateService.Start();
        }

        private void UpdateFlatPriceValues()
        {
            ConcurrentDictionary<string, decimal?> localCache = new ConcurrentDictionary<string, decimal?>();

            List<int> portfolioIds = _busClient.Portfolios.Keys.ToList();

            foreach (int portfolioId in portfolioIds)
            {
                UpdateCacheForPortfolio(portfolioId, localCache);
            }

            lock (_lockUpdateCache)
            {
                _flatPriceValues.Clear();

                foreach (KeyValuePair<string, decimal?> pair in localCache)
                {
                    _flatPriceValues.TryAdd(pair.Key, pair.Value);
                }
            }
        }

        private void UpdateCacheForPortfolio(int portfolioId, ConcurrentDictionary<string, decimal?> localCache)
        {
            List<int> ids = new List<int> { portfolioId };

            Portfolio firstOrDefault = _busClient.Portfolios.Values.FirstOrDefault(p => p.PortfolioId == portfolioId);

            if (firstOrDefault != null)
            {
                ids = PortfolioManager.GetHierarchyPortfolioIds(firstOrDefault).ToList();
            }

            List<CalculationDetail> portfolioPositions =
                _busClient.Positions.Values.Where(v => v.PortfolioId.HasValue && ids.Contains(v.PortfolioId.Value))
                          .ToList();

            if (portfolioPositions.Any())
            {
                string cacheKey = new FlatPriceValueKey(portfolioId).ToString();

                decimal? _;
                localCache.TryRemove(cacheKey, out _);
                localCache.TryAdd(cacheKey, portfolioPositions.Sum(c => c.AmountInner) / 1000);

                var productsColumns = portfolioPositions
                    .GroupBy(g => new { g.ProductId })
                    .Select(
                        x => new
                        {
                            ProductId = x.Key.ProductId,
                            Amount = x.Sum(p => p.AmountInner)
                        }
                    );

                foreach (var column in productsColumns)
                {
                    string key = new ProductFlatPriceValueKey(portfolioId, column.ProductId, "").ToString();

                    decimal? __;
                    localCache.TryRemove(key, out __);
                    localCache.TryAdd(key, column.Amount / 1000);
                }

                var productGroupsColumns = portfolioPositions
                    .GroupBy(g => new { g.ProductCategoryId })
                    .Select(
                        x => new
                        {
                            ProductGroupId = x.Key.ProductCategoryId,
                            Amount = x.Sum(p => p.AmountInner)
                        }
                    );

                foreach (var column in productGroupsColumns)
                {
                    string key = new ProductGroupFlatPriceValueKey(portfolioId, column.ProductGroupId, "").ToString();

                    decimal? __;
                    localCache.TryRemove(key, out __);
                    localCache.TryAdd(key, column.Amount / 1000);
                }
            }
        }

        public decimal? GetValue(FlatPriceValueKey valueKey)
        {
            string cacheKey = valueKey.ToString();

            lock (_lockUpdateCache)
            {
                decimal? amount;
                if (_flatPriceValues.TryGetValue(cacheKey, out amount))
                    return amount;
            }

            return null;
        }
    }
}