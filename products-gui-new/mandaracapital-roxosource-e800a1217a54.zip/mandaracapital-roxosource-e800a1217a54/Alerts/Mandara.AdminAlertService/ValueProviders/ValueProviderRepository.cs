﻿using System;
using System.Collections.Generic;
using Mandara.AdminAlertService.PubSubEvents;
using Mandara.Business.Bus;
using Mandara.Business.PublishSubscribe;
using Mandara.Entities;
using Mandara.Entities.ErrorReporting;

namespace Mandara.AdminAlertService.ValueProviders
{
    /// <summary>
    /// Contains value providers used by the service.
    /// </summary>
    class ValueProviderRepository : IDisposable
    {
        public PnlValueProvider PnlValueProvider { get; private set; }
        public VarValueProvider VarValueProvider { get; private set; }
        public TradeInPortfolioValueProvider TradeInPortfolioValueProvider { get; private set; }
        public TradeTimeKeyValueProvider TradeTimeKeyValueProvider { get; private set; }
        public FlatPricePositionKeyValueProvider FlatPriceKeyValueValueProvider { get; private set; }
        public ExpiringProductsValueProvider ExpiringProductsValueProvider { get; private set; }
        public TransferErrorsValueProvider TransferErrorsValueProvider { get; private set; }

        private List<IDisposable> _disposables;

        public ValueProviderRepository(BusClient busClient, TradeRepository tradeRepository)
        {
            try
            {
                FlatPriceKeyValueValueProvider = new FlatPricePositionKeyValueProvider(busClient);
                PnlValueProvider = new PnlValueProvider(busClient);
//                VarValueProvider = new VarValueProvider(busClient);
                TradeInPortfolioValueProvider = new TradeInPortfolioValueProvider(tradeRepository);
                TradeTimeKeyValueProvider = new TradeTimeKeyValueProvider(tradeRepository);
                ExpiringProductsValueProvider = new ExpiringProductsValueProvider(busClient);
                TransferErrorsValueProvider = new TransferErrorsValueProvider(busClient);
            }
            catch (Exception ex)
            {
                ErrorReportingHelper.ReportError(
                    "Alerts Service",
                    ErrorType.Exception,
                    "ValueProviderRepository encountered an error during initialisation. "
                        + "Alerts Service will be stopped.",
                    null,
                    ex,
                    ErrorLevel.Critical);

                PubSub.SendMessage(new StopServiceEvent(true));
            }

            _disposables = new List<IDisposable>
                               {
                                   PnlValueProvider,
                                   VarValueProvider
                               };
        }

        public void Dispose()
        {
            if (_disposables != null)
            {
                for (int i = 0; i < _disposables.Count; i++)
                {
                    if (_disposables[i] != null)
                        _disposables[i].Dispose();
                }
            }
        }
    }
}

