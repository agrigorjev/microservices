﻿using System;
using System.Collections.Generic;
using System.Threading;
using Mandara.Business;
using Mandara.Business.Bus;
using Mandara.Business.Bus.Messages;

namespace Mandara.AdminAlertService.ValueProviders
{
    public class ExpiringProductsValueProvider : IValueProvider<List<ExpiringProductWarning>>
    {
        private readonly BusClient _busClient;
        private ManualResetEvent _event = new ManualResetEvent(false);
        private List<ExpiringProductWarning> _expiringProductWarnings;

        public ExpiringProductsValueProvider(BusClient busClient)
        {
            _busClient = busClient;
        }

        public CheckValue<List<ExpiringProductWarning>> GetValue(int daysToExpire)
        {
            _busClient.GetExpiringProductsSnapshot(new ExpiringProductsSnapshotMessage(daysToExpire), Callback);

            _event.WaitOne();
            _event.Reset();
            string numEpxiringProducts = $"Expiring products count: {_expiringProductWarnings.Count}";

            return new CheckValue<List<ExpiringProductWarning>>(_expiringProductWarnings, numEpxiringProducts);
        }

        private void Callback(ExpiringProductsSnapshotMessage message)
        {
            if (message != null)
            {
                _expiringProductWarnings = message.ExpiringProducts;
            }

            _event.Set();
        }

        public void Dispose()
        {
            
        }
    }
}