﻿using System.Diagnostics;
using Mandara.Entities;

namespace Mandara.AdminAlertService.ValueProviders
{
    class FlatPriceValueKey : ValueKey<decimal?>
    {
        public static FlatPriceValueKey FromAlert(AdministrativeAlert alert)
        {
            Debug.Assert(alert.TypeOfAlert == AdministrativeAlert.AdmAlertType.Flat_Price_Position);
            if (alert.Product != null)
                return new ProductFlatPriceValueKey(alert.Portfolio.PortfolioId, alert.Product.ProductId, alert.Product.Name);

            if (alert.ProductGroup != null)
                return new ProductGroupFlatPriceValueKey(alert.Portfolio.PortfolioId, alert.ProductGroup.CategoryId, alert.ProductGroup.Name);

            return new FlatPriceValueKey(alert.Portfolio.PortfolioId);
        }

        public FlatPriceValueKey(int portfolioId)
            : base(portfolioId) {}

        public override string GetDisplayValue(decimal? value)
        {
            return string.Format("{0:F2}", value);
        }
    }

    class ProductFlatPriceValueKey : FlatPriceValueKey
    {
        public int? ProductId { get; set; }
        public string ProductName { get; set; }

        public ProductFlatPriceValueKey(int portfolioId, int? productId, string productName)
            : base(portfolioId)
        {
            ProductId = productId;
            ProductName = productName;
        }

        public override string ToString()
        {
            return base.ToString() + "_" + ProductId;
        }

        public override string GetDisplayValue(decimal? value)
        {
            return string.Format("Product: {0} - {1:F2}", ProductName, value);

        }
    }

    class ProductGroupFlatPriceValueKey : FlatPriceValueKey
    {
        public int? ProductGroupId { get; set; }
        public string ProductGroupName { get; set; }

        public ProductGroupFlatPriceValueKey(int portfolioId, int? productGroupId, string productGroupName)
            : base(portfolioId)
        {
            ProductGroupId = productGroupId;
            ProductGroupName = productGroupName;
        }

        public override string ToString()
        {
            return base.ToString() + "_g" + ProductGroupId;
        }

        public override string GetDisplayValue(decimal? value)
        {
            return string.Format("Product group: {0} - {1:F2}", ProductGroupName, value);
        }
    }
}