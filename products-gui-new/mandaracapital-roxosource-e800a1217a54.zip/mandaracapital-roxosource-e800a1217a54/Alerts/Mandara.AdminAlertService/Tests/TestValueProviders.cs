﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Mandara.AdminAlertService.ValueProviders;

namespace Mandara.AdminAlertService.Tests
{
    class TestNullableDecimalValueProvider : NullableDecimalProvider
    {
        private readonly decimal? _validValue;
    
        public TestNullableDecimalValueProvider(decimal? validValue)
        {
            _validValue = validValue;
        }

        protected override decimal? GetPortfolioValue(int portfolioId)
        {
            return _validValue;
        }

        public override void Dispose()
        {
        }
    }

    class TestTimeSpanValuesProvider : IMultiValueProvider<TimeSpan>
    {
        private readonly TimeSpan[] _values;

        public TestTimeSpanValuesProvider(TimeSpan[] values)
        {
            _values = values;
        }

        public TimeSpan[] GetValues(int portfolioId)
        {
            return _values;
        }

        public void Dispose()
        {
            
        }
    }
}
