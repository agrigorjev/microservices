﻿using Mandara.AdminAlertService.Alerts;
using Mandara.Entities;
using NUnit.Framework;
using System.Linq;

namespace Mandara.AdminAlertService.Tests
{
    [TestFixture]
    class SingleValueAlertTriggerTest
    {
        public const decimal ValidValue = 10m;
        public const decimal LesserThreshold = 8m;
        public const decimal GreaterThreshold = 12m;

        private static AlertTrigger CreateDecimalSingleValueTestTrigger(
            decimal? value,
            decimal threshold,
            AdministrativeAlert.BoundaryType boundaryType)
        {
            var alert = new AdministrativeAlert
            {
                Portfolio = new Portfolio(), TypeOfBoundary = boundaryType, ThresholdValue = threshold
            };
            var provider = new TestNullableDecimalValueProvider(value);
            return new SingleValueAlertTrigger<decimal?>(alert, a => a.ThresholdValue, provider, "TestTrigger");
        }

        [Test]
        public void simple_trigger_fires_if_condition_met()
        {
            var triggers = new[]
            {
                CreateDecimalSingleValueTestTrigger(
                    ValidValue,
                    GreaterThreshold,
                    AdministrativeAlert.BoundaryType.LessThan),
                CreateDecimalSingleValueTestTrigger(
                    ValidValue,
                    ValidValue,
                    AdministrativeAlert.BoundaryType.LessThan),
                CreateDecimalSingleValueTestTrigger(
                    ValidValue,
                    LesserThreshold,
                    AdministrativeAlert.BoundaryType.GreaterThan),
                CreateDecimalSingleValueTestTrigger(
                    ValidValue,
                    ValidValue,
                    AdministrativeAlert.BoundaryType.GreaterThan)
            };
            Assert.IsTrue(triggers.All(t => t.Triggered()));
        }

        [Test]
        public void simple_trigger_not_fires_if_condition_not_met()
        {
            var triggers = new[]
            {
                CreateDecimalSingleValueTestTrigger(
                    ValidValue,
                    LesserThreshold,
                    AdministrativeAlert.BoundaryType.LessThan),
                CreateDecimalSingleValueTestTrigger(
                    ValidValue,
                    GreaterThreshold,
                    AdministrativeAlert.BoundaryType.GreaterThan)
            };

            Assert.IsTrue(triggers.All(t => !t.Triggered()));
        }

        [Test]
        public void simple_trigger_not_fires_if_value_for_portfolio_is_null()
        {
            var triggers = new[]
            {
                CreateDecimalSingleValueTestTrigger(
                    null,
                    LesserThreshold,
                    AdministrativeAlert.BoundaryType.LessThan),
                CreateDecimalSingleValueTestTrigger(
                    null,
                    GreaterThreshold,
                    AdministrativeAlert.BoundaryType.LessThan),
                CreateDecimalSingleValueTestTrigger(null, ValidValue, AdministrativeAlert.BoundaryType.LessThan),
                CreateDecimalSingleValueTestTrigger(
                    null,
                    LesserThreshold,
                    AdministrativeAlert.BoundaryType.GreaterThan),
                CreateDecimalSingleValueTestTrigger(
                    null,
                    GreaterThreshold,
                    AdministrativeAlert.BoundaryType.GreaterThan),
                CreateDecimalSingleValueTestTrigger(null, ValidValue, AdministrativeAlert.BoundaryType.GreaterThan)
            };

            Assert.IsTrue(triggers.All(t => !t.Triggered()));
        }
    }
}