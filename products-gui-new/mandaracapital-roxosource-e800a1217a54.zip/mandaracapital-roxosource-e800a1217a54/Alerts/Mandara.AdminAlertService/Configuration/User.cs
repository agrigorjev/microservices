﻿using System.Configuration;
using Mandara.AdminAlertService.Configuration.Validation;

namespace Mandara.AdminAlertService.Configuration
{
    internal class User : ConfigurationElement
    {
        public const string ElemName = "user";
        public const string UserName = "name";
        public const string UserPassword = "password";
        private static readonly StringLengthCheck NameLength = new StringLengthCheck(1, 60);
        private static readonly StringLengthCheck AtLeastOneChar = new StringLengthCheck(
            1,
            StringLengthCheck.DefaultMax);

        [ConfigurationProperty(UserName, IsRequired = true)]
        public string Name
        {
            get => (string)this[UserName];
            set
            {
                NameLength.CheckValue(value, UserName);
                this[UserName] = value;
            }
        }

        [ConfigurationProperty(UserPassword, IsRequired = true)]
        public string Password
        {
            get => (string)this[UserPassword];
            set
            {
                AtLeastOneChar.CheckValue(value, UserPassword);
                this[UserPassword] = value;
            }
        }
    }
}
