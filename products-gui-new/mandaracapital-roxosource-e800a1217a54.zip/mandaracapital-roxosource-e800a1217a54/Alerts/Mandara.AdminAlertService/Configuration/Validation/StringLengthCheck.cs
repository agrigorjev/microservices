﻿
using System.Configuration;

namespace Mandara.AdminAlertService.Configuration.Validation
{
    internal class StringLengthCheck : PropertyValidator<string>
    {
        protected string errorMessageTemplate =
            "The length of {0} is invalid for '{1}'. Valid lengths are in the range {2} to {3}";

        public StringLengthCheck(int min, int max) : base(min, max)
        {
        }

        protected override bool IsValid(string value)
        {
            return null != value && Min <= value.Length && Max >= value.Length;
        }

        protected override void ThrowConfigurationError(string value, string configFieldName)
        {
            throw new ConfigurationErrorsException(
                string.Format(errorMessageTemplate, value, configFieldName, Min, Max));
        }
    }
}
