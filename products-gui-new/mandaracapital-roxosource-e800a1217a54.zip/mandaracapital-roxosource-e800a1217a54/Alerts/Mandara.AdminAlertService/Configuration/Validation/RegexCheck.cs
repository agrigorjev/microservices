﻿
using System.Configuration;
using System.Text.RegularExpressions;

namespace Mandara.AdminAlertService.Configuration.Validation
{
    internal class RegexCheck : StringLengthCheck
    {
        public string RegexPattern
        {
            get => _stringTest.ToString();
            set => _stringTest = new Regex(value ?? string.Empty);
        }

        private Regex _stringTest = new Regex(string.Empty);

        private bool _isLengthValid = true;
        private bool _isPatternMatched = true;

        private static readonly string _regexMatchErrorTemplate =
            "The {0} is invalid for '{1}' - it does not match the required string format.";

        public RegexCheck(string pattern) : this(pattern, 0, DefaultMax)
        {
        }

        public RegexCheck(string pattern, int min, int max) : base(min, max)
        {
            RegexPattern = pattern;
        }

        protected override bool IsValid(string value)
        {
            _isLengthValid = base.IsValid(value);
            _isPatternMatched = _stringTest.IsMatch(value);
            return _isLengthValid && _isPatternMatched;
        }

        protected override void ThrowConfigurationError(string value, string configFieldName)
        {
            if (!_isLengthValid)
            {
                base.ThrowConfigurationError(value, configFieldName);
            }
            else 
            {
                throw new ConfigurationErrorsException(string.Format(_regexMatchErrorTemplate, value, configFieldName));
            }
        }
    }
}
