﻿
using System;

namespace Mandara.AdminAlertService.Configuration.Validation
{
    /// <summary>
    /// The existing configuration validators available via attributes are of no use for actual configuration validation
    /// because they're only able to validate the default values.  If a field does not have a configured default and
    /// the default for the type doesn't match the validator rules then validation fails.  Also, the configured value is
    /// never validated.  The validators can be used directly, but they don't provide the opportunity to give a custom
    /// exception message unless the exception is caught and a new one thrown, which loses the stack trace.
    /// </summary>
    /// <typeparam name="T">The type that will be checked.  The class assumes that validation will include a min and max
    /// that can be translated in some way to integers.  Obviously this isn't always going to be the case, but until an
    /// example that has something else comes along, this can remain the base abstract class.</typeparam>
    internal abstract class PropertyValidator<T>
    {
        public const int DefaultMin = Int32.MinValue;
        private bool _isMinSet;
        private int _min;

        protected int Min
        {
            get => _min;
            set
            {
                if (_isMinSet)
                {
                    return;
                }

                _min = value;
                _isMinSet = true;
            }
        }

        public const int DefaultMax = Int32.MaxValue;

        private bool _isMaxSet;
        private int _max;

        protected int Max
        {
            get => _max;
            set
            {
                if (_isMaxSet)
                {
                    return;
                }

                _max = value;
                _isMaxSet = true;
            }
        }

        protected PropertyValidator(int min, int max)
        {
            Min = min;
            Max = max;
        }

        public virtual void CheckValue(T value, string configFieldName)
        {
            if (!IsValid(value))
            {
                ThrowConfigurationError(value, configFieldName);
            }
        }

        protected abstract bool IsValid(T value);
        protected abstract void ThrowConfigurationError(T value, string configFieldName);
    }
}
