﻿using System.Configuration;

namespace Mandara.AdminAlertService.Configuration.Validation
{
    internal class IntegerRangeCheck : PropertyValidator<int>
    {
        private static readonly string _errorMessageTemplate =
            "{0} is invalid for '{1}'. Valid values are in the range {2} to {3}";

        public IntegerRangeCheck(int min, int max) : base(min, max)
        {
        }

        protected override bool IsValid(int value)
        {
            return Min <= value && Max >= value;
        }

        protected override void ThrowConfigurationError(int value, string configFieldName)
        {
            throw new ConfigurationErrorsException(
                string.Format(_errorMessageTemplate, value, configFieldName, Min, Max));
        }
    }
}
