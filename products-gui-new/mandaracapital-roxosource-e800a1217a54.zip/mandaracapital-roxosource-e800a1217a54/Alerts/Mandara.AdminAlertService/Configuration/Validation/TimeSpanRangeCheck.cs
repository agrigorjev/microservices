﻿
using System;
using System.Configuration;

namespace Mandara.AdminAlertService.Configuration.Validation
{
    internal class TimeSpanRangeCheck : PropertyValidator<TimeSpan>
    {
        private TimeSpan MinTime
        {
            get => TimeSpan.FromMilliseconds(Min);
            set => Min = (int)value.TotalMilliseconds;
        }

        private TimeSpan MaxTime
        {
            get => TimeSpan.FromMilliseconds(Max);
            set => Max = (int)value.TotalMilliseconds;
        }

        private static readonly TimeSpan DefaultMinTime = TimeSpan.Zero;
        private static readonly TimeSpan DefaultMaxTime = TimeSpan.FromMilliseconds(Int32.MaxValue);
        private static readonly string _errorMessageTemplate =
            "{0} is invalid for '{1}'. Valid times are in the range {2} to {3}";

        internal TimeSpanRangeCheck(TimeSpan min, TimeSpan max) : base(DefaultMin, DefaultMax)
        {
            MinTime = min;
            MaxTime = max;
        }

        internal static TimeSpanRangeCheck LowerBound(TimeSpan min)
        {
            return new TimeSpanRangeCheck(min, DefaultMaxTime);
        }

        internal static TimeSpanRangeCheck UpperBound(TimeSpan max)
        {
            return new TimeSpanRangeCheck(DefaultMinTime, max);
        }

        protected override bool IsValid(TimeSpan value)
        {
            return MinTime <= value && MaxTime >= value;
        }

        protected override void ThrowConfigurationError(TimeSpan value, string configFieldName)
        {
            throw new ConfigurationErrorsException(
                String.Format(_errorMessageTemplate, value, configFieldName, MinTime, MaxTime));
        }
    }
}
