﻿using System;
using System.Configuration;
using Mandara.AdminAlertService.Configuration.Validation;

namespace Mandara.AdminAlertService.Configuration
{
    internal class TriggersCheckInterval : ConfigurationElement
    {
        public const string ElemName = "triggersCheckInterval";
        public const string IntervalName = "minutes";
        private static readonly IntegerRangeCheck AtLeastOne = new IntegerRangeCheck(1, IntegerRangeCheck.DefaultMax);

        [ConfigurationProperty(IntervalName, DefaultValue = 1)]
        public int Minutes
        {
            get => (int)this[IntervalName];
            set
            {
                AtLeastOne.CheckValue(value, IntervalName);
                this[IntervalName] = value;
            }
        }

        public static readonly TriggersCheckInterval Default = new TriggersCheckInterval();
    }

    internal class TriggersUpdateFromDbInterval : ConfigurationElement
    {
        public const string ElemName = "triggersUpdateFromDbInterval";
        public const string IntervalName = "seconds";

        private static readonly IntegerRangeCheck AtLeastThirty = new IntegerRangeCheck(
            30,
            IntegerRangeCheck.DefaultMax); 

        [ConfigurationProperty(IntervalName, DefaultValue = 60)]
        public int Seconds
        {
            get => (int)this[IntervalName];
            set
            {
                AtLeastThirty.CheckValue(value, IntervalName);
                this[IntervalName] = value;
            }
        }

        public TimeSpan Interval => TimeSpan.FromSeconds(Seconds);

        public static readonly TriggersUpdateFromDbInterval Default = new TriggersUpdateFromDbInterval();
    }

    internal class SleepOnErrorInterval : ConfigurationElement
    {
        public const string ElemName = "sleepOnErrorInterval";
        public const string IntervalName = "seconds";
        private static readonly IntegerRangeCheck AtLeastThirty = new IntegerRangeCheck(
            30,
            IntegerRangeCheck.DefaultMax); 

        [ConfigurationProperty(IntervalName, DefaultValue = 60)]
        public int Seconds
        {
            get => (int)this[IntervalName];
            set
            {
                AtLeastThirty.CheckValue(value, IntervalName);
                this[IntervalName] = value;
            }
        }

        public TimeSpan Interval => TimeSpan.FromSeconds(Seconds);

        public static readonly SleepOnErrorInterval Default = new SleepOnErrorInterval();
    }

    internal class FailuresBeforeEscalationToLevel1 : ConfigurationElement
    {
        public const string ElemName = "failuresBeforeEscalationToLevel1";
        public const string NumFailuresName = "failures";
        private static readonly IntegerRangeCheck AtLeastOne = new IntegerRangeCheck(1, IntegerRangeCheck.DefaultMax);

        [ConfigurationProperty(NumFailuresName, DefaultValue = 3)]
        public int Count
        {
            get => (int)this[NumFailuresName];
            set
            {
                AtLeastOne.CheckValue(value, NumFailuresName);
                this[NumFailuresName] = value;
            }
        }

        public static readonly FailuresBeforeEscalationToLevel1 Default = new FailuresBeforeEscalationToLevel1();
    }

    internal class AlertsCheck : ConfigurationSection
    {
        public const string SectionName = "alertsCheck";

        [ConfigurationProperty(TriggersCheckInterval.ElemName, IsRequired = false)]
        public TriggersCheckInterval TriggersCheck
        {
            get => (this[TriggersCheckInterval.ElemName] as TriggersCheckInterval) ?? TriggersCheckInterval.Default;
            set => this[TriggersCheckInterval.ElemName] = value;
        }

        [ConfigurationProperty(TriggersUpdateFromDbInterval.ElemName, IsRequired = false)]
        public TriggersUpdateFromDbInterval TriggersUpdate
        {
            get =>
                (this[TriggersUpdateFromDbInterval.ElemName] as TriggersUpdateFromDbInterval)
                ?? TriggersUpdateFromDbInterval.Default;
            set => this[TriggersUpdateFromDbInterval.ElemName] = value;
        }

        [ConfigurationProperty(SleepOnErrorInterval.ElemName, IsRequired = false)]
        public SleepOnErrorInterval SleepOnError
        {
            get => (this[SleepOnErrorInterval.ElemName] as SleepOnErrorInterval) ?? SleepOnErrorInterval.Default;
            set => this[SleepOnErrorInterval.ElemName] = value;
        }

        [ConfigurationProperty(FailuresBeforeEscalationToLevel1.ElemName, IsRequired = false)]
        public FailuresBeforeEscalationToLevel1 FailuresBeforeEscalation
        {
            get =>
                (this[FailuresBeforeEscalationToLevel1.ElemName] as FailuresBeforeEscalationToLevel1)
                ?? FailuresBeforeEscalationToLevel1.Default;
            set => this[FailuresBeforeEscalationToLevel1.ElemName] = value;
        }

        public static AlertsCheck GetSection()
        {
            return ConfigurationManager.GetSection(SectionName) as AlertsCheck;
        }
    }
}
