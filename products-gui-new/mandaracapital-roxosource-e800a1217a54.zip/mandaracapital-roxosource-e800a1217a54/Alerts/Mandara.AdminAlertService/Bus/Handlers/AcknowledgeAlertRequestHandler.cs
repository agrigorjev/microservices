﻿using JetBrains.Annotations;
using Mandara.Business.Bus.Handlers.Base;
using Mandara.Business.Bus.Messages.AdmAlerts;
using Mandara.Business.PublishSubscribe;

namespace Mandara.AdminAlertService.Bus.Handlers
{
    public class AcknowledgeAlertRequestHandler: RequestHandler<AcknowledgeAlertRequestMessage>
    {
        public AcknowledgeAlertRequestHandler([NotNull] IResponder responder) : base(responder)
        {
        }

        public override void Handle(AcknowledgeAlertRequestMessage message)
        {
            PubSub.SendMessage(message);

            AcknowledgeAlertResponseMessage responseMessage = new AcknowledgeAlertResponseMessage
                                                                  {
                                                                      TriggerKey = message.TriggerKey
                                                                  };

            Respond(responseMessage);
        }
    }
}