﻿using Mandara.Bus.Common.Server.Commands;
using com.latencybusters.lbm;
using Mandara.Business.Bus;
using Mandara.Business.Bus.Handlers.Base;
using Mandara.Business.Bus.Messages.Base;

namespace Mandara.AdminAlertService.Bus.Handlers
{
    /// <summary>
    /// Service class to redirect handle for proper processing
    /// </summary>
    /// <typeparam name="T">Type of snapshot request message</typeparam>
    public class SnapshotHandler<T> : IHandler where T : SnapshotMessageBase
    {
        /// <summary>
        /// Performs deserialization of request message and add command for process message to queue
        /// </summary>
        /// <param name="topicName">Topic name (All snapshot request topics)</param>
        /// <param name="lbmMessage">Snapshot request message</param>
        /// <param name="receivedEpoch">Received UTC epoch timestamp of the message</param>
        public void Handle(string topicName, LBMMessage lbmMessage,long receivedEpoch)
        {
            T message = null;

            switch (lbmMessage.type())
            {
                case LBM.MSG_BOS:
                    break;

                case LBM.MSG_EOS:
                    break;

                case LBM.MSG_REQUEST:
                    message = JsonHelper.Deserialize<T>(lbmMessage.data());
                    message.ReceivedAt = receivedEpoch;
                    break;

                default:
                    break;
            }

            if (message == null)
            {
                return;
            }

            AdminAlertService.Instance.CommandManager.AddCommand
                (new SnapshotResolveCommand(topicName, message, InformaticaHelper.BuildResponder(lbmMessage)));
        }
    }
}
