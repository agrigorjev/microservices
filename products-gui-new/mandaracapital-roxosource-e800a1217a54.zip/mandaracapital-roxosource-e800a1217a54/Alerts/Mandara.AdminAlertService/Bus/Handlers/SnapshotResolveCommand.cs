using System;
using Mandara.Business.Bus.Commands.Base;
using Mandara.Business.Bus.Messages.Base;
using NLog;
using com.latencybusters.lbm;
using Mandara.Business.Bus;

namespace Mandara.AdminAlertService.Bus.Handlers
{
    /// <summary>
    /// Service command used to handle snapshot requests.
    /// </summary>
    public class SnapshotResolveCommand : BusCommandBase
    {
        private readonly string _topicName;
        private SnapshotMessageBase _message;

        private readonly Logger _log = LogManager.GetCurrentClassLogger();
        private readonly InformaticaResponder _responder;

        public SnapshotResolveCommand(string topicName, SnapshotMessageBase message, InformaticaResponder respond)
        {
            _topicName = topicName;
            _message = message;
            _responder = respond;
        }

        public override void Execute()
        {
            switch (_message.SnapshotMessageType)
            {
                case SnapshotMessageType.SnapshotRequest:
                {
                    OnSnapshotRequest();
                }
                break;

                case SnapshotMessageType.SnapshotDataRequest:
                {
                    OnSnapshotDataRequest();
                }
                break;

                case SnapshotMessageType.SnapshotDataRetryRequest:
                {
                    OnSnapshotDataRetryRequest();
                }
                break;

                case SnapshotMessageType.Data:
                case SnapshotMessageType.EndOfSnapshot:
                case SnapshotMessageType.SnapshotRequestResponse:
                case SnapshotMessageType.SnapshotDataRequestResponse:
                case SnapshotMessageType.SnapshotDataRetryResponse:
                {
                    _log.Warn("Invalid SnapshotMessageType in SnapshotResolveCommand");
                }
                break;

                default:
                {
                    throw new ArgumentOutOfRangeException(
                        $"{_message.SnapshotMessageType} is not a recognised snapshot message type");
                }
            }
        }

        private void OnSnapshotDataRequest()
        {
            if (!_message.SnapshotId.HasValue)
                return;

            _message.SnapshotMessageType = SnapshotMessageType.SnapshotDataRequestResponse;
            Respond();

            CommandManager.RunStoredCommand(_message.SnapshotId.Value);
        }

        private void OnSnapshotRequest()
        {
            SnapshotCommandBase command = AdminAlertService.Instance.InformaticaHelper.GetSnapshotCommand(_topicName, ref _message);
            CommandManager.StoreCommand(command, command.Message.SnapshotId.Value);

            _message.SnapshotMessageType = SnapshotMessageType.SnapshotRequestResponse;
            Respond();

            // it's a bad code and need to be reworked along with the rest of this class
            // Messages should be created by command itself
            _message.SnapshotMessageType = SnapshotMessageType.Data;
        }

        private void OnSnapshotDataRetryRequest()
        {
            _log.Debug("Got data retry request");
            var command = AdminAlertService.Instance.InformaticaHelper.GetSnapshotDeliveryCommand(_message.SnapshotId.Value, _message);

            if (command.DeliveryContext.DataReady)
            {
                command.DeliveryContext.SnapshotData.RemoveMessages(_message.ReceivedSequences);
                CommandManager.AddCommand(command);
                _message.SnapshotMessageType = SnapshotMessageType.SnapshotDataRetryResponse;
                Respond();
            }
            else
            {
                _responder.Dispose();
            }
        }

        private void Respond()
        {
            RespondToLbmMessage(_responder, _message);
            _responder.Dispose();
        }
    }
}