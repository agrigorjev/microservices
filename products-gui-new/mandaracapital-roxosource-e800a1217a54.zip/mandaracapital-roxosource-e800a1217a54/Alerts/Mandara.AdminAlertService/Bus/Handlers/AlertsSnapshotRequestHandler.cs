﻿using System;
using System.Collections.Generic;
using System.Threading;
using JetBrains.Annotations;
using Mandara.Business.Bus.Handlers.Base;
using Mandara.Business.Bus.Messages.AdmAlerts;
using Mandara.Business.PublishSubscribe;
using Mandara.Business.PublishSubscribe.Events.Alerts;

namespace Mandara.AdminAlertService.Bus.Handlers
{
    public class AlertsSnapshotRequestHandler : RequestHandler<AdmAlertsSnapshotRequestMessage>
    {
        private readonly ManualResetEvent _event = new ManualResetEvent(false);

        public AlertsSnapshotRequestHandler([NotNull] IResponder responder) : base(responder)
        {
        }
        public override void Handle(AdmAlertsSnapshotRequestMessage message)
        {
            if (message == null || string.IsNullOrEmpty(message.IrmUserName))
                return;

            PubSub.SendMessage(new AlertsSnapshotEvent<List<AdmAlertDto>>(message.UserName, SnapshotCallback));

            _event.WaitOne(TimeSpan.FromSeconds(10));
        }

        private void SnapshotCallback(List<AdmAlertDto> alerts)
        {
            Respond(new AdmAlertsSnapshotResponseMessage {AdmAlerts = alerts});

            _event.Set();
        }

        
    }
}