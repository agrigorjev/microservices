﻿using System;
using Mandara.AdminAlertService.Bus.Handlers;
using Mandara.Bus.Common.Server;
using Mandara.Business.Bus;
using Mandara.Business.Bus.Handlers;
using Mandara.Business.Bus.Handlers.Base;
using Mandara.Business.Bus.Messages.AdmAlerts;
using com.latencybusters.lbm;
using Mandara.Extensions.Collections;

namespace Mandara.AdminAlertService.Bus
{
    class AlertsInformaticaHelper : ServerInformaticaHelperBase
    {

        public AlertsInformaticaHelper(LBMContext lbmContext, HandlerManager handlerManager) 
            : base(lbmContext, handlerManager) {}

        public override void CreateSources()
        {
            base.CreateSources();

            CreateSources(AdmAlertTopic);
            CreateSources(AdmAlertAcknowledgeDoneTopic);

            AddSnapshotCommands(AdmAlertHistorySnapshotTopic);
        }

        private void CreateSources(string topic)
        {
            GetAllServerAwareTopicNames(topic).ForEach(AddSource);
        }

        public override void CreateReceivers()
        {
            base.CreateReceivers();

            CreateReceivers(AdmAlertAcknowledgeTopic, typeof(AcknowledgeAlertRequestHandler));
            CreateReceivers(AdmAlertsSnapshotTopic, typeof(AlertsSnapshotRequestHandler));
            CreateReceivers(AdmAlertHistorySnapshotTopic, typeof(SnapshotHandler<AlertsHistorySnapshotMessage>));
        }

        private void CreateReceivers(string topic, Type handler)
        {
            GetAllServerAwareTopicNames(topic).ForEach(serverTopicName => AddReceiver(serverTopicName, handler));
        }

        private void AddSnapshotCommands(string topic)
        {
            GetAllServerAwareTopicNames(topic).ForEach(
                serverTopicName => AddSnapshotCommand(serverTopicName, typeof(AlertsHistorySnapshotCommand)));
        }
    }
}
