﻿using System;
using Mandara.Business.AdministrativeAlerts;
using Mandara.Business.Bus.Commands.Base;
using Mandara.Business.Bus.Messages.AdmAlerts;

namespace Mandara.AdminAlertService.Bus
{
    public class AlertsHistorySnapshotCommand : SnapshotCommandBase
    {
        public override void Execute()
        {
            AlertsHistorySnapshotMessage snapshotMessage = Message as AlertsHistorySnapshotMessage;

            if (snapshotMessage != null)
            {
                try
                {
                    snapshotMessage.AlertHistories = AdmAlertHelper.GetHistoryEntriesAt(snapshotMessage.Date);
                    DeliveryContext.SnapshotData.AddMessage(snapshotMessage);
                }
                catch (Exception ex)
                {
                    AlertsHistorySnapshotMessage errorMessage = new AlertsHistorySnapshotMessage {ErrorMessage = ex.Message};
                    errorMessage.SnapshotId = snapshotMessage.SnapshotId;

                    DeliveryContext.SnapshotData.AddMessage(errorMessage);
                }
            }

            SendPackage();
        }
    }
}