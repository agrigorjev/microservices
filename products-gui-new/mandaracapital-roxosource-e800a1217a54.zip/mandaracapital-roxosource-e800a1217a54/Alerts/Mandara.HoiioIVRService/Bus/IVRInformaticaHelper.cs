﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Mandara.Bus.Common.Server;
using com.latencybusters.lbm;
using Mandara.Business.Bus.Handlers.Base;

namespace Mandara.HoiioIVRService.Bus
{
    class IVRInformaticaHelper: ServerInformaticaHelperBase
    {
        public IVRInformaticaHelper(LBMContext lbmContext, HandlerManager handlerManager) 
            : base(lbmContext, handlerManager) {}

        public override void CreateSources()
        {
            base.CreateSources();
            AddSource(AdmAlertAcknowledgeDoneTopicName);
        }

        public override void CreateReceivers()
        {
            base.CreateReceivers();
            AddReceiver(AdmAlertAcknowledgeTopicName, typeof(AcknowledgeAlertRequestHandler));
        }
    }
}
