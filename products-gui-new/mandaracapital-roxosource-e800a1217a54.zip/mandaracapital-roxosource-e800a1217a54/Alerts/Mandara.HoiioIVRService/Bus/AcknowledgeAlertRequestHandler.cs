﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Mandara.Business.Bus.Messages.AdmAlerts;
using Mandara.Business.Bus.Handlers.Base;
using System.Threading;
using Mandara.Business.PublishSubscribe.Events.Alerts;
using Mandara.Business.PublishSubscribe;

namespace Mandara.HoiioIVRService.Bus
{
    class AcknowledgeAlertRequestHandler : RequestHandler<AdmAlertsSnapshotRequestMessage>
    {
        private readonly ManualResetEvent _event = new ManualResetEvent(false);

        protected override void Handle(AdmAlertsSnapshotRequestMessage message)
        {
            if (message == null || string.IsNullOrEmpty(message.IrmUserName))
                return;

            PubSub.SendMessage(new AlertsSnapshotEvent<List<AdmAlertDto>>(message.UserName, SnapshotCallback));

            _event.WaitOne(TimeSpan.FromSeconds(10));
        }

        private void SnapshotCallback(List<AdmAlertDto> alerts)
        {
            Respond(new AdmAlertsSnapshotResponseMessage { AdmAlerts = alerts });

            _event.Set();
        }
    }
}
