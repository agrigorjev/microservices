﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Mandara.Business.AsyncServices.Base;
using System.Collections.Concurrent;
using Mandara.Entities;
using Mandara.Business.AdministrativeAlerts;
using Mandara.HoiioIVRService.CallUtility;
using Roxosoft.Common.TaskSchedulers;
using NLog;
using System.Threading.Tasks;
using System.Threading;
using Mandara.HoiioIVRService.HttpUtility;
using HoiioSDK.NET;
using Mandara.Entities.ErrorReporting;
using Mandara.Business.Bus.Messages.AdmAlerts;
using Mandara.Business.PublishSubscribe;
using Mandara.Business.Bus;
using System.Globalization;

namespace Mandara.HoiioIVRService.AsyncServices
{
    /// <summary>
    /// Serves voice calls processung
    /// </summary>
    class QueueService : AsyncService
    {
        private ConcurrentQueue<CallSession> _activeQueue;

        private ConcurrentDictionary<string, CallSession> _sessionsInProgress;
        private ConcurrentBag<int> _ignoreTriggers;
        private DateTime _lastHistoryCheck = DateTime.Now.Date;
        private int _idleTimeout = 10;
        private int _lastProcessedId = 0;
        Logger _log = HoiioIVRService.Instance.Log;
        private readonly LimitedConcurrencyLevelTaskScheduler _scheduler;
        private static String ACKNOWLEDGE_CODE = System.Configuration.ConfigurationManager.AppSettings["AcknowledgeCode"] ?? "1";
        BusClient _busClient;
        private List<string> _phonesInProgress;
        private static object locklist = new object();
        /// <summary>
        /// Initialize instance
        /// </summary>
        /// <param name="client">Bus client reference</param>
        public QueueService(BusClient client)
        {

            _busClient = client;
            _scheduler = new LimitedConcurrencyLevelTaskScheduler(10);
            _activeQueue = new ConcurrentQueue<CallSession>();
            _sessionsInProgress = new ConcurrentDictionary<string, CallSession>();
            _ignoreTriggers = new ConcurrentBag<int>();
            _phonesInProgress = new List<string>();
        }
        /// <summary>
        /// Maintains collection of concurrent calls. 
        /// </summary>
        /// <param name="session">Call session to process</param>
        private void MaintainCollection(CallSession session)
        {
            Task.Factory.StartNew(() =>
            {
                try
                {

                    switch (session.Stage)
                    {
                        //Add to processes session on dial start
                        case CallSession.CallStage.Dial:
                            if (string.IsNullOrEmpty(session.SessionId))
                            {
                                _activeQueue.Enqueue(session);
                            }
                            else
                            {
                                _sessionsInProgress.AddOrUpdate(session.SessionId, session, (key, val) => session);
                            }
                            break;
                        //Remove from active session and store state in db on call end
                        case CallSession.CallStage.Finished:
                            if (string.IsNullOrEmpty(session.SessionId))
                            {
                                _activeQueue.Enqueue(session);
                            }
                            else
                            {
                                RemoveFromActiveList(session.Phone);
                                _sessionsInProgress.TryRemove(session.SessionId, out session);
                                
                            }
                            break;
                        //Remove from active session and store in queue for retry
                        case CallSession.CallStage.Retry:
                            //If retry setup wait call dictionary entry to dial again timeout
                            if (string.IsNullOrEmpty(session.SessionId))
                            {
                                _activeQueue.Enqueue(session);
                            }
                            else
                            {
                                CallSession outOf = null;
                                RemoveFromActiveList(session.Phone);
                                _sessionsInProgress.TryRemove(session.SessionId, out outOf);

                                _activeQueue.Enqueue(session);
                            }

                            break;
                    }
                    UpdateDbStatus(session);
                }
                catch (Exception ex)
                {
                    _log.Debug("Exception processing session {0} {1} : {2}", session.SessionId ?? "", session.Phone ?? "", ex.Message);
                }


            }, CancellationToken.None, TaskCreationOptions.None, _scheduler);
        }
        /// <summary>
        /// Save to db actual call state
        /// </summary>
        /// <param name="session"></param>
        private void UpdateDbStatus(CallSession session)
        {
            AdminAlertVoiceCall call = new AdminAlertVoiceCall()
            {
                CallId = session.RefId,
                RetryNum = session.Trials
            };
            if (session.LastDialed > DateTime.MinValue)
                call.DialedAt = session.LastDialed;
            switch (session.Stage)
            {
                case CallSession.CallStage.No:
                    call.Status = AdminAlertVoiceCall.CallState.Queued;
                    break;
                case CallSession.CallStage.Retry:
                    call.Status = AdminAlertVoiceCall.CallState.InRetry;
                    break;
                case CallSession.CallStage.Finished:
                    call.Status = AdminAlertVoiceCall.CallState.Served;
                    break;
                case CallSession.CallStage.Interrupted:
                    call.Status = AdminAlertVoiceCall.CallState.Interrupted;
                    break;
                default:
                    call.Status = AdminAlertVoiceCall.CallState.InProgress;
                    break;
            }
            switch (session.LastResult)
            {
                case CallSession.CallResult.Failed:
                case CallSession.CallResult.Unanswered:
                case CallSession.CallResult.Busy:
                    call.Result = CallResult.Fail;
                    break;
                case CallSession.CallResult.Answered:
                case CallSession.CallResult.Success:
                    call.Result = CallResult.Success;
                    break;
                default:
                    call.Result = CallResult.NaN;
                    break;
            }
            AdmAlertHelper.UpdateVoiceCall(call);

        }
        /// <summary>
        /// Performs update of voice calls,sessions and monitor acknowledged ot inactive triggered alerts
        /// </summary>
        protected override void DoWork()
        {
            try
            {
                UpdateQueue();
                List<CallSession> tempStore = new List<CallSession>(); ;
                while (!_activeQueue.IsEmpty && _sessionsInProgress.Count < 8)
                {
                    CallSession start;
                    if (_activeQueue.TryDequeue(out start))
                    {
                        //Check if current trigger no longer needs processing
                        if (!_ignoreTriggers.Contains(start.ReferencedHistory))
                        {
                            //Check if call should be dialed (check retry timeouts mostly)
                            if (start.Ready && CheckWait(start.Phone))
                            {
                                AddToActiveList(start.Phone);
                                start.Stage = CallSession.CallStage.No;
                                start.SessionId = string.Empty;
                                //Add to waitcall list to track phone added to dial list
                                start.Advance(MaintainCollection);
                            }
                            else
                            {
                                //if not need immediately processing - delay
                                tempStore.Add(start);
                            }
                        }
                        else
                        {
                            start.Stage = CallSession.CallStage.Interrupted;
                            UpdateDbStatus(start);
                        }
                    }

                }
                if (tempStore.Count > 0)
                {
                    //return delayed to queue awaiting processing
                    tempStore.ForEach(i => _activeQueue.Enqueue(i));
                }
                System.Threading.Thread.Sleep(_idleTimeout);
            }
            catch (Exception ex)
            {
                ErrorReportingHelper.ReportError("IVR Service", ErrorType.Exception, "IVR Service encounter an error during initialization IVR Service will be paused for a while.", null, ex, ErrorLevel.Critical);

                // on error we suspend service execution
                Thread.Sleep(_idleTimeout);
            }
        }

        /// <summary>
        /// Maintain actual processed phone list. Add new item
        /// </summary>
        /// <param name="value">Phone number as string</param>
        private void AddToActiveList(string value)
        {
            lock(locklist)
            {
                if (_phonesInProgress == null) _phonesInProgress = new List<string>();
                if (!_phonesInProgress.Contains(value))
                    _phonesInProgress.Add(value);
            }
        }
        /// <summary>
        /// Maintain actual processed phone list. Remove item
        /// </summary>
        /// <param name="value">Phone number as string</param>
        private void RemoveFromActiveList(string value)
        {
            lock (locklist)
            {
                if (_phonesInProgress == null) _phonesInProgress = new List<string>();
                _phonesInProgress.Remove(value);
            }
        }
        /// <summary>
        /// Check whether current number dialed lately
        /// </summary>
        /// <param name="phone">Phone number to check</param>
        /// <returns></returns>
        private bool CheckWait(string phone)
        {
            lock (locklist)
            {
                if (_phonesInProgress == null) _phonesInProgress = new List<string>();
                return !_phonesInProgress.Contains(phone);
            }
        }
        /// <summary>
        /// Update calls and history record from db
        /// </summary>
        private void UpdateQueue()
        {


            List<AdminAlertVoiceCall> list = AdmAlertHelper.ActualAlerts(_lastProcessedId);
            if (list.Count > 0)
            {
                _lastProcessedId = list.Max(l => l.CallId);
                list.ForEach(c => _activeQueue.Enqueue(new CallSession(c)));
            }
            List<int> ignoreTriggers = AdmAlertHelper.AcknowledgedOrInactiveTriggersAt(_lastHistoryCheck);
            ignoreTriggers.ForEach(t => _ignoreTriggers.Add(t));

        }
        /// <summary>
        /// Parse Http request from Hoiio
        /// </summary>
        /// <param name="info">string representation of request</param>
        public void ProcessHoiioResponse(string info)
        {

            Task.Factory.StartNew(() =>
            {
                CultureInfo cCulture = CultureInfo.CurrentCulture;
                Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;
                try
                {
                    IVRNotification ivrNotify = HoiioService.parseIVRNotify(info);
                    ServeCall(ivrNotify);
                }
                catch (Exception ex)
                {
                    _log.Debug("Exception parsing Hoiio request: {0}", ex.Message);
                }
                Thread.CurrentThread.CurrentCulture = cCulture;
            }, CancellationToken.None, TaskCreationOptions.None, _scheduler);

        }
        /// <summary>
        /// Process call session depending on call state
        /// </summary>
        /// <param name="ivrNotify"></param>
        private void ServeCall(IVRNotification ivrNotify)
        {

            CallSession session = null;
            if (_sessionsInProgress.TryGetValue(ivrNotify.session, out session))
            {
                switch (ivrNotify.callState)
                {
                    case IVRStatusTypes.ENDED:
                        if ((int)session.Stage <= (int)CallSession.CallStage.Play)
                        {
                            switch (ivrNotify.dialStatus)
                            {
                                case CallStatusTypes.BUSY:
                                    session.SetBusy(MaintainCollection);
                                    break;
                                case CallStatusTypes.UNANSWERED:
                                    session.SetUnunswered(MaintainCollection);
                                    break;
                                case CallStatusTypes.FAILED:
                                    session.SetFailed(MaintainCollection);
                                    break;
                                default:
                                    session.LastResult = CallSession.CallResult.Failed;
                                    session.Stage = CallSession.CallStage.Finished;
                                    MaintainCollection(session);
                                    break;

                            }
                        }
                        else if (ivrNotify.dialStatus == CallStatusTypes.UNDEFINED)
                        {
                            session.Advance(MaintainCollection);
                        }
                        //session.Stage = CallSession.CallStage.HangUp;
                        break;
                    case IVRStatusTypes.ONGOING:
                        if (session.Stage == CallSession.CallStage.Gather &&
                           !string.IsNullOrEmpty(ivrNotify.digits.Trim()))
                        {
                            _log.Debug("Gathered '{0}' from {1}", ivrNotify.digits, session.Phone);
                            if (ivrNotify.digits == "1") Acknowledge(session.AlertTrigger, session.Phone);
                            session.LastResult = CallSession.CallResult.Success;
                        }
                        session.Advance(MaintainCollection);
                        break;
                    default:
                        break;

                }

            }
        }
        /// <summary>
        /// Acknowledge alert
        /// </summary>
        /// <param name="triggerKey"></param>
        /// <param name="phone"></param>
        private void Acknowledge(string triggerKey, string phone)
        {
            AcknowledgeAlertRequestMessage requestMessage =
                                new AcknowledgeAlertRequestMessage()
                                {
                                    TriggerKey = triggerKey,
                                    UserName = phone
                                };
            Task.Factory.StartNew(() =>
            {
                try
                {
                    _busClient.SendRequest<AcknowledgeAlertRequestMessage, AcknowledgeAlertResponseMessage>(
                                       InformaticaHelper.AdmAlertAcknowledgeTopicName, requestMessage,
                                       null);
                }
                catch (Exception ex)
                {
                    _log.Debug("Exception acknowledging: {0}", ex.Message);
                }
            }, CancellationToken.None, TaskCreationOptions.None, _scheduler);
        }
    }
}
