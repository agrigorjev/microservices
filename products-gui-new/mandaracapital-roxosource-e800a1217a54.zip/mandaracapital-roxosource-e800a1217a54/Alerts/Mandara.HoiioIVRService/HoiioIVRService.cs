﻿using System;
using System.Threading;
using Mandara.Bus.Common.Server;
using Mandara.Business.Bus;
using Mandara.Business.PublishSubscribe;
using Mandara.HoiioIVRService.Bus;
using System.Reactive.Linq;
using System.Linq;
using NLog;
using System.Collections.Concurrent;
using Mandara.Entities;
using Mandara.Business.AsyncServices.Base;
using Mandara.HoiioIVRService.AsyncServices;
using Mandara.Bus.Common.Server.AsyncServices;
using Mandara.Entities.ErrorReporting;
using System.ComponentModel;
namespace Mandara.HoiioIVRService
{
    /// <summary>
    /// Windows service for place voice call
    /// </summary>
    public partial class HoiioIVRService : ServerBase
    {
        public readonly Logger Log = LogManager.GetCurrentClassLogger();
        private IDisposable _stopEvent;
        private BusClient _busClient;
        private  HttpUtility.HoiioListener _httpListener;
        private QueueService _voiceService;
        private static HoiioIVRService _instance;
        public static HoiioIVRService Instance { get { return _instance; } }
        public HoiioIVRService()
        {
            try
            {
                _instance = this;
                _busClient = new BusClient();
                _busClient.Start(turnOnMatchingDummies: false, turnOnErrorsReceiver: false);
                if (_voiceService == null)
                    _voiceService = new QueueService(_busClient);
                _httpListener = new HttpUtility.HoiioListener(_voiceService);
                _busClient.SequenceReset -= BusClientOnSequenceReset;
                _busClient.SequenceReset += BusClientOnSequenceReset;
                _stopEvent = PubSub.Listen<StopServiceEvent>()
                                   .ObserveOn(SynchronizationContext.Current)
                                   .Subscribe(_ => Stop());
            }
            catch (Exception ex)
            {
                ErrorReportingHelper.ReportError("IVR Service", ErrorType.Exception, "IVR Service encounter an error during initialization IVR Service will be paused for a while.", null, ex, ErrorLevel.Critical);
                Log.Error("Initialization IVR service error: {0}", ex.Message);
            }
        }
        private void BusClientOnSequenceReset(object sender, EventArgs eventArgs)
        {
            if (_voiceService != null)
            {
                _voiceService.Stop();

                while (_voiceService.IsRunning)
                {
                    Thread.Sleep(200);
                }
                _voiceService.Start();
            }
            if (_httpListener != null)
            {
                _httpListener.Stop();
                Thread.Sleep(200);
                _httpListener.Start();
            }
        }
        public override void Start()
        {
            BackgroundWorker serviceInitilizerWorker = new BackgroundWorker();
            serviceInitilizerWorker.DoWork += serviceInitilizerWorker_DoWork;
            serviceInitilizerWorker.RunWorkerCompleted += LogError_RunWorkerCompleted;
            serviceInitilizerWorker.RunWorkerAsync();
        }

        void LogError_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            var worker = sender as BackgroundWorker;

            if (worker == null)
                return;

            if (e.Cancelled)
                return;

            if (e.Error != null)
            {
                ErrorReportingHelper.ReportError("IVR Service", ErrorType.Exception, "Server core error.", null, e.Error, ErrorLevel.Critical);
                HoiioIVRService.Instance.Log.Error("Server core error. Service start failed. {0}", e.Error.Message);
            }
        }

        void serviceInitilizerWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            try
            {
                base.Start();
                _httpListener.Start();
            }
            catch (Exception ex)
            {
                ErrorReportingHelper.ReportError("IVR Service", ErrorType.Exception, "Server core error.", null, ex, ErrorLevel.Critical);
                HoiioIVRService.Instance.Log.Error("Server core error. Service start failed. {0}", ex.Message);
            }
        }

        public override void Stop()
        {
            if (_busClient != null)
            {
                _busClient.SequenceReset -= BusClientOnSequenceReset;

                _busClient.Stop();
            }
            Instance._httpListener.Stop();

            if (_stopEvent != null)
                _stopEvent.Dispose();

            base.Stop();
        }
        protected override string ServerName
        {
            get { return "Mandara Hoiio Voice Call Service"; }
        }
        protected override ServerInformaticaHelperBase CreateInformaticaHelper(com.latencybusters.lbm.LBMContext lbmContext, Mandara.Business.Bus.Handlers.Base.HandlerManager handlerManager)
        {
            return new IVRInformaticaHelper(lbmContext, handlerManager);
        }
        protected override AsyncService[] CreateAsyncServices()
        {
            if (_voiceService == null)
                _voiceService = new QueueService(_busClient);

            return base.CreateAsyncServices().Concat(new AsyncService[] { _voiceService }).ToArray();
        }

        
    }
}
