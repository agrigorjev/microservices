﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Mandara.Entities;
using HoiioSDK.NET;
using System.Threading;
using System.Globalization;

namespace Mandara.HoiioIVRService.CallUtility
{
    /// <summary>
    /// Class representing voice call. Contains actual call information and methods to preceed from stage to stage
    /// </summary>
    public class CallSession
    {
        
        private static NLog.Logger _log = NLog.LogManager.GetCurrentClassLogger();
        #region Configuration parameters
        private static String APP_ID = System.Configuration.ConfigurationManager.AppSettings["HoiioApplicationID"] ?? "u352sQCPwI1KgOnp";
        private static String ACCESS_TOKEN = System.Configuration.ConfigurationManager.AppSettings["HoiioToken"] ?? "Qd2y6ycNdKZse9Rs";
        private static String SENDER_NAME = System.Configuration.ConfigurationManager.AppSettings["HoiioSender"] ?? "";
        private static String NOTIFY_URL = System.Configuration.ConfigurationManager.AppSettings["HoiioNotifyUrl"] ?? "http://188.134.2.113:8080/";
        private static String BusyRedialIn = System.Configuration.ConfigurationManager.AppSettings["BusyTimeout"] ?? "5";
        private static TimeSpan BUSY_REDIAL
        {
            get
            {
                int redialminutes = 5;
                int.TryParse(BusyRedialIn, out redialminutes);
                return TimeSpan.FromMinutes(redialminutes);
            }
        }
        
        private static String UnansweredRedialIn = System.Configuration.ConfigurationManager.AppSettings["UnunsweredRedialTimeout"] ?? "10";
        private static TimeSpan UNANSWERED_REDIAL
        {
            get
            {
                int redialminutes = 5;
                int.TryParse(UnansweredRedialIn, out redialminutes);
                return TimeSpan.FromMinutes(redialminutes);
            }
        }

        private static String FailRedialIn = System.Configuration.ConfigurationManager.AppSettings["RedialTimeoutOnFail"] ?? "120";
        private static TimeSpan FAIL_REDIAL
        {
            get
            {
                int redialminutes = 120;
                int.TryParse(FailRedialIn, out redialminutes);
                return TimeSpan.FromMinutes(redialminutes);
            }
        }

        private static String UnansweredRetryCount = System.Configuration.ConfigurationManager.AppSettings["MaxRetryOnUnanswered"] ?? "3";
        private static int MAX_UNANSWERED_TRIALS
        {
            get
            {
                int tryUpTo = 3;
                int.TryParse(UnansweredRetryCount, out tryUpTo);
                return tryUpTo;
            }
        }
        
        private static String BusyRetryCount = System.Configuration.ConfigurationManager.AppSettings["MaxRetryOnBusy"] ?? "5";
        private static int MAX_BUSY_TRIALS
        {
            get
            {
                int tryUpTo = 5;
                int.TryParse(BusyRetryCount, out tryUpTo);
                return tryUpTo;
            }
        }

        private static String MaxFailRetryCount = System.Configuration.ConfigurationManager.AppSettings["MaxRetryOnFail"] ?? "2";
        private static int MAX_FAIL_TRIALS
        {
            get
            {
                int tryUpTo = 2;
                int.TryParse(MaxFailRetryCount, out tryUpTo);
                return tryUpTo;
            }
        }
        
        private String ACKNOWLEDGE_MESSAGE = System.Configuration.ConfigurationManager.AppSettings["AcknowledgeMessage"] ?? "Press 1 to acknowledgeor press 2 to end call.";
        private String HELLO_MESSAGE = System.Configuration.ConfigurationManager.AppSettings["HelloMessage"] ?? "Hello. Mandara triggered alert.";
        private String BYE_MESSAGE = System.Configuration.ConfigurationManager.AppSettings["ByeMessage"] ?? "Thank you. Good bye.";
        private String ACTUALVALUE_MESSAGE = System.Configuration.ConfigurationManager.AppSettings["ActualValueMessage"] ?? "Actual value is {0}";
        #endregion
        public HoiioSDK.NET.IVRStatusTypes SessionState
        { 
                    get;
                    set;
        }
        public HoiioSDK.NET.HoiioResponse ServerState
        {
            get;
            set;
        }

        //private Action<HoiioSDK.NET.IVRTransaction, CallSession> _dialCallback;
        private Action<CallSession> _callback;
        /// <summary>
        /// Reference history id item
        /// </summary>
        public int RefId { get; set; }
        public string SessionId { get; set; }

        public int ReferencedHistory { get; set; }
        public string Message { get; set; }
        public string Phone { get; set; }
        public string ActualValue { get; set; }
        public int Trials { get; set; }
        
        /// <summary>
        /// Current stage of call according Hoiio step be sptep IVR routine
        /// </summary>
        public enum CallStage
        {
            No,
            Interrupted,
            Dial,
            Play,
            Gather,
            HangUp,
            Finished,
            Retry

        }
        /// <summary>
        /// Result marks indication how  call should be treated
        /// </summary>
        public enum CallResult
        {
            Unknown,
            Busy,
            Unanswered,
            Failed,
            Answered,
            Success
        }

        public CallStage Stage {get;set;}
        public CallResult LastResult { get; set; }

        public DateTime LastDialed { get; set; }
        public DateTime NextDialIn { get; set; }

        public string AlertTrigger { get; set; }
        #region Constructors
        public CallSession(AdminAlertVoiceCall call)
        {
            AlertTrigger = call.TriggerKey;
            RefId = call.CallId;
            Message =call.Message;
            Phone = call.Phone;
            LastDialed = call.DialedAt.GetValueOrDefault();
            switch (call.Status)
            {
                case AdminAlertVoiceCall.CallState.InProgress:
                case AdminAlertVoiceCall.CallState.InRetry:
                    Stage = CallStage.Retry;
                    break;
                case AdminAlertVoiceCall.CallState.Queued:
                    Stage = CallStage.No;
                    break;
                default:
                    Stage = CallStage.Finished;
                    break;
            }
            NextDialIn = DateTime.MinValue;
            LastResult = CallResult.Unknown;
            Trials = call.RetryNum.GetValueOrDefault();
            SessionId = string.Empty;
            ActualValue = call.ActualValue;
            ReferencedHistory = call.AlertHistoryId;
        }
        public CallSession(CallSession call)
        {
            AlertTrigger = call.AlertTrigger;
            RefId = call.RefId;
            Message = call.Message;
            Phone = call.Phone;
            Stage = call.Stage;
            LastResult = call.LastResult;
            Trials = call.Trials;
            SessionId = string.Empty;
            NextDialIn = call.NextDialIn;
            ReferencedHistory = call.ReferencedHistory;
        }
        #endregion
        /// <summary>
        /// Check if call needs to be started
        /// </summary>
        public bool Ready
        {
            get
            {
                return Trials==0 ||( Stage==CallStage.Retry && NextDialIn <= DateTime.Now);
            }
        }
        /// <summary>
        /// Set call result to busy
        /// </summary>
        /// <param name="callback">Callback to queue processing routine</param>
        public void SetBusy(Action<CallSession> callback)
        {
            Stage = CallStage.Retry;
            LastResult = CallResult.Busy;
            NextDialIn = DateTime.Now.Add(BUSY_REDIAL);
            if (callback != null) callback(this);

        }
        /// <summary>
        /// Set call result to unanswered
        /// </summary>
        /// <param name="callback">Callback to queue processing routine</param>
        public void SetUnunswered(Action<CallSession> callback)
        {
            Stage = CallStage.Retry;
            LastResult = CallResult.Busy;
            NextDialIn = DateTime.Now.Add(UNANSWERED_REDIAL);
            if (callback != null) callback(this);

        }
        /// <summary>
        /// Perform next operation in call processing oredr
        /// </summary>
        /// <param name="callback">Callback to queue processing routine</param>
        public void SetFailed(Action<CallSession> callback)
        {
            Stage = CallStage.Retry;
            LastResult = CallResult.Failed;
            NextDialIn = DateTime.Now.Add(FAIL_REDIAL);
            if (callback != null) callback(this);

        }

        /// <summary>
        /// Process call from step
        /// </summary>
        /// <param name="callback">Callback to queue processing routine</param>
        public void Advance(Action<CallSession> callback)
        {
            CultureInfo cCulture = CultureInfo.CurrentCulture;
            Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;;
            _callback = callback;
            try
            {
                switch (Stage)
                {
                    case CallStage.No:
                        _log.Debug("place call to {0}", Phone);
                        ProcessDial();
                        break;
                    case CallStage.Dial:
                        _log.Debug("Play for {0} of #{1}", Phone, SessionId);
                        ProcessPlay();
                        break;
                    case CallStage.Play:
                        _log.Debug("Gather #{1}", Phone, SessionId);
                        ProcessGather();
                        break;
                    case CallStage.Gather:
                        _log.Debug("Hangup #{1}", Phone, SessionId);
                        ProcessHangup();
                        break;
                    case CallStage.HangUp:
                        _log.Debug("Finish #{1}", Phone, SessionId);
                        LastResult = CallResult.Success;
                        FinishCall(callback);
                        break;
                    case CallStage.Retry:
                        if (callback != null) callback(this);
                        break;
                }
                _log.Debug("Result: {0}", ServerState.statusString);
                Thread.CurrentThread.CurrentCulture = cCulture;
            }
            catch(Exception ex)
            {
                _log.Debug("Call progress error: {0}. Phone {1}. Session {2}", ex.Message, Phone,SessionId);
                if (!string.IsNullOrEmpty(SessionId))
                {
                    SetFailed(_callback);
                }
            }
        }
        /// <summary>
        /// Start call
        /// </summary>
        private void ProcessDial()
        {
            Trials++;
            if ((LastResult == CallResult.Failed && Trials > MAX_FAIL_TRIALS) || (LastResult == CallResult.Busy && Trials > MAX_BUSY_TRIALS) || (LastResult == CallResult.Unanswered && Trials > MAX_UNANSWERED_TRIALS))
             {
                    LastResult = CallResult.Failed;
                    if (_callback != null) FinishCall(_callback);  
                     
             }
            else
            {
                Stage = CallStage.Dial;
                IVRTransaction transaction= new IVRTransaction(IVRService.dial(APP_ID, ACCESS_TOKEN, Phone, HELLO_MESSAGE, SENDER_NAME, null, NOTIFY_URL));
                SessionId=transaction.session;
                LastDialed = DateTime.Now;
                ServerState = transaction as HoiioResponse;
                if (transaction.success)
                {
                    LastResult = CallResult.Success;
                    if (_callback != null) _callback(this);
                }
                else
                {
                    SetFailed(_callback);
                }
               
            }
            
        }
        /// <summary>
        /// Play main message
        /// </summary>
        private void ProcessPlay()
        {
            Stage = CallStage.Play;
            Message +=string.Format(ACTUALVALUE_MESSAGE, ActualValue);
            HoiioResponse response = new HoiioResponse(IVRService.play(APP_ID, ACCESS_TOKEN,SessionId, Message, null, NOTIFY_URL));
            ServerState = response;
            if (response.success)
            {
                LastResult = CallResult.Success;
                if (_callback != null) _callback(this);
            }
            else
            {
                SetFailed(_callback);
            }
            
        }
        /// <summary>
        /// Start gathering input
        /// </summary>
        private void ProcessGather()
        {
            HoiioResponse response = new HoiioResponse(IVRService.gather(APP_ID, ACCESS_TOKEN, SessionId, ACKNOWLEDGE_MESSAGE,1,15,2, null, NOTIFY_URL));
            ServerState = response;
            Stage = CallStage.Gather;
            if (response.success)
            {
                LastResult = CallResult.Success;
                if (_callback != null) _callback(this);
            }
            else FinishCall(_callback);
        }
        /// <summary>
        /// Hangup call
        /// </summary>
        private void ProcessHangup()
        {
            Stage = CallStage.HangUp;
            HoiioResponse response = new HoiioResponse(IVRService.hangup(APP_ID, ACCESS_TOKEN, SessionId, BYE_MESSAGE, null, NOTIFY_URL));
            ServerState = response;
            if (response.success)
            {
                LastResult = CallResult.Success;
                if (_callback != null) _callback(this);
            }
            else  FinishCall(_callback);
            
           
        }
        /// <summary>
        /// Make call  finished
        /// </summary>
        /// <param name="callback">Callback to queue processing routine</param>
        private void FinishCall(Action<CallSession> callback)
        {
            Stage = CallStage.Finished;
            if(callback!=null) callback(this);
        }

    }
}
