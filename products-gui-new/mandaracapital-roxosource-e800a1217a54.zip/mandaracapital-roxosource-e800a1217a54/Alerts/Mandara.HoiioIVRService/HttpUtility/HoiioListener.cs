﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.IO;
using Mandara.HoiioIVRService.AsyncServices;
using Mandara.Entities.ErrorReporting;

namespace Mandara.HoiioIVRService.HttpUtility
{
    /// <summary>
    /// Web listener for Hoiio callbeck
    /// </summary>
    class HoiioListener
    {
        private String URI_PATTERN = System.Configuration.ConfigurationManager.AppSettings["ListenerPattern"] ?? "http://*:8080/";
        private QueueService _requestsHandler;
        
        HttpListener _httpListener;
    /// <summary>
    /// Initializer
    /// </summary>
    /// <param name="_handler"></param>
    public HoiioListener(QueueService _handler)
    {
      _httpListener = new HttpListener();
      _httpListener.Prefixes.Add(URI_PATTERN);
      _requestsHandler = _handler;
    }
        /// <summary>
        /// Start listen
        /// </summary>
    public void Start()
    {
        try
        {
            HoiioIVRService.Instance.Log.Debug("Listening... ");
            _httpListener.Start();

            while (_httpListener.IsListening)
                ProcessRequest();
        }
        catch (Exception ex)
        {
            ErrorReportingHelper.ReportError("IVR Service", ErrorType.Exception, "Listener error.", null, ex, ErrorLevel.Critical);
            HoiioIVRService.Instance.Log.Error("Listener error. Service start failed. {0}",ex.Message);
        }

    }
    /// <summary>
    /// Stop listening
    /// </summary>
    public void Stop()
    {
      _httpListener.Stop();
    }
    /// <summary>
    /// Start process recieved request
    /// </summary>
    void ProcessRequest()
    {
      var result = _httpListener.BeginGetContext(ListenerCallback, _httpListener);
      result.AsyncWaitHandle.WaitOne();
    }
    /// <summary>
    /// Process request and respond to Hoiio (they need 200)
    /// </summary>
    /// <param name="result"></param>
    void ListenerCallback(IAsyncResult result)
    {
        try
        {
            var context = _httpListener.EndGetContext(result);
            _requestsHandler.ProcessHoiioResponse(Read(context.Request));
            //Read(context.Request);
            CreateResponse(context.Response, "info");
        }
        catch (Exception ex)
        {
            HoiioIVRService.Instance.Log.Error("Server core error. Service start failed. {0}", ex.Message);
        }
    }
    /// <summary>
    /// Extract body information in string readable by parser
    /// 
    /// </summary>
    /// <param name="request"></param>
    /// <returns></returns>
    public static string Read(HttpListenerRequest request)
    {
        string info = string.Empty;
        if (request.HasEntityBody)
        {

            Encoding encoding = request.ContentEncoding;
            using (var bodyStream = request.InputStream)
            using (var streamReader = new StreamReader(bodyStream, encoding))
            {
                info = streamReader.ReadToEnd();
            }
        }
        return info;
    }
    /// <summary>
    /// Create responce back to Hoiio because they would like to see 200 status
    /// </summary>
    /// <param name="response">Response to tune up</param>
    /// <param name="body">Response content</param>
    private static void CreateResponse(HttpListenerResponse response, string body)
    {
      response.StatusCode = (int)HttpStatusCode.OK;
      response.StatusDescription = HttpStatusCode.OK.ToString();
      byte[] buffer = new byte[1]; //Encoding.UTF8.GetBytes(body);
      response.ContentLength64 = buffer.Length;
      response.OutputStream.Write(buffer, 0, buffer.Length);
      response.OutputStream.Close();
    }
  }

    /// <summary>
    /// Supply class for webresponce
    /// </summary>
  public class WebResponseInfo
  {
    public string Body { get; set; }
    public string ContentEncoding { get; set; }
    public long ContentLength { get; set; }
    public string ContentType { get; set; }
    public HttpStatusCode StatusCode { get; set; }
    public string StatusDescription { get; set; }

    

  }
  
    
}
