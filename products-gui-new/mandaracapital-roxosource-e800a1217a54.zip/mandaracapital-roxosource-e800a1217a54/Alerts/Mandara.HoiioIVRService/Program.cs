﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceProcess;
using System.Text;

namespace Mandara.HoiioIVRService
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main(string[] args)
        {
            HoiioIVRService service = new HoiioIVRService();

            if (Environment.GetCommandLineArgs().Contains("-console"))
            {
                Console.CancelKeyPress += (x, y) => service.Stop();
                service.Start();
                Console.WriteLine("Running service");
                Console.ReadKey();
                service.Stop();
                Console.WriteLine("Service stopped");
            }
            else
            {
                ServiceBase.Run(service);
            }
           
        }
    }
}
