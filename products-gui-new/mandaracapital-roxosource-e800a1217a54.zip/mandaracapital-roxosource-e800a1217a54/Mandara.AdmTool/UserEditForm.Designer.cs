﻿namespace Mandara.AdmTool
{
    partial class UserEditForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserEditForm));
            this.checkEdit = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.txtUserName = new DevExpress.XtraEditors.TextEdit();
            this.layoutControl1 = new DevExpress.XtraLayout.LayoutControl();
            this.pcPortfolios = new DevExpress.XtraEditors.PopupContainerControl();
            this.tlTargetPortfolio = new DevExpress.XtraTreeList.TreeList();
            this.nameClmn = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.gcCategoryPortfolio = new DevExpress.XtraGrid.GridControl();
            this.gvCategoryPortfolios = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colProductCategory = new DevExpress.XtraGrid.Columns.GridColumn();
            this.riProductGroupLookup = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.colPortfolio = new DevExpress.XtraGrid.Columns.GridColumn();
            this.riPortfolios = new DevExpress.XtraEditors.Repository.RepositoryItemPopupContainerEdit();
            this.lcChangePasswordDays1 = new DevExpress.XtraEditors.LabelControl();
            this.daysBetweenPasswordChangeEnabled = new DevExpress.XtraEditors.CheckEdit();
            this.ceLockUser = new DevExpress.XtraEditors.CheckEdit();
            this.clbUserGroups = new DevExpress.XtraEditors.CheckedListBoxControl();
            this.lcChangePasswordDays2 = new DevExpress.XtraEditors.LabelControl();
            this.btnSave = new DevExpress.XtraEditors.SimpleButton();
            this.daysBetweenPasswordChange = new DevExpress.XtraEditors.SpinEdit();
            this.forcePasswordChange = new DevExpress.XtraEditors.CheckEdit();
            this.gcPortfolioPermissions = new DevExpress.XtraTreeList.TreeList();
            this.portfolioPermissionBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.btnCancel = new DevExpress.XtraEditors.SimpleButton();
            this.btnSetMasterPassword = new DevExpress.XtraEditors.SimpleButton();
            this.gcAliases = new DevExpress.XtraGrid.GridControl();
            this.gvAliases = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.ddlDefaultPortfolio = new DevExpress.XtraEditors.PopupContainerEdit();
            this.popupTarget = new DevExpress.XtraEditors.PopupContainerControl();
            this.tlTarget = new DevExpress.XtraTreeList.TreeList();
            this.txtLastName = new DevExpress.XtraEditors.TextEdit();
            this.txtFirstName = new DevExpress.XtraEditors.TextEdit();
            this.layoutControlGroup1 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem1 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem2 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem3 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem4 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlGroup2 = new DevExpress.XtraLayout.LayoutControlGroup();
            this.layoutControlItem7 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem6 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem2 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem5 = new DevExpress.XtraLayout.LayoutControlItem();
            this.splitterItem2 = new DevExpress.XtraLayout.SplitterItem();
            this.layoutControlItem8 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem9 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem10 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem1 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.splitterItem1 = new DevExpress.XtraLayout.SplitterItem();
            this.layoutControlItem11 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem12 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem32 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem3 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem15 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem33 = new DevExpress.XtraLayout.LayoutControlItem();
            this.layoutControlItem13 = new DevExpress.XtraLayout.LayoutControlItem();
            this.emptySpaceItem4 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem16 = new DevExpress.XtraLayout.LayoutControlItem();
            this.splitterItem3 = new DevExpress.XtraLayout.SplitterItem();
            this.portfolioPermissionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gvPortfolioPermissions = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.column1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colRead = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colWrite = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colViewPnl = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colCanViewRisk = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colCanViewPnl = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colCanAddEditTrades = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colCanUseMasterTool = new DevExpress.XtraGrid.Columns.GridColumn();
            this.layoutControlItem14 = new DevExpress.XtraLayout.LayoutControlItem();
            this.dxErrorProvider1 = new DevExpress.XtraEditors.DXErrorProvider.DXErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUserName.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl1)).BeginInit();
            this.layoutControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pcPortfolios)).BeginInit();
            this.pcPortfolios.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tlTargetPortfolio)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcCategoryPortfolio)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvCategoryPortfolios)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.riProductGroupLookup)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.riPortfolios)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.daysBetweenPasswordChangeEnabled.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ceLockUser.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clbUserGroups)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.daysBetweenPasswordChange.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.forcePasswordChange.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcPortfolioPermissions)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.portfolioPermissionBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcAliases)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvAliases)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ddlDefaultPortfolio.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.popupTarget)).BeginInit();
            this.popupTarget.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tlTarget)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLastName.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFirstName.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitterItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitterItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitterItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.portfolioPermissionBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvPortfolioPermissions)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dxErrorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // checkEdit
            // 
            this.checkEdit.AutoHeight = false;
            this.checkEdit.Name = "checkEdit";
            // 
            // txtUserName
            // 
            this.txtUserName.Location = new System.Drawing.Point(150, 106);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(321, 20);
            this.txtUserName.StyleController = this.layoutControl1;
            this.txtUserName.TabIndex = 0;
            // 
            // layoutControl1
            // 
            this.layoutControl1.Controls.Add(this.pcPortfolios);
            this.layoutControl1.Controls.Add(this.gcCategoryPortfolio);
            this.layoutControl1.Controls.Add(this.lcChangePasswordDays1);
            this.layoutControl1.Controls.Add(this.daysBetweenPasswordChangeEnabled);
            this.layoutControl1.Controls.Add(this.ceLockUser);
            this.layoutControl1.Controls.Add(this.clbUserGroups);
            this.layoutControl1.Controls.Add(this.lcChangePasswordDays2);
            this.layoutControl1.Controls.Add(this.btnSave);
            this.layoutControl1.Controls.Add(this.daysBetweenPasswordChange);
            this.layoutControl1.Controls.Add(this.forcePasswordChange);
            this.layoutControl1.Controls.Add(this.gcPortfolioPermissions);
            this.layoutControl1.Controls.Add(this.btnCancel);
            this.layoutControl1.Controls.Add(this.btnSetMasterPassword);
            this.layoutControl1.Controls.Add(this.gcAliases);
            this.layoutControl1.Controls.Add(this.ddlDefaultPortfolio);
            this.layoutControl1.Controls.Add(this.txtUserName);
            this.layoutControl1.Controls.Add(this.txtLastName);
            this.layoutControl1.Controls.Add(this.popupTarget);
            this.layoutControl1.Controls.Add(this.txtFirstName);
            this.layoutControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.layoutControl1.Location = new System.Drawing.Point(0, 0);
            this.layoutControl1.Name = "layoutControl1";
            this.layoutControl1.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = new System.Drawing.Rectangle(240, 315, 250, 350);
            this.layoutControl1.OptionsView.UseDefaultDragAndDropRendering = false;
            this.layoutControl1.Root = this.layoutControlGroup1;
            this.layoutControl1.Size = new System.Drawing.Size(1040, 560);
            this.layoutControl1.TabIndex = 17;
            this.layoutControl1.Text = "layoutControl1";
            // 
            // pcPortfolios
            // 
            this.pcPortfolios.Controls.Add(this.tlTargetPortfolio);
            this.pcPortfolios.Location = new System.Drawing.Point(765, 344);
            this.pcPortfolios.Name = "pcPortfolios";
            this.pcPortfolios.Size = new System.Drawing.Size(263, 140);
            this.pcPortfolios.TabIndex = 26;
            // 
            // tlTargetPortfolio
            // 
            this.tlTargetPortfolio.Appearance.FocusedRow.BackColor = System.Drawing.Color.Navy;
            this.tlTargetPortfolio.Appearance.FocusedRow.ForeColor = System.Drawing.Color.White;
            this.tlTargetPortfolio.Appearance.FocusedRow.Options.UseBackColor = true;
            this.tlTargetPortfolio.Appearance.FocusedRow.Options.UseForeColor = true;
            this.tlTargetPortfolio.Columns.AddRange(new DevExpress.XtraTreeList.Columns.TreeListColumn[] {
            this.nameClmn});
            this.tlTargetPortfolio.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlTargetPortfolio.KeyFieldName = "PortfolioId";
            this.tlTargetPortfolio.Location = new System.Drawing.Point(0, 0);
            this.tlTargetPortfolio.Name = "tlTargetPortfolio";
            this.tlTargetPortfolio.OptionsBehavior.AutoPopulateColumns = false;
            this.tlTargetPortfolio.OptionsPrint.UsePrintStyles = true;
            this.tlTargetPortfolio.OptionsView.ShowColumns = false;
            this.tlTargetPortfolio.OptionsView.ShowFilterPanelMode = DevExpress.XtraTreeList.ShowFilterPanelMode.Never;
            this.tlTargetPortfolio.OptionsView.ShowHorzLines = false;
            this.tlTargetPortfolio.OptionsView.ShowIndicator = false;
            this.tlTargetPortfolio.OptionsView.ShowVertLines = false;
            this.tlTargetPortfolio.ParentFieldName = "ParentPortfolioId";
            this.tlTargetPortfolio.Size = new System.Drawing.Size(263, 140);
            this.tlTargetPortfolio.TabIndex = 2;
            // 
            // nameClmn
            // 
            this.nameClmn.FieldName = "Name";
            this.nameClmn.Name = "nameClmn";
            this.nameClmn.OptionsColumn.AllowEdit = false;
            this.nameClmn.OptionsColumn.AllowSort = false;
            this.nameClmn.Visible = true;
            this.nameClmn.VisibleIndex = 0;
            // 
            // gcCategoryPortfolio
            // 
            this.gcCategoryPortfolio.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.gcCategoryPortfolio.EmbeddedNavigator.Buttons.First.Visible = false;
            this.gcCategoryPortfolio.EmbeddedNavigator.Buttons.Last.Visible = false;
            this.gcCategoryPortfolio.EmbeddedNavigator.Buttons.Next.Visible = false;
            this.gcCategoryPortfolio.EmbeddedNavigator.Buttons.NextPage.Visible = false;
            this.gcCategoryPortfolio.EmbeddedNavigator.Buttons.Prev.Visible = false;
            this.gcCategoryPortfolio.EmbeddedNavigator.Buttons.PrevPage.Visible = false;
            this.gcCategoryPortfolio.EmbeddedNavigator.TextLocation = DevExpress.XtraEditors.NavigatorButtonsTextLocation.None;
            this.gcCategoryPortfolio.Location = new System.Drawing.Point(480, 263);
            this.gcCategoryPortfolio.MainView = this.gvCategoryPortfolios;
            this.gcCategoryPortfolio.Name = "gcCategoryPortfolio";
            this.gcCategoryPortfolio.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.riPortfolios,
            this.riProductGroupLookup});
            this.gcCategoryPortfolio.Size = new System.Drawing.Size(548, 249);
            this.gcCategoryPortfolio.TabIndex = 24;
            this.gcCategoryPortfolio.UseEmbeddedNavigator = true;
            this.gcCategoryPortfolio.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gvCategoryPortfolios});
            // 
            // gvCategoryPortfolios
            // 
            this.gvCategoryPortfolios.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colProductCategory,
            this.colPortfolio});
            this.gvCategoryPortfolios.GridControl = this.gcCategoryPortfolio;
            this.gvCategoryPortfolios.Name = "gvCategoryPortfolios";
            this.gvCategoryPortfolios.OptionsBehavior.AllowFixedGroups = DevExpress.Utils.DefaultBoolean.False;
            this.gvCategoryPortfolios.OptionsFilter.AllowColumnMRUFilterList = false;
            this.gvCategoryPortfolios.OptionsFilter.AllowFilterEditor = false;
            this.gvCategoryPortfolios.OptionsFilter.AllowMRUFilterList = false;
            this.gvCategoryPortfolios.OptionsMenu.EnableColumnMenu = false;
            this.gvCategoryPortfolios.OptionsView.ShowFilterPanelMode = DevExpress.XtraGrid.Views.Base.ShowFilterPanelMode.Never;
            this.gvCategoryPortfolios.OptionsView.ShowGroupExpandCollapseButtons = false;
            this.gvCategoryPortfolios.OptionsView.ShowGroupPanel = false;
            this.gvCategoryPortfolios.OptionsView.ShowIndicator = false;
            this.gvCategoryPortfolios.ValidateRow += new DevExpress.XtraGrid.Views.Base.ValidateRowEventHandler(this.gvCategoryPortfolios_ValidateRow);
            // 
            // colProductCategory
            // 
            this.colProductCategory.Caption = "Product Category";
            this.colProductCategory.ColumnEdit = this.riProductGroupLookup;
            this.colProductCategory.FieldName = "ProductCategory";
            this.colProductCategory.Name = "colProductCategory";
            this.colProductCategory.Visible = true;
            this.colProductCategory.VisibleIndex = 0;
            // 
            // riProductGroupLookup
            // 
            this.riProductGroupLookup.AutoHeight = false;
            this.riProductGroupLookup.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.riProductGroupLookup.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("Name", "ProductGroup")});
            this.riProductGroupLookup.Name = "riProductGroupLookup";
            this.riProductGroupLookup.QueryPopUp += new System.ComponentModel.CancelEventHandler(this.riProductGroupLookup_QueryPopUp);
            // 
            // colPortfolio
            // 
            this.colPortfolio.Caption = "Portfolio";
            this.colPortfolio.ColumnEdit = this.riPortfolios;
            this.colPortfolio.FieldName = "Portfolio";
            this.colPortfolio.Name = "colPortfolio";
            this.colPortfolio.Visible = true;
            this.colPortfolio.VisibleIndex = 1;
            // 
            // riPortfolios
            // 
            this.riPortfolios.AutoHeight = false;
            this.riPortfolios.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.riPortfolios.Name = "riPortfolios";
            this.riPortfolios.QueryResultValue += new DevExpress.XtraEditors.Controls.QueryResultValueEventHandler(this.riPortfolios_QueryResultValue);
            this.riPortfolios.QueryPopUp += new System.ComponentModel.CancelEventHandler(this.riPortfolios_QueryPopUp);
            this.riPortfolios.Closed += new DevExpress.XtraEditors.Controls.ClosedEventHandler(this.riPortfolios_Closed);
            // 
            // lcChangePasswordDays1
            // 
            this.lcChangePasswordDays1.Location = new System.Drawing.Point(30, 61);
            this.lcChangePasswordDays1.Name = "lcChangePasswordDays1";
            this.lcChangePasswordDays1.Size = new System.Drawing.Size(117, 13);
            this.lcChangePasswordDays1.StyleController = this.layoutControl1;
            this.lcChangePasswordDays1.TabIndex = 23;
            this.lcChangePasswordDays1.Text = "Change password every";
            // 
            // daysBetweenPasswordChangeEnabled
            // 
            this.daysBetweenPasswordChangeEnabled.Location = new System.Drawing.Point(12, 58);
            this.daysBetweenPasswordChangeEnabled.Name = "daysBetweenPasswordChangeEnabled";
            this.daysBetweenPasswordChangeEnabled.Properties.Caption = "";
            this.daysBetweenPasswordChangeEnabled.Size = new System.Drawing.Size(18, 19);
            this.daysBetweenPasswordChangeEnabled.StyleController = this.layoutControl1;
            this.daysBetweenPasswordChangeEnabled.TabIndex = 21;
            this.daysBetweenPasswordChangeEnabled.CheckedChanged += new System.EventHandler(this.daysBetweenPasswordChangeEnabled_CheckedChanged);
            // 
            // ceLockUser
            // 
            this.ceLockUser.Location = new System.Drawing.Point(12, 12);
            this.ceLockUser.Name = "ceLockUser";
            this.ceLockUser.Properties.Caption = "Locked";
            this.ceLockUser.Size = new System.Drawing.Size(459, 19);
            this.ceLockUser.StyleController = this.layoutControl1;
            this.ceLockUser.TabIndex = 17;
            // 
            // clbUserGroups
            // 
            this.clbUserGroups.Location = new System.Drawing.Point(24, 209);
            this.clbUserGroups.Name = "clbUserGroups";
            this.clbUserGroups.Size = new System.Drawing.Size(435, 68);
            this.clbUserGroups.StyleController = this.layoutControl1;
            this.clbUserGroups.TabIndex = 14;
            // 
            // lcChangePasswordDays2
            // 
            this.lcChangePasswordDays2.Location = new System.Drawing.Point(212, 61);
            this.lcChangePasswordDays2.Name = "lcChangePasswordDays2";
            this.lcChangePasswordDays2.Size = new System.Drawing.Size(31, 13);
            this.lcChangePasswordDays2.StyleController = this.layoutControl1;
            this.lcChangePasswordDays2.TabIndex = 22;
            this.lcChangePasswordDays2.Text = "day(s)";
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(844, 526);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(89, 22);
            this.btnSave.StyleController = this.layoutControl1;
            this.btnSave.TabIndex = 9;
            this.btnSave.Text = "Save";
            this.btnSave.Click += new System.EventHandler(this.BtnSaveClick);
            // 
            // daysBetweenPasswordChange
            // 
            this.daysBetweenPasswordChange.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.daysBetweenPasswordChange.Location = new System.Drawing.Point(151, 58);
            this.daysBetweenPasswordChange.Name = "daysBetweenPasswordChange";
            this.daysBetweenPasswordChange.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.daysBetweenPasswordChange.Properties.IsFloatValue = false;
            this.daysBetweenPasswordChange.Properties.Mask.EditMask = "N00";
            this.daysBetweenPasswordChange.Size = new System.Drawing.Size(57, 20);
            this.daysBetweenPasswordChange.StyleController = this.layoutControl1;
            this.daysBetweenPasswordChange.TabIndex = 19;
            // 
            // forcePasswordChange
            // 
            this.forcePasswordChange.Location = new System.Drawing.Point(12, 35);
            this.forcePasswordChange.Name = "forcePasswordChange";
            this.forcePasswordChange.Properties.Caption = "Force password change at next login";
            this.forcePasswordChange.Size = new System.Drawing.Size(459, 19);
            this.forcePasswordChange.StyleController = this.layoutControl1;
            this.forcePasswordChange.TabIndex = 18;
            // 
            // gcPortfolioPermissions
            // 
            this.gcPortfolioPermissions.DataSource = this.portfolioPermissionBindingSource1;
            this.gcPortfolioPermissions.KeyFieldName = "PortfoiolId";
            this.gcPortfolioPermissions.Location = new System.Drawing.Point(480, 28);
            this.gcPortfolioPermissions.Name = "gcPortfolioPermissions";
            this.gcPortfolioPermissions.OptionsPrint.UsePrintStyles = true;
            this.gcPortfolioPermissions.ParentFieldName = "ParentPortfolioId";
            this.gcPortfolioPermissions.Size = new System.Drawing.Size(548, 210);
            this.gcPortfolioPermissions.TabIndex = 15;
            this.gcPortfolioPermissions.CellValueChanging += new DevExpress.XtraTreeList.CellValueChangedEventHandler(this.gcPortfolioPermissions_CellValueChanging);
            // 
            // portfolioPermissionBindingSource1
            // 
            this.portfolioPermissionBindingSource1.DataSource = typeof(Mandara.AdmTool.PortfolioPermission);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(937, 526);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(91, 22);
            this.btnCancel.StyleController = this.layoutControl1;
            this.btnCancel.TabIndex = 10;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.Click += new System.EventHandler(this.BtnCancelClick);
            // 
            // btnSetMasterPassword
            // 
            this.btnSetMasterPassword.Location = new System.Drawing.Point(256, 488);
            this.btnSetMasterPassword.Name = "btnSetMasterPassword";
            this.btnSetMasterPassword.Size = new System.Drawing.Size(203, 22);
            this.btnSetMasterPassword.StyleController = this.layoutControl1;
            this.btnSetMasterPassword.TabIndex = 16;
            this.btnSetMasterPassword.Text = "Set Password";
            this.btnSetMasterPassword.Click += new System.EventHandler(this.BtnSetMasterPasswordClick);
            // 
            // gcAliases
            // 
            this.gcAliases.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.gcAliases.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.gcAliases.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.gcAliases.EmbeddedNavigator.Buttons.First.Visible = false;
            this.gcAliases.EmbeddedNavigator.Buttons.Last.Visible = false;
            this.gcAliases.EmbeddedNavigator.Buttons.Next.Visible = false;
            this.gcAliases.EmbeddedNavigator.Buttons.NextPage.Visible = false;
            this.gcAliases.EmbeddedNavigator.Buttons.Prev.Visible = false;
            this.gcAliases.EmbeddedNavigator.Buttons.PrevPage.Visible = false;
            this.gcAliases.EmbeddedNavigator.TextLocation = DevExpress.XtraEditors.NavigatorButtonsTextLocation.None;
            this.gcAliases.Location = new System.Drawing.Point(24, 286);
            this.gcAliases.MainView = this.gvAliases;
            this.gcAliases.Name = "gcAliases";
            this.gcAliases.ShowOnlyPredefinedDetails = true;
            this.gcAliases.Size = new System.Drawing.Size(435, 198);
            this.gcAliases.TabIndex = 11;
            this.gcAliases.UseEmbeddedNavigator = true;
            this.gcAliases.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gvAliases});
            // 
            // gvAliases
            // 
            this.gvAliases.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn1});
            this.gvAliases.GridControl = this.gcAliases;
            this.gvAliases.Name = "gvAliases";
            this.gvAliases.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn1
            // 
            this.gridColumn1.Caption = "User Aliases";
            this.gridColumn1.FieldName = "Alias";
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 0;
            // 
            // ddlDefaultPortfolio
            // 
            this.ddlDefaultPortfolio.Location = new System.Drawing.Point(150, 154);
            this.ddlDefaultPortfolio.Name = "ddlDefaultPortfolio";
            this.ddlDefaultPortfolio.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.ddlDefaultPortfolio.Properties.PopupControl = this.popupTarget;
            this.ddlDefaultPortfolio.Properties.EditValueChanged += new System.EventHandler(this.ValueChanged);
            this.ddlDefaultPortfolio.Size = new System.Drawing.Size(321, 20);
            this.ddlDefaultPortfolio.StyleController = this.layoutControl1;
            this.ddlDefaultPortfolio.TabIndex = 13;
            // 
            // popupTarget
            // 
            this.popupTarget.Controls.Add(this.tlTarget);
            this.popupTarget.Location = new System.Drawing.Point(814, 33);
            this.popupTarget.Name = "popupTarget";
            this.popupTarget.Size = new System.Drawing.Size(321, 199);
            this.popupTarget.TabIndex = 30;
            // 
            // tlTarget
            // 
            this.tlTarget.Appearance.FocusedRow.BackColor = System.Drawing.Color.Navy;
            this.tlTarget.Appearance.FocusedRow.ForeColor = System.Drawing.Color.White;
            this.tlTarget.Appearance.FocusedRow.Options.UseBackColor = true;
            this.tlTarget.Appearance.FocusedRow.Options.UseForeColor = true;
            this.tlTarget.Columns.AddRange(new DevExpress.XtraTreeList.Columns.TreeListColumn[] {
            this.nameClmn});
            this.tlTarget.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlTarget.KeyFieldName = "PortfolioId";
            this.tlTarget.Location = new System.Drawing.Point(0, 0);
            this.tlTarget.Name = "tlTarget";
            this.tlTarget.OptionsBehavior.AutoPopulateColumns = false;
            this.tlTarget.OptionsView.ShowColumns = false;
            this.tlTarget.OptionsView.ShowFilterPanelMode = DevExpress.XtraTreeList.ShowFilterPanelMode.Never;
            this.tlTarget.OptionsView.ShowHorzLines = false;
            this.tlTarget.OptionsView.ShowIndicator = false;
            this.tlTarget.OptionsView.ShowVertLines = false;
            this.tlTarget.ParentFieldName = "ParentPortfolioId";
            this.tlTarget.Size = new System.Drawing.Size(321, 199);
            this.tlTarget.TabIndex = 0;
            this.tlTarget.FocusedNodeChanged += new DevExpress.XtraTreeList.FocusedNodeChangedEventHandler(this.tlTarget_FocusedNodeChanged);
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(150, 82);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(321, 20);
            this.txtLastName.StyleController = this.layoutControl1;
            this.txtLastName.TabIndex = 2;
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(150, 130);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(321, 20);
            this.txtFirstName.StyleController = this.layoutControl1;
            this.txtFirstName.TabIndex = 4;
            // 
            // layoutControlGroup1
            // 
            this.layoutControlGroup1.CustomizationFormText = "Root";
            this.layoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.True;
            this.layoutControlGroup1.GroupBordersVisible = false;
            this.layoutControlGroup1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem1,
            this.layoutControlItem2,
            this.layoutControlItem3,
            this.layoutControlItem4,
            this.layoutControlGroup2,
            this.layoutControlItem8,
            this.layoutControlItem9,
            this.layoutControlItem10,
            this.emptySpaceItem1,
            this.splitterItem1,
            this.layoutControlItem11,
            this.layoutControlItem12,
            this.layoutControlItem32,
            this.emptySpaceItem3,
            this.layoutControlItem15,
            this.layoutControlItem33,
            this.layoutControlItem13,
            this.emptySpaceItem4,
            this.layoutControlItem16,
            this.splitterItem3});
            this.layoutControlGroup1.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup1.Name = "Root";
            this.layoutControlGroup1.Size = new System.Drawing.Size(1040, 560);
            this.layoutControlGroup1.Text = "Root";
            this.layoutControlGroup1.TextVisible = false;
            // 
            // layoutControlItem1
            // 
            this.layoutControlItem1.Control = this.txtUserName;
            this.layoutControlItem1.CustomizationFormText = "Last Name";
            this.layoutControlItem1.Location = new System.Drawing.Point(0, 94);
            this.layoutControlItem1.Name = "layoutControlItem1";
            this.layoutControlItem1.Size = new System.Drawing.Size(463, 24);
            this.layoutControlItem1.Text = "User Name";
            this.layoutControlItem1.TextSize = new System.Drawing.Size(135, 13);
            // 
            // layoutControlItem2
            // 
            this.layoutControlItem2.Control = this.txtLastName;
            this.layoutControlItem2.CustomizationFormText = "User Name";
            this.layoutControlItem2.Location = new System.Drawing.Point(0, 70);
            this.layoutControlItem2.Name = "layoutControlItem2";
            this.layoutControlItem2.Size = new System.Drawing.Size(463, 24);
            this.layoutControlItem2.Text = "Last Name";
            this.layoutControlItem2.TextSize = new System.Drawing.Size(135, 13);
            // 
            // layoutControlItem3
            // 
            this.layoutControlItem3.Control = this.txtFirstName;
            this.layoutControlItem3.CustomizationFormText = "First Name";
            this.layoutControlItem3.Location = new System.Drawing.Point(0, 118);
            this.layoutControlItem3.Name = "layoutControlItem3";
            this.layoutControlItem3.Size = new System.Drawing.Size(463, 24);
            this.layoutControlItem3.Text = "First Name";
            this.layoutControlItem3.TextSize = new System.Drawing.Size(135, 13);
            // 
            // layoutControlItem4
            // 
            this.layoutControlItem4.Control = this.ddlDefaultPortfolio;
            this.layoutControlItem4.CustomizationFormText = "Default Portfolio";
            this.layoutControlItem4.Location = new System.Drawing.Point(0, 142);
            this.layoutControlItem4.Name = "layoutControlItem4";
            this.layoutControlItem4.Size = new System.Drawing.Size(463, 24);
            this.layoutControlItem4.Text = "Default Portfolio";
            this.layoutControlItem4.TextSize = new System.Drawing.Size(135, 13);
            // 
            // layoutControlGroup2
            // 
            this.layoutControlGroup2.CustomizationFormText = "User Groups:";
            this.layoutControlGroup2.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem7,
            this.layoutControlItem6,
            this.emptySpaceItem2,
            this.layoutControlItem5,
            this.splitterItem2});
            this.layoutControlGroup2.Location = new System.Drawing.Point(0, 166);
            this.layoutControlGroup2.Name = "layoutControlGroup2";
            this.layoutControlGroup2.Size = new System.Drawing.Size(463, 348);
            this.layoutControlGroup2.Text = "User Groups:";
            // 
            // layoutControlItem7
            // 
            this.layoutControlItem7.Control = this.btnSetMasterPassword;
            this.layoutControlItem7.CustomizationFormText = "layoutControlItem7";
            this.layoutControlItem7.Location = new System.Drawing.Point(232, 279);
            this.layoutControlItem7.Name = "layoutControlItem7";
            this.layoutControlItem7.Size = new System.Drawing.Size(207, 26);
            this.layoutControlItem7.Text = "layoutControlItem7";
            this.layoutControlItem7.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem7.TextToControlDistance = 0;
            this.layoutControlItem7.TextVisible = false;
            // 
            // layoutControlItem6
            // 
            this.layoutControlItem6.Control = this.gcAliases;
            this.layoutControlItem6.CustomizationFormText = "layoutControlItem6";
            this.layoutControlItem6.Location = new System.Drawing.Point(0, 77);
            this.layoutControlItem6.Name = "layoutControlItem6";
            this.layoutControlItem6.Size = new System.Drawing.Size(439, 202);
            this.layoutControlItem6.Text = "layoutControlItem6";
            this.layoutControlItem6.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem6.TextToControlDistance = 0;
            this.layoutControlItem6.TextVisible = false;
            // 
            // emptySpaceItem2
            // 
            this.emptySpaceItem2.AllowHotTrack = false;
            this.emptySpaceItem2.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem2.Location = new System.Drawing.Point(0, 279);
            this.emptySpaceItem2.Name = "emptySpaceItem2";
            this.emptySpaceItem2.Size = new System.Drawing.Size(232, 26);
            this.emptySpaceItem2.Text = "emptySpaceItem2";
            this.emptySpaceItem2.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem5
            // 
            this.layoutControlItem5.Control = this.clbUserGroups;
            this.layoutControlItem5.CustomizationFormText = "layoutControlItem5";
            this.layoutControlItem5.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem5.Name = "layoutControlItem5";
            this.layoutControlItem5.Size = new System.Drawing.Size(439, 72);
            this.layoutControlItem5.Text = "layoutControlItem5";
            this.layoutControlItem5.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem5.TextToControlDistance = 0;
            this.layoutControlItem5.TextVisible = false;
            // 
            // splitterItem2
            // 
            this.splitterItem2.AllowHotTrack = true;
            this.splitterItem2.CustomizationFormText = "splitterItem2";
            this.splitterItem2.Location = new System.Drawing.Point(0, 72);
            this.splitterItem2.Name = "splitterItem2";
            this.splitterItem2.Size = new System.Drawing.Size(439, 5);
            // 
            // layoutControlItem8
            // 
            this.layoutControlItem8.Control = this.gcPortfolioPermissions;
            this.layoutControlItem8.CustomizationFormText = "Default Portfolio";
            this.layoutControlItem8.Location = new System.Drawing.Point(468, 0);
            this.layoutControlItem8.MinSize = new System.Drawing.Size(104, 40);
            this.layoutControlItem8.Name = "layoutControlItem8";
            this.layoutControlItem8.Size = new System.Drawing.Size(552, 230);
            this.layoutControlItem8.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem8.Text = "Portfolio Permissions";
            this.layoutControlItem8.TextLocation = DevExpress.Utils.Locations.Top;
            this.layoutControlItem8.TextSize = new System.Drawing.Size(135, 13);
            // 
            // layoutControlItem9
            // 
            this.layoutControlItem9.Control = this.btnCancel;
            this.layoutControlItem9.CustomizationFormText = "layoutControlItem9";
            this.layoutControlItem9.Location = new System.Drawing.Point(925, 514);
            this.layoutControlItem9.Name = "layoutControlItem9";
            this.layoutControlItem9.Size = new System.Drawing.Size(95, 26);
            this.layoutControlItem9.Text = "layoutControlItem9";
            this.layoutControlItem9.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem9.TextToControlDistance = 0;
            this.layoutControlItem9.TextVisible = false;
            // 
            // layoutControlItem10
            // 
            this.layoutControlItem10.Control = this.btnSave;
            this.layoutControlItem10.CustomizationFormText = "layoutControlItem10";
            this.layoutControlItem10.Location = new System.Drawing.Point(832, 514);
            this.layoutControlItem10.Name = "layoutControlItem10";
            this.layoutControlItem10.Size = new System.Drawing.Size(93, 26);
            this.layoutControlItem10.Text = "layoutControlItem10";
            this.layoutControlItem10.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem10.TextToControlDistance = 0;
            this.layoutControlItem10.TextVisible = false;
            // 
            // emptySpaceItem1
            // 
            this.emptySpaceItem1.AllowHotTrack = false;
            this.emptySpaceItem1.CustomizationFormText = "emptySpaceItem1";
            this.emptySpaceItem1.Location = new System.Drawing.Point(0, 514);
            this.emptySpaceItem1.Name = "emptySpaceItem1";
            this.emptySpaceItem1.Size = new System.Drawing.Size(832, 26);
            this.emptySpaceItem1.Text = "emptySpaceItem1";
            this.emptySpaceItem1.TextSize = new System.Drawing.Size(0, 0);
            // 
            // splitterItem1
            // 
            this.splitterItem1.AllowHotTrack = true;
            this.splitterItem1.CustomizationFormText = "splitterItem1";
            this.splitterItem1.Location = new System.Drawing.Point(463, 0);
            this.splitterItem1.Name = "splitterItem1";
            this.splitterItem1.Size = new System.Drawing.Size(5, 514);
            // 
            // layoutControlItem11
            // 
            this.layoutControlItem11.Control = this.ceLockUser;
            this.layoutControlItem11.CustomizationFormText = "layoutControlItem11";
            this.layoutControlItem11.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem11.Name = "layoutControlItem11";
            this.layoutControlItem11.Size = new System.Drawing.Size(463, 23);
            this.layoutControlItem11.Text = "layoutControlItem11";
            this.layoutControlItem11.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem11.TextToControlDistance = 0;
            this.layoutControlItem11.TextVisible = false;
            // 
            // layoutControlItem12
            // 
            this.layoutControlItem12.Control = this.forcePasswordChange;
            this.layoutControlItem12.CustomizationFormText = "layoutControlItem12";
            this.layoutControlItem12.Location = new System.Drawing.Point(0, 23);
            this.layoutControlItem12.Name = "layoutControlItem12";
            this.layoutControlItem12.Size = new System.Drawing.Size(463, 23);
            this.layoutControlItem12.Text = "layoutControlItem12";
            this.layoutControlItem12.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem12.TextToControlDistance = 0;
            this.layoutControlItem12.TextVisible = false;
            // 
            // layoutControlItem32
            // 
            this.layoutControlItem32.Control = this.daysBetweenPasswordChange;
            this.layoutControlItem32.CustomizationFormText = "day(s)";
            this.layoutControlItem32.Location = new System.Drawing.Point(139, 46);
            this.layoutControlItem32.MaxSize = new System.Drawing.Size(170, 24);
            this.layoutControlItem32.MinSize = new System.Drawing.Size(30, 24);
            this.layoutControlItem32.Name = "layoutControlItem32";
            this.layoutControlItem32.Size = new System.Drawing.Size(61, 24);
            this.layoutControlItem32.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem32.Text = "Change password every";
            this.layoutControlItem32.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem32.TextToControlDistance = 0;
            this.layoutControlItem32.TextVisible = false;
            // 
            // emptySpaceItem3
            // 
            this.emptySpaceItem3.AllowHotTrack = false;
            this.emptySpaceItem3.CustomizationFormText = "emptySpaceItem3";
            this.emptySpaceItem3.Location = new System.Drawing.Point(233, 46);
            this.emptySpaceItem3.Name = "emptySpaceItem3";
            this.emptySpaceItem3.Size = new System.Drawing.Size(230, 24);
            this.emptySpaceItem3.Text = "emptySpaceItem3";
            this.emptySpaceItem3.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem15
            // 
            this.layoutControlItem15.Control = this.daysBetweenPasswordChangeEnabled;
            this.layoutControlItem15.CustomizationFormText = "layoutControlItem15";
            this.layoutControlItem15.Location = new System.Drawing.Point(0, 46);
            this.layoutControlItem15.MaxSize = new System.Drawing.Size(144, 24);
            this.layoutControlItem15.MinSize = new System.Drawing.Size(10, 15);
            this.layoutControlItem15.Name = "layoutControlItem15";
            this.layoutControlItem15.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 0, 2, 2);
            this.layoutControlItem15.Size = new System.Drawing.Size(20, 24);
            this.layoutControlItem15.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem15.Text = "layoutControlItem15";
            this.layoutControlItem15.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem15.TextToControlDistance = 0;
            this.layoutControlItem15.TextVisible = false;
            // 
            // layoutControlItem33
            // 
            this.layoutControlItem33.Control = this.lcChangePasswordDays2;
            this.layoutControlItem33.ControlAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.layoutControlItem33.CustomizationFormText = "day(s)";
            this.layoutControlItem33.Location = new System.Drawing.Point(200, 46);
            this.layoutControlItem33.Name = "layoutControlItem33";
            this.layoutControlItem33.Padding = new DevExpress.XtraLayout.Utils.Padding(2, 0, 0, 0);
            this.layoutControlItem33.Size = new System.Drawing.Size(33, 24);
            this.layoutControlItem33.Text = "day(s)";
            this.layoutControlItem33.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem33.TextToControlDistance = 0;
            this.layoutControlItem33.TextVisible = false;
            this.layoutControlItem33.TrimClientAreaToControl = false;
            // 
            // layoutControlItem13
            // 
            this.layoutControlItem13.Control = this.lcChangePasswordDays1;
            this.layoutControlItem13.ControlAlignment = System.Drawing.ContentAlignment.MiddleLeft;
            this.layoutControlItem13.CustomizationFormText = "layoutControlItem13";
            this.layoutControlItem13.Location = new System.Drawing.Point(20, 46);
            this.layoutControlItem13.Name = "layoutControlItem13";
            this.layoutControlItem13.Padding = new DevExpress.XtraLayout.Utils.Padding(0, 2, 0, 0);
            this.layoutControlItem13.Size = new System.Drawing.Size(119, 24);
            this.layoutControlItem13.Text = "layoutControlItem13";
            this.layoutControlItem13.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem13.TextToControlDistance = 0;
            this.layoutControlItem13.TextVisible = false;
            this.layoutControlItem13.TrimClientAreaToControl = false;
            // 
            // emptySpaceItem4
            // 
            this.emptySpaceItem4.AllowHotTrack = false;
            this.emptySpaceItem4.CustomizationFormText = "emptySpaceItem4";
            this.emptySpaceItem4.Location = new System.Drawing.Point(468, 504);
            this.emptySpaceItem4.Name = "emptySpaceItem4";
            this.emptySpaceItem4.Size = new System.Drawing.Size(552, 10);
            this.emptySpaceItem4.Text = "emptySpaceItem4";
            this.emptySpaceItem4.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem16
            // 
            this.layoutControlItem16.Control = this.gcCategoryPortfolio;
            this.layoutControlItem16.CustomizationFormText = "CateGoryPortfolio";
            this.layoutControlItem16.Location = new System.Drawing.Point(468, 235);
            this.layoutControlItem16.Name = "layoutControlItem16";
            this.layoutControlItem16.Size = new System.Drawing.Size(552, 269);
            this.layoutControlItem16.Text = "Product Categories Portfolio";
            this.layoutControlItem16.TextLocation = DevExpress.Utils.Locations.Top;
            this.layoutControlItem16.TextSize = new System.Drawing.Size(135, 13);
            // 
            // splitterItem3
            // 
            this.splitterItem3.AllowHotTrack = true;
            this.splitterItem3.CustomizationFormText = "splitterItem3";
            this.splitterItem3.Location = new System.Drawing.Point(468, 230);
            this.splitterItem3.Name = "splitterItem3";
            this.splitterItem3.Size = new System.Drawing.Size(552, 5);
            // 
            // portfolioPermissionBindingSource
            // 
            this.portfolioPermissionBindingSource.DataSource = typeof(Mandara.AdmTool.PortfolioPermission);
            // 
            // gvPortfolioPermissions
            // 
            this.gvPortfolioPermissions.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.column1,
            this.colRead,
            this.colWrite,
            this.colViewPnl,
            this.colCanViewRisk,
            this.colCanViewPnl,
            this.colCanAddEditTrades,
            this.colCanUseMasterTool});
            this.gvPortfolioPermissions.Name = "gvPortfolioPermissions";
            this.gvPortfolioPermissions.OptionsView.ShowGroupPanel = false;
            // 
            // column1
            // 
            this.column1.Caption = "Name";
            this.column1.FieldName = "Name";
            this.column1.Name = "column1";
            this.column1.OptionsColumn.AllowEdit = false;
            this.column1.Visible = true;
            this.column1.VisibleIndex = 0;
            // 
            // colRead
            // 
            this.colRead.Caption = "Read";
            this.colRead.ColumnEdit = this.checkEdit;
            this.colRead.FieldName = "Read";
            this.colRead.Name = "colRead";
            this.colRead.Visible = true;
            this.colRead.VisibleIndex = 1;
            // 
            // colWrite
            // 
            this.colWrite.Caption = "Write";
            this.colWrite.ColumnEdit = this.checkEdit;
            this.colWrite.FieldName = "Write";
            this.colWrite.Name = "colWrite";
            this.colWrite.Visible = true;
            this.colWrite.VisibleIndex = 2;
            // 
            // colViewPnl
            // 
            this.colViewPnl.Caption = "View PnL";
            this.colViewPnl.ColumnEdit = this.checkEdit;
            this.colViewPnl.FieldName = "ViewPNL";
            this.colViewPnl.Name = "colViewPnl";
            this.colViewPnl.Visible = true;
            this.colViewPnl.VisibleIndex = 3;
            // 
            // colCanViewRisk
            // 
            this.colCanViewRisk.Caption = "View Risk";
            this.colCanViewRisk.FieldName = "CanViewRisk";
            this.colCanViewRisk.Name = "colCanViewRisk";
            this.colCanViewRisk.Visible = true;
            this.colCanViewRisk.VisibleIndex = 4;
            // 
            // colCanViewPnl
            // 
            this.colCanViewPnl.Caption = "View Pnl";
            this.colCanViewPnl.FieldName = "CanViewPnl";
            this.colCanViewPnl.Name = "colCanViewPnl";
            this.colCanViewPnl.Visible = true;
            this.colCanViewPnl.VisibleIndex = 5;
            // 
            // colCanAddEditTrades
            // 
            this.colCanAddEditTrades.Caption = "Add/Edit Trades";
            this.colCanAddEditTrades.FieldName = "CanAddEditTrades";
            this.colCanAddEditTrades.Name = "colCanAddEditTrades";
            this.colCanAddEditTrades.Visible = true;
            this.colCanAddEditTrades.VisibleIndex = 6;
            // 
            // colCanUseMasterTool
            // 
            this.colCanUseMasterTool.Caption = "Use Master Tool";
            this.colCanUseMasterTool.FieldName = "CanUseMasterTool";
            this.colCanUseMasterTool.Name = "colCanUseMasterTool";
            this.colCanUseMasterTool.Visible = true;
            this.colCanUseMasterTool.VisibleIndex = 7;
            // 
            // layoutControlItem14
            // 
            this.layoutControlItem14.Control = this.gcPortfolioPermissions;
            this.layoutControlItem14.CustomizationFormText = "Default Portfolio";
            this.layoutControlItem14.Location = new System.Drawing.Point(468, 0);
            this.layoutControlItem14.MinSize = new System.Drawing.Size(104, 40);
            this.layoutControlItem14.Name = "layoutControlItem8";
            this.layoutControlItem14.Size = new System.Drawing.Size(552, 234);
            this.layoutControlItem14.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem14.Text = "Portfolio Permissions";
            this.layoutControlItem14.TextLocation = DevExpress.Utils.Locations.Top;
            this.layoutControlItem14.TextSize = new System.Drawing.Size(98, 13);
            this.layoutControlItem14.TextToControlDistance = 5;
            // 
            // dxErrorProvider1
            // 
            this.dxErrorProvider1.ContainerControl = this;
            // 
            // UserEditForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1040, 560);
            this.Controls.Add(this.layoutControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "UserEditForm";
            this.Text = "User Edit";
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUserName.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControl1)).EndInit();
            this.layoutControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pcPortfolios)).EndInit();
            this.pcPortfolios.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tlTargetPortfolio)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcCategoryPortfolio)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvCategoryPortfolios)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.riProductGroupLookup)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.riPortfolios)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.daysBetweenPasswordChangeEnabled.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ceLockUser.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clbUserGroups)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.daysBetweenPasswordChange.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.forcePasswordChange.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcPortfolioPermissions)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.portfolioPermissionBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcAliases)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvAliases)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ddlDefaultPortfolio.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.popupTarget)).EndInit();
            this.popupTarget.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tlTarget)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtLastName.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFirstName.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitterItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitterItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitterItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.portfolioPermissionBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvPortfolioPermissions)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dxErrorProvider1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.TextEdit txtUserName;
        private DevExpress.XtraEditors.TextEdit txtLastName;
        private DevExpress.XtraEditors.TextEdit txtFirstName;
        private DevExpress.XtraEditors.SimpleButton btnSave;
        private DevExpress.XtraEditors.SimpleButton btnCancel;
        private DevExpress.XtraGrid.GridControl gcAliases;
        private DevExpress.XtraGrid.Views.Grid.GridView gvAliases;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraEditors.PopupContainerEdit ddlDefaultPortfolio;
        private DevExpress.XtraEditors.PopupContainerControl popupTarget;
        private DevExpress.XtraEditors.CheckedListBoxControl clbUserGroups;
        private DevExpress.XtraTreeList.TreeList tlTarget;
        private DevExpress.XtraTreeList.TreeList gcPortfolioPermissions;
        private DevExpress.XtraGrid.Views.Grid.GridView gvPortfolioPermissions;
        private DevExpress.XtraGrid.Columns.GridColumn column1;
        private DevExpress.XtraGrid.Columns.GridColumn colRead;
        private DevExpress.XtraGrid.Columns.GridColumn colWrite;
        private DevExpress.XtraGrid.Columns.GridColumn colViewPnl;
        private DevExpress.XtraEditors.SimpleButton btnSetMasterPassword;
        private DevExpress.XtraLayout.LayoutControl layoutControl1;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem3;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem4;
        private DevExpress.XtraLayout.LayoutControlGroup layoutControlGroup2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem7;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem6;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem5;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem8;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem9;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem10;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;
        private DevExpress.XtraLayout.SplitterItem splitterItem1;
        private DevExpress.XtraLayout.SplitterItem splitterItem2;
        private DevExpress.XtraEditors.CheckEdit ceLockUser;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem11;
        private System.Windows.Forms.BindingSource portfolioPermissionBindingSource;
        private DevExpress.XtraGrid.Columns.GridColumn colCanViewRisk;
        private DevExpress.XtraGrid.Columns.GridColumn colCanViewPnl;
        private DevExpress.XtraGrid.Columns.GridColumn colCanAddEditTrades;
        private DevExpress.XtraGrid.Columns.GridColumn colCanUseMasterTool;
        private System.Windows.Forms.BindingSource portfolioPermissionBindingSource1;
        private DevExpress.XtraEditors.CheckEdit forcePasswordChange;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem12;
        private DevExpress.XtraEditors.CheckEdit daysBetweenPasswordChangeEnabled;
        private DevExpress.XtraEditors.SpinEdit daysBetweenPasswordChange;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem32;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem3;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem15;
        private DevExpress.XtraEditors.LabelControl lcChangePasswordDays2;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem33;
        private DevExpress.XtraEditors.LabelControl lcChangePasswordDays1;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem13;
        private DevExpress.XtraGrid.GridControl gcCategoryPortfolio;
        private DevExpress.XtraGrid.Views.Grid.GridView gvCategoryPortfolios;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem4;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem16;
        private DevExpress.XtraLayout.LayoutControlItem layoutControlItem14;
        private DevExpress.XtraGrid.Columns.GridColumn colPortfolio;
        private DevExpress.XtraEditors.Repository.RepositoryItemPopupContainerEdit riPortfolios;
        private DevExpress.XtraEditors.PopupContainerControl pcPortfolios;
        private DevExpress.XtraTreeList.TreeList tlTargetPortfolio;
        private DevExpress.XtraTreeList.Columns.TreeListColumn nameClmn;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit checkEdit;
        private DevExpress.XtraGrid.Columns.GridColumn colProductCategory;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit riProductGroupLookup;
        private DevExpress.XtraLayout.SplitterItem splitterItem3;
        private DevExpress.XtraEditors.DXErrorProvider.DXErrorProvider dxErrorProvider1;
    }
}