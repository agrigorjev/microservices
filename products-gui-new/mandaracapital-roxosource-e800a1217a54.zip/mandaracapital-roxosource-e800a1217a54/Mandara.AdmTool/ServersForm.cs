﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;

namespace Mandara.AdmTool
{
    public partial class ServersForm : DevExpress.XtraEditors.XtraForm
    {
        public ServersForm()
        {
            InitializeComponent();
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            gcServers.DataSource = MainForm.Instance.ServerConnections.Values;
            _refreshServersStatusTimer.Start();
        }

        private void _refreshServersStatusTimer_Tick(object sender, EventArgs e)
        {
            gcServers.RefreshDataSource();
        }

        private void ServersForm_FormClosing(object sender, System.Windows.Forms.FormClosingEventArgs e)
        {
            _refreshServersStatusTimer.Stop();
        }

        private void gvServers_RowCellStyle(object sender, DevExpress.XtraGrid.Views.Grid.RowCellStyleEventArgs e)
        {
            if (e.Column == colStatus)
            {
                string status = e.CellValue as string;
                switch (status)
                {
                    case "Online":
                        e.Appearance.ForeColor = Color.Green;
                        break;
                    case "Lost hearbeat":
                        e.Appearance.ForeColor = Color.LightGreen;
                        break;
                    case "Offline":
                        e.Appearance.ForeColor = Color.Red;
                        break;
                }
            }
        }
    }
}
