﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using Mandara.Business.Managers;
using Mandara.Entities;
using System.Linq;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraEditors.Controls;
using Mandara.Business.Audit;

namespace Mandara.AdmTool
{
    public partial class AlertGroupEditForm : DevExpress.XtraEditors.XtraForm
    {
        private AdministrativeAlertGroup _group;
        /// <summary>
        /// Group edited by form
        /// </summary>
        public AdministrativeAlertGroup Group
        {
            get
            {
                return _group;
            }
            set
            {
                _group = value;
            }
        }
        BindingList<AlertPhone> _phones;
        BindingList<AlertVoicePhone> _voicePhones;
         BindingList<AlertEmailAddress> _emails;
         BindingList<User> _users;
        public AlertGroupEditForm()
        {
            InitializeComponent();
        }
        /// <summary>
        /// Bind alert group to form controls on form load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AlertGroupEditForm_Load(object sender, EventArgs e)
        {
             AuthorizationManager _authManager = new AuthorizationManager();

             txtTitle.DataBindings.Add("EditValue", Group, "Title");
            _phones=new BindingList<AlertPhone>(_group.Phones.ToList());
            gcPhone.DataSource = _phones;
            _voicePhones = new BindingList<AlertVoicePhone>(_group.VoicePhones.ToList());
            gcVoicePhones.DataSource = _voicePhones;
            _emails=new BindingList<AlertEmailAddress>(_group.Emails.ToList());
            gcEmails.DataSource = _emails;
            _users=new BindingList<User>(_authManager.GetUsers().OrderBy(u=>u.UserName).ToList());
            clbxUsers.DataSource = _users;
            List<User> tt = _group.Users.ToList();
            tt.ForEach(u =>{
               int c= clbxUsers.FindItem(0, true, (ListBoxFindItemDelegate)delegate(ListBoxFindItemArgs ee)
                                            {
                                                ee.IsFound = ee.ItemValue.Equals(u.UserId);
                                            });
               if (c > -1) clbxUsers.SetItemChecked(c, true);
            });
        }

    
        /// <summary>
        /// Validate if entered data enough to save alert group
        /// </summary>
        /// <returns></returns>
        private bool ValidateGroup()
        {
            bool valid = true;
            if (string.IsNullOrWhiteSpace(txtTitle.Text))
            {
                dxErrorProvider1.SetError(txtTitle,"Group Title required");
                valid = false;
            }

            if (clbxUsers.CheckedItems.Count + _emails.Count + _phones.Where(p => !string.IsNullOrEmpty(p.Phone.Trim())).Count()+ _voicePhones.Where(p => !string.IsNullOrEmpty(p.Phone.Trim())).Count() < 1)
            {
                MessageBox.Show("Can not save group with empty contact list. Please add contacts to group.", "Save error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                valid = false;
            }

            return valid;
        }


        /// <summary>
        /// Close form with no changes to edited group
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        /// <summary>
        /// Save group to db
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ValidateGroup())
            {
                try
                {
                    _group.Phones.Clear();
                    foreach (AlertPhone p in _phones)
                    {
                        if (!string.IsNullOrEmpty(p.Phone.Trim()))
                        {
                            _group.Phones.Add(p);
                            p.AlertGroupId = _group.GroupId;
                        }
                    }
                    _group.VoicePhones.Clear();
                    foreach (AlertVoicePhone p in _voicePhones)
                    {
                        if (!string.IsNullOrEmpty(p.Phone.Trim()))
                        {
                            _group.VoicePhones.Add(p);
                            p.AlertGroupId = _group.GroupId;
                        }
                    }
                    _group.Emails.Clear();
                    foreach (AlertEmailAddress p in _emails)
                    {
                        _group.Emails.Add(p);
                        p.AlertGroupId = _group.GroupId;
                    }
                    _group.Users.Clear();
                    foreach (User u in clbxUsers.CheckedItems)
                    {
                        _group.Users.Add(u);
                        u.AlertGroups.Add(_group);
                    }

                    AuditContext context = MainForm.CreateAuditContext(_group.GroupId > 0 ? "Update administrative alert group" : "Create administrative alert group");
                    AdministrativeAlertManager.SaveGroup(_group, context);
                    this.Close();
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error on save");
                }
            }
        }
        /// <summary>
        /// Reset validation error state on user input
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txtTitle_EditValueChanging(object sender, DevExpress.XtraEditors.Controls.ChangingEventArgs e)
        {
            if (dxErrorProvider1.HasErrors)
            {
                dxErrorProvider1.SetError((Control)sender, null);
            }   
        }

        /// <summary>
        /// Validate enetred email value, prevent vontrol to loose focus on fail
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void gridView1_ValidateRow(object sender, DevExpress.XtraGrid.Views.Base.ValidateRowEventArgs e)
        {
           System.Text.RegularExpressions.Regex re=new System.Text.RegularExpressions.Regex(@"^[-+.\w]{1,64}@[-.\w]{1,64}\.[-.\w]{2,6}$");
           GridView view = sender as GridView;
           string textToMatch = (view.GetRowCellValue(e.RowHandle, colEmail)??"").ToString();
           if (!re.IsMatch(textToMatch))
           {
               e.Valid = false;
               view.SetColumnError(colEmail, "Valid email address required");
           }
           else
           {
               e.Valid = true;
           }
        }
        /// <summary>
        /// Prevent grid validation error popup
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void gvEmail_InvalidRowException(object sender, DevExpress.XtraGrid.Views.Base.InvalidRowExceptionEventArgs e)
        {
            e.ExceptionMode = ExceptionMode.NoAction;
        }

       
      

    }
}
