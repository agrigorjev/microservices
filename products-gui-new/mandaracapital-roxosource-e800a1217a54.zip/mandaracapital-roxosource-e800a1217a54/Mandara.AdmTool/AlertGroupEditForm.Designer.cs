﻿namespace Mandara.AdmTool
{
    partial class AlertGroupEditForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AlertGroupEditForm));
            this.label1 = new System.Windows.Forms.Label();
            this.txtTitle = new DevExpress.XtraEditors.TextEdit();
            this.gcPhone = new DevExpress.XtraGrid.GridControl();
            this.gvPhones = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colPhone = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemTextEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.gcEmails = new DevExpress.XtraGrid.GridControl();
            this.gvEmail = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colEmail = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemTextEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.lblEmail = new DevExpress.XtraEditors.LabelControl();
            this.lblPhones = new DevExpress.XtraEditors.LabelControl();
            this.lblUsers = new DevExpress.XtraEditors.LabelControl();
            this.btnSave = new DevExpress.XtraEditors.SimpleButton();
            this.btnCancel = new DevExpress.XtraEditors.SimpleButton();
            this.clbxUsers = new DevExpress.XtraEditors.CheckedListBoxControl();
            this.dxErrorProvider1 = new DevExpress.XtraEditors.DXErrorProvider.DXErrorProvider(this.components);
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.gcVoicePhones = new DevExpress.XtraGrid.GridControl();
            this.gvVoicePhones = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemTextEdit3 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTitle.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcPhone)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvPhones)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcEmails)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvEmail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clbxUsers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dxErrorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcVoicePhones)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvVoicePhones)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit3)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Group Title :";
            // 
            // txtTitle
            // 
            this.txtTitle.Location = new System.Drawing.Point(86, 4);
            this.txtTitle.Name = "txtTitle";
            this.txtTitle.Size = new System.Drawing.Size(335, 20);
            this.txtTitle.TabIndex = 1;
            this.txtTitle.EditValueChanging += new DevExpress.XtraEditors.Controls.ChangingEventHandler(this.txtTitle_EditValueChanging);
            // 
            // gcPhone
            // 
            this.gcPhone.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.gcPhone.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.gcPhone.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.gcPhone.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.gcPhone.EmbeddedNavigator.Buttons.First.Visible = false;
            this.gcPhone.EmbeddedNavigator.Buttons.Last.Visible = false;
            this.gcPhone.EmbeddedNavigator.Buttons.Next.Visible = false;
            this.gcPhone.EmbeddedNavigator.Buttons.NextPage.Visible = false;
            this.gcPhone.EmbeddedNavigator.Buttons.Prev.Visible = false;
            this.gcPhone.EmbeddedNavigator.Buttons.PrevPage.Visible = false;
            this.gcPhone.EmbeddedNavigator.TextLocation = DevExpress.XtraEditors.NavigatorButtonsTextLocation.None;
            this.gcPhone.EmbeddedNavigator.TextStringFormat = "";
            this.gcPhone.Location = new System.Drawing.Point(225, 63);
            this.gcPhone.MainView = this.gvPhones;
            this.gcPhone.Name = "gcPhone";
            this.gcPhone.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemTextEdit2});
            this.gcPhone.Size = new System.Drawing.Size(196, 445);
            this.gcPhone.TabIndex = 6;
            this.gcPhone.UseEmbeddedNavigator = true;
            this.gcPhone.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gvPhones});
            // 
            // gvPhones
            // 
            this.gvPhones.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colPhone});
            this.gvPhones.GridControl = this.gcPhone;
            this.gvPhones.Name = "gvPhones";
            this.gvPhones.OptionsView.ShowGroupPanel = false;
            this.gvPhones.InvalidRowException += new DevExpress.XtraGrid.Views.Base.InvalidRowExceptionEventHandler(this.gvEmail_InvalidRowException);
            // 
            // colPhone
            // 
            this.colPhone.ColumnEdit = this.repositoryItemTextEdit2;
            this.colPhone.FieldName = "Phone";
            this.colPhone.Name = "colPhone";
            this.colPhone.Visible = true;
            this.colPhone.VisibleIndex = 0;
            // 
            // repositoryItemTextEdit2
            // 
            this.repositoryItemTextEdit2.AllowNullInput = DevExpress.Utils.DefaultBoolean.False;
            this.repositoryItemTextEdit2.AutoHeight = false;
            this.repositoryItemTextEdit2.MaxLength = 15;
            this.repositoryItemTextEdit2.Name = "repositoryItemTextEdit2";
            // 
            // gcEmails
            // 
            this.gcEmails.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.gcEmails.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.gcEmails.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.gcEmails.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.gcEmails.EmbeddedNavigator.Buttons.First.Visible = false;
            this.gcEmails.EmbeddedNavigator.Buttons.Last.Visible = false;
            this.gcEmails.EmbeddedNavigator.Buttons.Next.Visible = false;
            this.gcEmails.EmbeddedNavigator.Buttons.NextPage.Visible = false;
            this.gcEmails.EmbeddedNavigator.Buttons.Prev.Visible = false;
            this.gcEmails.EmbeddedNavigator.Buttons.PrevPage.Visible = false;
            this.gcEmails.EmbeddedNavigator.TextLocation = DevExpress.XtraEditors.NavigatorButtonsTextLocation.None;
            this.gcEmails.EmbeddedNavigator.TextStringFormat = "";
            this.gcEmails.Location = new System.Drawing.Point(7, 63);
            this.gcEmails.MainView = this.gvEmail;
            this.gcEmails.Name = "gcEmails";
            this.gcEmails.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemTextEdit1});
            this.gcEmails.Size = new System.Drawing.Size(196, 445);
            this.gcEmails.TabIndex = 7;
            this.gcEmails.UseEmbeddedNavigator = true;
            this.gcEmails.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gvEmail});
            // 
            // gvEmail
            // 
            this.gvEmail.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colEmail});
            this.gvEmail.GridControl = this.gcEmails;
            this.gvEmail.Name = "gvEmail";
            this.gvEmail.OptionsView.ShowGroupPanel = false;
            this.gvEmail.InvalidRowException += new DevExpress.XtraGrid.Views.Base.InvalidRowExceptionEventHandler(this.gvEmail_InvalidRowException);
            this.gvEmail.ValidateRow += new DevExpress.XtraGrid.Views.Base.ValidateRowEventHandler(this.gridView1_ValidateRow);
            // 
            // colEmail
            // 
            this.colEmail.ColumnEdit = this.repositoryItemTextEdit1;
            this.colEmail.FieldName = "Email";
            this.colEmail.Name = "colEmail";
            this.colEmail.Visible = true;
            this.colEmail.VisibleIndex = 0;
            // 
            // repositoryItemTextEdit1
            // 
            this.repositoryItemTextEdit1.AllowNullInput = DevExpress.Utils.DefaultBoolean.False;
            this.repositoryItemTextEdit1.AutoHeight = false;
            this.repositoryItemTextEdit1.Mask.AutoComplete = DevExpress.XtraEditors.Mask.AutoCompleteType.None;
            this.repositoryItemTextEdit1.Mask.BeepOnError = true;
            this.repositoryItemTextEdit1.Mask.IgnoreMaskBlank = false;
            this.repositoryItemTextEdit1.Mask.SaveLiteral = false;
            this.repositoryItemTextEdit1.Mask.ShowPlaceHolders = false;
            this.repositoryItemTextEdit1.Name = "repositoryItemTextEdit1";
            this.repositoryItemTextEdit1.ValidateOnEnterKey = true;
            // 
            // lblEmail
            // 
            this.lblEmail.Location = new System.Drawing.Point(18, 44);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(62, 13);
            this.lblEmail.TabIndex = 9;
            this.lblEmail.Text = "Alert Emails :";
            // 
            // lblPhones
            // 
            this.lblPhones.Location = new System.Drawing.Point(225, 44);
            this.lblPhones.Name = "lblPhones";
            this.lblPhones.Size = new System.Drawing.Size(99, 13);
            this.lblPhones.TabIndex = 9;
            this.lblPhones.Text = "Alert Phones (SMS) :";
            // 
            // lblUsers
            // 
            this.lblUsers.Location = new System.Drawing.Point(636, 7);
            this.lblUsers.Name = "lblUsers";
            this.lblUsers.Size = new System.Drawing.Size(60, 13);
            this.lblUsers.TabIndex = 9;
            this.lblUsers.Text = "Alert Users :";
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnSave.Location = new System.Drawing.Point(795, 485);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(103, 23);
            this.btnSave.TabIndex = 10;
            this.btnSave.Text = "Save";
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnCancel.Location = new System.Drawing.Point(672, 485);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(103, 23);
            this.btnCancel.TabIndex = 10;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // clbxUsers
            // 
            this.clbxUsers.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.clbxUsers.CheckOnClick = true;
            this.clbxUsers.DisplayMember = "UserName";
            this.clbxUsers.Location = new System.Drawing.Point(636, 29);
            this.clbxUsers.Name = "clbxUsers";
            this.clbxUsers.Size = new System.Drawing.Size(264, 450);
            this.clbxUsers.TabIndex = 11;
            this.clbxUsers.ValueMember = "UserId";
            // 
            // dxErrorProvider1
            // 
            this.dxErrorProvider1.ContainerControl = this;
            // 
            // labelControl1
            // 
            this.labelControl1.Location = new System.Drawing.Point(434, 44);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(127, 13);
            this.labelControl1.TabIndex = 13;
            this.labelControl1.Text = "Alert Phones (Voice calls) :";
            // 
            // gcVoicePhones
            // 
            this.gcVoicePhones.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.gcVoicePhones.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.gcVoicePhones.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.gcVoicePhones.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.gcVoicePhones.EmbeddedNavigator.Buttons.First.Visible = false;
            this.gcVoicePhones.EmbeddedNavigator.Buttons.Last.Visible = false;
            this.gcVoicePhones.EmbeddedNavigator.Buttons.Next.Visible = false;
            this.gcVoicePhones.EmbeddedNavigator.Buttons.NextPage.Visible = false;
            this.gcVoicePhones.EmbeddedNavigator.Buttons.Prev.Visible = false;
            this.gcVoicePhones.EmbeddedNavigator.Buttons.PrevPage.Visible = false;
            this.gcVoicePhones.EmbeddedNavigator.TextLocation = DevExpress.XtraEditors.NavigatorButtonsTextLocation.None;
            this.gcVoicePhones.EmbeddedNavigator.TextStringFormat = "";
            this.gcVoicePhones.Location = new System.Drawing.Point(434, 63);
            this.gcVoicePhones.MainView = this.gvVoicePhones;
            this.gcVoicePhones.Name = "gcVoicePhones";
            this.gcVoicePhones.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemTextEdit3});
            this.gcVoicePhones.Size = new System.Drawing.Size(196, 445);
            this.gcVoicePhones.TabIndex = 12;
            this.gcVoicePhones.UseEmbeddedNavigator = true;
            this.gcVoicePhones.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gvVoicePhones});
            // 
            // gvVoicePhones
            // 
            this.gvVoicePhones.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn1});
            this.gvVoicePhones.GridControl = this.gcVoicePhones;
            this.gvVoicePhones.Name = "gvVoicePhones";
            this.gvVoicePhones.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn1
            // 
            this.gridColumn1.ColumnEdit = this.repositoryItemTextEdit3;
            this.gridColumn1.FieldName = "Phone";
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 0;
            // 
            // repositoryItemTextEdit3
            // 
            this.repositoryItemTextEdit3.AllowNullInput = DevExpress.Utils.DefaultBoolean.False;
            this.repositoryItemTextEdit3.AutoHeight = false;
            this.repositoryItemTextEdit3.MaxLength = 15;
            this.repositoryItemTextEdit3.Name = "repositoryItemTextEdit3";
            // 
            // AlertGroupEditForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(912, 520);
            this.Controls.Add(this.labelControl1);
            this.Controls.Add(this.gcVoicePhones);
            this.Controls.Add(this.clbxUsers);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.lblUsers);
            this.Controls.Add(this.lblPhones);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.gcEmails);
            this.Controls.Add(this.gcPhone);
            this.Controls.Add(this.txtTitle);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AlertGroupEditForm";
            this.Text = "Edit Alert Group";
            this.Load += new System.EventHandler(this.AlertGroupEditForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.txtTitle.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcPhone)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvPhones)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcEmails)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvEmail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clbxUsers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dxErrorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gcVoicePhones)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvVoicePhones)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private DevExpress.XtraEditors.TextEdit txtTitle;
        private DevExpress.XtraGrid.GridControl gcPhone;
        private DevExpress.XtraGrid.Views.Grid.GridView gvPhones;
        private DevExpress.XtraGrid.Columns.GridColumn colPhone;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit2;
        private DevExpress.XtraGrid.GridControl gcEmails;
        private DevExpress.XtraGrid.Views.Grid.GridView gvEmail;
        private DevExpress.XtraGrid.Columns.GridColumn colEmail;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit1;
        private DevExpress.XtraEditors.LabelControl lblEmail;
        private DevExpress.XtraEditors.LabelControl lblPhones;
        private DevExpress.XtraEditors.LabelControl lblUsers;
        private DevExpress.XtraEditors.SimpleButton btnSave;
        private DevExpress.XtraEditors.SimpleButton btnCancel;
        private DevExpress.XtraEditors.CheckedListBoxControl clbxUsers;
        private DevExpress.XtraEditors.DXErrorProvider.DXErrorProvider dxErrorProvider1;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraGrid.GridControl gcVoicePhones;
        private DevExpress.XtraGrid.Views.Grid.GridView gvVoicePhones;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit3;
    }
}