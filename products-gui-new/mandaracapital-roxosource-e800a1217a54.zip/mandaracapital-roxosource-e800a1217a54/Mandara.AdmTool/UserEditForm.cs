﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors.DXErrorProvider;
using DevExpress.XtraTreeList.Columns;
using DevExpress.XtraTreeList.Nodes;
using Mandara.AdmTool.Properties;
using Mandara.Business;
using Mandara.Business.Audit;
using Mandara.Business.Authorization;
using Mandara.Business.Managers;
using Mandara.Entities;
using Mandara.Entities.Enums;

namespace Mandara.AdmTool
{
    

    public partial class UserEditForm : DevExpress.XtraEditors.XtraForm
    {

        private readonly AuthorizationManager _authManager = new AuthorizationManager();
        private BindingList<UserAlias> _userAliases;
        private BindingList<PortfolioPermission> _portfolioPermissions;
        public event EventHandler NewUserSaved;
        public event EventHandler UserChanged;
        public User User { get; set; }
        private MainForm _mainForm;
        private readonly ProductManager _pManager = new ProductManager();
        private BindingList<Portfolio> _portfolios;
        private BindingList<ProductCategory> _productGroups;
        private BindingList<UserProductCategoryPortfolio> _currentUserPortfolioGroups;
        public MainForm MainForm
        {
            get
            {
                if (_mainForm == null)
                    _mainForm = MdiParent as MainForm;

                return _mainForm;
            }
        }
 
        public UserEditForm()
        {
            InitializeComponent();
            Activated += UsersFormActivated;
            riPortfolios.PopupControl = pcPortfolios;
        }
        /// <summary>
        /// Raise User data changeed event
        /// </summary>
        /// <param name="user"></param>
        protected void OnNewUserSaved(User user)
        {
            if (NewUserSaved != null)
            {
                NewUserSaved(user, new EventArgs());
            }
        }

        protected void OnUserChanged(User user)
        {
            if (UserChanged != null)
            {
                UserChanged(user, new EventArgs());
            }
        }

        void UsersFormActivated(object sender, EventArgs e)
        {
            if (User == null)
                return;
            txtUserName.Text = User.UserName;
            txtLastName.Text = User.LastName;
            txtFirstName.Text = User.FirstName;
            ceLockUser.EditValue = User.LockedValue;
            forcePasswordChange.EditValue = User.ForcePasswordChange == PasswordChangeReason.ForcedByAdmin;
            daysBetweenPasswordChangeEnabled.Checked = User.DaysBetweenPasswordChange != null;
            daysBetweenPasswordChange.EditValue = User.DaysBetweenPasswordChange ?? 0;
            UpdateChangePasswordDaysControls();

           
            BindUserGroups();
            BindUserAliases();
            BindDefaultPortfolio();
            BindPortfolioPermissions();
            BindUserPortfolioProductGroup();

            //If the user edited and user authorized are the same - setup event handler
            if (User.UserId == MainForm.AuthorizedUser.UserId)
            {
                clbUserGroups.ItemChecking += clbUserGroups_ItemChecking;
            }
            _portfolios = new BindingList<Portfolio>(_authManager.GetPortfolios());
            _productGroups = new BindingList<ProductCategory>(_pManager.GetGroups());
            tlTargetPortfolio.DataSource = _portfolios;
            riProductGroupLookup.DataSource = _productGroups;
            
        }
        /// <summary>
        /// Intercept group membership changes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void clbUserGroups_ItemChecking(object sender, ItemCheckingEventArgs e)
        {
            //We only take care of uncheck
            if(e.NewValue==CheckState.Unchecked)
            {
                try
                {
                    //Count checked groups having SA permissions 
                    int checkedSAgroups =
                        clbUserGroups.CheckedItems.Cast<CheckedListBoxItem>().Select(cb => (Group) cb.Value).Count(
                            g => g.Permissions.Contains(PermissionType.SuperAdministrator));

                    if (checkedSAgroups < 2)
                    {
                        //If the group clicked is only remainig - show message and cancel event
                        MessageBox.Show(this, Resources.RemoveFromLastSAGroupDenied, Resources.MandaraAdministrationTool);
                        e.Cancel = true;
                    }

                }
                catch { }
            }
        }

        private void BindUserGroups()
        {
            List<Group> groups = _authManager.GetGroups().ToList();
            clbUserGroups.DisplayMember = "GroupName";
            clbUserGroups.ValueMember = "GroupId";

            int index = 0;
            clbUserGroups.Items.Clear();

            foreach (var group in groups)
            {
                clbUserGroups.Items.Add(group);
                if (User.Groups.Any(g => g.GroupId == group.GroupId))
                {
                    clbUserGroups.SetItemCheckState(index, CheckState.Checked);
                }

                index++;
            }
        }

        private void BindUserAliases()
        {
            _userAliases = new BindingList<UserAlias>(User.UserAliases.ToList());
            gcAliases.DataSource = _userAliases;
        }

        private void BindDefaultPortfolio()
        {
            List<Portfolio> portfolios = _authManager.GetPortfolios();
            portfolios.Insert(0, new Portfolio { PortfolioId = -1, Name = string.Empty });

            tlTarget.DataSource = new BindingList<Portfolio>(portfolios);
            tlTarget.ExpandAll();

            if (User.Portfolio != null)
            {
                ddlDefaultPortfolio.EditValue = User.Portfolio;
                //Set up selected node
                TreeListNode node = tlTarget.FindNodeByKeyID(User.Portfolio.PortfolioId);
                if (node != null)
                    tlTarget.SetFocusedNode(node);
                else
                    tlTarget.MoveFirst();
            }
            else
            {
                tlTarget.MoveFirst();            
            }
        }

        private void tlTarget_FocusedNodeChanged(object sender, DevExpress.XtraTreeList.FocusedNodeChangedEventArgs e)
        {
            if (e.Node == null)
                return;

            if (_portfolios != null)
            {
                int portfolioId = (int) e.Node.GetValue("PortfolioId");
                Portfolio portfolio = _portfolios.FirstOrDefault(x => x.PortfolioId == portfolioId);

                ddlDefaultPortfolio.EditValue = portfolio;
                ddlDefaultPortfolio.ClosePopup();
            }
        }

        private void ValueChanged(object sender, EventArgs e)
        {
            dxErrorProvider1.SetError(sender as Control, null);
        }

        private void BindPortfolioPermissions()
        {
            _portfolioPermissions = new BindingList<PortfolioPermission>();

            var allPortfolios = _authManager.GetPortfolios();
            foreach (var portfolio in allPortfolios)
            {
                var portPermissions = new PortfolioPermission
                {
                    PortfoiolId = portfolio.PortfolioId,
                    ParentPortfolioId = portfolio.ParentPortfolioId,
                    Name = portfolio.Name
                };
                var permissions = User.PortfolioPermissions.SingleOrDefault(p => p.PortfolioId == portfolio.PortfolioId);
                if (permissions != null)
                {
                    portPermissions.CanViewRisk = permissions.CanViewRiskValue;
                    portPermissions.CanViewPnl = permissions.CanViewPnlValue;
                    portPermissions.CanAddEditTrades = permissions.CanAddEditTradesValue;
                    portPermissions.CanUseMasterTool = permissions.CanUseMasterToolValue;
                    portPermissions.CanAddEditBooks = permissions.CanAddEditBooksValue;
                    portPermissions.CanAmendBrokerage = permissions.CanAmendBrokerageValue;
                }
                //Set all permissions to each portfolio for new user
                else if (User.UserId == 0)
                {
                    portPermissions.CanViewRisk = true;
                    portPermissions.CanViewPnl = true;
                    portPermissions.CanAddEditTrades = true;
                    portPermissions.CanUseMasterTool = true;
                    portPermissions.CanAddEditBooks = true;
                    portPermissions.CanAmendBrokerage = true;
                }
                _portfolioPermissions.Add(portPermissions);
            }
            gcPortfolioPermissions.DataSource = _portfolioPermissions;
            gcPortfolioPermissions.ExpandAll();
        }

        private void BindUserPortfolioProductGroup()
        {
            _currentUserPortfolioGroups = new BindingList<UserProductCategoryPortfolio>(User.ProductGroupPortfolios.ToList());
            gcCategoryPortfolio.DataSource = _currentUserPortfolioGroups;
            
        }

        private void BtnCancelClick(object sender, EventArgs e)
        {
            
            this.Close();
        }

        private bool ValidateData()
        {
            bool result = true;
            if (string.IsNullOrEmpty(txtUserName.Text))
            {
                dxErrorProvider1.SetError(txtUserName, "The user name is required", ErrorType.Warning);
                result = false;
            }

            return result;
        }

        private void BtnSaveClick(object sender, EventArgs e)
        {
            if (!ValidateData())
                return;

            var groupEtalon =
                User.Groups.
                Where(am => _authManager.GetGroups().FirstOrDefault(pm => pm.GroupId == am.GroupId 
                    && (pm.Permissions.Contains(PermissionType.SuperAdministrator) || pm.Permissions.Contains(PermissionType.Administrator))) != null).ToList();
            var b1 = (clbUserGroups.CheckedItems.Cast<CheckedListBoxItem>().
                        Select(@gr => (Group) @gr.Value).Count(groupEtalon.Contains) != groupEtalon.Count()
                                && !AuthorizationService.IsUserAuthorizedTo(MainForm.AuthorizedUser, PermissionType.SuperAdministrator));
            var b2 = clbUserGroups.CheckedItems.Cast<CheckedListBoxItem>().
                Select(@group => (Group) @group.Value).
                Any(gr =>
                    (gr.Permissions.Contains(PermissionType.SuperAdministrator) && !AuthorizationService.IsUserAuthorizedTo(MainForm.AuthorizedUser, PermissionType.SuperAdministrator))
                    ||
                    (gr.Permissions.Contains(PermissionType.Administrator) && !AuthorizationService.IsUserAuthorizedTo(MainForm.AuthorizedUser, PermissionType.SuperAdministrator)));
            if (b1 || b2)
            {
                MessageBox.Show(this, Resources.SuperAdministratorPrivilegesRequired, Resources.MandaraAdministrationTool);
                return;
            }

            if (User != null)
            {
                bool isNewUser = User.UserId == 0;
                User.UserName = txtUserName.Text;
                User.LastName = txtLastName.Text;
                User.FirstName = txtFirstName.Text;
                User.LockedValue = (bool) ceLockUser.EditValue;
                User.ForcePasswordChange = forcePasswordChange.Checked ? PasswordChangeReason.ForcedByAdmin : PasswordChangeReason.NoForce;
                User.DaysBetweenPasswordChange = daysBetweenPasswordChangeEnabled.Checked
                    ? (int?)Convert.ToInt32(daysBetweenPasswordChange.EditValue)
                    : (int?)null;

                User.Groups.Clear();
                foreach (var group in clbUserGroups.CheckedItems.Cast<CheckedListBoxItem>())
                {
                    User.Groups.Add((Group) group.Value);
                }

                User.UserAliases.Clear();
                foreach (var alias in _userAliases)
                {
                    User.UserAliases.Add(new UserAlias { UserId = User.UserId, Alias = alias.Alias });
                }

                User.Portfolio = (Portfolio)ddlDefaultPortfolio.EditValue;

                User.PortfolioPermissions.Clear();
                foreach (var permission in _portfolioPermissions)
                {
                    User.PortfolioPermissions.Add(new UserPortfolioPermission 
                    { 
                        PortfolioId = permission.PortfoiolId,
                        CanViewRisk = permission.CanViewRisk,
                        CanViewPnl = permission.CanViewPnl,
                        CanAddEditTrades = permission.CanAddEditTrades,
                        CanUseMasterTool = permission.CanUseMasterTool,
                        CanAddEditBooks = permission.CanAddEditBooks,
                        CanEditBrokerage = permission.CanAmendBrokerage,
                    });
                }
                User.ProductGroupPortfolios.Clear();
                foreach (var item in _currentUserPortfolioGroups)
                {
                    User.ProductGroupPortfolios.Add(item);
                }

                AuditContext auditContext = MainForm.CreateAuditContext("User Details");

                _authManager.SaveUser(User, auditContext);
                if (isNewUser)
                {
                    OnNewUserSaved(User);
                }
                else
                {
                    //we should refresh grid on users form even if existing user data changed
                    OnUserChanged(User);
                }
            }
            if (User.UserId == MainForm.AuthorizedUser.UserId)
            {
                MainForm.RefreshUser();
            }
            
            Close();
        }

        private void BtnSetMasterPasswordClick(object sender, EventArgs e)
        {
            MasterPasswordForm masterPasswordForm = new MasterPasswordForm(User);
            masterPasswordForm.ShowDialog(this);
        }

        private void daysBetweenPasswordChangeEnabled_CheckedChanged(object sender, EventArgs e)
        {
            UpdateChangePasswordDaysControls();
        }

        private void UpdateChangePasswordDaysControls()
        {
            lcChangePasswordDays1.Enabled = daysBetweenPasswordChangeEnabled.Checked;
            lcChangePasswordDays2.Enabled = daysBetweenPasswordChangeEnabled.Checked;
            daysBetweenPasswordChange.Enabled = daysBetweenPasswordChangeEnabled.Checked;
        }
        /// <summary>
        /// Recursively set checked state for child nodes
        /// </summary>
        /// <param name="nodes">List of nodes</param>
        /// <param name="column">Column to chnge value</param>
        /// <param name="value">Actual value</param>
        private void CheckChildren(TreeListNodes nodes,TreeListColumn column ,bool value )
        {
            foreach (TreeListNode node in nodes)
            {
                node.SetValue(column, value);
                if (node.HasChildren)
                {
                    CheckChildren(node.Nodes, column, value);
                }
            }
           
        }
        /// <summary>
        /// Handles manual chancked changing event
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void gcPortfolioPermissions_CellValueChanging(object sender, DevExpress.XtraTreeList.CellValueChangedEventArgs e)
        {
            if (e.Node.HasChildren)
            {
                CheckChildren(e.Node.Nodes, e.Column, (bool)e.Value);
            }
            e.Node.SetValue(e.Column, e.Value);
        }

        private void riPortfolios_QueryPopUp(object sender, CancelEventArgs e)
        {

            tlTargetPortfolio.ExpandAll();
            var currentlyEdited=pcPortfolios.OwnerEdit.EditValue;
            if(currentlyEdited!=null)
            {
                var node = tlTargetPortfolio.FindNodeByFieldValue("PortfolioId", (currentlyEdited as Portfolio).PortfolioId);
                if (node != null)
                    tlTargetPortfolio.FocusedNode = node;
            }
            tlTargetPortfolio.FocusedNodeChanged += tlTargetPortfolio_FocusedNodeChanged;
        }
        private void tlTargetPortfolio_FocusedNodeChanged(object sender, DevExpress.XtraTreeList.FocusedNodeChangedEventArgs e)
        {
            if (e.Node == null)
                return;
            int portfolioId = (int)e.Node.GetValue("PortfolioId");
            Portfolio portfolio = _portfolios.FirstOrDefault(x => x.PortfolioId == portfolioId);
            pcPortfolios.OwnerEdit.EditValue = portfolio;
            pcPortfolios.OwnerEdit.ClosePopup();
            
        }
        private void riPortfolios_QueryResultValue(object sender, QueryResultValueEventArgs e)
        {
            e.Value = (tlTargetPortfolio.Parent as PopupContainerControl).OwnerEdit.EditValue;
        }
        private void riPortfolios_Closed(object sender, ClosedEventArgs e)
        {
            tlTargetPortfolio.FocusedNodeChanged -= tlTargetPortfolio_FocusedNodeChanged;
        }
        private void riProductGroupLookup_QueryPopUp(object sender, CancelEventArgs e)
        {
            LookUpEdit targetEditor=sender as LookUpEdit;
            ProductCategory currentlyEdited = (targetEditor.EditValue as ProductCategory);
            Func<ProductCategory, ProductCategory, bool> f = (x, y) =>
                x.CategoryId == y.CategoryId;
            var comparer = new Comparer<ProductCategory>(f);
            List<ProductCategory> src = _productGroups.Except(_currentUserPortfolioGroups.Where(p => (currentlyEdited == null || p.ProductCategory.CategoryId != currentlyEdited.CategoryId)).Select(p => p.ProductCategory), comparer).ToList();
            targetEditor.Properties.DataSource = src;
            
        }
        private void gvCategoryPortfolios_ValidateRow(object sender, DevExpress.XtraGrid.Views.Base.ValidateRowEventArgs e)
        {
            string errorText="";
            if( (e.Row as UserProductCategoryPortfolio).ProductCategory==null)
                errorText+="Product Group is null\n";
            if ((e.Row as UserProductCategoryPortfolio).Portfolio == null)
                errorText+="Portfolio is null\n";
            e.ErrorText = errorText;
            e.Valid = string.IsNullOrEmpty(errorText);
            
        }
    }
    class Comparer<T> : IEqualityComparer<T>
    {
        private readonly Func<T, T, bool> _comparer;

        public Comparer(Func<T, T, bool> comparer)
        {
            if (comparer == null)
                throw new ArgumentNullException("comparer");

            _comparer = comparer;
        }

        public bool Equals(T x, T y)
        {
            return _comparer(x, y);
        }

        public int GetHashCode(T obj)
        {
            return obj.ToString().ToLower().GetHashCode();
        }
    }

        
}
