﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows.Forms;
using DevExpress.DataProcessing;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraTreeList;
using DevExpress.XtraTreeList.Nodes;
using Mandara.Business;
using Mandara.Business.Audit;
using Mandara.Business.Managers;
using Mandara.Entities;

namespace Mandara.AdmTool
{
    public partial class AlertEditForm : XtraForm
    {
        /// <summary>
        /// Alert to edit
        /// </summary>
        public AdministrativeAlert Alert { get; set; }

        private BindingList<Portfolio> _portfolios;

        public AlertEditForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Bind alert properties to GUI controls on form load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AlertGroupEditForm_Load(object sender, EventArgs e)
        {
            chkDoNotTriggerOnWeekends.DataBindings.Add("EditValue", Alert, "DoNotTriggerOnWeekends");

            txtTitle.DataBindings.Add("EditValue", Alert, "Title");
            cbxActive.DataBindings.Add("EditValue", Alert, "Active");

            txtSubject1.DataBindings.Add("EditValue", Alert, "Level1Subject");
            txtSubject2.DataBindings.Add("EditValue", Alert, "Level2Subject");
            txtSubject3.DataBindings.Add("EditValue", Alert, "Level3Subject");
            txtSubject4.DataBindings.Add("EditValue", Alert, "Level4Subject");

            txtMessage1.DataBindings.Add("EditValue", Alert, "Level1Message");
            txtMessage2.DataBindings.Add("EditValue", Alert, "Level2Message");
            txtMessage3.DataBindings.Add("EditValue", Alert, "Level3Message");
            txtMessage4.DataBindings.Add("EditValue", Alert, "Level4Message");

            txtEmailSubjectTemplate.DataBindings.Add("EditValue", Alert, "EmailSubjectTemplate");
            txtEmailMessageTemplate.DataBindings.Add("EditValue", Alert, "EmailMessageTemplate");

            rgrBoundary.DataBindings.Add("EditValue", Alert, "Boundary");

            txtEscalation.EditValue = Alert.Escalation.TotalMinutes;
            txtConditionCountCheck.EditValue = Alert.ConditionCheckCount;

            if (Alert.Level1Escalation.HasValue)
            {
                txtEscalation1.EditValue = Alert.Level1Escalation.Value.TotalMinutes;
            }

            if (Alert.Level2Escalation.HasValue)
            {
                txtEscalation2.EditValue = Alert.Level2Escalation.Value.TotalMinutes;
            }

            if (Alert.Level3Escalation.HasValue)
            {
                txtEscalation3.EditValue = Alert.Level3Escalation.Value.TotalMinutes;
            }

            if (Alert.Level4Escalation.HasValue)
            {
                txtEscalation4.EditValue = Alert.Level4Escalation.Value.TotalMinutes;
            }

            TypeToIndex(Alert.TypeOfAlert);

            if (Alert.TypeOfAlert == AdministrativeAlert.AdmAlertType.Trade_Time)
            {
                if (Alert.TypeOfBoundary != AdministrativeAlert.BoundaryType.InRange)
                {
                    teThresholdTime.Time = new DateTime(1999, 1, 1).Add(Alert.TradeTime);
                }
                else
                {
                    teThresholdStartTime.Time = new DateTime(1999, 1, 1).Add(Alert.TradeTimeRange.Start);
                    teThresholdEndTime.Time = new DateTime(1999, 1, 1).Add(Alert.TradeTimeRange.End);
                }
            }

            txtThreshold.DataBindings.Add("EditValue", Alert, "ThresholdValue");

            leGroup1.Properties.DataSource = AdministrativeAlertManager.AlertGroups;
            leGroup2.Properties.DataSource = AdministrativeAlertManager.AlertGroups;
            leGroup3.Properties.DataSource = AdministrativeAlertManager.AlertGroups;
            leGroup4.Properties.DataSource = AdministrativeAlertManager.AlertGroups;

            _portfolios = new BindingList<Portfolio>(AdministrativeAlertManager.GetPortfolios());
            tlTarget.DataSource = new BindingList<Portfolio>(_portfolios);
            tlTarget.ExpandAll();

            if (Alert.Portfolio != null)
            {
                //Set up selected node
                TreeListNode node = tlTarget.FindNodeByKeyID(Alert.Portfolio.PortfolioId);
                if (node != null)
                {
                    tlTarget.SetFocusedNode(node);
                }
                else
                {
                    tlTarget.MoveFirst();
                }
            }
            else
            {
                tlTarget.MoveFirst();
            }

            if (Alert.AlertGroup1 != null)
            {
                leGroup1.ItemIndex = AdministrativeAlertManager.AlertGroups.IndexOf(
                    AdministrativeAlertManager
                        .AlertGroups.SingleOrDefault(
                            ag => ag.GroupId
                                  == Alert.AlertGroup1.GroupId));
            }

            if (Alert.AlertGroup2 != null)
            {
                leGroup2.ItemIndex = AdministrativeAlertManager.AlertGroups.IndexOf(
                    AdministrativeAlertManager
                        .AlertGroups.SingleOrDefault(
                            ag => ag.GroupId
                                  == Alert.AlertGroup2.GroupId));
            }

            if (Alert.AlertGroup3 != null)
            {
                leGroup3.ItemIndex = AdministrativeAlertManager.AlertGroups.IndexOf(
                    AdministrativeAlertManager
                        .AlertGroups.SingleOrDefault(
                            ag => ag.GroupId
                                  == Alert.AlertGroup3.GroupId));
            }

            if (Alert.AlertGroup4 != null)
            {
                leGroup4.ItemIndex = AdministrativeAlertManager.AlertGroups.IndexOf(
                    AdministrativeAlertManager
                        .AlertGroups.SingleOrDefault(
                            ag => ag.GroupId
                                  == Alert.AlertGroup4.GroupId));
            }

            List<Product> products = new ProductManager().GetProducts().OrderBy(p => p.Name).ToList();
            cmbProduct.Properties.Items.Clear();
            cmbProduct.Properties.Items.Add(new Product { ProductId = -1 });
            cmbProduct.Properties.Items.AddRange(products);

            if (Alert.Product != null)
            {
                Alert.Product = products.SingleOrDefault(p => p.ProductId == Alert.Product.ProductId);
                ceProduct.Checked = true;
            }

            cmbProduct.DataBindings.Add("EditValue", Alert, "Product");

            List<ProductCategory> productGroups = new ProductManager().GetProductGroups().OrderBy(p => p.Name).ToList();
            cmbProductGroup.Properties.Items.Clear();
            cmbProductGroup.Properties.Items.Add(new ProductCategory { CategoryId = -1 });
            cmbProductGroup.Properties.Items.AddRange(productGroups);

            if (Alert.ProductGroup != null)
            {
                Alert.ProductGroup = productGroups.SingleOrDefault(p => p.CategoryId == Alert.ProductGroup.CategoryId);
                ceProductGroup.Checked = true;
            }

            cmbProductGroup.DataBindings.Add("EditValue", Alert, "ProductGroup");

            chkLevel1Active.DataBindings.Add("EditValue", Alert, "IsLevel1Active");
            chkLevel2Active.DataBindings.Add("EditValue", Alert, "IsLevel2Active");
            chkLevel3Active.DataBindings.Add("EditValue", Alert, "IsLevel3Active");
            chkLevel4Active.DataBindings.Add("EditValue", Alert, "IsLevel4Active");

            teStartTime.DataBindings.Add("EditValue", Alert, "StartTime");

            UpdateProductCombosVisibility();
            UpdateProductCombos();
            UpdateExpiringProductsType();

            SetupContextMenuStripForTemplates();

            ApplyCustomProperties();

            CheckFeatures();
        }

        private void ApplyCustomProperties()
        {
            GetTransferErrorsCustomProperties().ForEach(MarkErrorTypesAsPresent);

            IEnumerable<IEnumerable<string>> GetTransferErrorsCustomProperties()
            {
                return Alert.CustomProperties.Where(
                                property => AdministrativeAlert.CustomProperty.TransferErrorsTypes == property.Key
                                            && null != property.Value)
                            .Select(properties => properties.Value.Split(','));
            }

            void MarkErrorTypesAsPresent(IEnumerable<string> errorTypes)
            {
                errorTypes.ForEach(
                    errorType =>
                    {
                        if (int.TryParse(errorType, out int intErrorType))
                        {
                            chkListTransferErrorsTypes.SetItemChecked(intErrorType - 1, true);
                        }
                    });
            }
        }

        private void CheckFeatures()
        {
            chkDoNotTriggerOnWeekends.Visible = true;
        }

        private void UpdateExpiringProductsType()
        {
            bool sectionVisible = IndexToAlertType() == AdministrativeAlert.AdmAlertType.Expiring_Products;

            lblStartTime.Visible = sectionVisible;
            teStartTime.Visible = sectionVisible;
        }

        private void SetupContextMenuStripForTemplates()
        {
            productToolStripMenuItem.Visible = false;
            tradeIdToolStripMenuItem.Visible = false;
            traderToolStripMenuItem.Visible = false;

            if (IndexToAlertType() == AdministrativeAlert.AdmAlertType.Trade_Time)
            {
                productToolStripMenuItem.Visible = true;
                tradeIdToolStripMenuItem.Visible = true;
                traderToolStripMenuItem.Visible = true;
            }
        }

        /// <summary>
        /// Check if alert is valid for save
        /// </summary>
        /// <returns>bool if save is allowed</returns>
        private bool ValidateAlert()
        {
            bool valid = true;
            if (string.IsNullOrWhiteSpace(txtTitle.Text))
            {
                dxErrorProvider1.SetError(txtTitle, "Alert Title required");
                valid = false;
            }

            if (cbxMethod.SelectedIndex < 0)
            {
                dxErrorProvider1.SetError(cbxMethod, "Choose alert type.");
                valid = false;
            }

            AdministrativeAlert.AdmAlertType alertType = IndexToAlertType();
            if (txtThreshold.EditValue.Equals(0) && alertType != AdministrativeAlert.AdmAlertType.Trade_Time)
            {
                dxErrorProvider1.SetError(txtThreshold, "Threshold should be greater than zero");
                valid = false;
            }

            if (pePortfolio.EditValue == null)
            {
                dxErrorProvider1.SetError(pePortfolio, "Choose portfolio for alert.");
                valid = false;
            }

            if (leGroup1.GetSelectedDataRow() == null)
            {
                dxErrorProvider1.SetError(leGroup1, "Choose recipient group for level 1 alert.");
                valid = false;
            }

            if (leGroup2.GetSelectedDataRow() == null)
            {
                dxErrorProvider1.SetError(leGroup2, "Choose recipient group for level 2 alert.");
                valid = false;
            }

            if (leGroup3.GetSelectedDataRow() == null)
            {
                dxErrorProvider1.SetError(leGroup3, "Choose recipient group for level 3 alert.");
                valid = false;
            }

            if (leGroup4.GetSelectedDataRow() == null)
            {
                dxErrorProvider1.SetError(leGroup4, "Choose recipient group for level 4 alert.");
                valid = false;
            }

            return valid;
        }

        /// <summary>
        /// Close the form without saving changes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        /// <summary>
        /// Save current alert. Close form on successful save
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (ValidateAlert())
            {
                try
                {
                    Alert.Escalation = TimeSpan.FromMinutes(Convert.ToInt32(txtEscalation.EditValue));
                    Alert.ConditionCheckCount = txtConditionCountCheck.EditValue != null
                        ? Convert.ToInt32(txtConditionCountCheck.EditValue)
                        : (int?)null;

                    if (txtEscalation1.EditValue != null)
                    {
                        Alert.Level1Escalation = TimeSpan.FromMinutes(Convert.ToInt32(txtEscalation1.EditValue));
                    }
                    else
                    {
                        Alert.Level1Escalation = null;
                    }

                    if (txtEscalation2.EditValue != null)
                    {
                        Alert.Level2Escalation = TimeSpan.FromMinutes(Convert.ToInt32(txtEscalation2.EditValue));
                    }
                    else
                    {
                        Alert.Level2Escalation = null;
                    }

                    if (txtEscalation3.EditValue != null)
                    {
                        Alert.Level3Escalation = TimeSpan.FromMinutes(Convert.ToInt32(txtEscalation3.EditValue));
                    }
                    else
                    {
                        Alert.Level3Escalation = null;
                    }

                    if (txtEscalation4.EditValue != null)
                    {
                        Alert.Level4Escalation = TimeSpan.FromMinutes(Convert.ToInt32(txtEscalation4.EditValue));
                    }
                    else
                    {
                        Alert.Level4Escalation = null;
                    }

                    Alert.TypeOfAlert = IndexToAlertType();

                    if (Alert.TypeOfAlert == AdministrativeAlert.AdmAlertType.Trade_Time)
                    {
                        if (Alert.TypeOfBoundary != AdministrativeAlert.BoundaryType.InRange)
                        {
                            Alert.TradeTime = teThresholdTime.Time.TimeOfDay;
                        }
                        else
                        {
                            Alert.TradeTimeRange = new AdministrativeAlert.TimeRange(
                                teThresholdStartTime.Time.TimeOfDay,
                                teThresholdEndTime.Time.TimeOfDay);
                        }
                    }
                    else
                    {
                        Alert.ThresholdValue = Convert.ToDecimal(txtThreshold.EditValue);
                    }

                    if (Alert.TypeOfAlert == AdministrativeAlert.AdmAlertType.Flat_Price_Position)
                    {
                        Alert.Product = ceProduct.Checked ? cmbProduct.EditValue as Product : null;
                        Alert.ProductGroup =
                            ceProductGroup.Checked ? cmbProductGroup.EditValue as ProductCategory : null;
                    }

                    if (pePortfolio.EditValue != null)
                    {
                        Alert.Portfolio = (Portfolio)pePortfolio.EditValue;
                    }

                    Alert.AlertGroup1 = (AdministrativeAlertGroup)leGroup1.GetSelectedDataRow();
                    Alert.AlertGroup2 = (AdministrativeAlertGroup)leGroup2.GetSelectedDataRow();
                    Alert.AlertGroup3 = (AdministrativeAlertGroup)leGroup3.GetSelectedDataRow();
                    Alert.AlertGroup4 = (AdministrativeAlertGroup)leGroup4.GetSelectedDataRow();

                    Alert.IsLevel1Active = chkLevel1Active.Checked;
                    Alert.IsLevel2Active = chkLevel2Active.Checked;
                    Alert.IsLevel3Active = chkLevel3Active.Checked;
                    Alert.IsLevel4Active = chkLevel4Active.Checked;

                    Alert.DoNotTriggerOnWeekends = chkDoNotTriggerOnWeekends.Checked;

                    Alert.StartTime = teStartTime.Time;

                    List<string> list = new List<string>();

                    for (int i = 0; i < chkListTransferErrorsTypes.CheckedIndices.Count; i++)
                    {
                        list.Add((chkListTransferErrorsTypes.CheckedIndices[i] + 1).ToString());
                    }

                    Alert[AdministrativeAlert.CustomProperty.TransferErrorsTypes] = string.Join(",", list);

                    AuditContext context = MainForm.CreateAuditContext(
                        Alert.AlertId > 0 ? "Update administrative alert" : "Create administrative alert");

                    AdministrativeAlertManager.SaveAlert(Alert, context);
                    Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error on save");
                }
            }
        }

        /// <summary>
        /// Reset validation errors on user input to affected controls
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void txt_EditValueChanging(object sender, ChangingEventArgs e)
        {
            if (dxErrorProvider1.HasErrors)
            {
                dxErrorProvider1.SetError((Control)sender, null);
            }
        }

        /// <summary>
        /// Show /hide proper control for threshold in case of change alert type
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cbxMethod_SelectedIndexChanged(object sender, EventArgs e)
        {
            AdministrativeAlert.AdmAlertType alertType = IndexToAlertType();
            bool isTransferErrorsAlert = alertType == AdministrativeAlert.AdmAlertType.TransferServiceErrors;

            lblThreshold.Visible = !isTransferErrorsAlert;
            rgrBoundary.Visible = !isTransferErrorsAlert;
            chkListTransferErrorsTypes.Visible = isTransferErrorsAlert;

            bool isTradeTimeAlert = alertType == AdministrativeAlert.AdmAlertType.Trade_Time;

            UpdateTimeEditorsVisibility();

            if (isTradeTimeAlert)
            {
                rgrBoundary.Properties.Items.Add(
                    new RadioGroupItem((short)AdministrativeAlert.BoundaryType.InRange, "In Range"));
                rgrBoundary.Height += 20;
            }
            else
            {
                RadioGroupItem item = rgrBoundary.Properties.Items.GetItemByValue(
                    (short)AdministrativeAlert.BoundaryType.InRange);

                if (item != null)
                {
                    rgrBoundary.Properties.Items.Remove(item);
                    rgrBoundary.Height -= 20;
                }
            }

            txtThreshold.Visible = !isTradeTimeAlert && !isTransferErrorsAlert;

            UpdateProductCombosVisibility();
            UpdateExpiringProductsType();
            SetupContextMenuStripForTemplates();
        }

        private void UpdateProductCombosVisibility()
        {
            bool isFlatPricePositionAlert = IndexToAlertType() == AdministrativeAlert.AdmAlertType.Flat_Price_Position;
            lblProduct.Visible = isFlatPricePositionAlert;
            cmbProduct.Visible = isFlatPricePositionAlert;
            ceProduct.Visible = isFlatPricePositionAlert;
            lblProductGroup.Visible = isFlatPricePositionAlert;
            cmbProductGroup.Visible = isFlatPricePositionAlert;
            ceProductGroup.Visible = isFlatPricePositionAlert;
        }

        /// <summary>
        /// Determine Alert type by type combobox index
        /// </summary>
        /// <returns>AdmAlertType</returns>
        private AdministrativeAlert.AdmAlertType IndexToAlertType()
        {
            try
            {
                return (AdministrativeAlert.AdmAlertType)(cbxMethod.SelectedIndex + 1);
            }
            catch
            {
                return AdministrativeAlert.AdmAlertType.NaN;
            }
        }

        /// <summary>
        /// Set selected index for given alert type
        /// </summary>
        /// <param name="type">AdmAlertType</param>
        private void TypeToIndex(AdministrativeAlert.AdmAlertType type)
        {
            try
            {
                if (type != AdministrativeAlert.AdmAlertType.NaN)
                {
                    cbxMethod.SelectedIndex = ((int)type) - 1;
                }
            }
            catch
            {
                cbxMethod.SelectedIndex = -1;
            }
        }

        private void tlTarget_FocusedNodeChanged(object sender, FocusedNodeChangedEventArgs e)
        {
            if (e.Node == null)
            {
                return;
            }

            int portfolioId = (int)e.Node.GetValue("PortfolioId");
            Portfolio portfolio = _portfolios.FirstOrDefault(x => x.PortfolioId == portfolioId);

            pePortfolio.EditValue = portfolio;
            pePortfolio.ClosePopup();
        }

        private void ValueChanged(object sender, EventArgs e)
        {
            dxErrorProvider1.SetError(sender as Control, null);
        }

        private void ceProdutGroup_CheckedChanged(object sender, EventArgs e)
        {
            if (ceProductGroup.Checked)
            {
                ceProduct.Checked = false;
            }

            UpdateProductCombos();
        }

        private void ceProduct_CheckedChanged(object sender, EventArgs e)
        {
            if (ceProduct.Checked)
            {
                ceProductGroup.Checked = false;
            }

            UpdateProductCombos();
        }

        public void UpdateProductCombos()
        {
            cmbProduct.Enabled = ceProduct.Checked;
            cmbProductGroup.Enabled = ceProductGroup.Checked;
        }

        private void rgrBoundary_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateTimeEditorsVisibility();
        }

        private void UpdateTimeEditorsVisibility()
        {
            bool tradeTimeSelected = IndexToAlertType() == AdministrativeAlert.AdmAlertType.Trade_Time;
            bool rangeSelected = rgrBoundary.EditValue is short
                                 && (short)rgrBoundary.EditValue == (short)AdministrativeAlert.BoundaryType.InRange;

            lblFrom.Visible = tradeTimeSelected && rangeSelected;
            lblTo.Visible = tradeTimeSelected && rangeSelected;
            teThresholdStartTime.Visible = tradeTimeSelected && rangeSelected;
            teThresholdEndTime.Visible = tradeTimeSelected && rangeSelected;
            teThresholdTime.Visible = tradeTimeSelected && !rangeSelected;
        }

        private void contextMenuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            string placeholder = string.Empty;

            if (e.ClickedItem == subjectToolStripMenuItem)
            {
                placeholder = "{subject}";
            }

            if (e.ClickedItem == messageToolStripMenuItem)
            {
                placeholder = "{message}";
            }

            if (e.ClickedItem == actualValueToolStripMenuItem)
            {
                placeholder = "{actual_value}";
            }

            if (e.ClickedItem == thresholdToolStripMenuItem)
            {
                placeholder = "{threshold}";
            }

            if (e.ClickedItem == bookToolStripMenuItem)
            {
                placeholder = "{book}";
            }

            if (e.ClickedItem == traderToolStripMenuItem)
            {
                placeholder = "{trader}";
            }

            if (e.ClickedItem == productToolStripMenuItem)
            {
                placeholder = "{product}";
            }

            if (e.ClickedItem == tradeIdToolStripMenuItem)
            {
                placeholder = "{trade_id}";
            }

            ContextMenuStrip menuStrip = sender as ContextMenuStrip;
            if (menuStrip == null)
            {
                return;
            }

            TextBoxMaskBox txt = menuStrip.SourceControl as TextBoxMaskBox;
            if (txt != null && !string.IsNullOrEmpty(placeholder))
            {
                if (txt.Parent.Name == txtEmailSubjectTemplate.Name)
                {
                    int selectionStart = txtEmailSubjectTemplate.SelectionStart;
                    txtEmailSubjectTemplate.Text = txtEmailSubjectTemplate.Text.Insert(selectionStart, placeholder);

                    txtEmailSubjectTemplate.SelectionStart = selectionStart + placeholder.Length;
                }

                if (txt.Parent.Name == txtEmailMessageTemplate.Name)
                {
                    int selectionStart = txtEmailMessageTemplate.SelectionStart;
                    txtEmailMessageTemplate.Text = txtEmailMessageTemplate.Text.Insert(selectionStart, placeholder);

                    txtEmailMessageTemplate.SelectionStart = selectionStart + placeholder.Length;
                }
            }
        }
    }
}