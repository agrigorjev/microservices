﻿namespace Mandara.AdmTool
{
    partial class UserConnectionsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserConnectionsForm));
            this.panel2 = new System.Windows.Forms.Panel();
            this.gcUserConnections = new DevExpress.XtraGrid.GridControl();
            this.gvUserConnections = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colUser = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colServer = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colIpAddress = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colReconnect = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemHyperLinkEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemHyperLinkEdit();
            this.riGroups = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.repositoryItemCheckEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.repositoryItemCheckEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.repositoryItemCheckEdit3 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.repositoryItemCheckEdit4 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.userReconnectRepositoryItemButtonEdit = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this._updateTimer = new System.Windows.Forms.Timer(this.components);
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gcUserConnections)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvUserConnections)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemHyperLinkEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.riGroups)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.userReconnectRepositoryItemButtonEdit)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.gcUserConnections);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(626, 450);
            this.panel2.TabIndex = 29;
            // 
            // gcUserConnections
            // 
            this.gcUserConnections.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gcUserConnections.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.gcUserConnections.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.gcUserConnections.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.gcUserConnections.EmbeddedNavigator.Buttons.First.Visible = false;
            this.gcUserConnections.EmbeddedNavigator.Buttons.Last.Visible = false;
            this.gcUserConnections.EmbeddedNavigator.Buttons.Next.Visible = false;
            this.gcUserConnections.EmbeddedNavigator.Buttons.NextPage.Visible = false;
            this.gcUserConnections.EmbeddedNavigator.Buttons.Prev.Visible = false;
            this.gcUserConnections.EmbeddedNavigator.Buttons.PrevPage.Visible = false;
            this.gcUserConnections.EmbeddedNavigator.TextLocation = DevExpress.XtraEditors.NavigatorButtonsTextLocation.None;
            this.gcUserConnections.Location = new System.Drawing.Point(0, 0);
            this.gcUserConnections.MainView = this.gvUserConnections;
            this.gcUserConnections.Name = "gcUserConnections";
            this.gcUserConnections.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.riGroups,
            this.repositoryItemCheckEdit1,
            this.repositoryItemCheckEdit2,
            this.repositoryItemCheckEdit3,
            this.repositoryItemCheckEdit4,
            this.userReconnectRepositoryItemButtonEdit,
            this.repositoryItemHyperLinkEdit1});
            this.gcUserConnections.Size = new System.Drawing.Size(626, 450);
            this.gcUserConnections.TabIndex = 2;
            this.gcUserConnections.UseEmbeddedNavigator = true;
            this.gcUserConnections.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gvUserConnections});
            // 
            // gvUserConnections
            // 
            this.gvUserConnections.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colUser,
            this.colServer,
            this.colIpAddress,
            this.colReconnect});
            this.gvUserConnections.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gvUserConnections.GridControl = this.gcUserConnections;
            this.gvUserConnections.GroupFooterShowMode = DevExpress.XtraGrid.Views.Grid.GroupFooterShowMode.VisibleAlways;
            this.gvUserConnections.Name = "gvUserConnections";
            this.gvUserConnections.OptionsBehavior.Editable = false;
            this.gvUserConnections.OptionsCustomization.AllowGroup = false;
            this.gvUserConnections.OptionsView.ShowGroupPanel = false;
            this.gvUserConnections.ShowButtonMode = DevExpress.XtraGrid.Views.Base.ShowButtonModeEnum.Default;
            this.gvUserConnections.RowCellClick += new DevExpress.XtraGrid.Views.Grid.RowCellClickEventHandler(this.gvUserConnections_RowCellClick);
            // 
            // colUser
            // 
            this.colUser.Caption = "User";
            this.colUser.FieldName = "Name";
            this.colUser.MinWidth = 100;
            this.colUser.Name = "colUser";
            this.colUser.OptionsColumn.AllowEdit = false;
            this.colUser.OptionsColumn.AllowFocus = false;
            this.colUser.Visible = true;
            this.colUser.VisibleIndex = 0;
            this.colUser.Width = 100;
            // 
            // colServer
            // 
            this.colServer.Caption = "Server";
            this.colServer.FieldName = "ServerName";
            this.colServer.MinWidth = 100;
            this.colServer.Name = "colServer";
            this.colServer.OptionsColumn.AllowEdit = false;
            this.colServer.OptionsColumn.AllowFocus = false;
            this.colServer.Visible = true;
            this.colServer.VisibleIndex = 1;
            this.colServer.Width = 100;
            // 
            // colIpAddress
            // 
            this.colIpAddress.Caption = "IP";
            this.colIpAddress.FieldName = "IpAddress";
            this.colIpAddress.Name = "colIpAddress";
            this.colIpAddress.OptionsColumn.AllowEdit = false;
            this.colIpAddress.OptionsColumn.AllowFocus = false;
            this.colIpAddress.Visible = true;
            this.colIpAddress.VisibleIndex = 2;
            // 
            // colReconnect
            // 
            this.colReconnect.Caption = "Reconnect";
            this.colReconnect.ColumnEdit = this.repositoryItemHyperLinkEdit1;
            this.colReconnect.FieldName = "Reconnect";
            this.colReconnect.Name = "colReconnect";
            this.colReconnect.OptionsColumn.AllowEdit = false;
            this.colReconnect.Visible = true;
            this.colReconnect.VisibleIndex = 3;
            // 
            // repositoryItemHyperLinkEdit1
            // 
            this.repositoryItemHyperLinkEdit1.AutoHeight = false;
            this.repositoryItemHyperLinkEdit1.Name = "repositoryItemHyperLinkEdit1";
            // 
            // riGroups
            // 
            this.riGroups.AutoHeight = false;
            this.riGroups.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.riGroups.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("GroupName", "Group")});
            this.riGroups.Name = "riGroups";
            this.riGroups.NullText = "[Group is not specified]";
            this.riGroups.ValueMember = "Instance";
            // 
            // repositoryItemCheckEdit1
            // 
            this.repositoryItemCheckEdit1.AutoHeight = false;
            this.repositoryItemCheckEdit1.Name = "repositoryItemCheckEdit1";
            // 
            // repositoryItemCheckEdit2
            // 
            this.repositoryItemCheckEdit2.AutoHeight = false;
            this.repositoryItemCheckEdit2.Name = "repositoryItemCheckEdit2";
            // 
            // repositoryItemCheckEdit3
            // 
            this.repositoryItemCheckEdit3.AutoHeight = false;
            this.repositoryItemCheckEdit3.Name = "repositoryItemCheckEdit3";
            // 
            // repositoryItemCheckEdit4
            // 
            this.repositoryItemCheckEdit4.AutoHeight = false;
            this.repositoryItemCheckEdit4.Name = "repositoryItemCheckEdit4";
            // 
            // userReconnectRepositoryItemButtonEdit
            // 
            this.userReconnectRepositoryItemButtonEdit.Name = "userReconnectRepositoryItemButtonEdit";
            // 
            // _updateTimer
            // 
            this._updateTimer.Interval = 1000;
            this._updateTimer.Tick += new System.EventHandler(this._updateTimer_Tick);
            // 
            // UserConnectionsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(626, 450);
            this.Controls.Add(this.panel2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "UserConnectionsForm";
            this.Text = "User Connections";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.UserConnectionsForm_FormClosing);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gcUserConnections)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvUserConnections)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemHyperLinkEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.riGroups)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.userReconnectRepositoryItemButtonEdit)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private DevExpress.XtraGrid.GridControl gcUserConnections;
        private DevExpress.XtraGrid.Views.Grid.GridView gvUserConnections;
        private DevExpress.XtraGrid.Columns.GridColumn colUser;
        private DevExpress.XtraGrid.Columns.GridColumn colServer;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit riGroups;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit2;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit3;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit4;
        private DevExpress.XtraGrid.Columns.GridColumn colReconnect;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit userReconnectRepositoryItemButtonEdit;
        private System.Windows.Forms.Timer _updateTimer;
        private DevExpress.XtraGrid.Columns.GridColumn colIpAddress;
        private DevExpress.XtraEditors.Repository.RepositoryItemHyperLinkEdit repositoryItemHyperLinkEdit1;

    }
}