﻿namespace Mandara.AdmTool
{
    partial class AlertEditForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AlertEditForm));
            this.label1 = new System.Windows.Forms.Label();
            this.txtTitle = new DevExpress.XtraEditors.TextEdit();
            this.cbxMethod = new DevExpress.XtraEditors.ComboBoxEdit();
            this.label2 = new System.Windows.Forms.Label();
            this.btnSave = new DevExpress.XtraEditors.SimpleButton();
            this.btnCancel = new DevExpress.XtraEditors.SimpleButton();
            this.dxErrorProvider1 = new DevExpress.XtraEditors.DXErrorProvider.DXErrorProvider(this.components);
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.txtEscalation = new DevExpress.XtraEditors.TextEdit();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.lblThreshold = new DevExpress.XtraEditors.LabelControl();
            this.teThresholdTime = new DevExpress.XtraEditors.TimeEdit();
            this.txtThreshold = new DevExpress.XtraEditors.TextEdit();
            this.leGroup1 = new DevExpress.XtraEditors.LookUpEdit();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.leGroup2 = new DevExpress.XtraEditors.LookUpEdit();
            this.cbxActive = new DevExpress.XtraEditors.CheckEdit();
            this.rgrBoundary = new DevExpress.XtraEditors.RadioGroup();
            this.label7 = new System.Windows.Forms.Label();
            this.popupTarget = new DevExpress.XtraEditors.PopupContainerControl();
            this.tlTarget = new DevExpress.XtraTreeList.TreeList();
            this.nameClmn = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.pePortfolio = new DevExpress.XtraEditors.PopupContainerEdit();
            this.lblProduct = new System.Windows.Forms.Label();
            this.cmbProduct = new DevExpress.XtraEditors.ComboBoxEdit();
            this.leGroup4 = new DevExpress.XtraEditors.LookUpEdit();
            this.leGroup3 = new DevExpress.XtraEditors.LookUpEdit();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.txtEscalation1 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.txtEscalation2 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl12 = new DevExpress.XtraEditors.LabelControl();
            this.txtEscalation4 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl13 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl14 = new DevExpress.XtraEditors.LabelControl();
            this.txtEscalation3 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl15 = new DevExpress.XtraEditors.LabelControl();
            this.txtConditionCountCheck = new DevExpress.XtraEditors.TextEdit();
            this.labelControl16 = new DevExpress.XtraEditors.LabelControl();
            this.teThresholdEndTime = new DevExpress.XtraEditors.TimeEdit();
            this.lblFrom = new DevExpress.XtraEditors.LabelControl();
            this.lblTo = new DevExpress.XtraEditors.LabelControl();
            this.cmbProductGroup = new DevExpress.XtraEditors.ComboBoxEdit();
            this.lblProductGroup = new System.Windows.Forms.Label();
            this.ceProductGroup = new DevExpress.XtraEditors.CheckEdit();
            this.ceProduct = new DevExpress.XtraEditors.CheckEdit();
            this.teThresholdStartTime = new DevExpress.XtraEditors.TimeEdit();
            this.xtraTabControl1 = new DevExpress.XtraTab.XtraTabControl();
            this.xtraTabPage1 = new DevExpress.XtraTab.XtraTabPage();
            this.txtMessage4 = new DevExpress.XtraEditors.MemoEdit();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtSubject4 = new DevExpress.XtraEditors.TextEdit();
            this.txtSubject1 = new DevExpress.XtraEditors.TextEdit();
            this.txtMessage1 = new DevExpress.XtraEditors.MemoEdit();
            this.label10 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtSubject2 = new DevExpress.XtraEditors.TextEdit();
            this.txtMessage2 = new DevExpress.XtraEditors.MemoEdit();
            this.txtMessage3 = new DevExpress.XtraEditors.MemoEdit();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtSubject3 = new DevExpress.XtraEditors.TextEdit();
            this.xtraTabPage2 = new DevExpress.XtraTab.XtraTabPage();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtEmailSubjectTemplate = new DevExpress.XtraEditors.TextEdit();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.subjectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.messageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.actualValueToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thresholdToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bookToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tradeIdToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.productToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.traderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.txtEmailMessageTemplate = new DevExpress.XtraEditors.MemoEdit();
            this.chkLevel1Active = new DevExpress.XtraEditors.CheckEdit();
            this.chkLevel2Active = new DevExpress.XtraEditors.CheckEdit();
            this.chkLevel3Active = new DevExpress.XtraEditors.CheckEdit();
            this.chkLevel4Active = new DevExpress.XtraEditors.CheckEdit();
            this.lblStartTime = new DevExpress.XtraEditors.LabelControl();
            this.teStartTime = new DevExpress.XtraEditors.TimeEdit();
            this.chkDoNotTriggerOnWeekends = new DevExpress.XtraEditors.CheckEdit();
            this.chkListTransferErrorsTypes = new DevExpress.XtraEditors.CheckedListBoxControl();
            ((System.ComponentModel.ISupportInitialize)(this.txtTitle.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbxMethod.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dxErrorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEscalation.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.teThresholdTime.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtThreshold.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.leGroup1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.leGroup2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbxActive.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rgrBoundary.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.popupTarget)).BeginInit();
            this.popupTarget.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tlTarget)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pePortfolio.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbProduct.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.leGroup4.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.leGroup3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEscalation1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEscalation2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEscalation4.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEscalation3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtConditionCountCheck.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.teThresholdEndTime.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbProductGroup.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ceProductGroup.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ceProduct.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.teThresholdStartTime.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).BeginInit();
            this.xtraTabControl1.SuspendLayout();
            this.xtraTabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtMessage4.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSubject4.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSubject1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMessage1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSubject2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMessage2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMessage3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSubject3.Properties)).BeginInit();
            this.xtraTabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtEmailSubjectTemplate.Properties)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtEmailMessageTemplate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkLevel1Active.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkLevel2Active.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkLevel3Active.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkLevel4Active.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.teStartTime.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkDoNotTriggerOnWeekends.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkListTransferErrorsTypes)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(31, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Alert Title :";
            // 
            // txtTitle
            // 
            this.txtTitle.Location = new System.Drawing.Point(96, 4);
            this.txtTitle.Name = "txtTitle";
            this.txtTitle.Size = new System.Drawing.Size(338, 20);
            this.txtTitle.TabIndex = 0;
            this.txtTitle.EditValueChanging += new DevExpress.XtraEditors.Controls.ChangingEventHandler(this.txt_EditValueChanging);
            // 
            // cbxMethod
            // 
            this.cbxMethod.Location = new System.Drawing.Point(96, 30);
            this.cbxMethod.Name = "cbxMethod";
            this.cbxMethod.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cbxMethod.Properties.DropDownRows = 10;
            this.cbxMethod.Properties.Items.AddRange(new object[] {
            "PnL",
            "VaR",
            "Flat_Price_Position",
            "Trade_Time",
            "Expiring_Products",
            "Transfer Errors",
            "Trade In Book"});
            this.cbxMethod.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
            this.cbxMethod.Size = new System.Drawing.Size(338, 20);
            this.cbxMethod.TabIndex = 1;
            this.cbxMethod.SelectedIndexChanged += new System.EventHandler(this.cbxMethod_SelectedIndexChanged);
            this.cbxMethod.EditValueChanging += new DevExpress.XtraEditors.Controls.ChangingEventHandler(this.txt_EditValueChanging);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(27, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Alert Type :";
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnSave.Location = new System.Drawing.Point(779, 551);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(103, 23);
            this.btnSave.TabIndex = 24;
            this.btnSave.Text = "Save";
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnCancel.Location = new System.Drawing.Point(664, 551);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(103, 23);
            this.btnCancel.TabIndex = 25;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // dxErrorProvider1
            // 
            this.dxErrorProvider1.ContainerControl = this;
            // 
            // labelControl1
            // 
            this.labelControl1.Location = new System.Drawing.Point(538, 40);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(118, 13);
            this.labelControl1.TabIndex = 11;
            this.labelControl1.Text = "Default Escalation Time :";
            // 
            // txtEscalation
            // 
            this.txtEscalation.Location = new System.Drawing.Point(662, 37);
            this.txtEscalation.Name = "txtEscalation";
            this.txtEscalation.Properties.Mask.EditMask = "######";
            this.txtEscalation.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtEscalation.Properties.Mask.SaveLiteral = false;
            this.txtEscalation.Properties.Mask.ShowPlaceHolders = false;
            this.txtEscalation.Size = new System.Drawing.Size(100, 20);
            this.txtEscalation.TabIndex = 17;
            this.txtEscalation.EditValueChanging += new DevExpress.XtraEditors.Controls.ChangingEventHandler(this.txt_EditValueChanging);
            // 
            // labelControl2
            // 
            this.labelControl2.Location = new System.Drawing.Point(768, 40);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(45, 13);
            this.labelControl2.TabIndex = 13;
            this.labelControl2.Text = "(minutes)";
            // 
            // lblThreshold
            // 
            this.lblThreshold.Location = new System.Drawing.Point(33, 75);
            this.lblThreshold.Name = "lblThreshold";
            this.lblThreshold.Size = new System.Drawing.Size(54, 13);
            this.lblThreshold.TabIndex = 11;
            this.lblThreshold.Text = "Threshold :";
            // 
            // teThresholdTime
            // 
            this.teThresholdTime.EditValue = new System.DateTime(2012, 11, 16, 0, 0, 0, 0);
            this.teThresholdTime.Location = new System.Drawing.Point(204, 72);
            this.teThresholdTime.Name = "teThresholdTime";
            this.teThresholdTime.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.teThresholdTime.Size = new System.Drawing.Size(100, 20);
            this.teThresholdTime.TabIndex = 14;
            this.teThresholdTime.EditValueChanging += new DevExpress.XtraEditors.Controls.ChangingEventHandler(this.txt_EditValueChanging);
            // 
            // txtThreshold
            // 
            this.txtThreshold.Location = new System.Drawing.Point(204, 72);
            this.txtThreshold.Name = "txtThreshold";
            this.txtThreshold.Properties.Mask.EditMask = "n";
            this.txtThreshold.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtThreshold.Properties.Mask.SaveLiteral = false;
            this.txtThreshold.Properties.Mask.ShowPlaceHolders = false;
            this.txtThreshold.Size = new System.Drawing.Size(100, 20);
            this.txtThreshold.TabIndex = 4;
            this.txtThreshold.EditValueChanging += new DevExpress.XtraEditors.Controls.ChangingEventHandler(this.txt_EditValueChanging);
            // 
            // leGroup1
            // 
            this.leGroup1.Location = new System.Drawing.Point(96, 141);
            this.leGroup1.Name = "leGroup1";
            this.leGroup1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.leGroup1.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("Title", "Title")});
            this.leGroup1.Properties.DisplayMember = "Title";
            this.leGroup1.Properties.EditValueChanged += new System.EventHandler(this.ValueChanged);
            this.leGroup1.Size = new System.Drawing.Size(215, 20);
            this.leGroup1.TabIndex = 5;
            // 
            // labelControl4
            // 
            this.labelControl4.Location = new System.Drawing.Point(15, 144);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(72, 13);
            this.labelControl4.TabIndex = 11;
            this.labelControl4.Text = "Level 1 group :";
            // 
            // labelControl5
            // 
            this.labelControl5.Location = new System.Drawing.Point(15, 170);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(72, 13);
            this.labelControl5.TabIndex = 11;
            this.labelControl5.Text = "Level 2 group :";
            // 
            // leGroup2
            // 
            this.leGroup2.Location = new System.Drawing.Point(96, 167);
            this.leGroup2.Name = "leGroup2";
            this.leGroup2.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.leGroup2.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("Title", "Title")});
            this.leGroup2.Properties.DisplayMember = "Title";
            this.leGroup2.Properties.EditValueChanged += new System.EventHandler(this.ValueChanged);
            this.leGroup2.Size = new System.Drawing.Size(215, 20);
            this.leGroup2.TabIndex = 6;
            // 
            // cbxActive
            // 
            this.cbxActive.Location = new System.Drawing.Point(449, 4);
            this.cbxActive.Name = "cbxActive";
            this.cbxActive.Properties.Caption = "Active";
            this.cbxActive.Size = new System.Drawing.Size(75, 19);
            this.cbxActive.TabIndex = 2;
            // 
            // rgrBoundary
            // 
            this.rgrBoundary.Location = new System.Drawing.Point(96, 58);
            this.rgrBoundary.Name = "rgrBoundary";
            this.rgrBoundary.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(1)), "Less Than"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem(((short)(2)), "Greater Than")});
            this.rgrBoundary.Properties.NullText = "1";
            this.rgrBoundary.Size = new System.Drawing.Size(99, 53);
            this.rgrBoundary.TabIndex = 3;
            this.rgrBoundary.SelectedIndexChanged += new System.EventHandler(this.rgrBoundary_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(488, 66);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(54, 13);
            this.label7.TabIndex = 29;
            this.label7.Text = "Portfolio :";
            // 
            // popupTarget
            // 
            this.popupTarget.Controls.Add(this.tlTarget);
            this.popupTarget.Location = new System.Drawing.Point(814, 33);
            this.popupTarget.Name = "popupTarget";
            this.popupTarget.Size = new System.Drawing.Size(215, 199);
            this.popupTarget.TabIndex = 30;
            // 
            // tlTarget
            // 
            this.tlTarget.Appearance.FocusedRow.BackColor = System.Drawing.Color.Navy;
            this.tlTarget.Appearance.FocusedRow.ForeColor = System.Drawing.Color.White;
            this.tlTarget.Appearance.FocusedRow.Options.UseBackColor = true;
            this.tlTarget.Appearance.FocusedRow.Options.UseForeColor = true;
            this.tlTarget.Columns.AddRange(new DevExpress.XtraTreeList.Columns.TreeListColumn[] {
            this.nameClmn});
            this.tlTarget.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlTarget.KeyFieldName = "PortfolioId";
            this.tlTarget.Location = new System.Drawing.Point(0, 0);
            this.tlTarget.Name = "tlTarget";
            this.tlTarget.OptionsBehavior.AutoPopulateColumns = false;
            this.tlTarget.OptionsView.ShowColumns = false;
            this.tlTarget.OptionsView.ShowFilterPanelMode = DevExpress.XtraTreeList.ShowFilterPanelMode.Never;
            this.tlTarget.OptionsView.ShowHorzLines = false;
            this.tlTarget.OptionsView.ShowIndicator = false;
            this.tlTarget.OptionsView.ShowVertLines = false;
            this.tlTarget.ParentFieldName = "ParentPortfolioId";
            this.tlTarget.Size = new System.Drawing.Size(215, 199);
            this.tlTarget.TabIndex = 0;
            this.tlTarget.FocusedNodeChanged += new DevExpress.XtraTreeList.FocusedNodeChangedEventHandler(this.tlTarget_FocusedNodeChanged);
            // 
            // nameClmn
            // 
            this.nameClmn.FieldName = "Name";
            this.nameClmn.Name = "nameClmn";
            this.nameClmn.OptionsColumn.AllowEdit = false;
            this.nameClmn.OptionsColumn.AllowSort = false;
            this.nameClmn.Visible = true;
            this.nameClmn.VisibleIndex = 0;
            // 
            // pePortfolio
            // 
            this.pePortfolio.Location = new System.Drawing.Point(547, 63);
            this.pePortfolio.Name = "pePortfolio";
            this.pePortfolio.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.pePortfolio.Properties.PopupControl = this.popupTarget;
            this.pePortfolio.Properties.EditValueChanged += new System.EventHandler(this.ValueChanged);
            this.pePortfolio.Size = new System.Drawing.Size(215, 20);
            this.pePortfolio.TabIndex = 18;
            // 
            // lblProduct
            // 
            this.lblProduct.AutoSize = true;
            this.lblProduct.Location = new System.Drawing.Point(491, 120);
            this.lblProduct.Name = "lblProduct";
            this.lblProduct.Size = new System.Drawing.Size(51, 13);
            this.lblProduct.TabIndex = 32;
            this.lblProduct.Text = "Product :";
            this.lblProduct.Visible = false;
            // 
            // cmbProduct
            // 
            this.cmbProduct.Location = new System.Drawing.Point(547, 117);
            this.cmbProduct.Name = "cmbProduct";
            this.cmbProduct.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cmbProduct.Size = new System.Drawing.Size(215, 20);
            this.cmbProduct.TabIndex = 19;
            this.cmbProduct.Visible = false;
            // 
            // leGroup4
            // 
            this.leGroup4.Location = new System.Drawing.Point(96, 219);
            this.leGroup4.Name = "leGroup4";
            this.leGroup4.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.leGroup4.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("Title", "Title")});
            this.leGroup4.Properties.DisplayMember = "Title";
            this.leGroup4.Properties.EditValueChanged += new System.EventHandler(this.ValueChanged);
            this.leGroup4.Size = new System.Drawing.Size(215, 20);
            this.leGroup4.TabIndex = 8;
            // 
            // leGroup3
            // 
            this.leGroup3.Location = new System.Drawing.Point(96, 193);
            this.leGroup3.Name = "leGroup3";
            this.leGroup3.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.leGroup3.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("Title", "Title")});
            this.leGroup3.Properties.DisplayMember = "Title";
            this.leGroup3.Properties.EditValueChanged += new System.EventHandler(this.ValueChanged);
            this.leGroup3.Size = new System.Drawing.Size(215, 20);
            this.leGroup3.TabIndex = 7;
            // 
            // labelControl6
            // 
            this.labelControl6.Location = new System.Drawing.Point(15, 196);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(72, 13);
            this.labelControl6.TabIndex = 42;
            this.labelControl6.Text = "Level 3 group :";
            // 
            // labelControl7
            // 
            this.labelControl7.Location = new System.Drawing.Point(15, 222);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(72, 13);
            this.labelControl7.TabIndex = 43;
            this.labelControl7.Text = "Level 4 group :";
            // 
            // labelControl8
            // 
            this.labelControl8.Location = new System.Drawing.Point(768, 144);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(45, 13);
            this.labelControl8.TabIndex = 48;
            this.labelControl8.Text = "(minutes)";
            // 
            // txtEscalation1
            // 
            this.txtEscalation1.Location = new System.Drawing.Point(662, 141);
            this.txtEscalation1.Name = "txtEscalation1";
            this.txtEscalation1.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.True;
            this.txtEscalation1.Properties.Mask.EditMask = "######";
            this.txtEscalation1.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtEscalation1.Properties.Mask.SaveLiteral = false;
            this.txtEscalation1.Properties.Mask.ShowPlaceHolders = false;
            this.txtEscalation1.Size = new System.Drawing.Size(100, 20);
            this.txtEscalation1.TabIndex = 20;
            // 
            // labelControl9
            // 
            this.labelControl9.Location = new System.Drawing.Point(536, 144);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(117, 13);
            this.labelControl9.TabIndex = 46;
            this.labelControl9.Text = "Level 1 Escalation Time :";
            // 
            // labelControl10
            // 
            this.labelControl10.Location = new System.Drawing.Point(768, 170);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(45, 13);
            this.labelControl10.TabIndex = 51;
            this.labelControl10.Text = "(minutes)";
            // 
            // txtEscalation2
            // 
            this.txtEscalation2.Location = new System.Drawing.Point(662, 167);
            this.txtEscalation2.Name = "txtEscalation2";
            this.txtEscalation2.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.True;
            this.txtEscalation2.Properties.Mask.EditMask = "######";
            this.txtEscalation2.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtEscalation2.Properties.Mask.SaveLiteral = false;
            this.txtEscalation2.Properties.Mask.ShowPlaceHolders = false;
            this.txtEscalation2.Size = new System.Drawing.Size(100, 20);
            this.txtEscalation2.TabIndex = 21;
            // 
            // labelControl11
            // 
            this.labelControl11.Location = new System.Drawing.Point(536, 170);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(117, 13);
            this.labelControl11.TabIndex = 49;
            this.labelControl11.Text = "Level 2 Escalation Time :";
            // 
            // labelControl12
            // 
            this.labelControl12.Location = new System.Drawing.Point(768, 222);
            this.labelControl12.Name = "labelControl12";
            this.labelControl12.Size = new System.Drawing.Size(45, 13);
            this.labelControl12.TabIndex = 57;
            this.labelControl12.Text = "(minutes)";
            // 
            // txtEscalation4
            // 
            this.txtEscalation4.Location = new System.Drawing.Point(662, 219);
            this.txtEscalation4.Name = "txtEscalation4";
            this.txtEscalation4.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.True;
            this.txtEscalation4.Properties.Mask.EditMask = "######";
            this.txtEscalation4.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtEscalation4.Properties.Mask.SaveLiteral = false;
            this.txtEscalation4.Properties.Mask.ShowPlaceHolders = false;
            this.txtEscalation4.Size = new System.Drawing.Size(100, 20);
            this.txtEscalation4.TabIndex = 23;
            // 
            // labelControl13
            // 
            this.labelControl13.Location = new System.Drawing.Point(536, 222);
            this.labelControl13.Name = "labelControl13";
            this.labelControl13.Size = new System.Drawing.Size(117, 13);
            this.labelControl13.TabIndex = 55;
            this.labelControl13.Text = "Level 4 Escalation Time :";
            // 
            // labelControl14
            // 
            this.labelControl14.Location = new System.Drawing.Point(768, 196);
            this.labelControl14.Name = "labelControl14";
            this.labelControl14.Size = new System.Drawing.Size(45, 13);
            this.labelControl14.TabIndex = 54;
            this.labelControl14.Text = "(minutes)";
            // 
            // txtEscalation3
            // 
            this.txtEscalation3.Location = new System.Drawing.Point(662, 193);
            this.txtEscalation3.Name = "txtEscalation3";
            this.txtEscalation3.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.True;
            this.txtEscalation3.Properties.Mask.EditMask = "######";
            this.txtEscalation3.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtEscalation3.Properties.Mask.SaveLiteral = false;
            this.txtEscalation3.Properties.Mask.ShowPlaceHolders = false;
            this.txtEscalation3.Size = new System.Drawing.Size(100, 20);
            this.txtEscalation3.TabIndex = 22;
            // 
            // labelControl15
            // 
            this.labelControl15.Location = new System.Drawing.Point(536, 196);
            this.labelControl15.Name = "labelControl15";
            this.labelControl15.Size = new System.Drawing.Size(117, 13);
            this.labelControl15.TabIndex = 52;
            this.labelControl15.Text = "Level 3 Escalation Time :";
            // 
            // txtConditionCountCheck
            // 
            this.txtConditionCountCheck.Location = new System.Drawing.Point(662, 11);
            this.txtConditionCountCheck.Name = "txtConditionCountCheck";
            this.txtConditionCountCheck.Properties.Mask.EditMask = "######";
            this.txtConditionCountCheck.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            this.txtConditionCountCheck.Properties.Mask.SaveLiteral = false;
            this.txtConditionCountCheck.Properties.Mask.ShowPlaceHolders = false;
            this.txtConditionCountCheck.Size = new System.Drawing.Size(100, 20);
            this.txtConditionCountCheck.TabIndex = 59;
            // 
            // labelControl16
            // 
            this.labelControl16.Location = new System.Drawing.Point(572, 14);
            this.labelControl16.Name = "labelControl16";
            this.labelControl16.Size = new System.Drawing.Size(84, 13);
            this.labelControl16.TabIndex = 58;
            this.labelControl16.Text = "Condition Count :";
            // 
            // teThresholdEndTime
            // 
            this.teThresholdEndTime.EditValue = new System.DateTime(2012, 11, 16, 0, 0, 0, 0);
            this.teThresholdEndTime.Location = new System.Drawing.Point(241, 90);
            this.teThresholdEndTime.Name = "teThresholdEndTime";
            this.teThresholdEndTime.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.teThresholdEndTime.Size = new System.Drawing.Size(100, 20);
            this.teThresholdEndTime.TabIndex = 60;
            // 
            // lblFrom
            // 
            this.lblFrom.Location = new System.Drawing.Point(204, 62);
            this.lblFrom.Name = "lblFrom";
            this.lblFrom.Size = new System.Drawing.Size(31, 13);
            this.lblFrom.TabIndex = 61;
            this.lblFrom.Text = "From :";
            // 
            // lblTo
            // 
            this.lblTo.Location = new System.Drawing.Point(216, 94);
            this.lblTo.Name = "lblTo";
            this.lblTo.Size = new System.Drawing.Size(19, 13);
            this.lblTo.TabIndex = 62;
            this.lblTo.Text = "To :";
            // 
            // cmbProductGroup
            // 
            this.cmbProductGroup.Location = new System.Drawing.Point(547, 90);
            this.cmbProductGroup.Name = "cmbProductGroup";
            this.cmbProductGroup.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cmbProductGroup.Size = new System.Drawing.Size(215, 20);
            this.cmbProductGroup.TabIndex = 63;
            // 
            // lblProductGroup
            // 
            this.lblProductGroup.AutoSize = true;
            this.lblProductGroup.Location = new System.Drawing.Point(458, 93);
            this.lblProductGroup.Name = "lblProductGroup";
            this.lblProductGroup.Size = new System.Drawing.Size(83, 13);
            this.lblProductGroup.TabIndex = 64;
            this.lblProductGroup.Text = "Product Group :";
            this.lblProductGroup.Visible = false;
            // 
            // ceProductGroup
            // 
            this.ceProductGroup.Location = new System.Drawing.Point(766, 90);
            this.ceProductGroup.Name = "ceProductGroup";
            this.ceProductGroup.Properties.Caption = "";
            this.ceProductGroup.Size = new System.Drawing.Size(20, 19);
            this.ceProductGroup.TabIndex = 65;
            this.ceProductGroup.CheckedChanged += new System.EventHandler(this.ceProdutGroup_CheckedChanged);
            // 
            // ceProduct
            // 
            this.ceProduct.Location = new System.Drawing.Point(766, 117);
            this.ceProduct.Name = "ceProduct";
            this.ceProduct.Properties.Caption = "";
            this.ceProduct.Size = new System.Drawing.Size(20, 19);
            this.ceProduct.TabIndex = 66;
            this.ceProduct.CheckedChanged += new System.EventHandler(this.ceProduct_CheckedChanged);
            // 
            // teThresholdStartTime
            // 
            this.teThresholdStartTime.EditValue = new System.DateTime(2012, 11, 16, 0, 0, 0, 0);
            this.teThresholdStartTime.Location = new System.Drawing.Point(241, 59);
            this.teThresholdStartTime.Name = "teThresholdStartTime";
            this.teThresholdStartTime.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.teThresholdStartTime.Size = new System.Drawing.Size(100, 20);
            this.teThresholdStartTime.TabIndex = 67;
            // 
            // xtraTabControl1
            // 
            this.xtraTabControl1.Location = new System.Drawing.Point(11, 249);
            this.xtraTabControl1.Name = "xtraTabControl1";
            this.xtraTabControl1.SelectedTabPage = this.xtraTabPage1;
            this.xtraTabControl1.Size = new System.Drawing.Size(904, 296);
            this.xtraTabControl1.TabIndex = 68;
            this.xtraTabControl1.TabPages.AddRange(new DevExpress.XtraTab.XtraTabPage[] {
            this.xtraTabPage1,
            this.xtraTabPage2});
            // 
            // xtraTabPage1
            // 
            this.xtraTabPage1.Controls.Add(this.txtMessage4);
            this.xtraTabPage1.Controls.Add(this.label4);
            this.xtraTabPage1.Controls.Add(this.label3);
            this.xtraTabPage1.Controls.Add(this.txtSubject4);
            this.xtraTabPage1.Controls.Add(this.txtSubject1);
            this.xtraTabPage1.Controls.Add(this.txtMessage1);
            this.xtraTabPage1.Controls.Add(this.label10);
            this.xtraTabPage1.Controls.Add(this.label6);
            this.xtraTabPage1.Controls.Add(this.label5);
            this.xtraTabPage1.Controls.Add(this.label11);
            this.xtraTabPage1.Controls.Add(this.txtSubject2);
            this.xtraTabPage1.Controls.Add(this.txtMessage2);
            this.xtraTabPage1.Controls.Add(this.txtMessage3);
            this.xtraTabPage1.Controls.Add(this.label9);
            this.xtraTabPage1.Controls.Add(this.label8);
            this.xtraTabPage1.Controls.Add(this.txtSubject3);
            this.xtraTabPage1.Name = "xtraTabPage1";
            this.xtraTabPage1.Size = new System.Drawing.Size(898, 268);
            this.xtraTabPage1.Text = "Messages by Level";
            // 
            // txtMessage4
            // 
            this.txtMessage4.Location = new System.Drawing.Point(554, 161);
            this.txtMessage4.Name = "txtMessage4";
            this.txtMessage4.Size = new System.Drawing.Size(335, 97);
            this.txtMessage4.TabIndex = 47;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 36);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(93, 13);
            this.label4.TabIndex = 48;
            this.label4.Text = "Level 1 Message :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 13);
            this.label3.TabIndex = 49;
            this.label3.Text = "Level 1 Subject :";
            // 
            // txtSubject4
            // 
            this.txtSubject4.Location = new System.Drawing.Point(554, 135);
            this.txtSubject4.Name = "txtSubject4";
            this.txtSubject4.Size = new System.Drawing.Size(335, 20);
            this.txtSubject4.TabIndex = 46;
            // 
            // txtSubject1
            // 
            this.txtSubject1.Location = new System.Drawing.Point(106, 7);
            this.txtSubject1.Name = "txtSubject1";
            this.txtSubject1.Size = new System.Drawing.Size(335, 20);
            this.txtSubject1.TabIndex = 40;
            // 
            // txtMessage1
            // 
            this.txtMessage1.Location = new System.Drawing.Point(106, 33);
            this.txtMessage1.Name = "txtMessage1";
            this.txtMessage1.Size = new System.Drawing.Size(335, 97);
            this.txtMessage1.TabIndex = 41;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(455, 164);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(93, 13);
            this.label10.TabIndex = 54;
            this.label10.Text = "Level 4 Message :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 138);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(87, 13);
            this.label6.TabIndex = 51;
            this.label6.Text = "Level 2 Subject :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 165);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(93, 13);
            this.label5.TabIndex = 50;
            this.label5.Text = "Level 2 Message :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(461, 137);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(87, 13);
            this.label11.TabIndex = 55;
            this.label11.Text = "Level 4 Subject :";
            // 
            // txtSubject2
            // 
            this.txtSubject2.Location = new System.Drawing.Point(106, 136);
            this.txtSubject2.Name = "txtSubject2";
            this.txtSubject2.Size = new System.Drawing.Size(335, 20);
            this.txtSubject2.TabIndex = 42;
            // 
            // txtMessage2
            // 
            this.txtMessage2.Location = new System.Drawing.Point(106, 162);
            this.txtMessage2.Name = "txtMessage2";
            this.txtMessage2.Size = new System.Drawing.Size(335, 97);
            this.txtMessage2.TabIndex = 43;
            // 
            // txtMessage3
            // 
            this.txtMessage3.Location = new System.Drawing.Point(554, 33);
            this.txtMessage3.Name = "txtMessage3";
            this.txtMessage3.Size = new System.Drawing.Size(335, 97);
            this.txtMessage3.TabIndex = 45;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(461, 9);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(87, 13);
            this.label9.TabIndex = 53;
            this.label9.Text = "Level 3 Subject :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(455, 36);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(93, 13);
            this.label8.TabIndex = 52;
            this.label8.Text = "Level 3 Message :";
            // 
            // txtSubject3
            // 
            this.txtSubject3.Location = new System.Drawing.Point(554, 7);
            this.txtSubject3.Name = "txtSubject3";
            this.txtSubject3.Size = new System.Drawing.Size(335, 20);
            this.txtSubject3.TabIndex = 44;
            // 
            // xtraTabPage2
            // 
            this.xtraTabPage2.Controls.Add(this.label12);
            this.xtraTabPage2.Controls.Add(this.label13);
            this.xtraTabPage2.Controls.Add(this.txtEmailSubjectTemplate);
            this.xtraTabPage2.Controls.Add(this.txtEmailMessageTemplate);
            this.xtraTabPage2.Name = "xtraTabPage2";
            this.xtraTabPage2.Size = new System.Drawing.Size(898, 268);
            this.xtraTabPage2.Text = "Email template";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(17, 36);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(83, 13);
            this.label12.TabIndex = 52;
            this.label12.Text = "Email Message :";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(23, 9);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(77, 13);
            this.label13.TabIndex = 53;
            this.label13.Text = "Email Subject :";
            // 
            // txtEmailSubjectTemplate
            // 
            this.txtEmailSubjectTemplate.Location = new System.Drawing.Point(106, 7);
            this.txtEmailSubjectTemplate.Name = "txtEmailSubjectTemplate";
            this.txtEmailSubjectTemplate.Properties.ContextMenuStrip = this.contextMenuStrip1;
            this.txtEmailSubjectTemplate.Size = new System.Drawing.Size(335, 20);
            this.txtEmailSubjectTemplate.TabIndex = 50;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.subjectToolStripMenuItem,
            this.messageToolStripMenuItem,
            this.actualValueToolStripMenuItem,
            this.thresholdToolStripMenuItem,
            this.bookToolStripMenuItem,
            this.tradeIdToolStripMenuItem,
            this.productToolStripMenuItem,
            this.traderToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(140, 180);
            this.contextMenuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.contextMenuStrip1_ItemClicked);
            // 
            // subjectToolStripMenuItem
            // 
            this.subjectToolStripMenuItem.Name = "subjectToolStripMenuItem";
            this.subjectToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.subjectToolStripMenuItem.Text = "Subject";
            // 
            // messageToolStripMenuItem
            // 
            this.messageToolStripMenuItem.Name = "messageToolStripMenuItem";
            this.messageToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.messageToolStripMenuItem.Text = "Message";
            // 
            // actualValueToolStripMenuItem
            // 
            this.actualValueToolStripMenuItem.Name = "actualValueToolStripMenuItem";
            this.actualValueToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.actualValueToolStripMenuItem.Text = "Actual value";
            // 
            // thresholdToolStripMenuItem
            // 
            this.thresholdToolStripMenuItem.Name = "thresholdToolStripMenuItem";
            this.thresholdToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.thresholdToolStripMenuItem.Text = "Threshold";
            // 
            // bookToolStripMenuItem
            // 
            this.bookToolStripMenuItem.Name = "bookToolStripMenuItem";
            this.bookToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.bookToolStripMenuItem.Text = "Book";
            // 
            // tradeIdToolStripMenuItem
            // 
            this.tradeIdToolStripMenuItem.Name = "tradeIdToolStripMenuItem";
            this.tradeIdToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.tradeIdToolStripMenuItem.Text = "Trade Id";
            // 
            // productToolStripMenuItem
            // 
            this.productToolStripMenuItem.Name = "productToolStripMenuItem";
            this.productToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.productToolStripMenuItem.Text = "Product";
            // 
            // traderToolStripMenuItem
            // 
            this.traderToolStripMenuItem.Name = "traderToolStripMenuItem";
            this.traderToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.traderToolStripMenuItem.Text = "Trader";
            // 
            // txtEmailMessageTemplate
            // 
            this.txtEmailMessageTemplate.Location = new System.Drawing.Point(106, 33);
            this.txtEmailMessageTemplate.Name = "txtEmailMessageTemplate";
            this.txtEmailMessageTemplate.Properties.ContextMenuStrip = this.contextMenuStrip1;
            this.txtEmailMessageTemplate.Size = new System.Drawing.Size(335, 226);
            this.txtEmailMessageTemplate.TabIndex = 51;
            // 
            // chkLevel1Active
            // 
            this.chkLevel1Active.EditValue = true;
            this.chkLevel1Active.Location = new System.Drawing.Point(516, 141);
            this.chkLevel1Active.Name = "chkLevel1Active";
            this.chkLevel1Active.Properties.Caption = "";
            this.chkLevel1Active.Size = new System.Drawing.Size(19, 19);
            this.chkLevel1Active.TabIndex = 69;
            // 
            // chkLevel2Active
            // 
            this.chkLevel2Active.EditValue = true;
            this.chkLevel2Active.Location = new System.Drawing.Point(516, 167);
            this.chkLevel2Active.Name = "chkLevel2Active";
            this.chkLevel2Active.Properties.Caption = "";
            this.chkLevel2Active.Size = new System.Drawing.Size(19, 19);
            this.chkLevel2Active.TabIndex = 70;
            // 
            // chkLevel3Active
            // 
            this.chkLevel3Active.EditValue = true;
            this.chkLevel3Active.Location = new System.Drawing.Point(516, 193);
            this.chkLevel3Active.Name = "chkLevel3Active";
            this.chkLevel3Active.Properties.Caption = "";
            this.chkLevel3Active.Size = new System.Drawing.Size(19, 19);
            this.chkLevel3Active.TabIndex = 71;
            // 
            // chkLevel4Active
            // 
            this.chkLevel4Active.EditValue = true;
            this.chkLevel4Active.Location = new System.Drawing.Point(516, 219);
            this.chkLevel4Active.Name = "chkLevel4Active";
            this.chkLevel4Active.Properties.Caption = "";
            this.chkLevel4Active.Size = new System.Drawing.Size(19, 19);
            this.chkLevel4Active.TabIndex = 72;
            // 
            // lblStartTime
            // 
            this.lblStartTime.Location = new System.Drawing.Point(482, 93);
            this.lblStartTime.Name = "lblStartTime";
            this.lblStartTime.Size = new System.Drawing.Size(56, 13);
            this.lblStartTime.TabIndex = 73;
            this.lblStartTime.Text = "Start Time :";
            // 
            // teStartTime
            // 
            this.teStartTime.EditValue = new System.DateTime(2014, 2, 11, 0, 0, 0, 0);
            this.teStartTime.Location = new System.Drawing.Point(547, 90);
            this.teStartTime.Name = "teStartTime";
            this.teStartTime.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.teStartTime.Properties.DisplayFormat.FormatString = "HH:mm";
            this.teStartTime.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.teStartTime.Properties.Mask.EditMask = "HH:mm";
            this.teStartTime.Size = new System.Drawing.Size(100, 20);
            this.teStartTime.TabIndex = 74;
            // 
            // chkDoNotTriggerOnWeekends
            // 
            this.chkDoNotTriggerOnWeekends.Location = new System.Drawing.Point(93, 118);
            this.chkDoNotTriggerOnWeekends.Name = "chkDoNotTriggerOnWeekends";
            this.chkDoNotTriggerOnWeekends.Properties.Caption = "Do not trigger on weekends";
            this.chkDoNotTriggerOnWeekends.Size = new System.Drawing.Size(157, 19);
            this.chkDoNotTriggerOnWeekends.TabIndex = 75;
            // 
            // chkListTransferErrorsTypes
            // 
            this.chkListTransferErrorsTypes.ColumnWidth = 110;
            this.chkListTransferErrorsTypes.Cursor = System.Windows.Forms.Cursors.Default;
            this.chkListTransferErrorsTypes.Items.AddRange(new DevExpress.XtraEditors.Controls.CheckedListBoxItem[] {
            new DevExpress.XtraEditors.Controls.CheckedListBoxItem("1", "Unknown Alias"),
            new DevExpress.XtraEditors.Controls.CheckedListBoxItem("2", "Unknown SD"),
            new DevExpress.XtraEditors.Controls.CheckedListBoxItem("3", "Unknown Strip"),
            new DevExpress.XtraEditors.Controls.CheckedListBoxItem("4", "Transfer Failure"),
            new DevExpress.XtraEditors.Controls.CheckedListBoxItem("5", "Unknown Portfolio"),
            new DevExpress.XtraEditors.Controls.CheckedListBoxItem("6", "Trade On Holiday")});
            this.chkListTransferErrorsTypes.Location = new System.Drawing.Point(96, 58);
            this.chkListTransferErrorsTypes.MultiColumn = true;
            this.chkListTransferErrorsTypes.Name = "chkListTransferErrorsTypes";
            this.chkListTransferErrorsTypes.Size = new System.Drawing.Size(227, 53);
            this.chkListTransferErrorsTypes.TabIndex = 76;
            this.chkListTransferErrorsTypes.Visible = false;
            // 
            // AlertEditForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(922, 586);
            this.Controls.Add(this.chkListTransferErrorsTypes);
            this.Controls.Add(this.chkDoNotTriggerOnWeekends);
            this.Controls.Add(this.teStartTime);
            this.Controls.Add(this.lblStartTime);
            this.Controls.Add(this.chkLevel4Active);
            this.Controls.Add(this.chkLevel3Active);
            this.Controls.Add(this.chkLevel2Active);
            this.Controls.Add(this.chkLevel1Active);
            this.Controls.Add(this.xtraTabControl1);
            this.Controls.Add(this.teThresholdStartTime);
            this.Controls.Add(this.ceProduct);
            this.Controls.Add(this.ceProductGroup);
            this.Controls.Add(this.lblProductGroup);
            this.Controls.Add(this.cmbProductGroup);
            this.Controls.Add(this.lblTo);
            this.Controls.Add(this.lblFrom);
            this.Controls.Add(this.teThresholdEndTime);
            this.Controls.Add(this.txtConditionCountCheck);
            this.Controls.Add(this.labelControl16);
            this.Controls.Add(this.labelControl12);
            this.Controls.Add(this.txtEscalation4);
            this.Controls.Add(this.labelControl13);
            this.Controls.Add(this.labelControl14);
            this.Controls.Add(this.txtEscalation3);
            this.Controls.Add(this.labelControl15);
            this.Controls.Add(this.labelControl10);
            this.Controls.Add(this.txtEscalation2);
            this.Controls.Add(this.labelControl11);
            this.Controls.Add(this.labelControl8);
            this.Controls.Add(this.txtEscalation1);
            this.Controls.Add(this.labelControl9);
            this.Controls.Add(this.leGroup4);
            this.Controls.Add(this.leGroup3);
            this.Controls.Add(this.labelControl6);
            this.Controls.Add(this.labelControl7);
            this.Controls.Add(this.cmbProduct);
            this.Controls.Add(this.lblProduct);
            this.Controls.Add(this.pePortfolio);
            this.Controls.Add(this.popupTarget);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.rgrBoundary);
            this.Controls.Add(this.cbxActive);
            this.Controls.Add(this.leGroup2);
            this.Controls.Add(this.leGroup1);
            this.Controls.Add(this.txtThreshold);
            this.Controls.Add(this.teThresholdTime);
            this.Controls.Add(this.labelControl2);
            this.Controls.Add(this.txtEscalation);
            this.Controls.Add(this.lblThreshold);
            this.Controls.Add(this.labelControl4);
            this.Controls.Add(this.labelControl5);
            this.Controls.Add(this.labelControl1);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.cbxMethod);
            this.Controls.Add(this.txtTitle);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AlertEditForm";
            this.ShowInTaskbar = false;
            this.Text = "Edit Alert";
            this.Load += new System.EventHandler(this.AlertGroupEditForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.txtTitle.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbxMethod.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dxErrorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEscalation.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.teThresholdTime.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtThreshold.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.leGroup1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.leGroup2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cbxActive.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rgrBoundary.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.popupTarget)).EndInit();
            this.popupTarget.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tlTarget)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pePortfolio.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbProduct.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.leGroup4.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.leGroup3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEscalation1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEscalation2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEscalation4.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtEscalation3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtConditionCountCheck.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.teThresholdEndTime.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbProductGroup.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ceProductGroup.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ceProduct.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.teThresholdStartTime.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).EndInit();
            this.xtraTabControl1.ResumeLayout(false);
            this.xtraTabPage1.ResumeLayout(false);
            this.xtraTabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtMessage4.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSubject4.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSubject1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMessage1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSubject2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMessage2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMessage3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSubject3.Properties)).EndInit();
            this.xtraTabPage2.ResumeLayout(false);
            this.xtraTabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtEmailSubjectTemplate.Properties)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtEmailMessageTemplate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkLevel1Active.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkLevel2Active.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkLevel3Active.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkLevel4Active.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.teStartTime.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkDoNotTriggerOnWeekends.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chkListTransferErrorsTypes)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private DevExpress.XtraEditors.TextEdit txtTitle;
        private DevExpress.XtraEditors.ComboBoxEdit cbxMethod;
        private System.Windows.Forms.Label label2;
        private DevExpress.XtraEditors.SimpleButton btnSave;
        private DevExpress.XtraEditors.SimpleButton btnCancel;
        private DevExpress.XtraEditors.DXErrorProvider.DXErrorProvider dxErrorProvider1;
        private DevExpress.XtraEditors.TextEdit txtThreshold;
        private DevExpress.XtraEditors.TimeEdit teThresholdTime;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.TextEdit txtEscalation;
        private DevExpress.XtraEditors.LabelControl lblThreshold;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.LookUpEdit leGroup2;
        private DevExpress.XtraEditors.LookUpEdit leGroup1;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.CheckEdit cbxActive;
        private DevExpress.XtraEditors.RadioGroup rgrBoundary;
        private System.Windows.Forms.Label label7;
        private DevExpress.XtraEditors.PopupContainerEdit pePortfolio;
        private DevExpress.XtraEditors.PopupContainerControl popupTarget;
        private DevExpress.XtraTreeList.TreeList tlTarget;
        private DevExpress.XtraTreeList.Columns.TreeListColumn nameClmn;
        private DevExpress.XtraEditors.ComboBoxEdit cmbProduct;
        private System.Windows.Forms.Label lblProduct;
        private DevExpress.XtraEditors.LabelControl labelControl12;
        private DevExpress.XtraEditors.TextEdit txtEscalation4;
        private DevExpress.XtraEditors.LabelControl labelControl13;
        private DevExpress.XtraEditors.LabelControl labelControl14;
        private DevExpress.XtraEditors.TextEdit txtEscalation3;
        private DevExpress.XtraEditors.LabelControl labelControl15;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        private DevExpress.XtraEditors.TextEdit txtEscalation2;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.TextEdit txtEscalation1;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private DevExpress.XtraEditors.LookUpEdit leGroup4;
        private DevExpress.XtraEditors.LookUpEdit leGroup3;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.TextEdit txtConditionCountCheck;
        private DevExpress.XtraEditors.LabelControl labelControl16;
        private DevExpress.XtraEditors.LabelControl lblTo;
        private DevExpress.XtraEditors.LabelControl lblFrom;
        private DevExpress.XtraEditors.TimeEdit teThresholdEndTime;
        private System.Windows.Forms.Label lblProductGroup;
        private DevExpress.XtraEditors.ComboBoxEdit cmbProductGroup;
        private DevExpress.XtraEditors.CheckEdit ceProduct;
        private DevExpress.XtraEditors.CheckEdit ceProductGroup;
        private DevExpress.XtraEditors.TimeEdit teThresholdStartTime;
        private DevExpress.XtraTab.XtraTabControl xtraTabControl1;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage1;
        private DevExpress.XtraEditors.MemoEdit txtMessage4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private DevExpress.XtraEditors.TextEdit txtSubject4;
        private DevExpress.XtraEditors.TextEdit txtSubject1;
        private DevExpress.XtraEditors.MemoEdit txtMessage1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label11;
        private DevExpress.XtraEditors.TextEdit txtSubject2;
        private DevExpress.XtraEditors.MemoEdit txtMessage2;
        private DevExpress.XtraEditors.MemoEdit txtMessage3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private DevExpress.XtraEditors.TextEdit txtSubject3;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private DevExpress.XtraEditors.TextEdit txtEmailSubjectTemplate;
        private DevExpress.XtraEditors.MemoEdit txtEmailMessageTemplate;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem subjectToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem messageToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem actualValueToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thresholdToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bookToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tradeIdToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem productToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem traderToolStripMenuItem;
        private DevExpress.XtraEditors.CheckEdit chkLevel4Active;
        private DevExpress.XtraEditors.CheckEdit chkLevel3Active;
        private DevExpress.XtraEditors.CheckEdit chkLevel2Active;
        private DevExpress.XtraEditors.CheckEdit chkLevel1Active;
        private DevExpress.XtraEditors.TimeEdit teStartTime;
        private DevExpress.XtraEditors.LabelControl lblStartTime;
        private DevExpress.XtraEditors.CheckEdit chkDoNotTriggerOnWeekends;
        private DevExpress.XtraEditors.CheckedListBoxControl chkListTransferErrorsTypes;
    }
}