﻿namespace Mandara.AdmTool
{
    partial class GroupsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GroupsForm));
            this.gcGroups = new DevExpress.XtraGrid.GridControl();
            this.groupViewModelBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gvGroups = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colGroupName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colAdministrator = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colSuperAdministrator = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colLaunchHAL = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colLaunchVHAL = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colRiskToolLaunchAccess = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colRiskToolWriteAccess = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colProductToolWriteAccess = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colProductToolLaunchAccess1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colViewCumulativePnl = new DevExpress.XtraGrid.Columns.GridColumn();
            this.riGroups = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.repositoryItemCheckEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.repositoryItemCheckEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.repositoryItemCheckEdit3 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.repositoryItemCheckEdit4 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.txtDummy = new DevExpress.XtraEditors.TextEdit();
            this.colUseProductBreakdown = new DevExpress.XtraGrid.Columns.GridColumn();
            ((System.ComponentModel.ISupportInitialize)(this.gcGroups)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupViewModelBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvGroups)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.riGroups)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDummy.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // gcGroups
            // 
            this.gcGroups.DataSource = this.groupViewModelBindingSource;
            this.gcGroups.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gcGroups.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.gcGroups.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.gcGroups.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.gcGroups.EmbeddedNavigator.Buttons.First.Visible = false;
            this.gcGroups.EmbeddedNavigator.Buttons.Last.Visible = false;
            this.gcGroups.EmbeddedNavigator.Buttons.Next.Visible = false;
            this.gcGroups.EmbeddedNavigator.Buttons.NextPage.Visible = false;
            this.gcGroups.EmbeddedNavigator.Buttons.Prev.Visible = false;
            this.gcGroups.EmbeddedNavigator.Buttons.PrevPage.Visible = false;
            this.gcGroups.EmbeddedNavigator.TextLocation = DevExpress.XtraEditors.NavigatorButtonsTextLocation.None;
            this.gcGroups.Location = new System.Drawing.Point(0, 0);
            this.gcGroups.MainView = this.gvGroups;
            this.gcGroups.Name = "gcGroups";
            this.gcGroups.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.riGroups,
            this.repositoryItemCheckEdit1,
            this.repositoryItemCheckEdit2,
            this.repositoryItemCheckEdit3,
            this.repositoryItemCheckEdit4});
            this.gcGroups.Size = new System.Drawing.Size(1164, 542);
            this.gcGroups.TabIndex = 0;
            this.gcGroups.UseEmbeddedNavigator = true;
            this.gcGroups.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gvGroups});
            // 
            // groupViewModelBindingSource
            // 
            this.groupViewModelBindingSource.DataSource = typeof(Mandara.AdmTool.GroupViewModel);
            // 
            // gvGroups
            // 
            this.gvGroups.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colGroupName,
            this.colAdministrator,
            this.colSuperAdministrator,
            this.colLaunchHAL,
            this.colLaunchVHAL,
            this.colRiskToolLaunchAccess,
            this.colRiskToolWriteAccess,
            this.colProductToolWriteAccess,
            this.colProductToolLaunchAccess1,
            this.colViewCumulativePnl,
            this.colUseProductBreakdown});
            this.gvGroups.GridControl = this.gcGroups;
            this.gvGroups.Name = "gvGroups";
            this.gvGroups.OptionsBehavior.AllowAddRows = DevExpress.Utils.DefaultBoolean.True;
            this.gvGroups.OptionsBehavior.AllowDeleteRows = DevExpress.Utils.DefaultBoolean.True;
            this.gvGroups.OptionsCustomization.AllowGroup = false;
            this.gvGroups.OptionsView.ShowGroupPanel = false;
            // 
            // colGroupName
            // 
            this.colGroupName.FieldName = "GroupName";
            this.colGroupName.Name = "colGroupName";
            this.colGroupName.Visible = true;
            this.colGroupName.VisibleIndex = 0;
            // 
            // colAdministrator
            // 
            this.colAdministrator.FieldName = "Administrator";
            this.colAdministrator.Name = "colAdministrator";
            this.colAdministrator.Visible = true;
            this.colAdministrator.VisibleIndex = 1;
            // 
            // colSuperAdministrator
            // 
            this.colSuperAdministrator.FieldName = "SuperAdministrator";
            this.colSuperAdministrator.Name = "colSuperAdministrator";
            this.colSuperAdministrator.Visible = true;
            this.colSuperAdministrator.VisibleIndex = 2;
            // 
            // colLaunchHAL
            // 
            this.colLaunchHAL.FieldName = "LaunchHAL";
            this.colLaunchHAL.Name = "colLaunchHAL";
            this.colLaunchHAL.Visible = true;
            this.colLaunchHAL.VisibleIndex = 3;
            // 
            // colLaunchVHAL
            // 
            this.colLaunchVHAL.FieldName = "LaunchVHAL";
            this.colLaunchVHAL.Name = "colLaunchVHAL";
            this.colLaunchVHAL.Visible = true;
            this.colLaunchVHAL.VisibleIndex = 4;
            // 
            // colRiskToolLaunchAccess
            // 
            this.colRiskToolLaunchAccess.Caption = "Risk Tool Launch";
            this.colRiskToolLaunchAccess.FieldName = "RiskToolLaunchAccess";
            this.colRiskToolLaunchAccess.Name = "colRiskToolLaunchAccess";
            this.colRiskToolLaunchAccess.Visible = true;
            this.colRiskToolLaunchAccess.VisibleIndex = 5;
            // 
            // colRiskToolWriteAccess
            // 
            this.colRiskToolWriteAccess.Caption = "Risk Tool Write";
            this.colRiskToolWriteAccess.FieldName = "RiskToolWriteAccess";
            this.colRiskToolWriteAccess.Name = "colRiskToolWriteAccess";
            this.colRiskToolWriteAccess.Visible = true;
            this.colRiskToolWriteAccess.VisibleIndex = 6;
            // 
            // colProductToolWriteAccess
            // 
            this.colProductToolWriteAccess.Caption = "Product Tool Write";
            this.colProductToolWriteAccess.FieldName = "ProductToolWriteAccess";
            this.colProductToolWriteAccess.Name = "colProductToolWriteAccess";
            this.colProductToolWriteAccess.Visible = true;
            this.colProductToolWriteAccess.VisibleIndex = 7;
            // 
            // colProductToolLaunchAccess1
            // 
            this.colProductToolLaunchAccess1.Caption = "Product Tool Launch";
            this.colProductToolLaunchAccess1.FieldName = "ProductToolLaunchAccess";
            this.colProductToolLaunchAccess1.Name = "colProductToolLaunchAccess1";
            this.colProductToolLaunchAccess1.Visible = true;
            this.colProductToolLaunchAccess1.VisibleIndex = 8;
            // 
            // colViewCumulativePnl
            // 
            this.colViewCumulativePnl.Caption = "View Cumulative Pnl";
            this.colViewCumulativePnl.FieldName = "ViewCumulativePnl";
            this.colViewCumulativePnl.Name = "colViewCumulativePnl";
            this.colViewCumulativePnl.Visible = true;
            this.colViewCumulativePnl.VisibleIndex = 9;
            // 
            // riGroups
            // 
            this.riGroups.AutoHeight = false;
            this.riGroups.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.riGroups.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("GroupName", "Group")});
            this.riGroups.Name = "riGroups";
            this.riGroups.NullText = "[Group is not specified]";
            this.riGroups.ValueMember = "Instance";
            // 
            // repositoryItemCheckEdit1
            // 
            this.repositoryItemCheckEdit1.AutoHeight = false;
            this.repositoryItemCheckEdit1.Name = "repositoryItemCheckEdit1";
            // 
            // repositoryItemCheckEdit2
            // 
            this.repositoryItemCheckEdit2.AutoHeight = false;
            this.repositoryItemCheckEdit2.Name = "repositoryItemCheckEdit2";
            // 
            // repositoryItemCheckEdit3
            // 
            this.repositoryItemCheckEdit3.AutoHeight = false;
            this.repositoryItemCheckEdit3.Name = "repositoryItemCheckEdit3";
            // 
            // repositoryItemCheckEdit4
            // 
            this.repositoryItemCheckEdit4.AutoHeight = false;
            this.repositoryItemCheckEdit4.Name = "repositoryItemCheckEdit4";
            // 
            // txtDummy
            // 
            this.txtDummy.Location = new System.Drawing.Point(32736, 394);
            this.txtDummy.Name = "txtDummy";
            this.txtDummy.Size = new System.Drawing.Size(100, 20);
            this.txtDummy.TabIndex = 1;
            // 
            // colUseProductBreakdown
            // 
            this.colUseProductBreakdown.Caption = "Use Product Breakdown";
            this.colUseProductBreakdown.FieldName = "UseProductBreakdown";
            this.colUseProductBreakdown.Name = "colUseProductBreakdown";
            this.colUseProductBreakdown.Visible = true;
            this.colUseProductBreakdown.VisibleIndex = 10;
            // 
            // GroupsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1164, 542);
            this.Controls.Add(this.txtDummy);
            this.Controls.Add(this.gcGroups);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "GroupsForm";
            this.Text = "Groups";
            ((System.ComponentModel.ISupportInitialize)(this.gcGroups)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupViewModelBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvGroups)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.riGroups)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDummy.Properties)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraGrid.GridControl gcGroups;
        private DevExpress.XtraGrid.Views.Grid.GridView gvGroups;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit riGroups;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit2;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit3;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit4;
        private DevExpress.XtraEditors.TextEdit txtDummy;
        private System.Windows.Forms.BindingSource groupViewModelBindingSource;
        private DevExpress.XtraGrid.Columns.GridColumn colGroupName;
        private DevExpress.XtraGrid.Columns.GridColumn colAdministrator;
        private DevExpress.XtraGrid.Columns.GridColumn colSuperAdministrator;
        private DevExpress.XtraGrid.Columns.GridColumn colLaunchHAL;
        private DevExpress.XtraGrid.Columns.GridColumn colLaunchVHAL;
        private DevExpress.XtraGrid.Columns.GridColumn colRiskToolLaunchAccess;
        private DevExpress.XtraGrid.Columns.GridColumn colRiskToolWriteAccess;
        private DevExpress.XtraGrid.Columns.GridColumn colProductToolWriteAccess;
        private DevExpress.XtraGrid.Columns.GridColumn colProductToolLaunchAccess1;
        private DevExpress.XtraGrid.Columns.GridColumn colViewCumulativePnl;
        private DevExpress.XtraGrid.Columns.GridColumn colUseProductBreakdown;
    }
}