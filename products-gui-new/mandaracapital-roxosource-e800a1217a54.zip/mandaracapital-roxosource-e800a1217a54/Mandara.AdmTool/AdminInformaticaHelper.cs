﻿using com.latencybusters.lbm;
using Mandara.Business.Bus;
using Mandara.Business.Bus.Handlers;
using Mandara.Business.Bus.Handlers.Base;
using System.Configuration;

namespace Mandara.AdmTool
{
    public class AdminInformaticaHelper : InformaticaHelper
    {
        public AdminInformaticaHelper(LBMContext lbmContext, HandlerManager handlerManager)
            : base(lbmContext, handlerManager)
        { }

        public override void CreateReceivers()
        {
            AddReceiver(ClientHeartbeatTopicName, typeof(ClientHeartbeatHandler));

            foreach (string prefix in ServersHelper.GetAllServerPrefixes())
            {
                AddReceiver(
                    GetServerAwareTopicNameWithPrefix(
                        ConfigurationManager.AppSettings["HeartbeatTopicName"]
                        ?? "MND/" + TopicDefinition.DefaultEnvironment + "/IRM/Heartbeat",
                        prefix),
                    typeof(ServerHeartbeatHandler));
            }

            base.CreateReceivers();
        }
    }
}
