﻿namespace Mandara.AdmTool
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.imageCollection1 = new DevExpress.Utils.ImageCollection(this.components);
            this.ribbonControl1 = new DevExpress.XtraBars.Ribbon.RibbonControl();
            this.btnUsers = new DevExpress.XtraBars.BarButtonItem();
            this.btnAbout = new DevExpress.XtraBars.BarButtonItem();
            this.Exit = new DevExpress.XtraBars.BarButtonItem();
            this.btnAuditMessages = new DevExpress.XtraBars.BarButtonItem();
            this.btnGroups = new DevExpress.XtraBars.BarButtonItem();
            this.btnGroupsSave = new DevExpress.XtraBars.BarButtonItem();
            this.btnUserEdit = new DevExpress.XtraBars.BarButtonItem();
            this.btnTradeScenarioEdit = new DevExpress.XtraBars.BarButtonItem();
            this.btnTradeScenarios = new DevExpress.XtraBars.BarButtonItem();
            this.btnAlertGroups = new DevExpress.XtraBars.BarButtonItem();
            this.btnAlerts = new DevExpress.XtraBars.BarButtonItem();
            this.btnAlertEdit = new DevExpress.XtraBars.BarButtonItem();
            this.btnReconnectClients = new DevExpress.XtraBars.BarButtonItem();
            this.btnServers = new DevExpress.XtraBars.BarButtonItem();
            this.btnClientConnections = new DevExpress.XtraBars.BarButtonItem();
            this.rpHome = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.rpgUserManagment = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.rpgUsers = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.rpgAlertEdit = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.rpgGroups = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.rpgTradeScenarios = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.rpgAlerts = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.rpqConnections = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.rpgMiscellaneous = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.xtraTabbedMdiManager = new DevExpress.XtraTabbedMdi.XtraTabbedMdiManager(this.components);
            this._messagesBackgroundWorker = new System.ComponentModel.BackgroundWorker();
            ((System.ComponentModel.ISupportInitialize)(this.imageCollection1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabbedMdiManager)).BeginInit();
            this.SuspendLayout();
            // 
            // imageCollection1
            // 
            this.imageCollection1.ImageSize = new System.Drawing.Size(32, 32);
            this.imageCollection1.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("imageCollection1.ImageStream")));
            this.imageCollection1.Images.SetKeyName(0, "users.png");
            this.imageCollection1.Images.SetKeyName(1, "permissions.png");
            this.imageCollection1.Images.SetKeyName(2, "about.png");
            this.imageCollection1.Images.SetKeyName(3, "cancel.png");
            this.imageCollection1.Images.SetKeyName(4, "utilities-log_viewer.png");
            this.imageCollection1.Images.SetKeyName(5, "user.png");
            this.imageCollection1.Images.SetKeyName(6, "book_edit.png");
            this.imageCollection1.Images.SetKeyName(7, "trade_scenarios.png");
            this.imageCollection1.Images.SetKeyName(8, "trade_scenario_edit.png");
            this.imageCollection1.Images.SetKeyName(9, "user_group_alert.png");
            this.imageCollection1.Images.SetKeyName(10, "group_alert.png");
            this.imageCollection1.Images.SetKeyName(11, "reconnect.png");
            this.imageCollection1.Images.SetKeyName(12, "17.png");
            this.imageCollection1.Images.SetKeyName(13, "UserConnections.png");
            // 
            // ribbonControl1
            // 
            this.ribbonControl1.AllowMdiChildButtons = false;
            this.ribbonControl1.AllowMinimizeRibbon = false;
            this.ribbonControl1.ApplicationButtonText = null;
            this.ribbonControl1.ExpandCollapseItem.Id = 0;
            this.ribbonControl1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.ribbonControl1.ExpandCollapseItem,
            this.btnUsers,
            this.btnAbout,
            this.Exit,
            this.btnAuditMessages,
            this.btnGroups,
            this.btnGroupsSave,
            this.btnUserEdit,
            this.btnTradeScenarioEdit,
            this.btnTradeScenarios,
            this.btnAlertGroups,
            this.btnAlerts,
            this.btnAlertEdit,
            this.btnReconnectClients,
            this.btnServers,
            this.btnClientConnections});
            this.ribbonControl1.LargeImages = this.imageCollection1;
            this.ribbonControl1.Location = new System.Drawing.Point(0, 0);
            this.ribbonControl1.MaxItemId = 19;
            this.ribbonControl1.Name = "ribbonControl1";
            this.ribbonControl1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.rpHome});
            this.ribbonControl1.ShowApplicationButton = DevExpress.Utils.DefaultBoolean.False;
            this.ribbonControl1.ShowCategoryInCaption = false;
            this.ribbonControl1.ShowDisplayOptionsMenuButton = DevExpress.Utils.DefaultBoolean.False;
            this.ribbonControl1.ShowExpandCollapseButton = DevExpress.Utils.DefaultBoolean.False;
            this.ribbonControl1.ShowPageHeadersInFormCaption = DevExpress.Utils.DefaultBoolean.False;
            this.ribbonControl1.ShowPageHeadersMode = DevExpress.XtraBars.Ribbon.ShowPageHeadersMode.Hide;
            this.ribbonControl1.ShowQatLocationSelector = false;
            this.ribbonControl1.ShowToolbarCustomizeItem = false;
            this.ribbonControl1.Size = new System.Drawing.Size(1208, 95);
            this.ribbonControl1.Toolbar.ShowCustomizeItem = false;
            this.ribbonControl1.ToolbarLocation = DevExpress.XtraBars.Ribbon.RibbonQuickAccessToolbarLocation.Hidden;
            // 
            // btnUsers
            // 
            this.btnUsers.Caption = "Users";
            this.btnUsers.Id = 1;
            this.btnUsers.ImageOptions.LargeImageIndex = 5;
            this.btnUsers.Name = "btnUsers";
            this.btnUsers.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnUsers_ItemClick);
            // 
            // btnAbout
            // 
            this.btnAbout.Caption = "About";
            this.btnAbout.Id = 3;
            this.btnAbout.ImageOptions.LargeImageIndex = 2;
            this.btnAbout.Name = "btnAbout";
            this.btnAbout.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnAbout_ItemClick);
            // 
            // Exit
            // 
            this.Exit.Caption = "Exit";
            this.Exit.Id = 4;
            this.Exit.ImageOptions.LargeImageIndex = 3;
            this.Exit.Name = "Exit";
            this.Exit.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.Exit_ItemClick);
            // 
            // btnAuditMessages
            // 
            this.btnAuditMessages.Caption = "Audit";
            this.btnAuditMessages.Id = 5;
            this.btnAuditMessages.ImageOptions.LargeImageIndex = 4;
            this.btnAuditMessages.Name = "btnAuditMessages";
            this.btnAuditMessages.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnAuditMessages_ItemClick);
            // 
            // btnGroups
            // 
            this.btnGroups.Caption = "Groups";
            this.btnGroups.Id = 6;
            this.btnGroups.ImageOptions.LargeImageIndex = 0;
            this.btnGroups.Name = "btnGroups";
            this.btnGroups.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnGroups_ItemClick);
            // 
            // btnGroupsSave
            // 
            this.btnGroupsSave.Caption = "Save";
            this.btnGroupsSave.Id = 7;
            this.btnGroupsSave.ImageOptions.LargeImageIndex = 0;
            this.btnGroupsSave.Name = "btnGroupsSave";
            // 
            // btnUserEdit
            // 
            this.btnUserEdit.Caption = "Edit";
            this.btnUserEdit.Id = 8;
            this.btnUserEdit.ImageOptions.LargeImageIndex = 5;
            this.btnUserEdit.Name = "btnUserEdit";
            // 
            // btnTradeScenarioEdit
            // 
            this.btnTradeScenarioEdit.Caption = "Edit";
            this.btnTradeScenarioEdit.Id = 9;
            this.btnTradeScenarioEdit.ImageOptions.LargeImageIndex = 8;
            this.btnTradeScenarioEdit.Name = "btnTradeScenarioEdit";
            this.btnTradeScenarioEdit.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            // 
            // btnTradeScenarios
            // 
            this.btnTradeScenarios.Caption = "Trade Scenarios";
            this.btnTradeScenarios.Id = 10;
            this.btnTradeScenarios.ImageOptions.LargeImageIndex = 7;
            this.btnTradeScenarios.Name = "btnTradeScenarios";
            this.btnTradeScenarios.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnTradeScenarios_ItemClick);
            // 
            // btnAlertGroups
            // 
            this.btnAlertGroups.Caption = "Alert Groups";
            this.btnAlertGroups.Id = 10;
            this.btnAlertGroups.ImageOptions.LargeImageIndex = 9;
            this.btnAlertGroups.Name = "btnAlertGroups";
            this.btnAlertGroups.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnAlertGroups_ItemClick);
            // 
            // btnAlerts
            // 
            this.btnAlerts.Caption = "Alerts";
            this.btnAlerts.Id = 11;
            this.btnAlerts.ImageOptions.LargeImageIndex = 10;
            this.btnAlerts.Name = "btnAlerts";
            this.btnAlerts.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnAlerts_ItemClick);
            // 
            // btnAlertEdit
            // 
            this.btnAlertEdit.Caption = "Edit";
            this.btnAlertEdit.Id = 12;
            this.btnAlertEdit.ImageOptions.LargeImageIndex = 6;
            this.btnAlertEdit.Name = "btnAlertEdit";
            // 
            // btnReconnectClients
            // 
            this.btnReconnectClients.Caption = "Reconnect Clients";
            this.btnReconnectClients.Id = 16;
            this.btnReconnectClients.ImageOptions.LargeImageIndex = 11;
            this.btnReconnectClients.Name = "btnReconnectClients";
            this.btnReconnectClients.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnReconnectClients_ItemClick);
            // 
            // btnServers
            // 
            this.btnServers.Caption = "Servers";
            this.btnServers.Id = 17;
            this.btnServers.ImageOptions.LargeImageIndex = 12;
            this.btnServers.Name = "btnServers";
            this.btnServers.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnServers_ItemClick);
            // 
            // btnClientConnections
            // 
            this.btnClientConnections.Caption = "Client Connections";
            this.btnClientConnections.Id = 18;
            this.btnClientConnections.ImageOptions.LargeImageIndex = 13;
            this.btnClientConnections.Name = "btnClientConnections";
            this.btnClientConnections.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnClientConnections_ItemClick);
            // 
            // rpHome
            // 
            this.rpHome.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.rpgUserManagment,
            this.rpgUsers,
            this.rpgAlertEdit,
            this.rpgGroups,
            this.rpgTradeScenarios,
            this.rpgAlerts,
            this.rpqConnections,
            this.rpgMiscellaneous});
            this.rpHome.Name = "rpHome";
            this.rpHome.Text = "Home";
            // 
            // rpgUserManagment
            // 
            this.rpgUserManagment.ItemLinks.Add(this.btnUsers);
            this.rpgUserManagment.ItemLinks.Add(this.btnGroups);
            this.rpgUserManagment.ItemLinks.Add(this.btnAuditMessages);
            this.rpgUserManagment.Name = "rpgUserManagment";
            this.rpgUserManagment.ShowCaptionButton = false;
            this.rpgUserManagment.Text = "User Management";
            // 
            // rpgUsers
            // 
            this.rpgUsers.ItemLinks.Add(this.btnUserEdit);
            this.rpgUsers.Name = "rpgUsers";
            this.rpgUsers.ShowCaptionButton = false;
            this.rpgUsers.Text = "Users";
            this.rpgUsers.Visible = false;
            // 
            // rpgAlertEdit
            // 
            this.rpgAlertEdit.ItemLinks.Add(this.btnAlertEdit);
            this.rpgAlertEdit.Name = "rpgAlertEdit";
            this.rpgAlertEdit.ShowCaptionButton = false;
            this.rpgAlertEdit.Text = "Edit";
            this.rpgAlertEdit.Visible = false;
            // 
            // rpgGroups
            // 
            this.rpgGroups.ItemLinks.Add(this.btnGroupsSave);
            this.rpgGroups.Name = "rpgGroups";
            this.rpgGroups.ShowCaptionButton = false;
            this.rpgGroups.Text = "Groups";
            this.rpgGroups.Visible = false;
            // 
            // rpgTradeScenarios
            // 
            this.rpgTradeScenarios.ItemLinks.Add(this.btnTradeScenarios);
            this.rpgTradeScenarios.ItemLinks.Add(this.btnTradeScenarioEdit);
            this.rpgTradeScenarios.Name = "rpgTradeScenarios";
            this.rpgTradeScenarios.ShowCaptionButton = false;
            this.rpgTradeScenarios.Text = "Trade Scenarios";
            // 
            // rpgAlerts
            // 
            this.rpgAlerts.ItemLinks.Add(this.btnAlerts);
            this.rpgAlerts.ItemLinks.Add(this.btnAlertGroups);
            this.rpgAlerts.Name = "rpgAlerts";
            this.rpgAlerts.ShowCaptionButton = false;
            this.rpgAlerts.Text = "Alerts";
            // 
            // rpqConnections
            // 
            this.rpqConnections.ItemLinks.Add(this.btnServers);
            this.rpqConnections.ItemLinks.Add(this.btnClientConnections);
            this.rpqConnections.Name = "rpqConnections";
            this.rpqConnections.ShowCaptionButton = false;
            this.rpqConnections.Text = "Connections";
            // 
            // rpgMiscellaneous
            // 
            this.rpgMiscellaneous.ItemLinks.Add(this.btnReconnectClients);
            this.rpgMiscellaneous.ItemLinks.Add(this.btnAbout);
            this.rpgMiscellaneous.ItemLinks.Add(this.Exit);
            this.rpgMiscellaneous.Name = "rpgMiscellaneous";
            this.rpgMiscellaneous.ShowCaptionButton = false;
            this.rpgMiscellaneous.Text = "Miscellaneous";
            // 
            // xtraTabbedMdiManager
            // 
            this.xtraTabbedMdiManager.ClosePageButtonShowMode = DevExpress.XtraTab.ClosePageButtonShowMode.InAllTabPageHeaders;
            this.xtraTabbedMdiManager.MdiParent = this;
            this.xtraTabbedMdiManager.UseFormIconAsPageImage = DevExpress.Utils.DefaultBoolean.True;
            // 
            // _messagesBackgroundWorker
            // 
            this._messagesBackgroundWorker.WorkerSupportsCancellation = true;
            this._messagesBackgroundWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this._messagesBackgroundWorker_DoWork);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1208, 746);
            this.Controls.Add(this.ribbonControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.Name = "MainForm";
            this.Text = "Mandara Administration Tool";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.imageCollection1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabbedMdiManager)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.Utils.ImageCollection imageCollection1;
        private DevExpress.XtraBars.Ribbon.RibbonControl ribbonControl1;
        protected DevExpress.XtraBars.BarButtonItem btnUsers;
        private DevExpress.XtraBars.Ribbon.RibbonPage rpHome;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup rpgUserManagment;
        private DevExpress.XtraBars.BarButtonItem btnAbout;
        private DevExpress.XtraBars.BarButtonItem Exit;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup rpgMiscellaneous;
        private DevExpress.XtraBars.BarButtonItem btnAuditMessages;
        private DevExpress.XtraBars.BarButtonItem btnGroups;
        public DevExpress.XtraBars.Ribbon.RibbonPageGroup rpgGroups;
        public DevExpress.XtraBars.BarButtonItem btnGroupsSave;
        public DevExpress.XtraBars.BarButtonItem btnUserEdit;
        public DevExpress.XtraBars.Ribbon.RibbonPageGroup rpgUsers;
        private DevExpress.XtraTabbedMdi.XtraTabbedMdiManager xtraTabbedMdiManager;
        public DevExpress.XtraBars.BarButtonItem btnTradeScenarioEdit;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup rpgTradeScenarios;
        private DevExpress.XtraBars.BarButtonItem btnTradeScenarios;
        private DevExpress.XtraBars.BarButtonItem btnAlertGroups;
        private DevExpress.XtraBars.BarButtonItem btnAlerts;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup rpgAlerts;
        public DevExpress.XtraBars.Ribbon.RibbonPageGroup rpgAlertEdit;
        public DevExpress.XtraBars.BarButtonItem btnAlertEdit;
        private DevExpress.XtraBars.BarButtonItem btnReconnectClients;
        private DevExpress.XtraBars.BarButtonItem btnServers;
        private DevExpress.XtraBars.BarButtonItem btnClientConnections;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup rpqConnections;
        private System.ComponentModel.BackgroundWorker _messagesBackgroundWorker;
    }
}
