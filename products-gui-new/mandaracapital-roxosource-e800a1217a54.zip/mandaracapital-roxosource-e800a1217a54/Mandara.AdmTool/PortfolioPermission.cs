namespace Mandara.AdmTool
{
    public class PortfolioPermission
    {
        public int PortfoiolId { get; set; }
        public int ParentPortfolioId { get; set; }
        public string Name { get; set; }
        
        public bool CanViewRisk { get; set; }
        public bool CanViewPnl { get; set; }
        public bool CanAddEditTrades { get; set; }
        public bool CanUseMasterTool { get; set; }
        public bool CanAddEditBooks { get; set; }
        public bool CanAmendBrokerage { get; set; }
    }
}