﻿using System.ComponentModel;
using System.Linq;
using DevExpress.XtraBars;
using Mandara.AdmTool.Properties;
using Mandara.Business.Authorization;
using Mandara.Business.Managers;
using Mandara.Entities;
using System.Windows.Forms;
using System;

namespace Mandara.AdmTool
{
    public partial class UsersForm : DevExpress.XtraEditors.XtraForm
    {
        private readonly AuthorizationManager _authManager = new AuthorizationManager();

        private MainForm _mainForm;
        private BindingList<User> _bindingList;

        private MainForm MainForm
        {
            get
            {
                if (_mainForm == null)
                    _mainForm = MdiParent as MainForm;

                return _mainForm;
            }
        }

        public UsersForm()
        {
            InitializeComponent();

            Activated += UsersForm_Activated;
            Deactivate += UsersForm_Deactivate;

            UpdateDataUsers();
        }

        private void UpdateDataUsers()
        {
            _bindingList = new BindingList<User>(_authManager.GetUsers().ToList());
            gcUsers.DataSource = _bindingList;
        }

        void UsersForm_Activated(object sender, System.EventArgs e)
        {
            if (MainForm == null)
                return;

            //TODO: uncomment if need always actual data on view. 
            //UpdateDataUsers();

            MainForm.rpgUsers.Visible = true;
            MainForm.btnUserEdit.ItemClick += btnUserEdit_ItemClick;
            gcUsers.EmbeddedNavigator.ButtonClick += EmbeddedNavigator_ButtonClick;
        }

        void UsersForm_Deactivate(object sender, System.EventArgs e)
        {
            if (MainForm == null)
                return;

            MainForm.rpgUsers.Visible = false;
            MainForm.btnUserEdit.ItemClick -= btnUserEdit_ItemClick;
            gcUsers.EmbeddedNavigator.ButtonClick -= EmbeddedNavigator_ButtonClick;
        }

        void EmbeddedNavigator_ButtonClick(object sender, DevExpress.XtraEditors.NavigatorButtonClickEventArgs e)
        {
            e.Handled = true;
            if (e.Button.ButtonType == DevExpress.XtraEditors.NavigatorButtonType.Remove)
            {
                var user = GetSelectedRowUser();
                //Deny delete himself if authorised user is of SA permissions
                if (user.UserId == MainForm.AuthorizedUser.UserId && AuthorizationService.IsUserAuthorizedTo(user, PermissionType.SuperAdministrator))
                {
                    MessageBox.Show(this, Resources.CouldNotDeleteHimself, Resources.MandaraAdministrationTool);
                }
                else
                {
                    var groupEtalon = user.Groups.
                                        Where(am => _authManager.GetGroups().FirstOrDefault(pm => pm.GroupId == am.GroupId
                                            && (pm.Permissions.Contains(PermissionType.SuperAdministrator)
                                                || pm.Permissions.Contains(PermissionType.Administrator))) != null).ToList();

                    if (!AuthorizationService.IsUserAuthorizedTo(MainForm.AuthorizedUser, PermissionType.SuperAdministrator) && groupEtalon.Count > 0)
                    {
                        MessageBox.Show(this, Resources.SuperAdministratorPrivilegesRequired, Resources.MandaraAdministrationTool);
                        return;
                    }

                    var result = MessageBox.Show(string.Format("Do you want to delete user {0} ?", user.UserName), Resources.MandaraAdministrationTool, MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        try
                        {
                            _authManager.DeleteUser(user, MainForm.CreateAuditContext("Users"));

                            User firstOrDefault = _bindingList.FirstOrDefault(u => u.UserId == user.UserId);

                            if (firstOrDefault != null)
                                _bindingList.Remove(firstOrDefault);
                        }
                        catch (Exception)
                        {
                            MessageBox.Show(this, Resources.CouldNotDeleteUser, Resources.MandaraAdministrationTool);
                        }
                    }
                }
            }
            else if (e.Button.ButtonType == DevExpress.XtraEditors.NavigatorButtonType.Append)
            {
                UserEditForm form = new UserEditForm();
                form.NewUserSaved += form_NewUserSaved;
                form.User = new User();
                form.MdiParent = MainForm;
                form.Show();
                form.Activate();
            }
        }

        void form_NewUserSaved(object sender, EventArgs e)
        {
            var newUser = (User)sender;
            _bindingList.Add(newUser);
        }

        private User GetSelectedRowUser()
        {
            User selectedRowUser = gvUsers.GetRow(gvUsers.FocusedRowHandle) as User;

            if (selectedRowUser != null)
                return _authManager.GetUserByName(selectedRowUser.UserName);

            return null;
        }

        private void ShowUserEditForm()
        {
            var form = new UserEditForm { User = GetSelectedRowUser() ?? new User(), MdiParent = MainForm };
            //Add binding to refresh grid on user data changed
            form.UserChanged += new EventHandler(form_UserChanged);
            form.Show();
            form.Activate();
        }
        /// <summary>
        /// Refresh grid on user data change
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void form_UserChanged(object sender, EventArgs e)
        {
            UpdateDataUsers();
        }

        private void btnUserEdit_ItemClick(object sender, ItemClickEventArgs e)
        {
            ShowUserEditForm();
        }

        private void gvUsers_DoubleClick(object sender, EventArgs e)
        {
            ShowUserEditForm();
        }
    }
}