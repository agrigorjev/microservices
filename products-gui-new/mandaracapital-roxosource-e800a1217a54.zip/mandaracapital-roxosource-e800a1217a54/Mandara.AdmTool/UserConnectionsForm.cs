﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows.Forms;
using com.latencybusters.lbm;
using Mandara.Business;
using Mandara.Business.Bus;
using Mandara.Business.Bus.Messages;
using Mandara.Entities;
using Mandara.Entities.ErrorReporting;

namespace Mandara.AdmTool
{
    public partial class UserConnectionsForm : DevExpress.XtraEditors.XtraForm
    {
        private BindingList<UserConnectionModel> _userConnections = new BindingList<UserConnectionModel>();

        public UserConnectionsForm()
        {
            InitializeComponent();
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            gcUserConnections.DataSource = _userConnections;
            _updateTimer.Start();
        }

        private void UserConnectionsForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            _updateTimer.Stop();
        }

        private void _updateTimer_Tick(object sender, EventArgs e)
        {
            var newConnections =
                MainForm.Instance.UserConnections.Values.Where(
                    x => _userConnections.All(c => c.ClientGuid != x.ClientGuid)).ToList();
            foreach(var newConnection in newConnections)
                _userConnections.Add(newConnection);

            var removedConnections =
                _userConnections.Where(
                    x => MainForm.Instance.UserConnections.Values.All(c => c.ClientGuid != x.ClientGuid)).ToList();
            foreach (var removedConnection in removedConnections)
                _userConnections.Remove(removedConnection);

            gcUserConnections.RefreshDataSource();
        }

        private void gvUserConnections_RowCellClick(object sender, DevExpress.XtraGrid.Views.Grid.RowCellClickEventArgs e)
        {
            if (e.Column.FieldName == "Reconnect")
            {
                UserConnectionModel userConnection = gvUserConnections.GetFocusedRow() as UserConnectionModel;
                if (userConnection != null && userConnection.ClientType == ClientType.IrmClient)
                {
                    using (ClientReconnectForm form = new ClientReconnectForm())
                    {
                        form.ReconnectOnlyOne = true;
                        if (form.ShowDialog(this) == DialogResult.Yes)
                        {
                            byte[] msg = new ClientReconnectMessage { Prefix = form.Prefix }.Serialize();
                            string topicName = InformaticaHelper.GetClientIndividualTopicName(InformaticaHelper.ClientReconnectTopicName, userConnection.ClientGuid);

                            try
                            {
                                LBMTopic topic = new LBMTopic(MainForm.Instance.LBMContext, topicName, new LBMSourceAttributes());
                                using (LBMSource clientReconnectSource = new LBMSource(MainForm.Instance.LBMContext, topic))
                                {
                                    InformaticaHelper.SendMessageToSource(clientReconnectSource, topicName, msg);
                                }
                            }
                            catch (Exception ex)
                            {
                                string txt = string.Format("Error sending message to topic [{0}]", topicName);

                                ErrorReportingHelper.GlobalQueue.Enqueue(new Error("IRM Server", ErrorType.Exception, txt, null, ex,
                                    ErrorLevel.Critical));
                            }
                        }
                    }
                }
            }
        }

    }
}
