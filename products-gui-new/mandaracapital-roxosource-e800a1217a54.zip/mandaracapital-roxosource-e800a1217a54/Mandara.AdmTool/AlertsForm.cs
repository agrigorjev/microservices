﻿using Mandara.Business.Client.Managers;
using Mandara.Business.Managers;
using Mandara.Entities;

namespace Mandara.AdmTool
{
    public partial class AlertsForm : DevExpress.XtraEditors.XtraForm
    {
        private MainForm _mainForm;
        private MainForm MainForm
        {
            get
            {
                if (_mainForm == null)
                    _mainForm = MdiParent as MainForm;

                return _mainForm;
            }
        }

       

        public AlertsForm()
        {
            InitializeComponent();

        }
        /// <summary>
        /// Bind main form buttons actions on alerts list activated
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AlertsForm_Activated(object sender, System.EventArgs e)
        {
            if (MainForm == null)
                return;

            MainForm.rpgAlertEdit.Visible = true;
            MainForm.btnAlertEdit.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(btnAlertEdit_ItemClick);
            UpdateData();
        }
        /// <summary>
        /// Main form edit button click handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void btnAlertEdit_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if (gvAlerts.FocusedRowHandle >= 0)
                ShowEditForm();
        }
        
        /// Remove bindings to main form buttons in case of form loose focus
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AlertsForm_Deactivate(object sender, System.EventArgs e)
        {
            if (MainForm == null)
                return;

            MainForm.rpgAlertEdit.Visible = false;
            MainForm.btnAlertEdit.ItemClick -= new DevExpress.XtraBars.ItemClickEventHandler(btnAlertEdit_ItemClick);
            MainForm.btnAlertEdit.Enabled = true;
        }

        /// <summary>
        /// Force reset data.
        /// </summary>

        private void UpdateData()
        {
            gcAlerts.DataSource = AdministrativeAlertManager.GetAlerts(true);
            MainForm.btnAlertEdit.Enabled = gvAlerts.FocusedRowHandle >= 0;
        }
        /// <summary>
        /// Intercept navigator add and remove button clicks
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        ///  <summary>
        void EmbeddedNavigator_ButtonClick(object sender, DevExpress.XtraEditors.NavigatorButtonClickEventArgs e)
        {
            e.Handled = true;
            if (e.Button.ButtonType == DevExpress.XtraEditors.NavigatorButtonType.Append)
            {
                AlertEditForm form = new AlertEditForm();
                form.MdiParent = MainForm;
                form.Alert = new AdministrativeAlert() { Active=true,Boundary=1};
                form.Show();
                form.Activate();
            }
            else if (e.Button.ButtonType == DevExpress.XtraEditors.NavigatorButtonType.Remove)
            {
                AdministrativeAlert selected = GetSelectedAlert();

                if (selected != null)
                {
                    AdministrativeAlertManager.DeleteAlert(selected.AlertId, MainForm.CreateAuditContext("Delete administrative alert"));
                }

                UpdateData();
            }
        }
        // <summary>
        /// Return alert from currently selected row in grid
        /// </summary>
        /// <returns>AdministrativeAlert</returns>
        private AdministrativeAlert GetSelectedAlert()
        {
            AdministrativeAlert selected = gvAlerts.GetRow(gvAlerts.FocusedRowHandle) as AdministrativeAlert;
            selected = AdministrativeAlertManager.GetAlert(selected.AlertId);

            if (selected != null)
                return selected;

            return null;
        }

        private void ShowEditForm()
        {
            AlertEditForm form = new AlertEditForm();
            form.MdiParent = MainForm;
            form.Alert = GetSelectedAlert() ?? new AdministrativeAlert() { Active = true, Boundary = 1 };
            form.Show();
            form.Activate();
        }
        /// <summary>
        /// Start edit alert on grid double click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void gcAlerts_DoubleClick(object sender, System.EventArgs e)
        {
            if (gvAlerts.FocusedRowHandle >= 0)
                ShowEditForm();
        }
        /// <summary>
        /// Alert active state chenged click processing
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void gvAlerts_CellValueChanging(object sender, DevExpress.XtraGrid.Views.Base.CellValueChangedEventArgs e)
        {
            AdministrativeAlert selected = gvAlerts.GetRow(e.RowHandle) as AdministrativeAlert;
            if (selected != null)
            {
                bool nValue=(bool)e.Value;
                AdministrativeAlertManager.SetAlertActive(selected.AlertId
                    , (bool)e.Value
                    , MainForm.CreateAuditContext(string.Format("Set administrative alert {0}.", nValue ? "active" : "inactive")));
            }
            
        }
      
    }
}