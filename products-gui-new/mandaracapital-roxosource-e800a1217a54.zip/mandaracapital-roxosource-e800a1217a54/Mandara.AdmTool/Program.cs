﻿using System;
using System.Windows.Forms;
using Mandara.AdmTool.Properties;
using Mandara.Business;
using Mandara.Business.Authorization;
using Mandara.Business.Bus;
using Ninject;
using Ninject.Extensions.Logging;

namespace Mandara.AdmTool
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            var kernel = CreateKernel();
            IoC.Initialize(kernel);
            BusClientProfile.InitAutomapper();


            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }

        private static IKernel CreateKernel()
        {
            var kernel = new StandardKernel();

            kernel.Load(new NLogModule(), new MainModule());

            return kernel;
        }
    }
}
