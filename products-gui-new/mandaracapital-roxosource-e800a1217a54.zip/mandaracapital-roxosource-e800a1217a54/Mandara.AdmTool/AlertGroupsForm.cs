﻿using System.Windows.Forms;
using Mandara.Business.Managers;
using Mandara.Entities;
using System;


namespace Mandara.AdmTool
{
    public partial class AlertGroupsForm : DevExpress.XtraEditors.XtraForm
    {
        private MainForm _mainForm;
        private MainForm MainForm
        {
            get
            {
                if (_mainForm == null)
                    _mainForm = MdiParent as MainForm;

                return _mainForm;
            }
        }



        public AlertGroupsForm()
        {
            InitializeComponent();

        }
        /// <summary>
        /// Bind main form buttons actions on alerts list activated
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AlertsForm_Activated(object sender, System.EventArgs e)
        {
            if (MainForm == null)
                return;

            MainForm.rpgAlertEdit.Visible = true;
            MainForm.btnAlertEdit.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(btnAlertEdit_ItemClick);
            gcGroups.EmbeddedNavigator.ButtonClick += new DevExpress.XtraEditors.NavigatorButtonClickEventHandler(EmbeddedNavigator_ButtonClick);
            gcGroups.DataSource = AdministrativeAlertManager.AlertGroups;
            MainForm.btnAlertEdit.Enabled = gvGroups.FocusedRowHandle >= 0;
           
        }
        /// <summary>
        /// Main form edit button click handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void btnAlertEdit_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            if (gvGroups.FocusedRowHandle >= 0)
                ShowEditForm();
        }
        /// <summary>
        /// Intercept navigator add and remove button clicks
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void EmbeddedNavigator_ButtonClick(object sender, DevExpress.XtraEditors.NavigatorButtonClickEventArgs e)
        {
            e.Handled = true;
            if (e.Button.ButtonType == DevExpress.XtraEditors.NavigatorButtonType.Append)
            {
                AlertGroupEditForm form = new AlertGroupEditForm();
                form.MdiParent = MainForm;
                form.Group = new AdministrativeAlertGroup();
                form.Show();
                form.Activate();
            }
            else if (e.Button.ButtonType == DevExpress.XtraEditors.NavigatorButtonType.Remove)
            {
                AdministrativeAlertGroup selectedGroup = GetSelectedGroup();
                if (selectedGroup != null)
                {
                    try
                    {
                        if (AdministrativeAlertManager.DeleteGroup(selectedGroup.GroupId, MainForm.CreateAuditContext("Delete administrative alert group.")))
                        {
                            gcGroups.DataSource = AdministrativeAlertManager.AlertGroups;
                        }
                        else
                        {
                            MessageBox.Show("This alert group cannot be deleted because it is linked with one or more alerts.","Warning");
                        }
                    }
                    catch(Exception ex)
                    {
                        MessageBox.Show(ex.Message,"Error");
                    }
                }
            }
        }

       
        /// <summary>
        /// Remove bindings to main form buttons in case of form loose focus
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AlertsForm_Deactivate(object sender, System.EventArgs e)
        {
            if (MainForm == null)
                return;

            MainForm.rpgAlertEdit.Visible = false;
            MainForm.btnAlertEdit.ItemClick -= new DevExpress.XtraBars.ItemClickEventHandler(btnAlertEdit_ItemClick);
            gcGroups.EmbeddedNavigator.ButtonClick -= new DevExpress.XtraEditors.NavigatorButtonClickEventHandler(EmbeddedNavigator_ButtonClick);
            MainForm.btnAlertEdit.Enabled = true;
        }
        /// <summary>
        /// Start edit group on grid double click
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void gvGroups_DoubleClick(object sender, System.EventArgs e)
        {
            if (gvGroups.FocusedRowHandle >=0)
                ShowEditForm();
        }

        /// <summary>
        /// Return group from currently selected row in grid
        /// </summary>
        /// <returns>AdministrativeAlertGroup</returns>
        private AdministrativeAlertGroup GetSelectedGroup()
        {
           
            AdministrativeAlertGroup selectedGroup = gvGroups.GetRow(gvGroups.FocusedRowHandle) as AdministrativeAlertGroup;
            selectedGroup = AdministrativeAlertManager.GetGroup(selectedGroup.GroupId);


            if (selectedGroup != null)
                return selectedGroup;
            return null;
        }
        /// <summary>
        /// pops up edit group form on main form button click or grid double click
        /// </summary>
        private void ShowEditForm()
        {
            AlertGroupEditForm form = new AlertGroupEditForm();
            form.MdiParent = MainForm;
            form.Group = GetSelectedGroup() ?? new AdministrativeAlertGroup();
            form.Show();
            form.Activate();
        }

      
    }
}