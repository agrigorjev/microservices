﻿using System;

namespace Mandara.AdmTool
{
    public enum ConnectionState
    {
        Online,
        LostHeartbeat,
        Offline
    }

    public class ServerConnectionModel
    {
        public string ServerPrefix { get; set; }

        public string ServerName { get; set; }

        public ConnectionState ServerStatus { get; set; } = ConnectionState.Offline;

        public DateTime LastActivityUtc { get; set; }
    }
}