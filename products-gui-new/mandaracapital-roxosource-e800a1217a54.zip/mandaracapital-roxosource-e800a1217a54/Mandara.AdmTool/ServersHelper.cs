﻿using System.Collections.Generic;
using System.Configuration;
using Mandara.Business.Config.Client;

namespace Mandara.AdmTool
{
    public static class ServersHelper
    {
        public static string GetServerName(string serverPrefix)
        {
            ServersConfigurationSection serversConfigurationSection = ConfigurationManager.GetSection("ServersSection") as ServersConfigurationSection;
            if (serversConfigurationSection != null)
            {
                foreach (var serverElement in serversConfigurationSection.Servers)
                {
                    if ((serverElement.Prefix ?? "") == (serverPrefix ?? ""))
                        return serverElement.Name;
                }
            }

            return null;
        }


        public static IEnumerable<string> GetAllServerPrefixes()
        {
            ServersConfigurationSection serversConfigurationSection = ConfigurationManager.GetSection("ServersSection") as ServersConfigurationSection;
            if (serversConfigurationSection != null)
            {
                foreach (var serverElement in serversConfigurationSection.Servers)
                {
                    yield return serverElement.Prefix;
                }
            }
        }

    }
}
