﻿namespace Mandara.AdmTool
{
    partial class ServersForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ServersForm));
            this.gcServers = new DevExpress.XtraGrid.GridControl();
            this.gvServers = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colServer = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colStatus = new DevExpress.XtraGrid.Columns.GridColumn();
            this.riGroups = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.repositoryItemCheckEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.repositoryItemCheckEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.repositoryItemCheckEdit3 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.repositoryItemCheckEdit4 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this._refreshServersStatusTimer = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.gcServers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvServers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.riGroups)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit4)).BeginInit();
            this.SuspendLayout();
            // 
            // gcServers
            // 
            this.gcServers.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gcServers.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.gcServers.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.gcServers.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.gcServers.EmbeddedNavigator.Buttons.First.Visible = false;
            this.gcServers.EmbeddedNavigator.Buttons.Last.Visible = false;
            this.gcServers.EmbeddedNavigator.Buttons.Next.Visible = false;
            this.gcServers.EmbeddedNavigator.Buttons.NextPage.Visible = false;
            this.gcServers.EmbeddedNavigator.Buttons.Prev.Visible = false;
            this.gcServers.EmbeddedNavigator.Buttons.PrevPage.Visible = false;
            this.gcServers.EmbeddedNavigator.TextLocation = DevExpress.XtraEditors.NavigatorButtonsTextLocation.None;
            this.gcServers.Location = new System.Drawing.Point(0, 0);
            this.gcServers.MainView = this.gvServers;
            this.gcServers.Name = "gcServers";
            this.gcServers.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.riGroups,
            this.repositoryItemCheckEdit1,
            this.repositoryItemCheckEdit2,
            this.repositoryItemCheckEdit3,
            this.repositoryItemCheckEdit4});
            this.gcServers.Size = new System.Drawing.Size(384, 342);
            this.gcServers.TabIndex = 1;
            this.gcServers.UseEmbeddedNavigator = true;
            this.gcServers.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gvServers});
            // 
            // gvServers
            // 
            this.gvServers.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colServer,
            this.colStatus});
            this.gvServers.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gvServers.GridControl = this.gcServers;
            this.gvServers.GroupFooterShowMode = DevExpress.XtraGrid.Views.Grid.GroupFooterShowMode.VisibleAlways;
            this.gvServers.Name = "gvServers";
            this.gvServers.OptionsBehavior.AllowAddRows = DevExpress.Utils.DefaultBoolean.True;
            this.gvServers.OptionsBehavior.AllowDeleteRows = DevExpress.Utils.DefaultBoolean.True;
            this.gvServers.OptionsCustomization.AllowGroup = false;
            this.gvServers.OptionsDetail.AllowZoomDetail = false;
            this.gvServers.OptionsDetail.EnableMasterViewMode = false;
            this.gvServers.OptionsDetail.ShowDetailTabs = false;
            this.gvServers.OptionsDetail.SmartDetailExpand = false;
            this.gvServers.OptionsView.ShowGroupPanel = false;
            this.gvServers.ShowButtonMode = DevExpress.XtraGrid.Views.Base.ShowButtonModeEnum.Default;
            this.gvServers.RowCellStyle += new DevExpress.XtraGrid.Views.Grid.RowCellStyleEventHandler(this.gvServers_RowCellStyle);
            // 
            // colServer
            // 
            this.colServer.Caption = "Server";
            this.colServer.FieldName = "ServerName";
            this.colServer.MinWidth = 100;
            this.colServer.Name = "colServer";
            this.colServer.OptionsColumn.AllowEdit = false;
            this.colServer.OptionsColumn.AllowFocus = false;
            this.colServer.Visible = true;
            this.colServer.VisibleIndex = 0;
            this.colServer.Width = 100;
            // 
            // colStatus
            // 
            this.colStatus.Caption = "Status";
            this.colStatus.FieldName = "ServerStatus";
            this.colStatus.MinWidth = 100;
            this.colStatus.Name = "colStatus";
            this.colStatus.OptionsColumn.AllowEdit = false;
            this.colStatus.OptionsColumn.AllowFocus = false;
            this.colStatus.Visible = true;
            this.colStatus.VisibleIndex = 1;
            this.colStatus.Width = 100;
            // 
            // riGroups
            // 
            this.riGroups.AutoHeight = false;
            this.riGroups.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.riGroups.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("GroupName", "Group")});
            this.riGroups.Name = "riGroups";
            this.riGroups.NullText = "[Group is not specified]";
            this.riGroups.ValueMember = "Instance";
            // 
            // repositoryItemCheckEdit1
            // 
            this.repositoryItemCheckEdit1.AutoHeight = false;
            this.repositoryItemCheckEdit1.Name = "repositoryItemCheckEdit1";
            // 
            // repositoryItemCheckEdit2
            // 
            this.repositoryItemCheckEdit2.AutoHeight = false;
            this.repositoryItemCheckEdit2.Name = "repositoryItemCheckEdit2";
            // 
            // repositoryItemCheckEdit3
            // 
            this.repositoryItemCheckEdit3.AutoHeight = false;
            this.repositoryItemCheckEdit3.Name = "repositoryItemCheckEdit3";
            // 
            // repositoryItemCheckEdit4
            // 
            this.repositoryItemCheckEdit4.AutoHeight = false;
            this.repositoryItemCheckEdit4.Name = "repositoryItemCheckEdit4";
            // 
            // _refreshServersStatusTimer
            // 
            this._refreshServersStatusTimer.Interval = 1000;
            this._refreshServersStatusTimer.Tick += new System.EventHandler(this._refreshServersStatusTimer_Tick);
            // 
            // ServersForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 342);
            this.Controls.Add(this.gcServers);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ServersForm";
            this.Text = "Servers";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ServersForm_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.gcServers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvServers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.riGroups)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraGrid.GridControl gcServers;
        private DevExpress.XtraGrid.Views.Grid.GridView gvServers;
        private DevExpress.XtraGrid.Columns.GridColumn colServer;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit riGroups;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit2;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit3;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit4;
        private DevExpress.XtraGrid.Columns.GridColumn colStatus;
        private System.Windows.Forms.Timer _refreshServersStatusTimer;
    }
}