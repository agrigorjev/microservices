﻿using System;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Reflection;
using System.Windows.Forms;
using com.latencybusters.lbm;
using DevExpress.XtraBars;
using DevExpress.XtraEditors;
using Mandara.AdmTool.Heartbeat;
using Mandara.Business;
using Mandara.Business.Audit;
using Mandara.Business.Bus;
using Mandara.Business.Bus.Handlers.Base;
using Mandara.Business.Bus.Messages;
using Mandara.Business.Bus.Messages.Features;
using Mandara.Business.Client.Managers;
using Mandara.Business.Config.Client;
using Mandara.Common;
using Mandara.Date.Time;
using Mandara.Entities;
using static Mandara.Business.Bus.InformaticaHelper;
using AuthorizationManager = Mandara.Business.Managers.AuthorizationManager;

namespace Mandara.AdmTool
{
    using System.Collections.Concurrent;
    using Business.Bus.Handlers;
    using Mandara.Business.Authorization;
    using Properties;

    public partial class MainForm : XtraForm
    {
        public static User AuthorizedUser { get; private set; }

        public ConcurrentDictionary<Guid, UserConnectionModel> UserConnections => _clientsAndServers.UserConnections;

        public ConcurrentDictionary<string, ServerConnectionModel> ServerConnections => _clientsAndServers.ServerConnections;

        private String LBMConfigurationFilePath => ConfigurationManager.AppSettings["LBMConfigurationFilePath"];

        public static MainForm Instance { get; private set; }

        private bool _onCloseAuditWritten;
        private LBMSource _clientReconnectSource;
        private LBMSource _featuresSource;
        private string _uiTitle;
        private AdminInformaticaHelper _adminInformaticaHelper;
        private Connections _clientsAndServers;

        public MainForm()
        {
            Instance = this;
            InitializeComponent();
        }

        protected override void OnLoad(EventArgs e)
        {
            _uiTitle = Text;
            _clientsAndServers = new Connections();
            base.OnLoad(e);
            DoAuthorization();
            InitBus();
            GetFeatureList();
            UpdateTitleBar();
        }

        private void UpdateTitleBar()
        {
            String serverName = "";

            if (ConfigurationManager.GetSection("ServersSection") is ServersConfigurationSection serversSection)
            {
                foreach (ServerConfigurationElement serverDef in serversSection.Servers)
                {
                    if (serverDef.Prefix.Equals(ServerPrefixes[0], StringComparison.InvariantCultureIgnoreCase))
                    {
                        serverName = serverDef.Name;
                    }
                }
            }

            Text = $"{_uiTitle} - v.{Assembly.GetEntryAssembly()?.GetName().Version} - {serverName}";
        }

        public LBMContext LBMContext
        {
            get;
            private set;
        }

        private void GetFeatureList()
        {
            LBMTopic topic = new LBMTopic(LBMContext, FeaturesTopicName, new LBMSourceAttributes());
            _featuresSource = new LBMSource(LBMContext, topic);

            FeaturesRequestMessage requestMessage = new FeaturesRequestMessage();
            byte[] msg = requestMessage.Serialize();

            SendRequestToSource(_featuresSource, FeaturesTopicName, msg, OnFeaturesResponse);
        }

        private int OnFeaturesResponse(object cbArg, LBMRequest lbmreq, LBMMessage lbmmsg)
        {
            switch (lbmmsg.type())
            {
                case LBM.MSG_RESPONSE:
                {
                    HandleFeatures(lbmmsg?.data());
                }
                break;

                default:
                break;
            }

            lbmreq.close();
            lbmreq.Dispose();
            lbmmsg.dispose();
            return 0;
        }

        private static void HandleFeatures(byte[] featuresData)
        {
            FeaturesResponseMessage message = JsonHelper.Deserialize<FeaturesResponseMessage>(featuresData);

            if (message != null)
            {
                FeatureManager.Init(message.Features);
            }
        }

        private void InitBus()
        {
            if (LBMConfigurationFilePath != null && File.Exists(LBMConfigurationFilePath))
            {
                LBM.setConfiguration(LBMConfigurationFilePath);
            }

            LBMContext = new LBMContext();

            LBMTopic topic = new LBMTopic(LBMContext, ClientReconnectTopicName, new LBMSourceAttributes());
            _clientReconnectSource = new LBMSource(LBMContext, topic);

            _adminInformaticaHelper = new AdminInformaticaHelper(LBMContext, new HandlerManager());
            _adminInformaticaHelper.CreateReceivers();

            _messagesBackgroundWorker.RunWorkerAsync();
        }

        private void DoAuthorization()
        {
            using (var authForm = new CheckPasswordForm())
            {
                if (authForm.ShowDialog(this) != DialogResult.OK)
                {
                    CloseWithAudit("Unauthorized Login Attempt");
                    return;
                }

                AuthorizedUser = authForm.AuthorizedUser;

                if (authForm.AuthorizedUser.Locked ?? false)
                {
                    MessageBox.Show(this, Resources.YourAccountIsLocked, Resources.MandaraAdministrationTool,
                                    MessageBoxButtons.OK, MessageBoxIcon.Error);

                    CloseWithAudit("Unauthorized Login Attempt");
                    return;
                }

                if (!AuthorizationService.IsUserAuthorizedTo(authForm.AuthorizedUser, PermissionType.Administrator)
                    && !AuthorizationService.IsUserAuthorizedTo(authForm.AuthorizedUser, PermissionType.SuperAdministrator))
                {
                    MessageBox.Show(this, Resources.YouDoNotHavePermissions, Resources.MandaraAdministrationTool,
                                    MessageBoxButtons.OK, MessageBoxIcon.Error);

                    CloseWithAudit("Unauthorized Login Attempt");
                    return;
                }
            }

            AuditManager.WriteAuditMessage(AuthorizedUser.UserName, null, "Admin tool", "Login", "User Login");
        }

        private void CloseWithAudit(string auditMessage, bool auditOnly = false)
        {
            if (_onCloseAuditWritten)
            {
                return;
            }

            AuditManager.WriteAuditMessage(
                AuthorizedUser?.UserName,
                null,
                "Admin tool",
                "Login",
                auditMessage);
            _onCloseAuditWritten = true;

            if (!auditOnly)
            {
                Close();
            }
        }

        public void RefreshUser()
        {
            AuthorizationManager manager = new AuthorizationManager();
            AuthorizedUser = manager.GetUserByName(AuthorizedUser.UserName);
        }

        private Form CreateOpenView(Type formType)
        {
            foreach (Form form in MdiChildren)
            {
                if (form.GetType() != formType)
                {
                    continue;
                }

                if (!form.Visible)
                {
                    form.Show();
                }

                form.Activate();
                form.WindowState = FormWindowState.Maximized;
                return form;
            }

            return CreateView(formType);
        }

        private Form CreateView(Type formType)
        {
            Form newForm = (Form)Activator.CreateInstance(formType);

            newForm.MdiParent = this;
            newForm.WindowState = FormWindowState.Maximized;
            newForm.Show();

            return newForm;
        }

        private void btnUsers_ItemClick(object sender, ItemClickEventArgs e)
        {
            CreateOpenView(typeof(UsersForm));
        }

        private void Exit_ItemClick(object sender, ItemClickEventArgs e)
        {
            Close();
        }

        private void btnAbout_ItemClick(object sender, ItemClickEventArgs e)
        {
            try
            {
                new AboutBox().ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
        }

        private void btnAuditMessages_ItemClick(object sender, ItemClickEventArgs e)
        {
            CreateOpenView(typeof(AuditMessagesForm));
        }

        private void btnGroups_ItemClick(object sender, ItemClickEventArgs e)
        {
            CreateOpenView(typeof(GroupsForm));
        }

        public static AuditContext CreateAuditContext(string contextName)
        {
            return new AuditContext
            {
                Source = "Admin tool",
                ContextName = contextName,
                UserName = AuthorizedUser.UserName,
                UserIp = LocalIPAddress(),
            };
        }

        private static string LocalIPAddress()
        {
            if (!System.Net.NetworkInformation.NetworkInterface.GetIsNetworkAvailable())
            {
                return null;
            }

            IPHostEntry host = Dns.GetHostEntry(Dns.GetHostName());
            IPAddress firstOrDefault =
                host.AddressList.FirstOrDefault(ip => ip.AddressFamily == AddressFamily.InterNetwork);

            return firstOrDefault?.ToString();
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            _adminInformaticaHelper?.CloseReceivers();
            _messagesBackgroundWorker.CancelAsync();

            if (_clientReconnectSource != null)
            {
                _clientReconnectSource.close();
                _clientReconnectSource.Dispose();
            }

            if (_featuresSource != null)
            {
                _featuresSource.close();
                _featuresSource.Dispose();
            }

            while (TempRequests.TryTake(out LBMRequest request))
            {
                request?.close();
            }

            if (LBMContext != null)
            {
                LBMContext.close();

                try
                {
                    LBMContext?.Dispose();
                }
                catch
                {
                    // ignored
                }
            }

            if (!_onCloseAuditWritten)
            {
                CloseWithAudit("User Logout", true);
            }
        }

        private void btnAlerts_ItemClick(object sender, ItemClickEventArgs e)
        {
            CreateOpenView(typeof(AlertsForm));
        }

        private void btnAlertGroups_ItemClick(object sender, ItemClickEventArgs e)
        {
            CreateOpenView(typeof(AlertGroupsForm));
        }

        private void btnTradeScenarios_ItemClick(object sender, ItemClickEventArgs e)
        {
            CreateOpenView(typeof(TradeScenariosForm));
        }

        private void btnReconnectClients_ItemClick(object sender, ItemClickEventArgs e)
        {
            ClientReconnectForm form = new ClientReconnectForm();

            if (form.ShowDialog(this) == DialogResult.Yes)
            {
                byte[] msg = new ClientReconnectMessage { Prefix = form.Prefix }.Serialize();

                SendMessageToSource(
                    _clientReconnectSource,
                    ClientReconnectTopicName,
                    msg);
            }
        }

        private void btnServers_ItemClick(object sender, ItemClickEventArgs e)
        {
            CreateOpenView(typeof(ServersForm));
        }

        private void btnClientConnections_ItemClick(object sender, ItemClickEventArgs e)
        {
            CreateOpenView(typeof(UserConnectionsForm));
        }

        private void _messagesBackgroundWorker_DoWork(object sender, System.ComponentModel.DoWorkEventArgs workArgs)
        {
            while (!workArgs.Cancel)
            {
                DateTime utcNow = InternalTime.UtcNow();

                ClientHeartbeatHandler.ReadMessage(out ClientHeartbeatMessage clientHeartbeat);
                ServerHeartbeatHandler.ReadMessage(out ServerHeartbeat serverHeartbeat);
                _clientsAndServers.UpdateConnections(clientHeartbeat, serverHeartbeat, utcNow);
            }
        }
    }
}