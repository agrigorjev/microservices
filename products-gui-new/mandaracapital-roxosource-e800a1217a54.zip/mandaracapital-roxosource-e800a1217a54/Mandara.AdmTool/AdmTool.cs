﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mandara.AdmTool
{
    public static class AdmTool
    {
        public static string CurrentServerPrefix { get; private set; }
        public static string PrimaryServerPrefix { get; set; }
        public static List<string> FallbackServersPrefixes { get; private set; }

        public static string GetNextServerPrefix(string prefix = null)
        {
            if (prefix != null)
            {
                CurrentServerPrefix = prefix;
            }
            else
            {
                if (CurrentServerPrefix == null)
                {
                    CurrentServerPrefix = PrimaryServerPrefix;
                }
                else
                {
                    List<string> prefixes = FallbackServersPrefixes.ToList();
                    prefixes.Insert(0, PrimaryServerPrefix);

                    int j = 0;
                    for (int i = 0; i < prefixes.Count; i++)
                    {
                        if (CurrentServerPrefix != prefixes[i])
                            continue;

                        j = (i + 1) % prefixes.Count;
                        break;
                    }

                    CurrentServerPrefix = prefixes[j];
                }
            }

            return CurrentServerPrefix;
        }

        static AdmTool()
        {
            FallbackServersPrefixes = new List<string>();
        }
    }
}
