﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Configuration;
using Mandara.Business.Bus.Messages;
using Mandara.Business.Config.Client;

namespace Mandara.AdmTool.Heartbeat
{
    public class Connections
    {
        public ConcurrentDictionary<Guid, UserConnectionModel> UserConnections { get; } =
            new ConcurrentDictionary<Guid, UserConnectionModel>();

        public ConcurrentDictionary<string, ServerConnectionModel> ServerConnections { get; } =
            new ConcurrentDictionary<string, ServerConnectionModel>();

        public static readonly TimeSpan DefaultOnlinePeriodSeconds = TimeSpan.FromSeconds(15);
        private TimeSpan _onlinePeriodSeconds = TimeSpan.MinValue;
        public TimeSpan OnlinePeriodSeconds
        {
            get
            {
                if (TimeSpan.MinValue == _onlinePeriodSeconds)
                {
                    _onlinePeriodSeconds = GetOnlinePeriodSeconds();
                }

                return _onlinePeriodSeconds;
            }
        }

        private static TimeSpan GetOnlinePeriodSeconds()
        {
            string period = ConfigurationManager.AppSettings["ServerOnline_Seconds"];

            if (string.IsNullOrEmpty(period) || !int.TryParse(period, out int onlinePeriodSeconds))
            {
                return DefaultOnlinePeriodSeconds;
            }

            return TimeSpan.FromSeconds(onlinePeriodSeconds);
        }

        public static readonly TimeSpan DefaultLostHeartbeatSeconds = TimeSpan.FromSeconds(30);
        private TimeSpan _lostHeartbeatPeriodSeconds = TimeSpan.MinValue;
        public TimeSpan LostHeartbeatPeriodSeconds
        {
            get
            {
                if (TimeSpan.MinValue == _lostHeartbeatPeriodSeconds)
                {
                    _lostHeartbeatPeriodSeconds = GetLostHeartbeatPeriodSeconds();
                }

                return _lostHeartbeatPeriodSeconds;
            }
        }

        private static TimeSpan GetLostHeartbeatPeriodSeconds()
        {
            // TODO: Check this spelling...
            string period = ConfigurationManager.AppSettings["ServerLostHearbeat_Seconds"];

            if (string.IsNullOrEmpty(period) || !int.TryParse(period, out int lostHeartbeatPeriodSeconds))
            {
                return DefaultLostHeartbeatSeconds;
            }

            return TimeSpan.FromSeconds(lostHeartbeatPeriodSeconds);
        }

        public Connections()
        {
            InitServerList();
        }

        private void InitServerList()
        {
            if (!(ConfigurationManager.GetSection("ServersSection") is ServersConfigurationSection servers))
            {
                return;
            }

            foreach (ServerConfigurationElement serverElement in servers.Servers)
            {
                AddServer(serverElement);
            }
        }

        private void AddServer(ServerConfigurationElement serverElement)
        {
            ServerConnectionModel serverConnectionModel = new ServerConnectionModel
            {
                ServerName = serverElement.Name,
                ServerPrefix = serverElement.Prefix
            };

            ServerConnections.TryAdd(serverConnectionModel.ServerPrefix ?? "", serverConnectionModel);
        }

        public void UpdateConnections(
            ClientHeartbeatMessage clientHeartbeat,
            ServerHeartbeat serverHeartbeat,
            DateTime utcNow)
        {
            if (null != clientHeartbeat)
            {
                HandleClientHeartbeat(clientHeartbeat, utcNow);
            }

            RemoveDisconnectedUsers(LostHeartbeatPeriodSeconds, utcNow);

            if (serverHeartbeat != null
                && ServerHeartbeat.NoPrefix != serverHeartbeat.ServerPrefix
                && ServerConnections.TryGetValue(
                    serverHeartbeat.ServerPrefix ?? "",
                    out ServerConnectionModel serverConnection))
            {
                serverConnection.LastActivityUtc = utcNow;
            }

            SetServerStatuses(utcNow);
        }

        private void HandleClientHeartbeat(ClientHeartbeatMessage heartbeat, DateTime utcNow)
        {
            if (UserConnections.TryGetValue(heartbeat.ClientGuid, out UserConnectionModel userConnection))
            {
                UpdateConnection(heartbeat, utcNow, userConnection);
            }
            else
            {
                UserConnections.TryAdd(heartbeat.ClientGuid, NewConnection(heartbeat, utcNow));
            }
        }

        private static void UpdateConnection(
            ClientHeartbeatMessage heartbeat,
            DateTime utcNow,
            UserConnectionModel userConnection)
        {
            if (userConnection.Name != heartbeat.UserName
                || userConnection.ServerPrefix != (heartbeat.ServerPrefix ?? ""))
            {
                userConnection = UpdateServerIdentification(heartbeat, userConnection);
            }

            userConnection.LastActivityUtc = utcNow;
        }

        private static UserConnectionModel UpdateServerIdentification(
            ClientHeartbeatMessage heartbeat,
            UserConnectionModel userConnection)
        {
            userConnection.Name = heartbeat.UserName;
            userConnection.ServerPrefix = heartbeat.ServerPrefix ?? "";
            userConnection.IpAddress = heartbeat.UserIp;
            userConnection.ServerName = ServersHelper.GetServerName(heartbeat.ServerPrefix ?? "")
                                        ?? $"Unknown Server with Prefix \"{heartbeat.ServerPrefix ?? ""}\"";

            return userConnection;
        }

        private static UserConnectionModel NewConnection(ClientHeartbeatMessage heartbeat, DateTime utcNow)
        {
            UserConnectionModel userConnection = new UserConnectionModel
            {
                ClientGuid = heartbeat.ClientGuid,
                ClientType = heartbeat.ClientType,
                LastActivityUtc = utcNow
            };

            return UpdateServerIdentification(heartbeat, userConnection);
        }

        private void RemoveDisconnectedUsers(TimeSpan lostHeartbeatPeriodSeconds, DateTime utcNow)
        {
            List<Guid> usersToRemove = new List<Guid>();

            foreach (UserConnectionModel uc in UserConnections.Values)
            {
                if (utcNow - uc.LastActivityUtc > lostHeartbeatPeriodSeconds)
                {
                    usersToRemove.Add(uc.ClientGuid);
                }
            }

            if (usersToRemove.Count == 0)
            {
                return;
            }

            foreach (Guid clientGuid in usersToRemove)
            {
                UserConnections.TryRemove(clientGuid, out UserConnectionModel _);
            }
        }

        private void SetServerStatuses(DateTime utcNow)
        {
            foreach (ServerConnectionModel serverConnection in ServerConnections.Values)
            {
                SetServerStatus(utcNow, serverConnection);
            }
        }

        private void SetServerStatus(DateTime utcNow, ServerConnectionModel serverConnection)
        {
            TimeSpan sinceLastActivity = utcNow - serverConnection.LastActivityUtc;

            if (sinceLastActivity < OnlinePeriodSeconds)
            {
                serverConnection.ServerStatus = ConnectionState.Online;
            }
            else if (sinceLastActivity < LostHeartbeatPeriodSeconds)
            {
                serverConnection.ServerStatus = ConnectionState.LostHeartbeat;
            }
            else
            {
                serverConnection.ServerStatus = ConnectionState.Offline;
            }
        }
    }
}