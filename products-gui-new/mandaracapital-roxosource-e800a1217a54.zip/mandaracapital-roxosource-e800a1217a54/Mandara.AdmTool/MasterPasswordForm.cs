﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using Mandara.Business.Authorization;
using Mandara.Business.Managers;
using Mandara.Entities;

namespace Mandara.AdmTool
{
    public partial class MasterPasswordForm : DevExpress.XtraEditors.XtraForm
    {
        private readonly User _user;

        public MasterPasswordForm(User user)
        {
            _user = user;

            InitializeComponent();
        }

        private void txtConfirm_Validating(object sender, CancelEventArgs e)
        {
            ValidatePasswordsMatch();
        }

        private void ValidatePasswordsMatch()
        {
            string errorText = txtPassword.Text.Equals(txtConfirm.Text) ? null : "Passwords should match";
            dxErrorProvider1.SetError(txtConfirm, errorText);
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnSetPassword_Click(object sender, EventArgs e)
        {
            if (_user == null)
                return;

            dxErrorProvider1.ClearErrors();

            ValidatePasswordsMatch();

            if (dxErrorProvider1.HasErrors)
                return;

            _user.MasterPasswordHash = Business.Client.Managers.AuthorizationManager.ComputeHash(txtPassword.Text);
            _user.LastPasswordChange = DateTime.Now.ToUniversalTime();

            Close();
        }

        
    }
}