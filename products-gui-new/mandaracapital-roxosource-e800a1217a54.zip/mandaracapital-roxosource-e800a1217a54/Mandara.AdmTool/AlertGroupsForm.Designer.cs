﻿namespace Mandara.AdmTool
{
    partial class AlertGroupsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AlertGroupsForm));
            this.gcGroups = new DevExpress.XtraGrid.GridControl();
            this.gvGroups = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colGroupName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.riGroups = new DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit();
            this.repositoryItemCheckEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.repositoryItemCheckEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.repositoryItemCheckEdit3 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.repositoryItemCheckEdit4 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.txtDummy = new DevExpress.XtraEditors.TextEdit();
            ((System.ComponentModel.ISupportInitialize)(this.gcGroups)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvGroups)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.riGroups)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDummy.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // gcGroups
            // 
            this.gcGroups.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gcGroups.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.gcGroups.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.gcGroups.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.gcGroups.EmbeddedNavigator.Buttons.First.Visible = false;
            this.gcGroups.EmbeddedNavigator.Buttons.Last.Visible = false;
            this.gcGroups.EmbeddedNavigator.Buttons.Next.Visible = false;
            this.gcGroups.EmbeddedNavigator.Buttons.NextPage.Visible = false;
            this.gcGroups.EmbeddedNavigator.Buttons.Prev.Visible = false;
            this.gcGroups.EmbeddedNavigator.Buttons.PrevPage.Visible = false;
            this.gcGroups.EmbeddedNavigator.TextLocation = DevExpress.XtraEditors.NavigatorButtonsTextLocation.None;
            this.gcGroups.Location = new System.Drawing.Point(0, 0);
            this.gcGroups.MainView = this.gvGroups;
            this.gcGroups.Name = "gcGroups";
            this.gcGroups.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.riGroups,
            this.repositoryItemCheckEdit1,
            this.repositoryItemCheckEdit2,
            this.repositoryItemCheckEdit3,
            this.repositoryItemCheckEdit4});
            this.gcGroups.Size = new System.Drawing.Size(1164, 542);
            this.gcGroups.TabIndex = 0;
            this.gcGroups.UseEmbeddedNavigator = true;
            this.gcGroups.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gvGroups});
            // 
            // gvGroups
            // 
            this.gvGroups.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colGroupName});
            this.gvGroups.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gvGroups.GridControl = this.gcGroups;
            this.gvGroups.GroupFooterShowMode = DevExpress.XtraGrid.Views.Grid.GroupFooterShowMode.VisibleAlways;
            this.gvGroups.Name = "gvGroups";
            this.gvGroups.OptionsBehavior.AllowAddRows = DevExpress.Utils.DefaultBoolean.True;
            this.gvGroups.OptionsBehavior.AllowDeleteRows = DevExpress.Utils.DefaultBoolean.True;
            this.gvGroups.OptionsCustomization.AllowGroup = false;
            this.gvGroups.OptionsDetail.AllowZoomDetail = false;
            this.gvGroups.OptionsDetail.EnableMasterViewMode = false;
            this.gvGroups.OptionsDetail.ShowDetailTabs = false;
            this.gvGroups.OptionsDetail.SmartDetailExpand = false;
            this.gvGroups.OptionsView.ShowGroupPanel = false;
            this.gvGroups.ShowButtonMode = DevExpress.XtraGrid.Views.Base.ShowButtonModeEnum.Default;
            this.gvGroups.DoubleClick += new System.EventHandler(this.gvGroups_DoubleClick);
            // 
            // colGroupName
            // 
            this.colGroupName.Caption = "Title";
            this.colGroupName.FieldName = "Title";
            this.colGroupName.Name = "colGroupName";
            this.colGroupName.OptionsColumn.AllowEdit = false;
            this.colGroupName.OptionsColumn.AllowFocus = false;
            this.colGroupName.Visible = true;
            this.colGroupName.VisibleIndex = 0;
            // 
            // riGroups
            // 
            this.riGroups.AutoHeight = false;
            this.riGroups.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.riGroups.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo("GroupName", "Group")});
            this.riGroups.Name = "riGroups";
            this.riGroups.NullText = "[Group is not specified]";
            this.riGroups.ValueMember = "Instance";
            // 
            // repositoryItemCheckEdit1
            // 
            this.repositoryItemCheckEdit1.AutoHeight = false;
            this.repositoryItemCheckEdit1.Name = "repositoryItemCheckEdit1";
            // 
            // repositoryItemCheckEdit2
            // 
            this.repositoryItemCheckEdit2.AutoHeight = false;
            this.repositoryItemCheckEdit2.Name = "repositoryItemCheckEdit2";
            // 
            // repositoryItemCheckEdit3
            // 
            this.repositoryItemCheckEdit3.AutoHeight = false;
            this.repositoryItemCheckEdit3.Name = "repositoryItemCheckEdit3";
            // 
            // repositoryItemCheckEdit4
            // 
            this.repositoryItemCheckEdit4.AutoHeight = false;
            this.repositoryItemCheckEdit4.Name = "repositoryItemCheckEdit4";
            // 
            // txtDummy
            // 
            this.txtDummy.Location = new System.Drawing.Point(32741, 394);
            this.txtDummy.Name = "txtDummy";
            this.txtDummy.Size = new System.Drawing.Size(100, 20);
            this.txtDummy.TabIndex = 1;
            // 
            // AlertGroupsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1164, 542);
            this.Controls.Add(this.txtDummy);
            this.Controls.Add(this.gcGroups);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AlertGroupsForm";
            this.Text = "Alert Groups";
            this.Activated += new System.EventHandler(this.AlertsForm_Activated);
            this.Deactivate += new System.EventHandler(this.AlertsForm_Deactivate);
            ((System.ComponentModel.ISupportInitialize)(this.gcGroups)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvGroups)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.riGroups)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDummy.Properties)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraGrid.GridControl gcGroups;
        private DevExpress.XtraGrid.Views.Grid.GridView gvGroups;
        private DevExpress.XtraEditors.Repository.RepositoryItemLookUpEdit riGroups;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit2;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit3;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit4;
        private DevExpress.XtraEditors.TextEdit txtDummy;
        private DevExpress.XtraGrid.Columns.GridColumn colGroupName;
    }
}