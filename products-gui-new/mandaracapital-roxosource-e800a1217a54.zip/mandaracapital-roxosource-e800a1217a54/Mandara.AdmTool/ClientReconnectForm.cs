﻿using System;
using System.Configuration;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using Mandara.Business.Config.Client;

namespace Mandara.AdmTool
{
    public partial class ClientReconnectForm : DevExpress.XtraEditors.XtraForm
    {
        public string Prefix { get; private set; }

        public ClientReconnectForm()
        {
            InitializeComponent();
        }

        private void ClientReconnectForm_Load(object sender, EventArgs e)
        {
            cmbServer.Properties.Items.Clear();

            ServersConfigurationSection serversSection =
                ConfigurationManager.GetSection("ServersSection") as ServersConfigurationSection;

            foreach (ServerConfigurationElement serverDef in serversSection.Servers)
            {
                cmbServer.Properties.Items.Add(serverDef);
            }

            if (cmbServer.Properties.Items.Count > 0)
            {
                cmbServer.SelectedIndex = 0;
            }
        }

        public bool ReconnectOnlyOne { get; set; }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnReconnect_Click(object sender, EventArgs e)
        {
            try
            {
                ServerConfigurationElement element = cmbServer.SelectedItem as ServerConfigurationElement;

                if (element != null)
                {
                    if (XtraMessageBox.Show(this, ReconnectOnlyOne ? string.Format("Are you sure you want to reconnect this client to a [{0}]?", element.Name) : string.Format("Are you sure you want to reconnect all clients to a [{0}]?", element.Name), "Reconnect Confirmation", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK)
                    {
                        Prefix = element.Prefix;
                        DialogResult = DialogResult.Yes;

                        Close();
                    }
                }
            }
            catch (ConfigurationErrorsException ex)
            {
                XtraMessageBox.Show(this, ex.Message, "Configuration Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    }
}