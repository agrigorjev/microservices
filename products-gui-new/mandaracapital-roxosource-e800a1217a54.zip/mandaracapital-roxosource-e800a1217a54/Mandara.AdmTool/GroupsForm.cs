﻿using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows.Forms;
using Mandara.AdmTool.Properties;
using Mandara.Business.Audit;
using Mandara.Business.Authorization;
using Mandara.Business.Managers;
using Mandara.Entities;

namespace Mandara.AdmTool
{
    public partial class GroupsForm : DevExpress.XtraEditors.XtraForm
    {
        private readonly AuthorizationManager _authManager = new AuthorizationManager();

        private MainForm _mainForm;
        private MainForm MainForm
        {
            get
            {
                if (_mainForm == null)
                    _mainForm = MdiParent as MainForm;

                return _mainForm;
            }
        }

        private BindingList<GroupViewModel> _groupsBindingList;

        public GroupsForm()
        {
            InitializeComponent();

            Activated += GroupsForm_Activated;
            Deactivate += GroupsForm_Deactivate;
            //Setup editor and event binding to intercept SA permission uncheck
            colSuperAdministrator.ColumnEdit = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            colSuperAdministrator.ColumnEdit.EditValueChanging += new DevExpress.XtraEditors.Controls.ChangingEventHandler(ColumnEdit_EditValueChanging);
            UpdateData();
        }

        void UpdateData()
        {
            var groups = _authManager.GetGroups();
            var groupViewModels = new List<GroupViewModel>();

            foreach (var group in groups)
            {
                var groupViewModel = new GroupViewModel
                {
                    GroupId = group.GroupId,
                    GroupName = group.GroupName,
                    RiskToolLaunchAccess = group.Permissions.Contains(PermissionType.LaunchRiskTool),
                    RiskToolWriteAccess = group.Permissions.Contains(PermissionType.RiskToolWriteAccess),
                    ProductToolLaunchAccess = group.Permissions.Contains(PermissionType.LaunchProductMgmtTool),
                    ProductToolWriteAccess = group.Permissions.Contains(PermissionType.ProductMgmtToolWriteAccess),

                    Administrator = group.Permissions.Contains(PermissionType.Administrator),
                    SuperAdministrator = group.Permissions.Contains(PermissionType.SuperAdministrator),
                    LaunchHAL = group.Permissions.Contains(PermissionType.LaunchHAL),
                    LaunchVHAL = group.Permissions.Contains(PermissionType.LaunchVHAL),

                    ViewCumulativePnl = group.Permissions.Contains(PermissionType.ViewCumulativePnl),

                    UseProductBreakdown = group.Permissions.Contains(PermissionType.UseProductBreakdown)
                };

                groupViewModels.Add(groupViewModel);
            }

            _groupsBindingList = new BindingList<GroupViewModel>(groupViewModels);


            gcGroups.DataSource = _groupsBindingList;

            riGroups.DataSource = groups.Distinct().ToList();
        }
        /// <summary>
        /// Intercept attempt to uncheck SA permission for group
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void ColumnEdit_EditValueChanging(object sender, DevExpress.XtraEditors.Controls.ChangingEventArgs e)
        {
            //We only take care if false (uncheck)
            if (!(bool)e.NewValue && gvGroups.FocusedRowHandle >= 0)
            {
                int editedGroup = _groupsBindingList[gvGroups.FocusedRowHandle].GroupId;
                if (MainForm.AuthorizedUser.Groups.Any(g => g.GroupId == editedGroup))
                {
                    //If the group is the Users's group - show deny message
                    MessageBox.Show(this, Resources.SuperAdministratorPrivilegeRevokeDenied, Resources.MandaraAdministrationTool);
                    //End prevent uncheck
                    e.Cancel = true;
                }
            }

        }

        void GroupsForm_Activated(object sender, System.EventArgs e)
        {
            if (MainForm == null)
                return;

            MainForm.rpgGroups.Visible = true;
            MainForm.btnGroupsSave.ItemClick += btnGroupsSave_ItemClick;
        }

        void GroupsForm_Deactivate(object sender, System.EventArgs e)
        {
            if (MainForm == null)
                return;

            MainForm.rpgGroups.Visible = false;
            MainForm.btnGroupsSave.ItemClick -= btnGroupsSave_ItemClick;
        }

        void btnGroupsSave_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            txtDummy.Focus();

            //If user not super and group Admin|Super delete.
            if (!AuthorizationService.IsUserAuthorizedTo(MainForm.AuthorizedUser, PermissionType.SuperAdministrator))
            {
                var etalonGrous = _authManager.GetGroups().
                    Where(am => _groupsBindingList.FirstOrDefault(pm => pm.GroupId == am.GroupId) == null).
                    Where(p =>
                          p.Permissions.Contains(PermissionType.SuperAdministrator) ||
                          p.Permissions.Contains(PermissionType.Administrator));
                if (etalonGrous.Any())
                {
                    MessageBox.Show(this, Resources.SuperAdministratorPrivilegesRequired, Resources.MandaraAdministrationTool);
                    UpdateData();
                    return;
                }
            }

            var groups = new List<Group>();

            foreach (var viewModel in _groupsBindingList)
            {
                Group g = null;

                var tmp = _authManager.GetGroups().FirstOrDefault(am => am.GroupId == viewModel.GroupId);
                if (tmp == null)
                    tmp = new Group { GroupName = viewModel.GroupName, GroupId = viewModel.GroupId };
                if (!AuthorizationService.IsUserAuthorizedTo(MainForm.AuthorizedUser, PermissionType.SuperAdministrator)
                    && ((!AuthorizationService.IsUserAuthorizedTo(MainForm.AuthorizedUser, PermissionType.SuperAdministrator)
                            && (tmp.Permissions.Contains(PermissionType.Administrator) || tmp.Permissions.Contains(PermissionType.SuperAdministrator)))
                        || (!AuthorizationService.IsUserAuthorizedTo(MainForm.AuthorizedUser, PermissionType.SuperAdministrator)
                            && (tmp.Permissions.Contains(PermissionType.Administrator) != viewModel.Administrator)
                        || tmp.Permissions.Contains(PermissionType.SuperAdministrator) != viewModel.SuperAdministrator)))
                {
                    g = tmp;
                }
                else
                {
                    g = groups.FirstOrDefault(x => x.GroupId == viewModel.GroupId) ??
                        new Group { GroupName = viewModel.GroupName, GroupId = viewModel.GroupId };

                    if (viewModel.ProductToolLaunchAccess)
                        g.Permissions.Add(new Permission { PermissionId = PermissionType.LaunchProductMgmtTool.GetPermissionId() });

                    if (viewModel.ProductToolWriteAccess)
                        g.Permissions.Add(new Permission { PermissionId = PermissionType.ProductMgmtToolWriteAccess.GetPermissionId() });

                    if (viewModel.RiskToolLaunchAccess)
                        g.Permissions.Add(new Permission { PermissionId = PermissionType.LaunchRiskTool.GetPermissionId() });

                    if (viewModel.RiskToolWriteAccess)
                        g.Permissions.Add(new Permission { PermissionId = PermissionType.RiskToolWriteAccess.GetPermissionId() });

                    if (viewModel.Administrator)
                        g.Permissions.Add(new Permission { PermissionId = PermissionType.Administrator.GetPermissionId() });

                    if (viewModel.SuperAdministrator)
                        g.Permissions.Add(new Permission { PermissionId = PermissionType.SuperAdministrator.GetPermissionId() });

                    if (viewModel.LaunchHAL)
                        g.Permissions.Add(new Permission { PermissionId = PermissionType.LaunchHAL.GetPermissionId() });

                    if (viewModel.LaunchVHAL)
                        g.Permissions.Add(new Permission { PermissionId = PermissionType.LaunchVHAL.GetPermissionId() });

                    if (viewModel.ViewCumulativePnl)
                        g.Permissions.Add(new Permission { PermissionId = PermissionType.ViewCumulativePnl.GetPermissionId() });

                    if (viewModel.UseProductBreakdown)
                        g.Permissions.Add(new Permission { PermissionId = PermissionType.UseProductBreakdown.GetPermissionId() });
                }
                groups.Add(g);
            }

            AuditContext auditContext = MainForm.CreateAuditContext("Group Details");

            _authManager.SaveGroups(groups, auditContext);
            MainForm.RefreshUser();
            UpdateData();
        }


    }
}