﻿using System;
using Mandara.Business;

namespace Mandara.AdmTool
{
    public class UserConnectionModel
    {
        public string Name { get; set; }

        public Guid ClientGuid { get; set; }

        public string ServerPrefix { get; set; }

        public string ServerName { get; set; }

        public DateTime LastActivityUtc { get; set; }

        public ClientType ClientType { get; set; }

        public string IpAddress { get; set; }

        public string Reconnect
        {
            get { return ClientType == ClientType.IrmClient ? "Reconnect" : null; }
        }
    }
}
