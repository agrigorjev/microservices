﻿namespace Mandara.AdmTool
{
    partial class AuditMessagesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AuditMessagesForm));
            this.gcAuditMessages = new DevExpress.XtraGrid.GridControl();
            this.gvAuditMessages = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colMessageTime = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colMessageType = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colUserName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colObjectType = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colObjectID = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colObjectDescription = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.dockManager1 = new DevExpress.XtraBars.Docking.DockManager(this.components);
            this.hideContainerRight = new DevExpress.XtraBars.Docking.AutoHideContainer();
            this.dockPanel1 = new DevExpress.XtraBars.Docking.DockPanel();
            this.dockPanel1_Container = new DevExpress.XtraBars.Docking.ControlContainer();
            this.tlAuditMessageDetails = new DevExpress.XtraTreeList.TreeList();
            this.colProperty = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.colOldValue = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.colNewValue = new DevExpress.XtraTreeList.Columns.TreeListColumn();
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.txtObjectDescription = new DevExpress.XtraEditors.MemoEdit();
            this.lblObjectDescription = new DevExpress.XtraEditors.LabelControl();
            this.lblObjectId = new DevExpress.XtraEditors.LabelControl();
            this.txtObjectId = new DevExpress.XtraEditors.TextEdit();
            this.lblObjectType = new DevExpress.XtraEditors.LabelControl();
            this.txtObjectType = new DevExpress.XtraEditors.TextEdit();
            this.lblUserName = new DevExpress.XtraEditors.LabelControl();
            this.txtUserName = new DevExpress.XtraEditors.TextEdit();
            this.lblMessageType = new DevExpress.XtraEditors.LabelControl();
            this.txtMessageType = new DevExpress.XtraEditors.TextEdit();
            this.lblTime = new DevExpress.XtraEditors.LabelControl();
            this.txtTime = new DevExpress.XtraEditors.TextEdit();
            this.barAndDockingController1 = new DevExpress.XtraBars.BarAndDockingController(this.components);
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.linkRefresh = new System.Windows.Forms.ToolStripLabel();
            this.deFilterDate = new DevExpress.XtraEditors.DateEdit();
            this.panelControl2 = new DevExpress.XtraEditors.PanelControl();
            ((System.ComponentModel.ISupportInitialize)(this.gcAuditMessages)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvAuditMessages)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dockManager1)).BeginInit();
            this.hideContainerRight.SuspendLayout();
            this.dockPanel1.SuspendLayout();
            this.dockPanel1_Container.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tlAuditMessageDetails)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtObjectDescription.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtObjectId.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtObjectType.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUserName.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMessageType.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTime.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.barAndDockingController1)).BeginInit();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.deFilterDate.Properties.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.deFilterDate.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).BeginInit();
            this.panelControl2.SuspendLayout();
            this.SuspendLayout();
            // 
            // gcAuditMessages
            // 
            this.gcAuditMessages.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gcAuditMessages.Location = new System.Drawing.Point(2, 2);
            this.gcAuditMessages.MainView = this.gvAuditMessages;
            this.gcAuditMessages.Name = "gcAuditMessages";
            this.gcAuditMessages.Size = new System.Drawing.Size(844, 437);
            this.gcAuditMessages.TabIndex = 0;
            this.gcAuditMessages.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gvAuditMessages});
            this.gcAuditMessages.DataSourceChanged += new System.EventHandler(this.gcAuditMessages_DataSourceChanged);
            // 
            // gvAuditMessages
            // 
            this.gvAuditMessages.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colMessageTime,
            this.gridColumn1,
            this.gridColumn3,
            this.colMessageType,
            this.colUserName,
            this.gridColumn5,
            this.colObjectType,
            this.colObjectID,
            this.colObjectDescription,
            this.gridColumn2});
            this.gvAuditMessages.GridControl = this.gcAuditMessages;
            this.gvAuditMessages.Name = "gvAuditMessages";
            this.gvAuditMessages.OptionsBehavior.Editable = false;
            this.gvAuditMessages.OptionsCustomization.AllowGroup = false;
            this.gvAuditMessages.OptionsView.ShowGroupPanel = false;
            this.gvAuditMessages.OptionsView.ShowIndicator = false;
            this.gvAuditMessages.SortInfo.AddRange(new DevExpress.XtraGrid.Columns.GridColumnSortInfo[] {
            new DevExpress.XtraGrid.Columns.GridColumnSortInfo(this.colMessageTime, DevExpress.Data.ColumnSortOrder.Descending)});
            this.gvAuditMessages.FocusedRowChanged += new DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.gvAuditMessages_FocusedRowChanged);
            // 
            // colMessageTime
            // 
            this.colMessageTime.Caption = "Time";
            this.colMessageTime.DisplayFormat.FormatString = "G";
            this.colMessageTime.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            this.colMessageTime.FieldName = "MessageTime";
            this.colMessageTime.Name = "colMessageTime";
            this.colMessageTime.Visible = true;
            this.colMessageTime.VisibleIndex = 0;
            // 
            // gridColumn1
            // 
            this.gridColumn1.Caption = "Source";
            this.gridColumn1.FieldName = "Source";
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 6;
            // 
            // gridColumn3
            // 
            this.gridColumn3.Caption = "Context Name";
            this.gridColumn3.FieldName = "ContextName";
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 8;
            // 
            // colMessageType
            // 
            this.colMessageType.Caption = "Message Type";
            this.colMessageType.FieldName = "MessageType";
            this.colMessageType.Name = "colMessageType";
            this.colMessageType.Visible = true;
            this.colMessageType.VisibleIndex = 1;
            // 
            // colUserName
            // 
            this.colUserName.Caption = "User Name";
            this.colUserName.FieldName = "UserNameOrRef";
            this.colUserName.Name = "colUserName";
            this.colUserName.Visible = true;
            this.colUserName.VisibleIndex = 2;
            // 
            // gridColumn5
            // 
            this.gridColumn5.Caption = "User IP";
            this.gridColumn5.FieldName = "UserIp";
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.Visible = true;
            this.gridColumn5.VisibleIndex = 9;
            // 
            // colObjectType
            // 
            this.colObjectType.Caption = "Object Type";
            this.colObjectType.FieldName = "ObjectType";
            this.colObjectType.Name = "colObjectType";
            this.colObjectType.Visible = true;
            this.colObjectType.VisibleIndex = 3;
            // 
            // colObjectID
            // 
            this.colObjectID.AppearanceCell.Options.UseTextOptions = true;
            this.colObjectID.AppearanceCell.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Near;
            this.colObjectID.Caption = "Object Id";
            this.colObjectID.FieldName = "ObjectId";
            this.colObjectID.Name = "colObjectID";
            this.colObjectID.Visible = true;
            this.colObjectID.VisibleIndex = 4;
            // 
            // colObjectDescription
            // 
            this.colObjectDescription.Caption = "Object Description";
            this.colObjectDescription.FieldName = "ObjectDescription";
            this.colObjectDescription.Name = "colObjectDescription";
            this.colObjectDescription.Visible = true;
            this.colObjectDescription.VisibleIndex = 5;
            // 
            // gridColumn2
            // 
            this.gridColumn2.Caption = "Context Id";
            this.gridColumn2.FieldName = "ContextId";
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 7;
            // 
            // dockManager1
            // 
            this.dockManager1.AutoHideContainers.AddRange(new DevExpress.XtraBars.Docking.AutoHideContainer[] {
            this.hideContainerRight});
            this.dockManager1.Controller = this.barAndDockingController1;
            this.dockManager1.Form = this;
            this.dockManager1.TopZIndexControls.AddRange(new string[] {
            "DevExpress.XtraBars.BarDockControl",
            "DevExpress.XtraBars.StandaloneBarDockControl",
            "System.Windows.Forms.StatusBar",
            "DevExpress.XtraBars.Ribbon.RibbonStatusBar",
            "DevExpress.XtraBars.Ribbon.RibbonControl"});
            // 
            // hideContainerRight
            // 
            this.hideContainerRight.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(236)))), ((int)(((byte)(239)))));
            this.hideContainerRight.Controls.Add(this.dockPanel1);
            this.hideContainerRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.hideContainerRight.Location = new System.Drawing.Point(848, 0);
            this.hideContainerRight.Name = "hideContainerRight";
            this.hideContainerRight.Size = new System.Drawing.Size(19, 466);
            // 
            // dockPanel1
            // 
            this.dockPanel1.Controls.Add(this.dockPanel1_Container);
            this.dockPanel1.Dock = DevExpress.XtraBars.Docking.DockingStyle.Right;
            this.dockPanel1.DockVertical = DevExpress.Utils.DefaultBoolean.False;
            this.dockPanel1.ID = new System.Guid("59905e79-6e6d-4b32-bd0b-07d84a9262e6");
            this.dockPanel1.Location = new System.Drawing.Point(0, 0);
            this.dockPanel1.Name = "dockPanel1";
            this.dockPanel1.OriginalSize = new System.Drawing.Size(420, 466);
            this.dockPanel1.SavedDock = DevExpress.XtraBars.Docking.DockingStyle.Right;
            this.dockPanel1.SavedIndex = 0;
            this.dockPanel1.Size = new System.Drawing.Size(420, 466);
            this.dockPanel1.Text = "Message Details";
            this.dockPanel1.Visibility = DevExpress.XtraBars.Docking.DockVisibility.AutoHide;
            // 
            // dockPanel1_Container
            // 
            this.dockPanel1_Container.Controls.Add(this.tlAuditMessageDetails);
            this.dockPanel1_Container.Controls.Add(this.panelControl1);
            this.dockPanel1_Container.Location = new System.Drawing.Point(4, 23);
            this.dockPanel1_Container.Name = "dockPanel1_Container";
            this.dockPanel1_Container.Size = new System.Drawing.Size(412, 439);
            this.dockPanel1_Container.TabIndex = 0;
            // 
            // tlAuditMessageDetails
            // 
            this.tlAuditMessageDetails.Columns.AddRange(new DevExpress.XtraTreeList.Columns.TreeListColumn[] {
            this.colProperty,
            this.colOldValue,
            this.colNewValue});
            this.tlAuditMessageDetails.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tlAuditMessageDetails.KeyFieldName = "Id";
            this.tlAuditMessageDetails.Location = new System.Drawing.Point(0, 201);
            this.tlAuditMessageDetails.Name = "tlAuditMessageDetails";
            this.tlAuditMessageDetails.OptionsBehavior.AutoPopulateColumns = false;
            this.tlAuditMessageDetails.OptionsBehavior.Editable = false;
            this.tlAuditMessageDetails.OptionsPrint.UsePrintStyles = true;
            this.tlAuditMessageDetails.OptionsView.ShowIndicator = false;
            this.tlAuditMessageDetails.ParentFieldName = "ParentId";
            this.tlAuditMessageDetails.Size = new System.Drawing.Size(412, 238);
            this.tlAuditMessageDetails.TabIndex = 1;
            // 
            // colProperty
            // 
            this.colProperty.Caption = "Property";
            this.colProperty.FieldName = "Property";
            this.colProperty.Name = "colProperty";
            this.colProperty.Visible = true;
            this.colProperty.VisibleIndex = 0;
            this.colProperty.Width = 120;
            // 
            // colOldValue
            // 
            this.colOldValue.Caption = "Old Value";
            this.colOldValue.FieldName = "OldValue";
            this.colOldValue.Name = "colOldValue";
            this.colOldValue.Visible = true;
            this.colOldValue.VisibleIndex = 1;
            this.colOldValue.Width = 150;
            // 
            // colNewValue
            // 
            this.colNewValue.Caption = "New Value";
            this.colNewValue.FieldName = "NewValue";
            this.colNewValue.Name = "colNewValue";
            this.colNewValue.Visible = true;
            this.colNewValue.VisibleIndex = 2;
            this.colNewValue.Width = 150;
            // 
            // panelControl1
            // 
            this.panelControl1.Controls.Add(this.txtObjectDescription);
            this.panelControl1.Controls.Add(this.lblObjectDescription);
            this.panelControl1.Controls.Add(this.lblObjectId);
            this.panelControl1.Controls.Add(this.txtObjectId);
            this.panelControl1.Controls.Add(this.lblObjectType);
            this.panelControl1.Controls.Add(this.txtObjectType);
            this.panelControl1.Controls.Add(this.lblUserName);
            this.panelControl1.Controls.Add(this.txtUserName);
            this.panelControl1.Controls.Add(this.lblMessageType);
            this.panelControl1.Controls.Add(this.txtMessageType);
            this.panelControl1.Controls.Add(this.lblTime);
            this.panelControl1.Controls.Add(this.txtTime);
            this.panelControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelControl1.Location = new System.Drawing.Point(0, 0);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(412, 201);
            this.panelControl1.TabIndex = 0;
            // 
            // txtObjectDescription
            // 
            this.txtObjectDescription.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtObjectDescription.Enabled = false;
            this.txtObjectDescription.Location = new System.Drawing.Point(99, 135);
            this.txtObjectDescription.Name = "txtObjectDescription";
            this.txtObjectDescription.Size = new System.Drawing.Size(305, 60);
            this.txtObjectDescription.TabIndex = 5;
            // 
            // lblObjectDescription
            // 
            this.lblObjectDescription.Location = new System.Drawing.Point(5, 138);
            this.lblObjectDescription.Name = "lblObjectDescription";
            this.lblObjectDescription.Size = new System.Drawing.Size(88, 13);
            this.lblObjectDescription.TabIndex = 11;
            this.lblObjectDescription.Text = "Object Description";
            // 
            // lblObjectId
            // 
            this.lblObjectId.Location = new System.Drawing.Point(5, 112);
            this.lblObjectId.Name = "lblObjectId";
            this.lblObjectId.Size = new System.Drawing.Size(45, 13);
            this.lblObjectId.TabIndex = 9;
            this.lblObjectId.Text = "Object Id";
            // 
            // txtObjectId
            // 
            this.txtObjectId.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtObjectId.Enabled = false;
            this.txtObjectId.Location = new System.Drawing.Point(99, 109);
            this.txtObjectId.Name = "txtObjectId";
            this.txtObjectId.Size = new System.Drawing.Size(305, 20);
            this.txtObjectId.TabIndex = 4;
            // 
            // lblObjectType
            // 
            this.lblObjectType.Location = new System.Drawing.Point(5, 86);
            this.lblObjectType.Name = "lblObjectType";
            this.lblObjectType.Size = new System.Drawing.Size(59, 13);
            this.lblObjectType.TabIndex = 7;
            this.lblObjectType.Text = "Object Type";
            // 
            // txtObjectType
            // 
            this.txtObjectType.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtObjectType.Enabled = false;
            this.txtObjectType.Location = new System.Drawing.Point(99, 83);
            this.txtObjectType.Name = "txtObjectType";
            this.txtObjectType.Size = new System.Drawing.Size(305, 20);
            this.txtObjectType.TabIndex = 3;
            // 
            // lblUserName
            // 
            this.lblUserName.Location = new System.Drawing.Point(5, 60);
            this.lblUserName.Name = "lblUserName";
            this.lblUserName.Size = new System.Drawing.Size(52, 13);
            this.lblUserName.TabIndex = 5;
            this.lblUserName.Text = "User Name";
            // 
            // txtUserName
            // 
            this.txtUserName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtUserName.Enabled = false;
            this.txtUserName.Location = new System.Drawing.Point(99, 57);
            this.txtUserName.Name = "txtUserName";
            this.txtUserName.Size = new System.Drawing.Size(305, 20);
            this.txtUserName.TabIndex = 2;
            // 
            // lblMessageType
            // 
            this.lblMessageType.Location = new System.Drawing.Point(5, 34);
            this.lblMessageType.Name = "lblMessageType";
            this.lblMessageType.Size = new System.Drawing.Size(69, 13);
            this.lblMessageType.TabIndex = 3;
            this.lblMessageType.Text = "Message Type";
            // 
            // txtMessageType
            // 
            this.txtMessageType.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtMessageType.Enabled = false;
            this.txtMessageType.Location = new System.Drawing.Point(99, 31);
            this.txtMessageType.Name = "txtMessageType";
            this.txtMessageType.Size = new System.Drawing.Size(305, 20);
            this.txtMessageType.TabIndex = 1;
            // 
            // lblTime
            // 
            this.lblTime.Location = new System.Drawing.Point(5, 8);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(22, 13);
            this.lblTime.TabIndex = 1;
            this.lblTime.Text = "Time";
            // 
            // txtTime
            // 
            this.txtTime.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtTime.Enabled = false;
            this.txtTime.Location = new System.Drawing.Point(99, 5);
            this.txtTime.Name = "txtTime";
            this.txtTime.Size = new System.Drawing.Size(305, 20);
            this.txtTime.TabIndex = 0;
            // 
            // toolStrip1
            // 
            this.toolStrip1.AllowMerge = false;
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel1,
            this.linkRefresh});
            this.toolStrip1.Location = new System.Drawing.Point(0, 441);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(848, 25);
            this.toolStrip1.TabIndex = 2;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(111, 22);
            this.toolStripLabel1.Text = "Show messages for:";
            // 
            // linkRefresh
            // 
            this.linkRefresh.IsLink = true;
            this.linkRefresh.Margin = new System.Windows.Forms.Padding(105, 1, 0, 2);
            this.linkRefresh.Name = "linkRefresh";
            this.linkRefresh.Size = new System.Drawing.Size(46, 22);
            this.linkRefresh.Text = "Refresh";
            this.linkRefresh.Click += new System.EventHandler(this.linkRefresh_Click);
            // 
            // deFilterDate
            // 
            this.deFilterDate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.deFilterDate.EditValue = null;
            this.deFilterDate.Location = new System.Drawing.Point(112, 443);
            this.deFilterDate.Name = "deFilterDate";
            this.deFilterDate.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.False;
            this.deFilterDate.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.deFilterDate.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
            this.deFilterDate.Properties.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.deFilterDate.Size = new System.Drawing.Size(100, 20);
            this.deFilterDate.TabIndex = 4;
            // 
            // panelControl2
            // 
            this.panelControl2.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.panelControl2.Controls.Add(this.gcAuditMessages);
            this.panelControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelControl2.Location = new System.Drawing.Point(0, 0);
            this.panelControl2.Name = "panelControl2";
            this.panelControl2.Padding = new System.Windows.Forms.Padding(2);
            this.panelControl2.Size = new System.Drawing.Size(848, 441);
            this.panelControl2.TabIndex = 6;
            // 
            // AuditMessagesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(867, 466);
            this.Controls.Add(this.panelControl2);
            this.Controls.Add(this.deFilterDate);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.hideContainerRight);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AuditMessagesForm";
            this.Text = "Audit Messages";
            this.Load += new System.EventHandler(this.AuditMessagesForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gcAuditMessages)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvAuditMessages)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dockManager1)).EndInit();
            this.hideContainerRight.ResumeLayout(false);
            this.dockPanel1.ResumeLayout(false);
            this.dockPanel1_Container.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.tlAuditMessageDetails)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            this.panelControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtObjectDescription.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtObjectId.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtObjectType.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUserName.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMessageType.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTime.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.barAndDockingController1)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.deFilterDate.Properties.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.deFilterDate.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).EndInit();
            this.panelControl2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraGrid.GridControl gcAuditMessages;
        private DevExpress.XtraGrid.Views.Grid.GridView gvAuditMessages;
        private DevExpress.XtraGrid.Columns.GridColumn colMessageTime;
        private DevExpress.XtraGrid.Columns.GridColumn colMessageType;
        private DevExpress.XtraGrid.Columns.GridColumn colUserName;
        private DevExpress.XtraGrid.Columns.GridColumn colObjectType;
        private DevExpress.XtraGrid.Columns.GridColumn colObjectID;
        private DevExpress.XtraGrid.Columns.GridColumn colObjectDescription;
        private DevExpress.XtraBars.Docking.DockManager dockManager1;
        private DevExpress.XtraBars.Docking.DockPanel dockPanel1;
        private DevExpress.XtraBars.Docking.ControlContainer dockPanel1_Container;
        private DevExpress.XtraBars.BarAndDockingController barAndDockingController1;
        private DevExpress.XtraTreeList.TreeList tlAuditMessageDetails;
        private DevExpress.XtraTreeList.Columns.TreeListColumn colProperty;
        private DevExpress.XtraTreeList.Columns.TreeListColumn colOldValue;
        private DevExpress.XtraTreeList.Columns.TreeListColumn colNewValue;
        private DevExpress.XtraEditors.PanelControl panelControl1;
        private DevExpress.XtraEditors.MemoEdit txtObjectDescription;
        private DevExpress.XtraEditors.LabelControl lblObjectDescription;
        private DevExpress.XtraEditors.LabelControl lblObjectId;
        private DevExpress.XtraEditors.TextEdit txtObjectId;
        private DevExpress.XtraEditors.LabelControl lblObjectType;
        private DevExpress.XtraEditors.TextEdit txtObjectType;
        private DevExpress.XtraEditors.LabelControl lblUserName;
        private DevExpress.XtraEditors.TextEdit txtUserName;
        private DevExpress.XtraEditors.LabelControl lblMessageType;
        private DevExpress.XtraEditors.TextEdit txtMessageType;
        private DevExpress.XtraEditors.LabelControl lblTime;
        private DevExpress.XtraEditors.TextEdit txtTime;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private DevExpress.XtraEditors.DateEdit deFilterDate;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraBars.Docking.AutoHideContainer hideContainerRight;
        private DevExpress.XtraEditors.PanelControl panelControl2;
        private System.Windows.Forms.ToolStripLabel linkRefresh;
    }
}