﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraLayout.Utils;
using Mandara.Business;
using Mandara.Business.Managers;
using Mandara.Entities;

namespace Mandara.AdmTool
{
    public partial class TradeScenarioEditForm : XtraForm
    {
        public TradeScenarioEditForm()
        {
            InitializeComponent();
            Activated += TradeScenarioEditForm_Activated;
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            InitSpreadTypeRadioGroup();
            InitStripCombos();
            InitProductLookup();


        }
        private void InitSpreadTypeRadioGroup()
        {
            rgTradeType.Properties.Items[0].Value = TradeType.Flat;
            rgTradeType.Properties.Items[1].Value = TradeType.Spread;
        }

        private List<Product> _products;
        private void InitProductLookup()
        {
            leProduct.Properties.ShowFooter = false;
            leProduct.Properties.ShowHeader = false;
            leProduct.Properties.Columns.Add(new DevExpress.XtraEditors.Controls.LookUpColumnInfo("Name"));
            leProduct.Properties.DisplayMember = "Name";
            _products = new ProductManager().GetProducts().OrderBy(p => p.Name).ToList();
            leProduct.Properties.DataSource = _products;
        }

        private void InitStripCombos()
        {
            InitStripCombo(cbStrip1);
            InitStripCombo(cbStrip2);
        }

        private void InitStripCombo(ComboBoxEdit cbStrip)
        {
            var strips = Enumerable.Range(0, 33).Select(i => new RelativeStrip {DateType = ProductDateType.MonthYear, DateIndex = i})
                .Concat(Enumerable.Range(0, 12).Select(i => new RelativeStrip {DateType = ProductDateType.Quarter, DateIndex = i}))
                .Concat(Enumerable.Range(0, 3).Select(i => new RelativeStrip {DateType = ProductDateType.Year, DateIndex = i}));

            cbStrip.Properties.Items.AddRange(strips.ToList());
        }

        void TradeScenarioEditForm_Activated(object sender, EventArgs e)
        {
            if (TradeScenario == null)
                return;

            FillFields(TradeScenario);
        }

        private void FillFields(TradeScenario tradeScenario)
        {
            rgTradeType.EditValue = tradeScenario.IsTimeSpread ? TradeType.Spread : TradeType.Flat;
            cbStrip1.EditValue = tradeScenario.Strip1;
            cbStrip2.EditValue = tradeScenario.Strip2 ?? cbStrip2.Properties.Items[0];
            leProduct.EditValue = tradeScenario.Product ?? _products.FirstOrDefault();
            teQuantity.Value = tradeScenario.Quantity;
        }

        public TradeScenario TradeScenario { get; set; }

        public event EventHandler TradeScenarioChanged;
        private void OnTradeScenarioChanged()
        {
            EventHandler handler = TradeScenarioChanged;
            if (handler != null) handler(this, EventArgs.Empty);
        }

        private void rgTradeType_SelectedIndexChanged(object sender, EventArgs e)
        {
            lciStrip2.Visibility = (TradeType)rgTradeType.EditValue == TradeType.Flat ? LayoutVisibility.Never : LayoutVisibility.Always;
        }

        private enum TradeType
        {
            Flat,
            Spread,
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            var changedTradeScenario = GetChagedTradeScenario();
            TradeScenarioManager.SaveTradeScenario(changedTradeScenario, MainForm.CreateAuditContext("Trade Scenario Edit"));
            TradeScenario = changedTradeScenario;
            OnTradeScenarioChanged();
            Close();
        }

        private TradeScenario GetChagedTradeScenario()
        {
            return new TradeScenario
                                    {
                                        TradeScenarioId = TradeScenario.TradeScenarioId,
                                        Strip1 = (RelativeStrip) cbStrip1.EditValue,
                                        Strip2 = (TradeType) rgTradeType.EditValue == TradeType.Spread
                                                     ? (RelativeStrip?) ((RelativeStrip) cbStrip2.EditValue)
                                                     : null,
                                        Product = (Product) leProduct.EditValue,
                                        Quantity = teQuantity.Value,
                                    };
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
