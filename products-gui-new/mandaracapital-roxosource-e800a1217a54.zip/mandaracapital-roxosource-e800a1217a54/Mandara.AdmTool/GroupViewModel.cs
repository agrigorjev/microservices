namespace Mandara.AdmTool
{
    public class GroupViewModel
    {
        public bool Administrator { get; set; }

        public bool SuperAdministrator { get; set; }
        
        public bool LaunchHAL { get; set; }
        
        public bool LaunchVHAL { get; set; }


        public bool RiskToolLaunchAccess { get; set; }

        public bool RiskToolWriteAccess { get; set; }

        public bool ProductToolLaunchAccess { get; set; }

        public bool ProductToolWriteAccess { get; set; }

        public bool ViewCumulativePnl { get; set; }

        public bool UseProductBreakdown { get; set; }

        public string GroupName { get; set; }

        public int GroupId { get; set; }


    }
}