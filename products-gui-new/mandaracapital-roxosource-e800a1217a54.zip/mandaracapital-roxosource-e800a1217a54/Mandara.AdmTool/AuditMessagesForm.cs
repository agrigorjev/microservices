﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using Mandara.Business.Authorization;
using Mandara.Business.Managers;
using Mandara.Entities;
using Mandara.Proto.Encoder;

namespace Mandara.AdmTool
{
    public partial class AuditMessagesForm : XtraForm
    {
        private List<AuditMessage> _auditMessages = new List<AuditMessage>();

        private Dictionary<AuditMessage, BindingList<AuditMessageDetails>> _detailsDict = new Dictionary<AuditMessage, BindingList<AuditMessageDetails>>();
        public AuditMessagesForm()
        {
            InitializeComponent();
        }

        private void AuditMessagesForm_Load(object sender, EventArgs e)
        {
            deFilterDate.EditValue = DateTime.Now.Date;
            deFilterDate.EditValueChanged -= DeFilterDateOnEditValueChanged;
            deFilterDate.EditValueChanged += DeFilterDateOnEditValueChanged;

            BindGrid();
        }

        private void DeFilterDateOnEditValueChanged(object sender, EventArgs eventArgs)
        {
            UpdateAuditMessages();
        }

        private void BindGrid()
        {
            UpdateAuditMessages();
        }

        private void UpdateAuditMessages()
        {
            deFilterDate.Enabled = false;

            AuthorizationManager manager = new AuthorizationManager();

            DateTime? filterDate = deFilterDate.EditValue as DateTime?;

            _auditMessages = manager.GetAuditMessages(filterDate);

            ClearAuditMessageDetailsPanel();
            gcAuditMessages.DataSource = _auditMessages;

            deFilterDate.Enabled = true;
        }

        private void gvAuditMessages_FocusedRowChanged(object sender, DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventArgs e)
        {
            ShowAuditMessageDetails();
        }

        private void ShowAuditMessageDetails()
        {
            var auditMessage = gvAuditMessages.GetRow(gvAuditMessages.FocusedRowHandle) as AuditMessage;

            if (auditMessage == null)
                return;
            else
            {
                ClearAuditMessageDetailsPanel();
            }

            txtTime.Text = auditMessage.MessageTime.ToString("G");
            txtMessageType.Text = auditMessage.MessageType;
            txtUserName.Text = auditMessage.UserNameOrRef;
            txtObjectType.Text = auditMessage.ObjectType;
            txtObjectId.Text = auditMessage.ObjectId != null ? auditMessage.ObjectId.ToString() : "";
            txtObjectDescription.Text = auditMessage.ObjectDescription;

            BindingList<AuditMessageDetails> details = null;
            if (_detailsDict.ContainsKey(auditMessage))
            {
                details = _detailsDict[auditMessage];
            }
            else
            {
                ProtoEncoder.DecodeDetailsAsGzipProto(auditMessage);

                details = new BindingList<AuditMessageDetails>();

                int id = 0;
                FillDetailsForTreeList(auditMessage.Details, ref id, details, auditMessage.Details?.Children?.Count > 0);

                _detailsDict.Add(auditMessage, details);
            }

            if (auditMessage.Details != null)
            {
                tlAuditMessageDetails.RootValue = auditMessage.Details.Id;
                tlAuditMessageDetails.DataSource = details;
                tlAuditMessageDetails.ExpandAll();
            }
            else
            {
                tlAuditMessageDetails.DataSource = null;
            }
        }

        private void ClearAuditMessageDetailsPanel()
        {
            txtTime.Text = string.Empty;
            txtMessageType.Text = string.Empty;
            txtUserName.Text = string.Empty;
            txtObjectType.Text = string.Empty;
            txtObjectId.Text = string.Empty;
            txtObjectDescription.Text = string.Empty;

            tlAuditMessageDetails.DataSource = null;
        }

        private void FillDetailsForTreeList(AuditMessageDetails details, ref int id, BindingList<AuditMessageDetails> bindingList, bool isRoot)
        {
            if (details == null)
                return;

            id++;
            details.Id = id;

            if (!isRoot)
                bindingList.Add(details);

            foreach (var child in details.Children)
            {
                child.ParentId = details.Id;
                FillDetailsForTreeList(child, ref id, bindingList, false);
            }
        }

        private void linkRefresh_Click(object sender, EventArgs e)
        {
            UpdateAuditMessages();
        }

        private void gcAuditMessages_DataSourceChanged(object sender, EventArgs e)
        {
            ShowAuditMessageDetails();
        }
    }
}