﻿using System.Collections.Generic;
using System.Configuration;
using Mandara.Business;
using Mandara.Business.Bus;
using Mandara.Business.Config.Client;
using Mandara.Business.Managers;

namespace Mandara.AdmTool
{
    using System;
    using System.Windows.Forms;
    using Mandara.Business.Authorization;
    using Mandara.Business.Bus.Messages;
    using System.Security.Principal;
    using Mandara.Entities;

    public partial class CheckPasswordForm : DevExpress.XtraEditors.XtraForm
    {
        public User AuthorizedUser { get; private set; }
        public string PasswordHash { get; set; }

        public CheckPasswordForm()
        {
            InitializeComponent();

            txtUsername.Text = WindowsIdentity.GetCurrent().Name;
        }

        private void CheckRights()
        {
            PasswordHash = Business.Client.Managers.AuthorizationManager.ComputeHash(txtPassword.Text);
            var user = AuthorizationService.AuthorizationManager.AuthorizeUser(txtUsername.Text, PasswordHash);

            if (user == null || user.UserId == -1)
            {
                AuthorizationNotGranted();
                return;
            }

            InformaticaHelper.ServerPrefix = AdmTool.GetNextServerPrefix();

            AuthorizedUser = user;
            DialogResult = DialogResult.OK;
            Close();
        }

        private void AuthorizationNotGranted()
        {
            MessageBox.Show(this, "Username or password are incorrect", "Authorization Error", MessageBoxButtons.OK,
                            MessageBoxIcon.Error);

            txtPassword.Text = string.Empty;

            AuditManager.WriteAuditMessage(null, null, "Admin tool", "Login", "Unauthorized Login Attempt", string.Format("Provided username: {0}", txtUsername.Text));
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }

        private void txt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                CheckRights();
            }
        }

        private void CheckPasswordForm_Load(object sender, EventArgs e)
        {
            txtPassword.Focus();

            ServersConfigurationSection serversSection =
                ConfigurationManager.GetSection("ServersSection") as ServersConfigurationSection;

            if (serversSection != null)
            {
                AdmTool.PrimaryServerPrefix = serversSection.DefaultPrefix;

                foreach (ServerConfigurationElement serverDef in serversSection.Servers)
                {
                    if (!serverDef.Prefix.Equals(AdmTool.PrimaryServerPrefix, StringComparison.InvariantCultureIgnoreCase))
                    {
                        AdmTool.FallbackServersPrefixes.Add(serverDef.Prefix);
                    }
                }
            }
        }

        private void btnAuthorize_Click(object sender, EventArgs e)
        {
            CheckRights();
        }
    }
}