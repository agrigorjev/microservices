﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraBars;
using DevExpress.XtraEditors;
using Mandara.AdmTool.Properties;
using Mandara.Business;
using Mandara.Business.Managers;
using Mandara.Entities;

namespace Mandara.AdmTool
{
    public partial class TradeScenariosForm : XtraForm
    {
        public TradeScenariosForm()
        {
            InitializeComponent();

            Activated += TradeScenariosForm_Activated;
            Deactivate += TradeScenariosForm_Deactivate;

            UpdateTradeScenarios();
        }

        private BindingList<TradeScenario> _tradeScenarios;
        private void UpdateTradeScenarios()
        {
            _tradeScenarios = new BindingList<TradeScenario>(TradeScenarioManager.GetTradeScenarios());
            gcTradeScenarios.DataSource = _tradeScenarios;
        }

        private MainForm _mainForm;
        private MainForm MainForm
        {
            get
            {
                if (_mainForm == null)
                    _mainForm = MdiParent as MainForm;

                return _mainForm;
            }
        }

        private void TradeScenariosForm_Activated(object sender, EventArgs e)
        {
            MainForm.btnTradeScenarioEdit.Visibility = BarItemVisibility.Always;
            MainForm.btnTradeScenarioEdit.ItemClick += btnTradeScenarioEdit_ItemClick;
            gcTradeScenarios.EmbeddedNavigator.ButtonClick += EmbeddedNavigator_ButtonClick;
        }

        private void TradeScenariosForm_Deactivate(object sender, EventArgs e)
        {
            if (MainForm == null)
                return;

            MainForm.btnTradeScenarioEdit.Visibility = BarItemVisibility.Never;
            MainForm.btnTradeScenarioEdit.ItemClick -= btnTradeScenarioEdit_ItemClick;
            gcTradeScenarios.EmbeddedNavigator.ButtonClick -= EmbeddedNavigator_ButtonClick;
        }

        private void btnTradeScenarioEdit_ItemClick(object sender, ItemClickEventArgs e)
        {
            ShowTradeScenarioEditForm(GetCurrentTradeScenario());
        }

        private TradeScenario GetCurrentTradeScenario()
        {
            return gvTradeScenarios.GetRow(gvTradeScenarios.FocusedRowHandle) as TradeScenario;
        }

        private void ShowTradeScenarioEditForm(TradeScenario tradeScenario)
        {
            var form = new TradeScenarioEditForm { TradeScenario = tradeScenario ?? new TradeScenario(), MdiParent = MainForm };
            //Add binding to refresh grid on user data changed
            form.TradeScenarioChanged += form_TradeScenarioChanged;
            form.Show();
            form.Activate();
        }

        private void form_TradeScenarioChanged(object sender, EventArgs e)
        {
            UpdateTradeScenarios();
        }

        void EmbeddedNavigator_ButtonClick(object sender, DevExpress.XtraEditors.NavigatorButtonClickEventArgs e)
        {
            e.Handled = true;
            if (e.Button.ButtonType == DevExpress.XtraEditors.NavigatorButtonType.Remove)
            {
                var currentTradeScenario = GetCurrentTradeScenario();
                if (MessageBox.Show(string.Format("Do you want to delete trade scenario {0}?", currentTradeScenario), Resources.MandaraAdministrationTool, MessageBoxButtons.YesNo)
                    == DialogResult.Yes)
                {
                    TradeScenarioManager.DeleteTradeScenario(currentTradeScenario, MainForm.CreateAuditContext("Trade Scenarios"));
                    UpdateTradeScenarios();
                }
            }
            else if (e.Button.ButtonType == DevExpress.XtraEditors.NavigatorButtonType.Append)
            {
                ShowTradeScenarioEditForm(new TradeScenario());
            }
        }
    }
}
