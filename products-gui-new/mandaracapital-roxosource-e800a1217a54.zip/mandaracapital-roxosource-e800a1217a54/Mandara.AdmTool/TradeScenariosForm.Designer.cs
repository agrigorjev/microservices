﻿namespace Mandara.AdmTool
{
    partial class TradeScenariosForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TradeScenariosForm));
            this.gcTradeScenarios = new DevExpress.XtraGrid.GridControl();
            this.gvTradeScenarios = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            ((System.ComponentModel.ISupportInitialize)(this.gcTradeScenarios)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvTradeScenarios)).BeginInit();
            this.SuspendLayout();
            // 
            // gcTradeScenarios
            // 
            this.gcTradeScenarios.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gcTradeScenarios.EmbeddedNavigator.Buttons.CancelEdit.Visible = false;
            this.gcTradeScenarios.EmbeddedNavigator.Buttons.Edit.Visible = false;
            this.gcTradeScenarios.EmbeddedNavigator.Buttons.EndEdit.Visible = false;
            this.gcTradeScenarios.EmbeddedNavigator.Buttons.First.Visible = false;
            this.gcTradeScenarios.EmbeddedNavigator.Buttons.Last.Visible = false;
            this.gcTradeScenarios.EmbeddedNavigator.Buttons.Next.Visible = false;
            this.gcTradeScenarios.EmbeddedNavigator.Buttons.NextPage.Visible = false;
            this.gcTradeScenarios.EmbeddedNavigator.Buttons.Prev.Visible = false;
            this.gcTradeScenarios.EmbeddedNavigator.Buttons.PrevPage.Visible = false;
            this.gcTradeScenarios.EmbeddedNavigator.TextLocation = DevExpress.XtraEditors.NavigatorButtonsTextLocation.None;
            this.gcTradeScenarios.Location = new System.Drawing.Point(0, 0);
            this.gcTradeScenarios.MainView = this.gvTradeScenarios;
            this.gcTradeScenarios.Name = "gcTradeScenarios";
            this.gcTradeScenarios.ShowOnlyPredefinedDetails = true;
            this.gcTradeScenarios.Size = new System.Drawing.Size(760, 500);
            this.gcTradeScenarios.TabIndex = 1;
            this.gcTradeScenarios.UseEmbeddedNavigator = true;
            this.gcTradeScenarios.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gvTradeScenarios});
            // 
            // gvTradeScenarios
            // 
            this.gvTradeScenarios.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn1,
            this.gridColumn2,
            this.gridColumn3});
            this.gvTradeScenarios.GridControl = this.gcTradeScenarios;
            this.gvTradeScenarios.Name = "gvTradeScenarios";
            this.gvTradeScenarios.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn1
            // 
            this.gridColumn1.Caption = "Strip";
            this.gridColumn1.FieldName = "RelativeStripName";
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.OptionsColumn.AllowEdit = false;
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 0;
            // 
            // gridColumn2
            // 
            this.gridColumn2.Caption = "Product";
            this.gridColumn2.FieldName = "Product";
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.OptionsColumn.AllowEdit = false;
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 1;
            // 
            // gridColumn3
            // 
            this.gridColumn3.Caption = "Quantity";
            this.gridColumn3.DisplayFormat.FormatString = "f2";
            this.gridColumn3.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn3.FieldName = "Quantity";
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.OptionsColumn.AllowEdit = false;
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 2;
            // 
            // TradeScenariosForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(760, 500);
            this.Controls.Add(this.gcTradeScenarios);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "TradeScenariosForm";
            this.Text = "Trade Scenarios";
            ((System.ComponentModel.ISupportInitialize)(this.gcTradeScenarios)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gvTradeScenarios)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraGrid.GridControl gcTradeScenarios;
        private DevExpress.XtraGrid.Views.Grid.GridView gvTradeScenarios;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;

    }
}