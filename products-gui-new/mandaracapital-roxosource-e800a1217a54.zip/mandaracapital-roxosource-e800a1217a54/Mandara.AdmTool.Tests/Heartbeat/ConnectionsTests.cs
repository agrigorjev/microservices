﻿using System;
using System.Collections.Generic;
using System.Linq;
using Mandara.AdmTool.Heartbeat;
using Mandara.Business;
using Mandara.Business.Bus.Messages;
using Mandara.Date.Time;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Mandara.AdmTool.Tests.Heartbeat
{
    [TestClass()]
    public class ConnectionsTests
    {
        [TestMethod()]
        public void TestConnections_ServersAndTimeSpansFromConfig()
        {
            Connections clientsAndServers = new Connections();

            Assert.AreEqual(3, clientsAndServers.ServerConnections.Count);
            Assert.AreEqual(Connections.DefaultOnlinePeriodSeconds, clientsAndServers.OnlinePeriodSeconds);
            Assert.AreEqual(Connections.DefaultLostHeartbeatSeconds, clientsAndServers.LostHeartbeatPeriodSeconds);
        }

        [TestMethod()]
        public void TestUpdateConnections_ServerHeartbeat_ServerMarkedOnline()
        {
            Connections clientsAndServers = new Connections();
            List<ServerConnectionModel> servers = clientsAndServers.ServerConnections.Values.ToList();

            servers.ForEach(server => Assert.AreEqual(ConnectionState.Offline, server.ServerStatus));

            string prefixOfConnectedServer = servers.Skip(1).First().ServerPrefix;
            ServerHeartbeat heartbeat = new ServerHeartbeat(
                new HeartbeatMessage(1, 1, 1)
                {
                    ServerPrefix = prefixOfConnectedServer,
                });

            clientsAndServers.UpdateConnections(null, heartbeat, InternalTime.UtcNow());

            servers.ForEach(
                server => Assert.AreEqual(
                    prefixOfConnectedServer == server.ServerPrefix ? ConnectionState.Online : ConnectionState.Offline,
                    server.ServerStatus));
        }

        [TestMethod()]
        public void TestUpdateConnections_ServerHeartbeatDelayed_ServerMarkedWithLostHeartbeat()
        {
            Connections clientsAndServers = new Connections();
            List<ServerConnectionModel> servers = clientsAndServers.ServerConnections.Values.ToList();
            DateTime fakeNow = InternalTime.UtcNow()
                                           .AddSeconds(Connections.DefaultOnlinePeriodSeconds.TotalSeconds + 1);
            string prefixOfConnectedServer = servers.First().ServerPrefix;
            ServerHeartbeat heartbeat = new ServerHeartbeat(
                new HeartbeatMessage(1, 1, 1)
                {
                    ServerPrefix = prefixOfConnectedServer,
                });

            clientsAndServers.UpdateConnections(null, heartbeat, InternalTime.UtcNow());
            clientsAndServers.UpdateConnections(null, null, fakeNow);

            servers.ForEach(
                server => Assert.AreEqual(
                    prefixOfConnectedServer == server.ServerPrefix
                        ? ConnectionState.LostHeartbeat
                        : ConnectionState.Offline,
                    server.ServerStatus));
        }

        [TestMethod()]
        public void TestUpdateConnections_ServerHeartbeatDelayedAndRestored_ServerMarkedOnline()
        {
            Connections clientsAndServers = new Connections();
            List<ServerConnectionModel> servers = clientsAndServers.ServerConnections.Values.ToList();
            DateTime fakeNow = InternalTime.UtcNow()
                                           .AddSeconds(Connections.DefaultOnlinePeriodSeconds.TotalSeconds + 1);
            string prefixOfConnectedServer = servers.First().ServerPrefix;
            ServerHeartbeat heartbeat = new ServerHeartbeat(
                new HeartbeatMessage(1, 1, 1)
                {
                    ServerPrefix = prefixOfConnectedServer,
                });

            clientsAndServers.UpdateConnections(null, heartbeat, InternalTime.UtcNow());
            clientsAndServers.UpdateConnections(null, null, fakeNow);
            clientsAndServers.UpdateConnections(null, heartbeat, fakeNow.AddSeconds(1));

            servers.ForEach(
                server => Assert.AreEqual(
                    prefixOfConnectedServer == server.ServerPrefix ? ConnectionState.Online : ConnectionState.Offline,
                    server.ServerStatus));
        }

        [TestMethod()]
        public void TestUpdateConnections_ServerHeartbeatLost_ServerMarkedOffline()
        {
            Connections clientsAndServers = new Connections();
            List<ServerConnectionModel> servers = clientsAndServers.ServerConnections.Values.ToList();
            DateTime fakeNow = InternalTime.UtcNow()
                                           .AddSeconds(Connections.DefaultLostHeartbeatSeconds.TotalSeconds + 1);
            string prefixOfConnectedServer = servers.First().ServerPrefix;
            ServerHeartbeat heartbeat = new ServerHeartbeat(
                new HeartbeatMessage(1, 1, 1)
                {
                    ServerPrefix = prefixOfConnectedServer,
                });

            clientsAndServers.UpdateConnections(null, heartbeat, InternalTime.UtcNow());
            clientsAndServers.UpdateConnections(null, null, fakeNow);

            servers.ForEach(
                server => Assert.AreEqual(ConnectionState.Offline, server.ServerStatus));
        }

        [TestMethod()]
        public void TestUpdateConnections_ClientHeartbeat_ClientMarkedOnline()
        {
            Connections clientsAndServers = new Connections();
            string prefixOfConnectedServer = clientsAndServers.ServerConnections.Values.First().ServerPrefix;

            Assert.AreEqual(0, clientsAndServers.UserConnections.Count);

            AddClient(prefixOfConnectedServer, clientsAndServers);

            Assert.AreEqual(1, clientsAndServers.UserConnections.Count);
        }

        private static ClientHeartbeatMessage AddClient(string prefixOfConnectedServer, Connections clientsAndServers)
        {
            Guid client = Guid.NewGuid();

            ClientHeartbeatMessage heartbeat = new ClientHeartbeatMessage()
            {
                ServerPrefix = prefixOfConnectedServer,
                ClientGuid = client,
                ClientType = ClientType.IrmClient,
                LastHeartbeatUtc = InternalTime.UtcNow(),
            };

            clientsAndServers.UpdateConnections(heartbeat, null, InternalTime.UtcNow());
            return heartbeat;
        }

        [TestMethod()]
        public void TestUpdateConnections_ClientHeartbeatLost_ClientRemoved()
        {
            Connections clientsAndServers = new Connections();
            string prefixOfConnectedServer = clientsAndServers.ServerConnections.Values.First().ServerPrefix;
            int numClients = 2;

            ClientHeartbeatMessage remainingClient = Enumerable.Range(0, numClients)
                                                               .Select(
                                                                   _ => AddClient(
                                                                       prefixOfConnectedServer,
                                                                       clientsAndServers))
                                                               .Last();

            Assert.AreEqual(numClients, clientsAndServers.UserConnections.Count);

            remainingClient.LastHeartbeatUtc = InternalTime.UtcNow()
                                                           .AddSeconds(
                                                               Connections.DefaultLostHeartbeatSeconds.TotalSeconds
                                                               - 1);

            clientsAndServers.UpdateConnections(remainingClient, null, remainingClient.LastHeartbeatUtc.AddSeconds(2));

            Assert.AreEqual(1, clientsAndServers.UserConnections.Count);
        }
    }
}