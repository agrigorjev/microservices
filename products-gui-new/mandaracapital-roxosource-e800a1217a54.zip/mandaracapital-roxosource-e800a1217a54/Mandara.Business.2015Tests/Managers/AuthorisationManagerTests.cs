﻿using Mandara.Business.Services.Users;
using Mandara.Entities;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Optional;

namespace Mandara.Business.Managers
{
    [TestClass]
    public class AuthorisationManagerTests
    {
        private const string UserName = "DummyUser";
        private const string MasterPassword = "1234";
        private static readonly User DefaultUser = new User()
        {
            UserName = UserName, UserId = 1, MasterPasswordHash = MasterPassword
        };

        [TestMethod]
        public void TestAuthorizeUser_UserWithMatchingPassword_UserAuthorised()
        {
            Mock<IUsersRepository> users = new Mock<IUsersRepository>();

            users.Setup(repo => repo.TryGetUser(It.IsAny<string>())).Returns(() => Option.Some(DefaultUser));

            AuthorizationManager authoriser = new AuthorizationManager(users.Object);

            Assert.AreEqual(DefaultUser, authoriser.AuthorizeUser(UserName, MasterPassword));
        }

        [TestMethod]
        public void TestAuthorizeUser_PasswordMismatch_UserNotAuthorised()
        {
            Mock<IUsersRepository> users = new Mock<IUsersRepository>();

            users.Setup(repo => repo.TryGetUser(It.IsAny<string>())).Returns(() => Option.Some(DefaultUser));

            AuthorizationManager authoriser = new AuthorizationManager(users.Object);

            Assert.IsNull(authoriser.AuthorizeUser(UserName, $"{MasterPassword}Wrong"));
        }

        [TestMethod]
        public void TestAuthorizeUser_NoPasswordProvided_UserAuthorised()
        {
            Mock<IUsersRepository> users = new Mock<IUsersRepository>();

            users.Setup(repo => repo.TryGetUser(It.IsAny<string>())).Returns(() => Option.Some(DefaultUser));

            AuthorizationManager authoriser = new AuthorizationManager(users.Object);

            Assert.AreEqual(DefaultUser, authoriser.AuthorizeUser(UserName, null));
        }
    }
}