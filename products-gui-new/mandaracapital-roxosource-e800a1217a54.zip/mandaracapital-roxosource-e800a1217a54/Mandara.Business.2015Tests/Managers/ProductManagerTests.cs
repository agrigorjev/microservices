﻿using Mandara.Entities;
using Mandara.Entities.Enums;
using Mandara.Extensions.Nullable;
using Mandara.Test.EntityBuilders;
using Mandara.Test.Extensions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using Mandara.Business.Managers.Calendars;

namespace Mandara.Business.Managers
{
    [TestClass]
    public class ProductManagerTests
    {
        private const int CalendarYearToUpdate = 2015;
        private const int CalendarMonthToUpdate = 3;
        private readonly DateTime[] _holidayDates =
            {
                new DateTime(2014, 3, 1),
                new DateTime(2015, 2, 16),
                new DateTime(2015, 3, 23),
                new DateTime(2015, 3, 24),
                new DateTime(2015, 3, 25)
            };
        private readonly DateTime[] _holidayDatesToUpdate =
            {
                new DateTime(CalendarMonthToUpdate, CalendarMonthToUpdate, 9),
                new DateTime(CalendarMonthToUpdate, CalendarMonthToUpdate, 2)
            };

        private ProductManager _productManager;
        private StockCalendar _holidayTestCalendar, _emptyTestCalendar;
        private Product _product1, _product2;
        private readonly OfficialProductBuilder _officialProductBuilder = new OfficialProductBuilder();
        private readonly ProductBuilder _productBuilder = new ProductBuilder();

        [TestInitialize]
        public void CreateProductManager()
        {
            _productManager = new ProductManager();

            try
            {
                InsertTestCalendars();
                InsertTestProducts();
            }
            catch (Exception)
            {
                CleanUpTestData();
                throw;
            }
        }

        [TestCleanup]
        public void CleanUpTestData()
        {
            DeleteTestProducts();
            DeleteTestCalendars();
        }

        private void DeleteTestProducts()
        {
            List<Product> testProducts =
                new List<Product>() { _product1, _product2 }.Where(product => product != null).ToList();
            List<int> testProductsToDelete = testProducts.Select(prod => prod.ProductId).ToList();
            List<int> officialProdsToDelete = testProducts.Select(prod => prod.OfficialProductId).ToList();

            using (MandaraEntities dbContext = CreateMandaraProductsDbContext())
            {
                dbContext.DeleteEntity(
                    dbContext.Products,
                    (product) => testProductsToDelete.Contains(product.ProductId));
                dbContext.DeleteEntity(
                    dbContext.OfficialProducts,
                    (offProd) => officialProdsToDelete.Contains(offProd.OfficialProductId));
                dbContext.DeleteEntity(
                    dbContext.Exchanges,
                    (exch) => exch.ExchangeId == _productBuilder.BuilderExchange.ExchangeId);
                dbContext.SaveChanges();
            }
        }

        private static MandaraEntities CreateMandaraProductsDbContext()
        {
            return new MandaraEntities(MandaraEntities.DefaultConnStrName, nameof(ProductManagerTests));
        }

        private void DeleteTestCalendars()
        {
            using (MandaraEntities dbContext = CreateMandaraProductsDbContext())
            {
                dbContext.DeleteEntity(
                    dbContext.CalendarHolidays,
                    (calHoliday) => calHoliday.CalendarId == _holidayTestCalendar.CalendarId);
                dbContext.DeleteEntity(
                    dbContext.StockCalendars,
                    (cal) => cal.CalendarId == _holidayTestCalendar.CalendarId);
                dbContext.DeleteEntity(
                    dbContext.StockCalendars,
                    (cal) => cal.CalendarId == _emptyTestCalendar.CalendarId);
                dbContext.SaveChanges();
            }
        }

        private void InsertTestCalendars()
        {
            using (MandaraEntities dbContext = CreateMandaraProductsDbContext())
            {

                _holidayTestCalendar = new StockCalendar()
                {
                    CalendarType = CalendarType.Holidays
                };

                _emptyTestCalendar = new StockCalendar()
                {
                    CalendarType = CalendarType.Expiry
                };

                dbContext.StockCalendars.Add(_holidayTestCalendar);
                dbContext.StockCalendars.Add(_emptyTestCalendar);
                for (int i = 0; i < _holidayDates.Length; i++)
                {
                    CalendarHoliday holiday = new CalendarHoliday()
                    {
                        StockCalendar = _holidayTestCalendar,
                        HolidayDate = _holidayDates[i]
                    };
                    dbContext.CalendarHolidays.Add(holiday);
                }

                dbContext.SaveChanges();
            }
        }

        [TestMethod]
        public void SaveCalendarHolidays()
        {
            StockCalendar calendarToUpdate = new StockCalendar()
            {
                CalendarId = _holidayTestCalendar.CalendarId,
                CalendarType = CalendarType.Holidays
            };

            calendarToUpdate.Holidays = _holidayDatesToUpdate.Select(h => new CalendarHoliday()
            {
                StockCalendar = calendarToUpdate,
                HolidayDate = h
            }).ToList();

            _productManager.UpdateHolidayCalendars(
                new CalendarChanges<NewHolidayCalendar>(
                    new List<StockCalendar>() { calendarToUpdate },
                    new List<NewHolidayCalendar>(),
                    new List<int>()),
                2015,
                3,
                null);

            using (MandaraEntities dbContext = CreateMandaraProductsDbContext())
            {
                IEnumerable<DateTime> holidays = dbContext.CalendarHolidays
                    .Where(h => h.CalendarId == _holidayTestCalendar.CalendarId)
                    .Select(h => h.HolidayDate)
                    .ToList();
                ISet<DateTime> holidaysSet = new HashSet<DateTime>(holidays);

                Assert.AreEqual(holidays.Count(), holidaysSet.Count);

                foreach (DateTime holiday in _holidayDates)
                {
                    if (holiday.Year != CalendarYearToUpdate || holiday.Month != CalendarMonthToUpdate)
                    {
                        Assert.IsTrue(holidaysSet.Contains(holiday));
                    }
                }

                foreach (DateTime holiday in _holidayDatesToUpdate)
                {
                    Assert.IsTrue(holidaysSet.Contains(holiday));
                }
            }
        }

        private void InsertTestProducts()
        {
            using (MandaraEntities dbContext = CreateMandaraProductsDbContext())
            {
                OfficialProduct prodMgrOfficialProd = _officialProductBuilder.BuildOfficialProductForDatabase(
                    "ProdManTest",
                    dbContext.Currencies.First().CurrencyId,
                    "pmt");
                _product1 = _productBuilder.BuildForDbContext(
                    ProductType.Futures,
                    "ProdManTest Product1",
                    prodMgrOfficialProd);
                _product2 = _productBuilder.BuildForDbContext(
                    ProductType.Futures,
                    "ProdManTest Product2",
                    prodMgrOfficialProd);

                dbContext.Products.Add(_product1);
                dbContext.Products.Add(_product2);
                dbContext.Exchanges.Add(_productBuilder.BuilderExchange);
                dbContext.OfficialProducts.Add(prodMgrOfficialProd);

                StockCalendar emptyTestCalendarInContext = dbContext.StockCalendars
                    .First(c => c.CalendarId == _emptyTestCalendar.CalendarId);
                StockCalendar holidayCalendarInContext = dbContext.StockCalendars
                    .First(c => c.CalendarId == _holidayTestCalendar.CalendarId);

                dbContext.Entry(emptyTestCalendarInContext).State = EntityState.Unchanged;
                dbContext.Entry(holidayCalendarInContext).State = EntityState.Unchanged;

                _product1.HolidaysCalendar = holidayCalendarInContext;
                _product1.ExpiryCalendar = emptyTestCalendarInContext;
                _product2.ExpiryCalendar = emptyTestCalendarInContext;
                _product1.OfficialProduct = prodMgrOfficialProd;
                _product2.OfficialProduct = prodMgrOfficialProd;
                _product1.Exchange = _productBuilder.BuilderExchange;
                _product2.Exchange = _productBuilder.BuilderExchange;

                dbContext.SaveChanges();
            }
        }

        [TestMethod]
        public void SetIsChangedForRelatedProducts_WhenHolidayCalendarChanged()
        {
            using (MandaraEntities dbContext = CreateMandaraProductsDbContext())
            {
                ProductManager.SetIsChangedForRelatedProducts(dbContext, _holidayTestCalendar.CalendarId);
                Product updatedPoduct = dbContext.Products.FirstOrDefault(p => p.ProductId == _product1.ProductId);
                Product notUpdatedPoduct = dbContext.Products.FirstOrDefault(p => p.ProductId == _product2.ProductId);

                Assert.IsTrue((updatedPoduct?.IsChanged).True());
                Assert.IsFalse((notUpdatedPoduct?.IsChanged).True());
            }
        }

        [TestMethod]
        public void SetIsChangedForRelatedProducts_WhenExpiryCalendarChanged()
        {
            using (MandaraEntities dbContext = CreateMandaraProductsDbContext())
            {
                ProductManager.SetIsChangedForRelatedProducts(dbContext, _emptyTestCalendar.CalendarId);

                IEnumerable<Product> updatedPoducts =
                    dbContext.Products.Where(
                        product => product.ProductId == _product1.ProductId || product.ProductId == _product2.ProductId);

                foreach (Product product in updatedPoducts)
                {
                    Assert.IsTrue(product.IsChanged);
                }
            }
        }
    }
}
