using Mandara.Business.DataInterface;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;

namespace Mandara.Business.Data.Tests
{
    [TestClass]
    public class SnapshotFxPricesProviderTests : LiveFxPricesProviderTests
    {
        private readonly DateTime _validSnapshotDatetime = new DateTime(2016, 06, 03, 15, 00, 00);
        private DateTime _invalidSnapshotDatetime;

        protected override void GetFxPricesProvider()
        {
            SetUpFxPricesDataProvider();

            SnapshotFxPricesProvider snapshotFxPricesProvider =
                new SnapshotFxPricesProvider(_fxPricesDataProviderMock.Object);
            snapshotFxPricesProvider.UpdatePrices(_validSnapshotDatetime);

            _fxPricesProvider = snapshotFxPricesProvider;
        }

        protected override void SetUpFxPricesDataProvider()
        {
            _invalidSnapshotDatetime = _validSnapshotDatetime.AddHours(1);
            _fxPricesDataProviderMock = new Mock<IFxPricesDataProvider>();
            _fxPricesDataProviderMock.Setup(x => x.GetSnapshotPrices(_validSnapshotDatetime)).Returns(_validPricesDict);
            _fxPricesDataProviderMock.Setup(
                x => x.GetSnapshotPrices(It.Is<DateTime>(dt => dt != _validSnapshotDatetime)))
                                     .Returns(new Dictionary<string, decimal>());
            SetUpMockCurrencyProvider();
            _fxPricesDataProviderMock.Setup(provider => provider.CurrencyProvider)
                                     .Returns(_mockCurrencyProvider.CurrencyProvider);
        }

        [TestMethod]
        public new void TryGetPrice_ValueDateWithoutPrices_PriceNotReturned()
        {
            SnapshotFxPricesProvider snapshotFxPricesProvider =
                new SnapshotFxPricesProvider(_fxPricesDataProviderMock.Object);
            snapshotFxPricesProvider.UpdatePrices(_invalidSnapshotDatetime);

            _fxPricesDataProviderMock.Verify(
                x => x.GetSnapshotPrices(It.Is<DateTime>(dt => dt != _validSnapshotDatetime)),
                Times.Once());
        }
    }
}