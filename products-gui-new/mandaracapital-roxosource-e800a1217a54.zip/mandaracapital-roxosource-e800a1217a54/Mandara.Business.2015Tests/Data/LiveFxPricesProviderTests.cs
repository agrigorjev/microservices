using Mandara.Business.DataInterface;
using Mandara.Date.Time;
using Mandara.Entities;
using Mandara.Extensions.Option;
using Mandara.Test.Mocks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;

namespace Mandara.Business.Data.Tests
{
    [TestClass]
    public class LiveFxPricesProviderTests
    {
        protected Mock<IFxPricesDataProvider> _fxPricesDataProviderMock;
        protected MockCurrencyProvider _mockCurrencyProvider;
        protected IFxPricesProvider _fxPricesProvider;
        protected string _validFxPriceKey;
        protected decimal _validPriceUsdGbp;
        protected Dictionary<string, decimal> _validPricesDict;
        protected Currency _usdCurrency;
        protected Currency _gbpCurrency;
        private Currency _eurCurrency;
        private CurrencyPair _usdGbpCurrencyPair;
        protected DateTime _validValueDate;
        protected DateTime _invalidValueDate;

        [TestInitialize]
        public void TestInitialise()
        {
            _validValueDate = SystemTime.Today();
            _invalidValueDate = _validValueDate.AddDays(1);
            _usdCurrency = new Currency { CurrencyId = 1, IsoName = "USD" };
            _gbpCurrency = new Currency { CurrencyId = 2, IsoName = "GBP" };
            _eurCurrency = new Currency { CurrencyId = 3, IsoName = "EUR" };
            _usdGbpCurrencyPair = new CurrencyPair(1, _usdCurrency, _gbpCurrency);

            _validFxPriceKey = FxPriceKey.Create(_validValueDate, _usdGbpCurrencyPair);
            _validPriceUsdGbp = 100.1234M;

            _validPricesDict = new Dictionary<string, decimal>
            {
                { _validFxPriceKey, _validPriceUsdGbp }
            };

            GetFxPricesProvider();
        }

        protected virtual void GetFxPricesProvider()
        {
            SetUpFxPricesDataProvider();
            _fxPricesProvider = new LiveFxPricesProvider(_fxPricesDataProviderMock.Object, null);
        }

        protected virtual void SetUpFxPricesDataProvider()
        {
            _fxPricesDataProviderMock = new Mock<IFxPricesDataProvider>();
            _fxPricesDataProviderMock.Setup(x => x.GetLivePrices()).Returns(_validPricesDict);
            SetUpMockCurrencyProvider();
            _fxPricesDataProviderMock.Setup(provider => provider.CurrencyProvider)
                                     .Returns(_mockCurrencyProvider.CurrencyProvider);
        }

        protected virtual MockCurrencyProvider SetUpMockCurrencyProvider()
        {
            _mockCurrencyProvider = new MockCurrencyProvider();
            _mockCurrencyProvider.SetUpCurrencies(new List<Currency>() { _usdCurrency, _gbpCurrency, _eurCurrency });
            _mockCurrencyProvider.SetUpCurrencyPairs(new List<CurrencyPair>() { _usdGbpCurrencyPair });
            return _mockCurrencyProvider;
        }

        [TestMethod]
        public void TryGetPrice_CurrencyOrderUsdGbp_UsdGbpPriceReturned()
        {
            TryGetResult<decimal> price = _fxPricesProvider.TryGetPrice(_validValueDate, _usdCurrency, _gbpCurrency);

            Assert.IsTrue(price.HasValue);
            Assert.AreEqual(_validPriceUsdGbp, price.Value);
        }

        [TestMethod]
        public void TryGetPrice_CurrencyOrderGbpUsd_OneOverUsdGbpPriceReturned()
        {
            TryGetResult<decimal> price = _fxPricesProvider.TryGetPrice(_validValueDate, _gbpCurrency, _usdCurrency);

            Assert.IsTrue(price.HasValue);
            Assert.AreEqual(1 / _validPriceUsdGbp, price.Value);
        }

        [TestMethod]
        public void TryGetPrice_ValueDateWithoutPrices_PriceNotReturned()
        {
            TryGetResult<decimal> price = _fxPricesProvider.TryGetPrice(_invalidValueDate, _gbpCurrency, _usdCurrency);

            Assert.IsFalse(price.HasValue);
        }

        [TestMethod]
        public void TryGetPrice_ValueDateWithPricesButUsdEurPriceNotThere_PriceNotReturned()
        {
            TryGetResult<decimal> price = _fxPricesProvider.TryGetPrice(_validValueDate, _usdCurrency, _eurCurrency);

            Assert.IsFalse(price.HasValue);
        }
    }
}