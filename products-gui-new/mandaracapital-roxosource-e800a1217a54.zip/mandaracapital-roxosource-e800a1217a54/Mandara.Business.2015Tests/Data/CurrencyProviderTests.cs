﻿using Mandara.Business.DataInterface;
using Mandara.Entities;
using Mandara.Extensions.Option;
using Mandara.Test.Extensions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Mandara.Business.Data
{
    [TestClass()]
    public class CurrencyProviderTests
    {
        private Currency _currencyAddedBeforeUpdate;
        private Currency _currencyAddedAfterUpdate;
        private List<Currency> _savedCurrencies = new List<Currency>();
        private ICurrencyProvider _CurrencyProvider = new CurrencyProvider();

        [TestInitialize]
        public void PrepareTest()
        {
            try
            {
                InitCurrencies();
                _CurrencyProvider.Update(Enumerable.Empty<int>());
            }
            catch (Exception)
            {
                CleanUpCurrencies();
                throw;
            }
        }

        private void InitCurrencies()
        {
            using (MandaraEntities dbContext = CreateMandaraProductsDbContext())
            {
                _currencyAddedBeforeUpdate = new Currency()
                {
                    IsoName = "CPB"
                };

                dbContext.Currencies.Add(_currencyAddedBeforeUpdate);
                dbContext.SaveChanges();
                _savedCurrencies.Add(_currencyAddedBeforeUpdate);
            }

            _currencyAddedAfterUpdate = new Currency()
            {
                IsoName = "CPA"
            };
        }

        private static MandaraEntities CreateMandaraProductsDbContext()
        {
            return new MandaraEntities(MandaraEntities.DefaultConnStrName, nameof(CurrencyProviderTests));
        }

        [TestCleanup]
        public void CleanUpCurrencies()
        {
            using (MandaraEntities dbContext = CreateMandaraProductsDbContext())
            {
                List<int> addedCurrencyIds = _savedCurrencies.Select(curr => curr.CurrencyId).ToList();

                dbContext.DeleteEntity(dbContext.Currencies, (curr) => addedCurrencyIds.Contains(curr.CurrencyId));
                dbContext.SaveChanges();
            }
        }

        [TestMethod]
        public void TestTryGetCurrency_CurrencyInDbBeforeUpdate_CurrencyReturned()
        {
            SaveCurrencyAfterUpdate();

            TryGetResult<Currency> foundCurrency =
                _CurrencyProvider.TryGetCurrency(_currencyAddedBeforeUpdate.CurrencyId);

            Assert.IsTrue(foundCurrency.HasValue);
            Assert.AreEqual(_currencyAddedBeforeUpdate, foundCurrency.Value);
        }

        private void SaveCurrencyAfterUpdate()
        {
            using (MandaraEntities dbContext = CreateMandaraProductsDbContext())
            {
                dbContext.Currencies.Add(_currencyAddedAfterUpdate);
                dbContext.SaveChanges();
                _savedCurrencies.Add(_currencyAddedAfterUpdate);
            }
        }

        [TestMethod]
        public void TestTryGetCurrency_WithDbContext_UpdateAfterNewCurrencySaved_CurrencyReturned()
        {
            SaveCurrencyAfterUpdate();

            using (MandaraEntities dbContext = CreateMandaraProductsDbContext())
            {
                TryGetResult<Currency> foundCurrency =
                    _CurrencyProvider.TryGetCurrency(_currencyAddedAfterUpdate.CurrencyId, dbContext);

                Assert.IsTrue(foundCurrency.HasValue);
                Assert.AreEqual(_currencyAddedAfterUpdate, foundCurrency.Value);
            }
        }
    }
}