using Mandara.Business.Dates;
using Mandara.Date;
using Mandara.Date.Time;
using Mandara.Entities;
using Mandara.Extensions.Collections;
using Mandara.Extensions.Option;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using Mandara.Test.DateAndTime;

namespace Mandara.Business.Data.Tests
{
    [TestClass]
    public class FxTradesInMemoryCacheTests
    {
        private int _nonexistingFxTradeId = -2;
        private int _validFxTradeId = 3;
        private decimal _validRate = 100M;
        private List<FxTrade> _validFxTrades;
        private Mock<IEndOfDayDateTimeProvider> _endOfDayDateTimes;

        private static readonly DateTime _today = new DateTime(2016, 09, 28);
        private static readonly DateTime _yesterday = _today.AddDays(-1);
        private FxTrade _liveFxTrade;
        private List<int> _skippedIds = new List<int>();

        [TestInitialize]
        public void TestInitialize()
        {
            _endOfDayDateTimes = new Mock<IEndOfDayDateTimeProvider>();

            _validFxTrades = new List<FxTrade>
            {
                new FxTrade
                {
                    FxTradeId = _validFxTradeId * 1,
                    Rate = _validRate * 1M,
                    TradeCapture = GetValidTradeCapture()
                },
                new FxTrade
                {
                    FxTradeId = _validFxTradeId * 2,
                    Rate = _validRate * 2M,
                    TradeCapture = GetValidTradeCapture()
                },
                new FxTrade
                {
                    FxTradeId = _validFxTradeId * 3,
                    Rate = _validRate * 3M,
                    TradeCapture = GetValidTradeCapture()
                },
            };

            _validFxTrades[0].TradeCapture.UtcTransactTime = _yesterday.AddHours(10);
            _validFxTrades[1].TradeCapture.UtcTransactTime = _yesterday.AddHours(-10);
            _validFxTrades[2].TradeCapture.UtcTransactTime = _today.AddHours(10);

            _liveFxTrade = _validFxTrades[0];

            SystemTimeForTest.SupercedeNow(() => _today.AddHours(12));
        }

        [TestCleanup]
        public void CleanUpAfterTest()
        {
            SystemTimeForTest.Reset();
        }

        private TradeCapture GetValidTradeCapture()
        {
            return new TradeCapture
            {
                SecurityDefinition = new SecurityDefinition { Product = new Product { Exchange = new Exchange() } }
            };
        }

        private FxTradesInMemoryCache GetFxTradesCache()
        {
            FxTradesInMemoryCache fxTradesCache = new FxTradesInMemoryCache(_endOfDayDateTimes.Object);

            fxTradesCache.AddOrUpdateEntities(_validFxTrades);
            return fxTradesCache;
        }

        [TestMethod]
        public void TestGetLiveFxTrades_LiveFxTradesAreInCache_LiveFxTradesReturned()
        {
            _endOfDayDateTimes.Setup(x => x.GetUtcDateRangeAccordingToEodTimes(It.IsAny<DateRange>()))
                                        .Returns(new DateRange(_yesterday, _today));

            FxTradesInMemoryCache entityInMemoryCache = GetFxTradesCache();

            IEnumerable<FxTrade> liveFxTrades = entityInMemoryCache.GetLiveFxTrades();

            Assert.IsNotNull(liveFxTrades);
            Assert.AreEqual(1, liveFxTrades.Count());
            Assert.AreEqual(_liveFxTrade, liveFxTrades.ElementAt(0));
        }

        [TestMethod]
        public void TestGetAll_NoFxTradesInCache_EmptyListReturned()
        {
            FxTradesInMemoryCache entityInMemoryCache = new FxTradesInMemoryCache(_endOfDayDateTimes.Object);
            IEnumerable<FxTrade> fxTradesFromCache = entityInMemoryCache.ReadLastFxTrades(0, 0, _skippedIds, Int32.MaxValue).Trades;

            Assert.IsNotNull(fxTradesFromCache);
            Assert.AreEqual(0, fxTradesFromCache.Count());
        }

        [TestMethod]
        public void TestGetAll_FxTradesInCache_AllFxTradesReturned()
        {
            FxTradesInMemoryCache entityInMemoryCache = GetFxTradesCache();
            IEnumerable<FxTrade> fxTradesFromCache = entityInMemoryCache.ReadLastFxTrades(0, 0, _skippedIds, Int32.MaxValue).Trades;

            Assert.IsNotNull(fxTradesFromCache);
            Assert.AreEqual(_validFxTrades.Count, fxTradesFromCache.Count());

            fxTradesFromCache.ForEachWithIndex(
                (index, fxTrade) =>
                {
                    Assert.AreEqual(_validFxTrades[index], fxTrade);
                });
        }

        [TestMethod]
        public void TestTryGetById_GetExistingId_FxTradeReturned()
        {
            FxTradesInMemoryCache entityInMemoryCache = GetFxTradesCache();
            TryGetResult<FxTrade> fxTradeFromCache = entityInMemoryCache.TryGetById(_validFxTradeId);

            Assert.IsTrue(fxTradeFromCache.HasValue);
            Assert.IsNotNull(fxTradeFromCache);
            Assert.AreEqual(_validFxTrades[0], fxTradeFromCache.Value);
            Assert.AreEqual(_validFxTradeId, fxTradeFromCache.Value.FxTradeId);
            Assert.AreEqual(_validRate, fxTradeFromCache.Value.Rate);
        }

        [TestMethod]
        public void TestTryGetById_GetNonExistingId_FxTradeReturnedIsNull()
        {
            FxTradesInMemoryCache entityInMemoryCache = GetFxTradesCache();
            TryGetResult<FxTrade> fxTradeFromCache = entityInMemoryCache.TryGetById(_nonexistingFxTradeId);

            Assert.IsFalse(fxTradeFromCache.HasValue);
        }

        [TestMethod]
        public void TestAddOrUpdateFxTrades_AddNewFxTradeWithTheSameId_FxTradeUpdatedInCache()
        {
            FxTradesInMemoryCache fxTradesCache = GetFxTradesCache();
            decimal updatedValidRate = _validRate * 10M + 1M;
            FxTrade updatedValidFxTrade = new FxTrade { FxTradeId = _validFxTradeId, Rate = updatedValidRate };

            fxTradesCache.AddOrUpdateEntity(updatedValidFxTrade);

            TryGetResult<FxTrade> fxTradeFromCache = fxTradesCache.TryGetById(_validFxTradeId);

            Assert.IsTrue(fxTradeFromCache.HasValue);
            Assert.IsNotNull(fxTradeFromCache);
            Assert.AreEqual(updatedValidFxTrade, fxTradeFromCache.Value);
            Assert.AreEqual(updatedValidFxTrade.Rate, fxTradeFromCache.Value.Rate);
        }
    }
}
