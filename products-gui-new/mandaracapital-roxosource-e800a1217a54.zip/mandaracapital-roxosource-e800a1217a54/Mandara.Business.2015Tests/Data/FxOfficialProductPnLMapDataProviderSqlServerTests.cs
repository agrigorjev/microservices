﻿//using Mandara.Entities.Entities;
//using Mandara.Entities.Enums;
//using Microsoft.VisualStudio.TestTools.UnitTesting;
//using Moq;
//using Ninject.Extensions.Logging;
//using Roxosoft.Common.Database;
//using System;
//using System.Collections.Generic;
//using System.Data.Entity.Core;
//using System.Data.SqlClient;
//using System.Linq;
//using System.Text;

//namespace Mandara.Business.Data.Tests
//{
//    [TestClass()]
//    public class FxOfficialProductPnLMapDataProviderSqlServerTests
//    {
//        private const string ProperTableName = "fxOfficialProductPnLMap";
//        private const string TemporaryTableName = "fxOfficialProductPnLMap_Temp";
//        private const string DbConnectionStringName = "MandaraEntities";
//        private static List<FxOfficialProductPnLMap> _preExistingRows;
//        private Mock<ILogger> _mockLog = new Mock<ILogger>();

//        [ClassInitialize]
//        public static void InitialiseFxOfficialProductPnLMapDataProviderTests(TestContext testContext)
//        {
//            _preExistingRows = RemoveExistingRows();
//        }

//        private static List<FxOfficialProductPnLMap> RemoveExistingRows()
//        {
//            List<FxOfficialProductPnLMap> existingRows =
//                SqlServerCommandExecution.ExecuteMsSqlReaderQuery<FxOfficialProductPnLMap>(
//                    FxOfficialProductPnLMapDataProviderSqlServerTests.DbConnectionStringName,
//                    "select * from " + FxOfficialProductPnLMapDataProviderSqlServerTests.ProperTableName,
//                    ConstructFxOfficialProductPnLMap);

//            SqlServerCommandExecution.ExecuteMsSqlScalarQuery(
//                FxOfficialProductPnLMapDataProviderSqlServerTests.DbConnectionStringName,
//                "delete from " + FxOfficialProductPnLMapDataProviderSqlServerTests.ProperTableName);

//            return existingRows;
//        }

//        private static FxOfficialProductPnLMap ConstructFxOfficialProductPnLMap(SqlDataReader reader)
//        {
//            return new FxOfficialProductPnLMap()
//            {
//                CurrencyId = reader.GetInt32(0),
//                OfficialProductId = reader.GetInt32(1),
//                HolidayCalendarId = reader.GetInt32(2),
//            };
//        }

//        [ClassCleanup]
//        public static void CleanUpFxOfficialProductPnLMapDataProviderTests()
//        {
//            RestoreRemovedRows(_preExistingRows);
//        }

//        private static void RestoreRemovedRows(List<FxOfficialProductPnLMap> removedRows)
//        {
//            if (!removedRows.Any())
//            {
//                return;
//            }

//            StringBuilder insertBuilder = new StringBuilder();

//            string insertQuery = removedRows.Aggregate(
//                insertBuilder,
//                (query, map) =>
//                    BuildFxOfficialProductPnLMapRowInsert(
//                        insertBuilder,
//                        map.CurrencyId,
//                        map.OfficialProductId,
//                        map.HolidayCalendarId)).ToString();

//            SqlServerCommandExecution.ExecuteMsSqlNonQuery(
//                FxOfficialProductPnLMapDataProviderSqlServerTests.DbConnectionStringName,
//                insertQuery);
//        }

//        private static StringBuilder BuildFxOfficialProductPnLMapRowInsert(
//            StringBuilder insertBuilder,
//            int currId,
//            int officialProdId,
//            int holCalId)
//        {
//            insertBuilder.AppendFormat(
//                "insert into {0} values ({1}, {2}, {3})\n",
//                FxOfficialProductPnLMapDataProviderSqlServerTests.ProperTableName,
//                currId,
//                officialProdId,
//                holCalId);

//            return insertBuilder;
//        }

//        [TestMethod()]
//        public void TestGetFxOfficialProductPnLMaps_TableMissing_LogsErrorReturnsEmpty()
//        {
//            string renameTableQuery = String.Format("sp_rename '{0}', '{1}'", ProperTableName, TemporaryTableName);

//            SqlServerCommandExecution.ExecuteMsSqlNonQuery(
//                FxOfficialProductPnLMapDataProviderSqlServerTests.DbConnectionStringName,
//                renameTableQuery);
//            FxOfficialProductPnLMapDataProviderSqlServer fxOfficialProdPnLMapDataProvider =
//                new FxOfficialProductPnLMapDataProviderSqlServer(_mockLog.Object);

//            try
//            {
//                fxOfficialProdPnLMapDataProvider.GetFxOfficialProductPnLMaps();

//                _mockLog.Verify(
//                    log =>
//                        log.Error(
//                            It.Is<SqlException>(sqlEx => sqlEx.Number == 208),
//                            It.Is<string>(msg => msg.Contains("FxOfficialProductPnLMapDataProviderSqlServer: Could "
//                                                                + "not read the FxOfficialProductPnLMap")),
//                            It.IsAny<string>()));
//            }
//            catch (EntityCommandExecutionException sqlEx)
//            {
//                Assert.Fail("The code should not get here, the invalid object exception should be caught and logged.");
//            }
//            finally
//            {
//                string restoreTableNameQuery = String.Format(
//                    "sp_rename '{0}', '{1}'",
//                    TemporaryTableName,
//                    ProperTableName);

//                SqlServerCommandExecution.ExecuteMsSqlNonQuery(
//                    FxOfficialProductPnLMapDataProviderSqlServerTests.DbConnectionStringName,
//                    restoreTableNameQuery);
//            }
//        }

//        [TestMethod()]
//        public void TestGetFxOfficialProductPnLMaps_TableEmpty_ReturnsEmpty()
//        {
//            FxOfficialProductPnLMapDataProviderSqlServer fxOfficialProdPnLMapDataProvider =
//                new FxOfficialProductPnLMapDataProviderSqlServer(_mockLog.Object);

//            List<FxOfficialProductPnLMap> loadedMaps = fxOfficialProdPnLMapDataProvider.GetFxOfficialProductPnLMaps();

//            Assert.AreEqual(0, loadedMaps.Count);
//        }

//        [TestMethod()]
//        public void TestGetFxOfficialProductPnLMaps_ValidData_ReturnsRows()
//        {
//            FxOfficialProductPnLMapDataProviderSqlServer fxOfficialProdPnLMapDataProvider =
//                new FxOfficialProductPnLMapDataProviderSqlServer(_mockLog.Object);
//            int expectedMapCount = InsertDummyData();

//            List<FxOfficialProductPnLMap> loadedMaps = fxOfficialProdPnLMapDataProvider.GetFxOfficialProductPnLMaps();

//            RemoveDummyData();

//            Assert.AreEqual(expectedMapCount, loadedMaps.Count);
//        }

//        private int InsertDummyData()
//        {
//            List<int> currencyIDs = GetCurrencyIDs();
//            List<int> officialProductIDs = GetOfficialProductIDs();
//            int numberOfOfficialProducts = officialProductIDs.Count;
//            int lastOfficialProductIdIndex = 0;
//            List<int> holidayCalendarIDs = GetHolidayCalendarIDs();
//            int numberOfHolidayCalendars = holidayCalendarIDs.Count;
//            int lastHolidayCalendarIdIndex = 0;
//            StringBuilder mappingInsertBuilder = new StringBuilder();

//            currencyIDs.ForEach(
//                currId =>
//                {
//                    lastOfficialProductIdIndex = GetNextIndex(lastOfficialProductIdIndex + 1, numberOfOfficialProducts);
//                    lastHolidayCalendarIdIndex = GetNextIndex(lastHolidayCalendarIdIndex + 1, numberOfHolidayCalendars);

//                    BuildFxOfficialProductPnLMapRowInsert(
//                        mappingInsertBuilder,
//                        currId,
//                        officialProductIDs[lastOfficialProductIdIndex],
//                        holidayCalendarIDs[lastHolidayCalendarIdIndex]);
//                });

//            return
//                SqlServerCommandExecution.ExecuteMsSqlNonQuery(
//                    FxOfficialProductPnLMapDataProviderSqlServerTests.DbConnectionStringName,
//                    mappingInsertBuilder.ToString());
//        }

//        private List<int> GetCurrencyIDs()
//        {
//            return
//                SqlServerCommandExecution.ExecuteMsSqlReaderQuery(
//                    FxOfficialProductPnLMapDataProviderSqlServerTests.DbConnectionStringName,
//                    "select currency_id from currencies",
//                    GetIDFromRow);
//        }

//        private int GetIDFromRow(SqlDataReader reader)
//        {
//            return reader.GetInt32(0);
//        }

//        private List<int> GetOfficialProductIDs()
//        {
//            return
//                SqlServerCommandExecution.ExecuteMsSqlReaderQuery(
//                    FxOfficialProductPnLMapDataProviderSqlServerTests.DbConnectionStringName,
//                    "select official_product_id from official_products",
//                    GetIDFromRow);
//        }

//        private List<int> GetHolidayCalendarIDs()
//        {
//            string query = String.Format(
//                "select calendar_id from stock_calendars where calendar_type = {0}",
//                (int)CalendarType.Holidays);

//            return
//                SqlServerCommandExecution.ExecuteMsSqlReaderQuery(
//                    FxOfficialProductPnLMapDataProviderSqlServerTests.DbConnectionStringName,
//                    query,
//                    GetIDFromRow);
//        }

//        private int GetNextIndex(int nextProposedIndex, int numberInSourceCollection)
//        {
//            if (nextProposedIndex >= numberInSourceCollection)
//            {
//                return 0;
//            }

//            return nextProposedIndex;
//        }

//        private void RemoveDummyData()
//        {
//            SqlServerCommandExecution.ExecuteMsSqlScalarQuery(
//                FxOfficialProductPnLMapDataProviderSqlServerTests.DbConnectionStringName,
//                "truncate table fxOfficialProductPnLMap");
//        }
//    }
//}