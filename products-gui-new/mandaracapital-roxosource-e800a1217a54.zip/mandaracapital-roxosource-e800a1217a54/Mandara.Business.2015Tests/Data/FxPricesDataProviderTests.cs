﻿using Mandara.Database.Query;
using Mandara.Database.Sql;
using Mandara.Entities;
using Mandara.Entities.Entities;
using Mandara.Test.Mocks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Ninject.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using Mandara.Date;

namespace Mandara.Business.Data.Tests
{
    [TestClass]
    public class FxPricesDataProviderTests
    {
        private FxPricesDataProvider _fxPricesDataProvider;
        private static MockCurrencyProvider _mockCurrencyProvider;
        private static int _numLivePricesInserted;
        private static int _numSnapshotPricesInserted;
        private static readonly DateTime _validSnapshotTimeWithData = new DateTime(2016, 06, 03, 15, 00, 00);
        private static readonly DateTime _validSnapshotTimeWithoutData = _validSnapshotTimeWithData.AddHours(1);
        private const decimal _validPriceJune3 = 123.456789M;
        private const decimal _validPriceJune4 = 1234.56789M;
        private static readonly DateTime _june3 = new DateTime(2016, 06, 03);
        private static readonly DateTime _june4 = new DateTime(2016, 06, 04);
        private Mock<ILogger> _logMock;
        private const string _dummyCurrency1Name = "CR1";
        private const string _dummyCurrency2Name = "CR2";
        private static int _dummyCurrency1Id;
        private static int _dummyCurrency2Id;
        private static int _dummyCurrencyPairId;

        private static readonly SqlConnectionStringBuilder PriceDbConnStr =
            ConnectionString.GetConnectionStringBuild("PriceDatabase");

        private static readonly SqlConnectionStringBuilder ProductDbConnStr =
            ConnectionString.GetConnectionStringBuild("MandaraEntities");
        private static Currency _dummyCurrency1;
        private static Currency _dummyCurrency2;
        private static FxPair _dummyFxPair;
        private static CurrencyPair _dummyCurrencyPair;
        private static string _livePricesTableName;
        private static string _snapshotPricesTableName;

        [ClassInitialize]
        public static void ClassInitialise(TestContext testContext)
        {
            _livePricesTableName = "mandara_fx_live";
            _snapshotPricesTableName = "mandara_fx";

            InitialiseData();
        }

        private static void InitialiseData()
        {
            CleanupData();

            InsertDummyCurrencyData();
            _numLivePricesInserted = InsertPrices(_livePricesTableName, _dummyCurrencyPairId, _validPriceJune3);
            _numSnapshotPricesInserted = InsertPrices(_snapshotPricesTableName, _dummyCurrencyPairId, _validPriceJune3);
        }

        [ClassCleanup]
        public static void ClassCleanup()
        {
            CleanupData();
        }

        private static void InsertDummyCurrencyData()
        {
            InsertDummyCurrencies();
            InsertDummyCurrencyPairs();
            SetUpMockCurrencyProvider();
        }

        private static void InsertDummyCurrencies()
        {
            string queryTemplate = "INSERT INTO currencies (iso_name) VALUES ('{0}'); SELECT @@IDENTITY";

            _dummyCurrency1Id =
                Convert.ToInt32(
                    SqlServerCommandExecution.ExecuteScalarQuery(
                        ProductDbConnStr,
                        string.Format(queryTemplate, _dummyCurrency1Name)));
            _dummyCurrency2Id =
                Convert.ToInt32(
                    SqlServerCommandExecution.ExecuteScalarQuery(
                        ProductDbConnStr,
                        String.Format(queryTemplate, _dummyCurrency2Name)));

            _dummyCurrency1 = new Currency { CurrencyId = _dummyCurrency1Id, IsoName = _dummyCurrency1Name };
            _dummyCurrency2 = new Currency { CurrencyId = _dummyCurrency2Id, IsoName = _dummyCurrency2Name };
            _dummyFxPair = new FxPair() { FromCurrency = _dummyCurrency1, ToCurrency = _dummyCurrency2 };
        }

        private static void InsertDummyCurrencyPairs()
        {
            string mssqlQuery = String.Format(
                "INSERT INTO fx_pairs (from_currency_id, to_currency_id, pair_name) "
                    + "VALUES ({0}, {1}, '{2}'); SELECT @@IDENTITY",
                _dummyFxPair.FromCurrencyId,
                _dummyFxPair.ToCurrencyId,
                _dummyFxPair.PairName);

            _dummyCurrencyPairId =
                Convert.ToInt32(
                    SqlServerCommandExecution.ExecuteScalarQuery(ProductDbConnStr, mssqlQuery));
            _dummyCurrencyPair = new CurrencyPair(
                _dummyCurrencyPairId,
                _dummyCurrency1,
                _dummyCurrency2);
        }

        private static void SetUpMockCurrencyProvider()
        {
            _mockCurrencyProvider = new MockCurrencyProvider();
            _mockCurrencyProvider.SetUpCurrencies(new List<Currency>() { _dummyCurrency1, _dummyCurrency2 });
            _mockCurrencyProvider.SetUpCurrencyPairs(new List<CurrencyPair>() { _dummyCurrencyPair });
        }

        private static int InsertPrices(string tableName, int currencyPairId, decimal validPriceJune3)
        {
            string query =
                string.Format(
                    "INSERT INTO {6} (RateId, TimeStamp, ValueDate, Rate) "
                        + "VALUES ({0}, '{1}', '{2}', {3}); "
                        + "INSERT INTO {6} (RateId, TimeStamp, ValueDate, Rate) "
                        + "VALUES ({0}, '{1}', '{4}', {5});"
                        + "SELECT COUNT(*) FROM {6}",
                    currencyPairId,
                    _validSnapshotTimeWithData.ToShortDateAndTime(),
                    _june3.ToSortableShortDate('-'),
                    validPriceJune3,
                    _june4.ToSortableShortDate('-'),
                    _validPriceJune4,
                    tableName);

            return Convert.ToInt32(SqlServerCommandExecution.ExecuteScalarQuery(PriceDbConnStr, query));
        }

        private static void CleanupData()
        {
            SqlServerCommandExecution.ExecuteNonQuery(
                PriceDbConnStr,
                $"truncate table {_livePricesTableName}");
            SqlServerCommandExecution.ExecuteNonQuery(
                PriceDbConnStr,
                $"truncate table {_snapshotPricesTableName}");

            SqlServerCommandExecution.ExecuteNonQuery(
                ProductDbConnStr,
                $"delete from fx_pairs where pair_id={_dummyCurrencyPairId}");
            SqlServerCommandExecution.ExecuteNonQuery(
                ProductDbConnStr,
                $"delete from currencies where iso_name='{_dummyCurrency1Name}'");
            SqlServerCommandExecution.ExecuteNonQuery(
                ProductDbConnStr,
                $"delete from currencies where iso_name='{_dummyCurrency2Name}'");
        }

        [TestInitialize]
        public void TestInitialise()
        {
            _logMock = new Mock<ILogger>();
            _fxPricesDataProvider = new FxPricesDataProvider(_mockCurrencyProvider.CurrencyProvider, _logMock.Object);
        }

        [TestMethod]
        public void GetLivePrices_LivePricesExists_AllAreReturned()
        {
            Dictionary<string, decimal> livePrices = _fxPricesDataProvider.GetLivePrices();

            Assert.IsNotNull(livePrices);
            Assert.AreEqual(_numLivePricesInserted, livePrices.Count);

            CheckLivePrice(livePrices, _june3, _validPriceJune3);
            CheckLivePrice(livePrices, _june4, _validPriceJune4);
        }

        private void CheckLivePrice(Dictionary<string, decimal> livePrices, DateTime valueDate, decimal expectedPrice)
        {
            bool hasLivePrice = livePrices.TryGetValue(
                FxPriceKey.Create(valueDate, _dummyCurrencyPair),
                out decimal livePrice);

            Assert.IsTrue(hasLivePrice);
            Assert.AreEqual(expectedPrice, livePrice);
        }

        [TestMethod]
        public void GetSnapshotPrices_SnapshotPricesExists_AllAreReturned()
        {
            Dictionary<string, decimal> livePrices = _fxPricesDataProvider.GetSnapshotPrices(_validSnapshotTimeWithData);

            Assert.IsNotNull(livePrices);
            Assert.AreEqual(_numSnapshotPricesInserted, livePrices.Count);

            CheckLivePrice(livePrices, _june3, _validPriceJune3);
            CheckLivePrice(livePrices, _june4, _validPriceJune4);
        }

        [TestMethod]
        public void GetSnapshotPrices_TimestampDoesntExists_ZeroPricesReturned()
        {
            Dictionary<string, decimal> snapshotPrices =
                _fxPricesDataProvider.GetSnapshotPrices(_validSnapshotTimeWithoutData);

            Assert.IsNotNull(snapshotPrices);
            Assert.AreEqual(0, snapshotPrices.Count);
        }
    }
}