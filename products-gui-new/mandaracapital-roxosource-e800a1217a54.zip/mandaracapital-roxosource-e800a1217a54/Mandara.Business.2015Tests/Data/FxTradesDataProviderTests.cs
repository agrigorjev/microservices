﻿using Mandara.Business.DataInterface;
using Mandara.Business.Dates;
using Mandara.Date.Time;
using Mandara.Entities;
using Mandara.Entities.Enums;
using Mandara.Entities.Trades;
using Mandara.Extensions.Option;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Mandara.Business.Data.Tests
{
    [TestClass]
    public class FxTradesDataProviderTests
    {
        private Mock<IFxTradesCache> _fxTradesCacheMock;
        private Mock<IFxTradesDataProvider> _fxTradesLoaderMock;
        private FxTradesDataProvider _fxTradesDataProvider;

        private const int _currencyId = 1;
        private const int _portfolioId = 1;
        private static readonly DateTime _riskDate = SystemTime.Now();
        private static readonly DateTime _dayBeforeRiskDate = _riskDate.AddDays(-1);
        private static readonly DateTime _twoDaysBeforeRiskDate = _riskDate.AddDays(-2);
        private static readonly DateTime _startDate = SystemTime.Now();
        private static readonly DateTime _endDate = _startDate.AddDays(1);

        private static readonly MandaraEntities _mandaraEntities = new MandaraEntities(
            MandaraEntities.DefaultConnStrName,
            nameof(FxTradesDataProviderTests));
        private static readonly int _tradeId = 1;
        private List<FxTrade> _fxTrades;
        private List<int> _skippedIds = new List<int>();

        [TestInitialize]
        public void TestInitialise()
        {
            _fxTradesCacheMock = new Mock<IFxTradesCache>();
            _fxTradesLoaderMock = new Mock<IFxTradesDataProvider>();

            _fxTradesDataProvider = new FxTradesDataProvider(_fxTradesCacheMock.Object, _fxTradesLoaderMock.Object);
            _fxTrades = GetSampleFxTrades();
        }

        private List<FxTrade> GetSampleFxTrades()
        {
            return new List<FxTrade>
            {
                new FxTrade()
                {
                    FxTradeId = 1,
                    AgainstCurrencyId = _currencyId,
                    TradeCapture =
                        new TradeCapture()
                        {
                            TradeId = _tradeId,
                            UtcTransactTime = _dayBeforeRiskDate,
                            PortfolioId = _portfolioId,
                            OrdStatus = TradeOrderStatus.Filled,
                        }
                },
                new FxTrade()
                {
                    FxTradeId = 2,
                    SpecifiedCurrencyId = _currencyId,
                    TradeCapture =
                        new TradeCapture()
                        {
                            TradeId = _tradeId + 1,
                            UtcTransactTime = _twoDaysBeforeRiskDate,
                            PortfolioId = _portfolioId,
                            OrdStatus = TradeOrderStatus.Filled,
                        }
                },
                new FxTrade()
                {
                    FxTradeId = 3,
                    AgainstCurrencyId = _currencyId,
                    TradeCapture =
                        new TradeCapture()
                        {
                            TradeId = _tradeId + 2,
                            UtcTransactTime = _twoDaysBeforeRiskDate.AddDays(-1),
                            PortfolioId = _portfolioId,
                            OrdStatus = TradeOrderStatus.Filled,
                        }
                },
            };
        }

        [TestMethod]
        public void TestReadLastFxTrades_TradesLoadedAndCacheUpdated()
        {
            const int lastFxTradeIdRead = 0;
            const int lastTradeChangeIdRead = 0;
            const int maxFxTradesReadPackageSize = 100;

            _fxTradesLoaderMock.Setup(
                loader =>
                    loader.ReadLastFxTrades(
                        lastFxTradeIdRead,
                        lastTradeChangeIdRead,
                        _skippedIds,
                        maxFxTradesReadPackageSize)).Returns(new FxTradesData(_fxTrades, new List<FxTradeChange>()));

            _fxTradesDataProvider.ReadLastFxTrades(
                lastFxTradeIdRead,
                lastTradeChangeIdRead,
                _skippedIds,
                maxFxTradesReadPackageSize);

            _fxTradesLoaderMock.Verify(
                loader =>
                    loader.ReadLastFxTrades(
                        lastFxTradeIdRead,
                        lastTradeChangeIdRead,
                        _skippedIds,
                        maxFxTradesReadPackageSize),
                Times.Once());

            _fxTradesCacheMock.Verify(
                cache =>
                    cache.ReadLastFxTrades(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<List<int>>(), It.IsAny<int>()),
                Times.Never);

            _fxTradesCacheMock.Verify(cache => cache.AddOrUpdateEntities(_fxTrades), Times.Once());
        }

        [TestMethod]
        public void TestReadFilledFxTradesForCurrency_FirstReadForCurrency_TradesLoadedAndCacheUpdated()
        {
            _fxTradesLoaderMock.Setup(x => x.ReadFilledFxTradesForCurrency(_currencyId)).Returns(_fxTrades);
            _fxTradesDataProvider.ReadFilledFxTradesForCurrency(_currencyId);

            _fxTradesLoaderMock.Verify(loader => loader.ReadFilledFxTradesForCurrency(_currencyId), Times.Once());
            _fxTradesCacheMock.Verify(cache => cache.ReadFilledFxTradesForCurrency(_currencyId), Times.Never());
            _fxTradesCacheMock.Verify(cache => cache.AddOrUpdateEntities(_fxTrades), Times.Once);
        }

        [TestMethod]
        public void TestReadFilledFxTradesForCurrency_ReadTwiceForCurrency_TradesReturnedFromCacheOnSecondRead()
        {
            _fxTradesDataProvider.ReadFilledFxTradesForCurrency(_currencyId);
            _fxTradesDataProvider.ReadFilledFxTradesForCurrency(_currencyId);

            _fxTradesLoaderMock.Verify(loader => loader.ReadFilledFxTradesForCurrency(_currencyId), Times.Once());
            _fxTradesCacheMock.Verify(cache => cache.ReadFilledFxTradesForCurrency(_currencyId), Times.Once());
            _fxTradesCacheMock.Verify(cache => cache.AddOrUpdateEntities(It.IsAny<IEnumerable<FxTrade>>()), Times.Once);
        }

        [TestMethod]
        public void TestReadFilledFxTradesForCurrency_CancelledTradeExcluded_TradesReturnedFromCacheOnSecondRead()
        {
            FxTradesInMemoryCache fxTradesCache = new FxTradesInMemoryCache(
                new Mock<IEndOfDayDateTimeProvider>().Object);

            _fxTradesLoaderMock.Setup(loader => loader.ReadFilledFxTradesForCurrency(_currencyId))
                               .Returns(_fxTrades)
                               .Callback(() => fxTradesCache.AddOrUpdateEntities(_fxTrades));
            _fxTradesDataProvider = new FxTradesDataProvider(fxTradesCache, _fxTradesLoaderMock.Object);

            List<FxTrade> initialTrades = _fxTradesDataProvider.ReadFilledFxTradesForCurrency(_currencyId);

            Assert.AreEqual(
                0,
                initialTrades.Count(fxTrade => fxTrade.TradeCapture.OrdStatus == TradeOrderStatus.Cancelled));

            List<FxTrade> initialCacheTrades = _fxTradesDataProvider.ReadFilledFxTradesForCurrency(_currencyId);
            int cachedTradesCount = initialCacheTrades.Count;

            Assert.AreEqual(
                0,
                initialCacheTrades.Count(fxTrade => fxTrade.TradeCapture.OrdStatus == TradeOrderStatus.Cancelled));

            initialCacheTrades.First().TradeCapture.OrdStatus = TradeOrderStatus.Cancelled;

            List<FxTrade> postCancelCacheTrades = _fxTradesDataProvider.ReadFilledFxTradesForCurrency(_currencyId);

            Assert.AreEqual(
                0,
                postCancelCacheTrades.Count(fxTrade => fxTrade.TradeCapture.OrdStatus == TradeOrderStatus.Cancelled));
            Assert.AreEqual(cachedTradesCount - 1, postCancelCacheTrades.Count);
        }

        [TestMethod]
        public void TestReadFxTradesForPeriod_ReadTwice_TradesAlwaysLoadedFromStorage()
        {
            _fxTradesDataProvider.ReadFxTradesForPeriod(_startDate, _endDate);
            _fxTradesDataProvider.ReadFxTradesForPeriod(_startDate, _endDate);

            _fxTradesLoaderMock.Verify(loader => loader.ReadFxTradesForPeriod(_startDate, _endDate), Times.Exactly(2));
            _fxTradesCacheMock.Verify(
                cache => cache.ReadFxTradesForPeriod(It.IsAny<DateTime>(), It.IsAny<DateTime>()),
                Times.Never);
            _fxTradesCacheMock.Verify(cache => cache.AddOrUpdateEntities(It.IsAny<IEnumerable<FxTrade>>()), Times.Never);
        }

        [TestMethod]
        public void TestReadFilledSpotFxTradesForPeriod_ReadTwice_TradesAlwaysLoadedFromStorage()
        {
            _fxTradesDataProvider.ReadFilledSpotFxTradesForPeriod(_startDate, _endDate);
            _fxTradesDataProvider.ReadFilledSpotFxTradesForPeriod(_startDate, _endDate);

            _fxTradesLoaderMock.Verify(
                loader => loader.ReadFilledSpotFxTradesForPeriod(_startDate, _endDate),
                Times.Exactly(2));
            _fxTradesCacheMock.Verify(
                cache => cache.ReadFilledSpotFxTradesForPeriod(It.IsAny<DateTime>(), It.IsAny<DateTime>()),
                Times.Never);
            _fxTradesCacheMock.Verify(
                cache => cache.AddOrUpdateEntities(It.IsAny<IEnumerable<FxTrade>>()),
                Times.Never());
        }

        [TestMethod]
        public void TestReadFilledFxTradesHistoric_NoRecentCurrencyDateLoaded_TradesLoadedAndCacheUpdated()
        {
            _fxTradesLoaderMock.Setup(loader => loader.ReadFilledFxTradesHistoric(_currencyId, _riskDate))
                               .Returns(_fxTrades);
            _fxTradesDataProvider.ReadFilledFxTradesHistoric(_currencyId, _riskDate);

            _fxTradesLoaderMock.Verify(
                loader => loader.ReadFilledFxTradesHistoric(_currencyId, _riskDate),
                Times.Once());
            _fxTradesCacheMock.Verify(cache => cache.ReadFilledFxTradesHistoric(_currencyId, _riskDate), Times.Never());
            _fxTradesCacheMock.Verify(cache => cache.AddOrUpdateEntities(_fxTrades), Times.Once());
        }

        [TestMethod]
        public void TestReadFilledFxTradesHistoric_RecentDateLoadedButLessThanRiskDate_TradesPartiallyLoadedAndCacheUpdated()
        {
            _fxTradesLoaderMock.Setup(loader => loader.ReadFilledFxTradesHistoric(_currencyId, _riskDate))
                               .Returns(_fxTrades);
            _fxTradesDataProvider.ReadFilledFxTradesHistoric(_currencyId, _riskDate);

            _fxTradesLoaderMock.Verify(
                loader => loader.ReadFilledFxTradesHistoric(_currencyId, _riskDate),
                Times.Once());
            _fxTradesCacheMock.Verify(cache => cache.ReadFilledFxTradesHistoric(_currencyId, _riskDate), Times.Never());
            _fxTradesCacheMock.Verify(cache => cache.AddOrUpdateEntities(_fxTrades), Times.Once());
        }

        [TestMethod]
        public void TestReadFilledFxTradesHistoric_RiskDateEarlierThanPreviousCall_TradesReturnedFromCacheOn2ndCall()
        {
            _fxTradesLoaderMock.Setup(loader => loader.ReadFilledFxTradesHistoric(_currencyId, _riskDate))
                               .Returns(_fxTrades);
            _fxTradesCacheMock.Setup(cache => cache.ReadFilledFxTradesHistoric(_currencyId, _dayBeforeRiskDate))
                              .Returns<int, DateTime>(
                                  (currId, riskDate) =>
                                      _fxTrades.Where(fxTrade => fxTrade.TradeCapture.UtcTransactTime < riskDate)
                                               .ToList());

            _fxTradesDataProvider.ReadFilledFxTradesHistoric(_currencyId, _riskDate);
            _fxTradesDataProvider.ReadFilledFxTradesHistoric(_currencyId, _dayBeforeRiskDate);

            _fxTradesLoaderMock.Verify(
                loader => loader.ReadFilledFxTradesHistoric(_currencyId, _riskDate),
                Times.Once());
            _fxTradesCacheMock.Verify(
                cache => cache.ReadFilledFxTradesHistoric(_currencyId, _dayBeforeRiskDate),
                Times.Once());
            _fxTradesCacheMock.Verify(cache => cache.AddOrUpdateEntities(_fxTrades), Times.Once());
        }

        [TestMethod]
        public void TestReadFilledFxTradesHistoric_RiskDateEqualToPreviousCall_OnlyUseCacheOn2ndCall()
        {
            _fxTradesLoaderMock.Setup(loader => loader.ReadFilledFxTradesHistoric(_currencyId, _riskDate))
                               .Returns(_fxTrades);
            _fxTradesCacheMock.Setup(cache => cache.ReadFilledFxTradesHistoric(_currencyId, _dayBeforeRiskDate))
                              .Returns<int, DateTime>(
                                  (currId, riskDate) =>
                                      _fxTrades.Where(fxTrade => fxTrade.TradeCapture.UtcTransactTime < riskDate)
                                               .ToList());

            _fxTradesDataProvider.ReadFilledFxTradesHistoric(_currencyId, _riskDate);
            _fxTradesDataProvider.ReadFilledFxTradesHistoric(_currencyId, _riskDate);

            _fxTradesLoaderMock.Verify(
                loader => loader.ReadFilledFxTradesHistoric(_currencyId, _riskDate),
                Times.Once());
            _fxTradesCacheMock.Verify(cache => cache.ReadFilledFxTradesHistoric(_currencyId, _riskDate), Times.Once());
            _fxTradesCacheMock.Verify(cache => cache.AddOrUpdateEntities(_fxTrades), Times.Once());
        }

        [TestMethod]
        public void TestReadFilledFxTradesHistoric_RiskDateGreaterThanPreviousCall_UseCacheAndStorageOn2ndCall()
        {
            _fxTradesLoaderMock.Setup(loader => loader.ReadFilledFxTradesHistoric(_currencyId, _dayBeforeRiskDate))
                               .Returns(
                                   _fxTrades.Where(fxTrade => fxTrade.TradeCapture.UtcTransactTime < _dayBeforeRiskDate)
                                            .ToList());
            _fxTradesLoaderMock.Setup(loader => loader.ReadFxTradesForPeriod(_dayBeforeRiskDate, _riskDate))
                               .Returns<DateTime, DateTime>(
                                   (startDate, endDate) =>
                                       _fxTrades.Where(
                                           fxTrade =>
                                               fxTrade.TradeCapture.UtcTransactTime >= startDate
                                               && fxTrade.TradeCapture.UtcTransactTime < endDate).ToList());
            _fxTradesCacheMock.Setup(cache => cache.ReadFilledFxTradesHistoric(_currencyId, _dayBeforeRiskDate))
                              .Returns<int, DateTime>(
                                  (currId, riskDate) =>
                                      _fxTrades.Where(fxTrade => fxTrade.TradeCapture.UtcTransactTime < riskDate)
                                               .ToList());

            List<FxTrade> historicTradesBeforeYesterday = _fxTradesDataProvider.ReadFilledFxTradesHistoric(
                _currencyId,
                _dayBeforeRiskDate);
            List<FxTrade> allHistoricTrades = _fxTradesDataProvider.ReadFilledFxTradesHistoric(_currencyId, _riskDate);

            _fxTradesLoaderMock.Verify(
                loader => loader.ReadFilledFxTradesHistoric(_currencyId, _dayBeforeRiskDate),
                Times.Once());
            _fxTradesLoaderMock.Verify(
                loader => loader.ReadFxTradesForPeriod(_dayBeforeRiskDate, _riskDate),
                Times.Once);
            _fxTradesCacheMock.Verify(
                cache => cache.ReadFilledFxTradesHistoric(_currencyId, _dayBeforeRiskDate),
                Times.Once());
            _fxTradesCacheMock.Verify(cache => cache.AddOrUpdateEntities(It.IsAny<List<FxTrade>>()), Times.Exactly(2));
            Assert.AreEqual(_fxTrades.Count - 1, historicTradesBeforeYesterday.Count);
            Assert.AreEqual(
                _twoDaysBeforeRiskDate.Date,
                historicTradesBeforeYesterday.Max(trade => trade.TradeCapture.UtcTransactTime.Date));
            Assert.AreEqual(_fxTrades.Count, allHistoricTrades.Count);
            Assert.AreEqual(
                _dayBeforeRiskDate.Date,
                allHistoricTrades.Max(trade => trade.TradeCapture.UtcTransactTime.Date));
        }

        [TestMethod]
        public void TestReadFxTradeByTradeId_CacheHit_ReturnedFromCache()
        {
            _fxTradesCacheMock.Setup(cache => cache.ReadFxTradeByTradeId(_mandaraEntities, _tradeId))
                              .Returns(
                                  new TryGetRef<FxTrade>(fx => false)
                                  {
                                      Value = _fxTrades.First(fxTrade => fxTrade.TradeCapture.TradeId == _tradeId)
                                  });

            _fxTradesDataProvider.ReadFxTradeByTradeId(_mandaraEntities, _tradeId);

            _fxTradesCacheMock.Verify(cache => cache.ReadFxTradeByTradeId(_mandaraEntities, _tradeId), Times.Once());
            _fxTradesLoaderMock.Verify(loader => loader.ReadFxTradeByTradeId(_mandaraEntities, _tradeId), Times.Never());
        }

        [TestMethod]
        public void TestReadFxTradeByTradeId_CacheMiss_TradeLoaded()
        {
            _fxTradesCacheMock.Setup(cache => cache.ReadFxTradeByTradeId(_mandaraEntities, _tradeId))
                              .Returns(new TryGetRef<FxTrade>());
            _fxTradesLoaderMock.Setup(loader => loader.ReadFxTradeByTradeId(_mandaraEntities, _tradeId))
                               .Returns(
                                   new TryGetRef<FxTrade>(fx => false)
                                   {
                                       Value = _fxTrades.First(fxTrade => fxTrade.TradeCaptureId == _tradeId)
                                   });

            _fxTradesDataProvider.ReadFxTradeByTradeId(_mandaraEntities, _tradeId);

            _fxTradesCacheMock.Verify(cache => cache.ReadFxTradeByTradeId(_mandaraEntities, _tradeId), Times.Once());
            _fxTradesCacheMock.Verify(cache => cache.AddOrUpdateEntity(It.IsAny<FxTrade>()), Times.Once());
            _fxTradesLoaderMock.Verify(loader => loader.ReadFxTradeByTradeId(_mandaraEntities, _tradeId), Times.Once());
        }

        [TestMethod]
        public void TestReadFxTradesByPortfolio_FirstReadForPortfolio_TradesLoadedAndCacheUpdated()
        {
            _fxTradesLoaderMock.Setup(loader => loader.ReadFxTradesByPortfolio(_currencyId, _portfolioId))
                               .Returns(_fxTrades);

            _fxTradesDataProvider.ReadFxTradesByPortfolio(_currencyId, _portfolioId);

            _fxTradesLoaderMock.Verify(
                loader => loader.ReadFxTradesByPortfolio(_currencyId, _portfolioId),
                Times.Once());
            _fxTradesCacheMock.Verify(cache => cache.ReadFxTradesByPortfolio(_currencyId, _portfolioId), Times.Never());
            _fxTradesCacheMock.Verify(cache => cache.AddOrUpdateEntities(_fxTrades), Times.Once());
        }

        [TestMethod]
        public void TestReadFxTradesByPortfolio_LoadTwice_ReturnedFromCacheOn2ndRead()
        {
            _fxTradesLoaderMock.Setup(loader => loader.ReadFxTradesByPortfolio(_currencyId, _portfolioId))
                               .Returns(_fxTrades);
            _fxTradesCacheMock.Setup(cache => cache.ReadFxTradesByPortfolio(_currencyId, _portfolioId))
                              .Returns(_fxTrades);

            _fxTradesDataProvider.ReadFxTradesByPortfolio(_currencyId, _portfolioId);
            _fxTradesDataProvider.ReadFxTradesByPortfolio(_currencyId, _portfolioId);

            _fxTradesLoaderMock.Verify(
                loader => loader.ReadFxTradesByPortfolio(_currencyId, _portfolioId),
                Times.Once());
            _fxTradesCacheMock.Verify(cache => cache.ReadFxTradesByPortfolio(_currencyId, _portfolioId), Times.Once());
            _fxTradesCacheMock.Verify(
                cache => cache.AddOrUpdateEntities(It.IsAny<IEnumerable<FxTrade>>()),
                Times.Once());
        }
    }
}