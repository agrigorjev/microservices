using Mandara.Business.Contracts;
using Mandara.Business.Dates;
using Mandara.Business.Services;
using Mandara.Database.Query;
using Mandara.Database.Sql;
using Mandara.Date;
using Mandara.Date.Time;
using Mandara.Entities;
using Mandara.Entities.Enums;
using Mandara.Entities.Trades;
using Mandara.Extensions.Guids;
using Mandara.Test;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using Mandara.Test.DateAndTime;

namespace Mandara.Business.Data.Tests
{
    [TestClass]
    public class FxTradesDataProviderMssqlTests
    {
        private static int _lastFxTradeId;
        private static int _lastTradeCaptureId;
        private static int _numTradesInserted = 7;
        private static int _lastTradeChangeId;

        private static readonly SqlConnectionStringBuilder ConnString =
            ConnectionString.GetConnectionStringBuild("MandaraEntities");
        private static int _nonExistingPortfolioId;
        private static int _lastPortfolioId;
        private Mock<IEndOfDayDateTimeProvider> _endOfDayDateTimeProvider;
        private static readonly IProductsStorage _productsStore = new ProductsStorage(new CurrencyProvider());
        private readonly List<int> _skippedIds = new List<int>();

        private static int _jpyCurrencyId;
        private const int NumOfTradesInLastPortfolio = 3;
        private const int MaxFxTradesReadPackageSize = 100;

        private static readonly List<string> TestCurrencyNames = new List<string>() { "GBP", "JPY", "EUR" };
        private static List<int> _existingTestCurrencies;
        private static bool _secDefInserted;
        private const string SecDefUnderlyingSymbol = "456890";
        private const int FxDummyProductId = 138;

        [ClassInitialize]
        public static void InitialiseFxTradesDataProviderMssqlTests(TestContext context)
        {
            _productsStore.Update();
            ImplicitDependencyLoader.ForceLoadImplicitDependency<System.Data.Entity.SqlServer.SqlProviderServices>();
        }

        [TestInitialize]
        public void InitialiseFxTradesDataProviderMsSqlTests()
        {
            _endOfDayDateTimeProvider = new Mock<IEndOfDayDateTimeProvider>();

            try
            {
                InitialiseCurrencies();
                InitialiseSecurityDefinition();
                InitialiseTrades();
                GetCurrentMaxIds();
                InitialiseTradeChanges();
            }
            catch (Exception)
            {
                CleanupFxTradesDataProviderMsSqlTests();
                throw;
            }
        }

        private static void GetCurrentMaxIds()
        {
            const string lastFxTradeIdQuery = "select max(fx_trade_id) from fx_trades";
            object dbFxTradeIdReturned =
                SqlServerCommandExecution.ExecuteScalarQuery(
                    ConnString,
                    lastFxTradeIdQuery);

            _lastFxTradeId = dbFxTradeIdReturned != DBNull.Value
                ? (int)dbFxTradeIdReturned - _numTradesInserted
                : 0;

            const string lastTradeCapturesIdQuery = "select max(idTradeCapture) from trade_captures";
            object dbTradeCaptureIdReturned =
                SqlServerCommandExecution.ExecuteScalarQuery(
                    ConnString,
                    lastTradeCapturesIdQuery);

            FxTradesDataProviderMssqlTests._lastTradeCaptureId = dbTradeCaptureIdReturned != DBNull.Value
                ? (int)dbTradeCaptureIdReturned - _numTradesInserted
                : 0;

            string lastPortfolioIdQuery = "select max(portfolio_id) from portfolios";
            object dbPortfolioIdReturned = SqlServerCommandExecution.ExecuteScalarQuery(
                ConnString,
                lastPortfolioIdQuery);

            if (dbPortfolioIdReturned == DBNull.Value)
            {
                return;
            }

            _lastPortfolioId = (int)dbPortfolioIdReturned;
            _nonExistingPortfolioId = _lastPortfolioId + 1;
        }

        private static void InitialiseTradeChanges()
        {
            string format = @"INSERT INTO [dbo].[trade_changes]
                   ([trade_id]
                   ,[trade_change_type]
                   ,[change_date]
                   ,[from_portfolio_id]
                   ,[old_quantity]
                   ,[entity_type])
                    VALUES ({0}, {1}, GETDATE(), NULL, NULL, {2})";

            StringBuilder sb = new StringBuilder();

            for (int id = _lastTradeCaptureId + 1; id <= _lastTradeCaptureId + _numTradesInserted; id++)
            {
                sb.AppendLine(
                    string.Format(format, id, (int)TradeChangeType.Assigned, (int)TradeChangeEntityType.FxTrade));
            }

            SqlServerCommandExecution.ExecuteNonQuery(ConnString, sb.ToString());
            GetCurrentMaxTradeChangeId();
        }

        private static void GetCurrentMaxTradeChangeId()
        {
            const string lastTradeChangesIdQuery = "select max(change_id) from trade_changes";
            object dbTradeChangeIdReturned =
                SqlServerCommandExecution.ExecuteScalarQuery(
                    ConnString,
                    lastTradeChangesIdQuery);

            _lastTradeChangeId = dbTradeChangeIdReturned != DBNull.Value
                ? (int)dbTradeChangeIdReturned - _numTradesInserted
                : 0;
        }

        [TestCleanup]
        public void CleanupFxTradesDataProviderMsSqlTests()
        {
            SqlServerCommandExecution.ExecuteNonQuery(
                ConnString,
                $"delete from trade_changes where change_id > {_lastTradeChangeId}");
            SqlServerCommandExecution.ExecuteNonQuery(
                ConnString,
                $"delete from fx_trades where fx_trade_id > {_lastFxTradeId}");
            SqlServerCommandExecution.ExecuteNonQuery(
                ConnString,
                $"delete from trade_captures where idTradeCapture > {_lastTradeCaptureId}");
            CleanUpSecurityDefinition();
            CleanUpCurrencies();
            SystemTimeForTest.Reset();
        }

        private void CleanUpSecurityDefinition()
        {
            if (_secDefInserted)
            {
                SqlServerCommandExecution.ExecuteScalarQuery(
                    ConnString,
                    $"delete from security_definitions where UnderlyingSymbol = '{SecDefUnderlyingSymbol}'");
            }
        }

        private void CleanUpCurrencies()
        {
            List<int> addedCurrencies = GetAddedCurrencies();

            if (addedCurrencies.Any())
            {
                SqlServerCommandExecution.ExecuteScalarQuery(
                    ConnString,
                    $"delete from currencies where currency_id in ({String.Join(", ", addedCurrencies)})");
            }
        }

        private List<int> GetAddedCurrencies()
        {
            return GetTestCurrencies().Except(_existingTestCurrencies).ToList();
        }

        private static List<int> GetTestCurrencies()
        {
            return SqlServerCommandExecution.ReadToList(
                ConnString,
                String.Format(
                    "select currency_id from currencies where iso_name in ({0})",
                    String.Join(", ", TestCurrencyNames.Select(iso => $"'{iso}'"))),
                (currencyReader) => currencyReader.GetInt32(0));
        }

        private static void InitialiseCurrencies()
        {
            _existingTestCurrencies = GetTestCurrencies();

            string currencyInsert =
                @"if NOT EXISTS(select * from dbo.currencies where iso_name='GBP')
                        begin
                        insert into dbo.currencies(iso_name)
                        values ('GBP')
                        end

                        if NOT EXISTS(select * from dbo.currencies where iso_name='JPY')
                        begin
                        insert into dbo.currencies(iso_name)
                        values ('JPY')
                        end

                        if NOT EXISTS(select * from dbo.currencies where iso_name='EUR')
                        begin
                        insert into dbo.currencies(iso_name)
                        values ('EUR')
                        end";
            SqlServerCommandExecution.ExecuteNonQuery(ConnString, currencyInsert);
        }

        private static void InitialiseSecurityDefinition()
        {
            string secDefInsertFormat = @"
                if not exists (select * from security_definitions where UnderlyingSymbol = '{0}')
                BEGIN
                    insert into security_definitions (
                    UnderlyingSymbol, 
                    UnderlyingSecurityID, 
                    UnderlyingSecurityIDSource, 
                    UnderlyingCFICode, 
                    UnderlyingSecurityDesc, 
                    UnderlyingMaturityDate, 
                    UnderlyingContractMultiplier, 
                    IncrementPrice, 
                    IncrementQty, 
                    LotSize, 
                    NumOfCycles, 
                    LotSizeMultiplier, 
                    Clearable, 
                    StartDate, 
                    EndDate, 
                    StripId, 
                    StripType, 
                    StripName, 
                    HubId, 
                    HubName, 
                    HubAlias, 
                    UnderlyingUnitOfMeasure, 
                    PriceDenomination, 
                    PriceUnit, 
                    Granularity, 
                    NumOfDecimalPrice, 
                    NumOfDecimalQty, 
                    ProductId, 
                    ProductName, 
                    ProductDescription, 
                    TickValue, 
                    PrimaryLegSymbol, 
                    SecondaryLegSymbol, 
                    Exchange, 
                    StartDateAsDate, 
                    EndDateAsDate, 
                    Strip1DateType, 
                    Strip2DateType, 
                    product_id, 
                    Strip1Date, 
                    Strip2Date) 

                    values (
                    '{0}', 
                    'BAR SQV0013.Z0013-BAR SQF0014.H0014', 
                    8, 
                    'FXXXXX', 
                    'Fuel Oil Spr - 3.5% Rdam Barges swap - Q4 13/Q1 14', 
                    '20130930', 
                    1000.000000, 
                    0.250000, 
                    1.000000, 
                    1000, 
                    3, 
                    1.000000, 
                    1, 
                    '20131001', 
                    '20140331', 
                    8598, 
                    17, 
                    'Q4 13/Q1 14', 
                    12, 
                    '3.5% Rotterdam FOB Barges Fuel Oil Swap', 
                    '3.5% Rdam Barges swap', 
                    'mt', 
                    'USD', 
                    'USD / mt', 
                    'monthly', 
                    2, 
                    0, 
                    110, 
                    'Fuel Oil Spr', 
                    '3.5% Rdam Barges Time Spread', 
                    250.000000, 
                    '452472', 
                    '456205', 
                    'ICE', 
                    '2013-10-01 00:00:00.000', 
                    '2014-03-31 00:00:00.000', 
                    3, 
                    3, 
                    {1}, 
                    '2013-10-01 00:00:00.000', 
                    '2014-01-01 00:00:00.000');
                END";

            string secDefInsert = string.Format(secDefInsertFormat, SecDefUnderlyingSymbol, FxDummyProductId);

            _secDefInserted = (int)SqlServerCommandExecution.ExecuteNonQuery(ConnString, secDefInsert)
                              == 1;
        }

        private static int InitialiseTrades()
        {
            string fxTradesInsertFormat =
                @"
                        declare @portfolioId int = (select max(portfolio_id) from portfolios);
                        declare @previousPortfolioId int = (select max(portfolio_id) from portfolios where portfolio_id <> @portfolioId);
                        declare @secDefId int = (select idSecurityDefinition from security_definitions 
                                                 where UnderlyingSymbol='{8}');
                        declare @productId int = 
                                (select product_id from security_definitions where idSecurityDefinition = @secDefId);

        INSERT [dbo].[trade_captures] (
            [TradeReportID], 			
            [TradeReportTransType], 
            [ExecID], 
            [ExecType], 
            [OrdStatus], 
            [Symbol], 
            [TradeDate], 
            [Side], 
            [OrderID], 
            [TimeStamp], 
            [OriginationTrader], 
            [TransactTime], 
            [UtcTransactTime], 
            [Exchange], 
            [TradeStartDate], 
            [TradeEndDate], 
            [PortfolioId], 
            [idSecurityDefinition])     
        VALUES (
            N'A2016064007WM00', 
            N'NEWT', 
            N'{0}', 
            N'Trade', 
            N'Filled', 
            N'USD/GBP', 
            CAST(N'2016-03-04 00:00:00.000' AS DateTime), 
            N'BUY', 
            N'A2016064007WM00', 
            CAST(N'2016-03-04 13:31:52.000' AS DateTime), 
            N'int1fbgc3200gui1', 
            CAST(N'2016-03-04 13:31:52.000' AS DateTime), 
            CAST(N'2016-03-04 13:31:52.000' AS DateTime), 
            N'Currenex', 
            CAST(N'2016-03-04 00:00:00.000' AS DateTime), 
            CAST(N'2016-03-04 00:00:00.000' AS DateTime), 
            @previousPortfolioId, 
            @secDefId); 

        INSERT [dbo].[fx_trades] (
            [product_type], 
            [specified_currency_id], 
            [specified_amount], 
            [against_currency_id], 
            [rate], 
            [spot_rate], 
            [tenor], 
            [link_trade_report_id], 
            [link_type], 
            [value_date], 
            [product_id], 
            [trade_capture_id], 
            [against_amount]) 
        VALUES (
            N'SP', 
            2, 
            CAST(80000.000000 AS Decimal(18, 6)), 
            1, 
            CAST(1.413380 AS Decimal(18, 6)), 
            CAST(1.413380 AS Decimal(18, 6)), 
            N'SP', 
            N'A2016064007WL00', 
            N'Parent', 
            CAST(N'2016-03-08 00:00:00.000' AS DateTime), 
            @productId, 
            SCOPE_IDENTITY(), 
            CAST(113070.000000 AS Decimal(18, 6)));

        INSERT [dbo].[trade_captures] (
            [TradeReportID], 			
            [TradeReportTransType], 
            [ExecID], 
            [ExecType], 
            [OrdStatus], 
            [Symbol], 
            [TradeDate], 
            [Side], 
            [OrderID], 
            [TimeStamp], 
            [OriginationTrader], 
            [TransactTime], 
            [UtcTransactTime], 
            [Exchange], 
            [TradeStartDate], 
            [TradeEndDate], 
            [PortfolioId], 
            [idSecurityDefinition])     
        VALUES (
            N'A2016064007WS00', 
            N'NEWT', 
            N'{1}', 
            N'Trade', 
            N'Filled', 
            N'USD/GBP', 
            CAST(N'2016-03-04 00:00:00.000' AS DateTime), 
            N'BUY', 
            N'A2016064007WS00', 
            CAST(N'2016-03-04 13:32:29.000' AS DateTime), 
            N'int1fbgc3200gui1', 
            CAST(N'2016-03-04 13:32:29.000' AS DateTime), 
            CAST(N'2016-03-04 13:32:29.000' AS DateTime), 
            N'Currenex', 
            CAST(N'2016-03-04 00:00:00.000' AS DateTime), 
            CAST(N'2016-03-04 00:00:00.000' AS DateTime), 
            @previousPortfolioId, 
            @secDefId) ;

        INSERT [dbo].[fx_trades] (
            [product_type], 
            [specified_currency_id], 
            [specified_amount], 
            [against_currency_id], 
            [rate], 
            [spot_rate], 
            [tenor], 
            [link_trade_report_id], 
            [link_type], 
            [value_date], 
            [product_id], 
            [trade_capture_id], 
            [against_amount]) 
        VALUES (
            N'SP', 
            (select currency_id from currencies where iso_name='GBP'), 
            CAST(80000.000000 AS Decimal(18, 6)), 
            (select currency_id from currencies where iso_name='USD'), 
            CAST(1.413590 AS Decimal(18, 6)), 
            CAST(1.413590 AS Decimal(18, 6)), 
            N'SP', 
            N'A2016064007WR00', 
            N'Parent', 
            CAST(N'2016-03-08 00:00:00.000' AS DateTime), 
            @productId, 
            SCOPE_IDENTITY(), 
            CAST(113087.000000 AS Decimal(18, 6)));

        INSERT [dbo].[trade_captures] (
            [TradeReportID], 			
            [TradeReportTransType], 
            [ExecID], 
            [ExecType], 
            [OrdStatus], 
            [Symbol], 
            [TradeDate], 
            [Side], 
            [OrderID], 
            [TimeStamp], 
            [OriginationTrader], 
            [TransactTime], 
            [UtcTransactTime], 
            [Exchange], 
            [TradeStartDate], 
            [TradeEndDate], 
            [PortfolioId], 
            [idSecurityDefinition])     
        VALUES (
            N'A201606402JHW00', 
            N'NEWT', 
            N'{2}', 
            N'Trade', 
            N'Filled', 
            N'USD/EUR', 
            CAST(N'2016-03-04 00:00:00.000' AS DateTime), 
            N'BUY', 
            N'A201606402JHW00', 
            CAST(N'2016-03-04 13:33:12.000' AS DateTime), 
            N'int1fbgc3200gui1', 
            CAST(N'2016-03-04 13:33:12.000' AS DateTime), 
            CAST(N'2016-03-04 13:33:12.000' AS DateTime), 
            N'Currenex', 
            CAST(N'2016-03-04 00:00:00.000' AS DateTime), 
            CAST(N'2016-03-04 00:00:00.000' AS DateTime), 
            @previousPortfolioId, 
            @secDefId);

        INSERT [dbo].[fx_trades] (
            [product_type], 
            [specified_currency_id], 
            [specified_amount], 
            [against_currency_id], 
            [rate], 
            [spot_rate], 
            [tenor], 
            [link_trade_report_id], 
            [link_type], 
            [value_date], 
            [product_id], 
            [trade_capture_id], 
            [against_amount]) 
        VALUES (
            N'OR', 
            (select currency_id from currencies where iso_name='EUR'), 
            CAST(10000.000000 AS Decimal(18, 6)), 
            (select currency_id from currencies where iso_name='USD'), 
            CAST(1.092760 AS Decimal(18, 6)), 
            CAST(1.092710 AS Decimal(18, 6)), 
            N'1W', 
            N'A201606402JHU00', 
            N'Parent', 
            CAST(N'2016-03-15 00:00:00.000' AS DateTime), 
            @productId, 
            SCOPE_IDENTITY(), 
            CAST(10927.600000 AS Decimal(18, 6)));

        INSERT [dbo].[trade_captures] (
            [TradeReportID], 			
            [TradeReportTransType], 
            [ExecID], 
            [ExecType], 
            [OrdStatus], 
            [Symbol], 
            [TradeDate], 
            [Side], 
            [OrderID], 
            [TimeStamp], 
            [OriginationTrader], 
            [TransactTime], 
            [UtcTransactTime], 
            [Exchange], 
            [TradeStartDate], 
            [TradeEndDate], 
            [PortfolioId], 
            [idSecurityDefinition])     
        VALUES (
            N'A201606402JJ000', 
            N'NEWT', 
            N'{3}', 
            N'Trade', 
            N'Filled', 
            N'USD/EUR', 
            CAST(N'2016-03-04 00:00:00.000' AS DateTime), 
            N'BUY', 
            N'A201606402JJ000', 
            CAST(N'2016-03-04 13:33:46.000' AS DateTime), 
            N'int1fbgc3200gui1', 
            CAST(N'2016-03-04 13:33:46.000' AS DateTime), 
            CAST(N'2016-03-04 13:33:46.000' AS DateTime), 
            N'Currenex', 
            CAST(N'2016-03-04 00:00:00.000' AS DateTime), 
            CAST(N'2016-03-04 00:00:00.000' AS DateTime), 
            @previousPortfolioId, 
            @secDefId);

        INSERT [dbo].[fx_trades] (
            [product_type], 
            [specified_currency_id], 
            [specified_amount], 
            [against_currency_id], 
            [rate], 
            [spot_rate], 
            [tenor], 
            [link_trade_report_id], 
            [link_type], 
            [value_date], 
            [product_id], 
            [trade_capture_id], 
            [against_amount]) 
        VALUES (
            N'OR', 
            (select currency_id from currencies where iso_name='EUR'), 
            CAST(10000.000000 AS Decimal(18, 6)), 
            (select currency_id from currencies where iso_name='USD'), 
            CAST(1.092400 AS Decimal(18, 6)), 
            CAST(1.092320 AS Decimal(18, 6)), 
            N'2M', 
            N'A201606402JHY00', 
            N'Parent', 
            CAST(N'2016-05-09 00:00:00.000' AS DateTime), 
            @productId, 
            SCOPE_IDENTITY(), 
            CAST(10924.000000 AS Decimal(18, 6)));

        INSERT [dbo].[trade_captures] (
            [TradeReportID], 			
            [TradeReportTransType], 
            [ExecID], 
            [ExecType], 
            [OrdStatus], 
            [Symbol], 
            [TradeDate], 
            [Side], 
            [OrderID], 
            [TimeStamp], 
            [OriginationTrader], 
            [TransactTime], 
            [UtcTransactTime], 
            [Exchange], 
            [TradeStartDate], 
            [TradeEndDate], 
            [PortfolioId], 
            [idSecurityDefinition])     
        VALUES (
            N'A2016064007XC00', 
            N'NEWT', 
            N'{4}', 
            N'Trade', 
            N'Filled', 
            N'USD/GBP', 
            CAST(N'2016-03-04 00:00:00.000' AS DateTime), 
            N'SELL', 
            N'A2016064007XC00', 
            CAST(N'2016-03-04 13:33:59.000' AS DateTime), 
            N'int1fbgc3200gui1', 
            CAST(N'2016-03-04 13:33:59.000' AS DateTime), 
            CAST(N'2016-03-04 13:33:59.000' AS DateTime), 
            N'Currenex', 
            CAST(N'2016-03-04 00:00:00.000' AS DateTime), 
            CAST(N'2016-03-04 00:00:00.000' AS DateTime), 
            @previousPortfolioId, 
            @secDefId) ;

        INSERT [dbo].[fx_trades] (
            [product_type], 
            [specified_currency_id], 
            [specified_amount], 
            [against_currency_id], 
            [rate], 
            [spot_rate], 
            [tenor], 
            [link_trade_report_id], 
            [link_type], 
            [value_date], 
            [product_id], 
            [trade_capture_id], 
            [against_amount]) 
        VALUES (
            N'SP', 
            (select currency_id from currencies where iso_name='GBP'), 
            CAST(56642.800000 AS Decimal(18, 6)), 
            (select currency_id from currencies where iso_name='USD'), 
            CAST(1.412360 AS Decimal(18, 6)), 
            CAST(1.412360 AS Decimal(18, 6)), 
            N'SP', 
            N'A2016064007XB00', 
            N'Parent', 
            CAST(N'2016-03-08 00:00:00.000' AS DateTime), 
            @productId, 
            SCOPE_IDENTITY(), 
            CAST(80000.000000 AS Decimal(18, 6)));

        INSERT [dbo].[trade_captures] (
            [TradeReportID], 			
            [TradeReportTransType], 
            [ExecID], 
            [ExecType], 
            [OrdStatus], 
            [Symbol], 
            [TradeDate], 
            [Side], 
            [OrderID], 
            [TimeStamp], 
            [OriginationTrader], 
            [TransactTime], 
            [UtcTransactTime], 
            [Exchange], 
            [TradeStartDate], 
            [TradeEndDate], 
            [PortfolioId], 
            [idSecurityDefinition])     
        VALUES (
            N'A201611202JHB00', 
            N'NEWT', 
            N'{5}', 
            N'Trade', 
            N'Filled', 
            N'JPY/USD', 
            CAST(N'2016-04-21 00:00:00.000' AS DateTime), 
            N'SELL', 
            N'A201611202JHB00', 
            CAST(N'2016-04-21 07:35:09.000' AS DateTime), 
            N'int1fbgc3200gui1', 
            CAST(N'2016-04-21 07:35:09.000' AS DateTime), 
            CAST(N'2016-04-21 07:35:09.000' AS DateTime), 
            N'Currenex', 
            CAST(N'2016-04-21 00:00:00.000' AS DateTime), 
            CAST(N'2016-04-21 00:00:00.000' AS DateTime), 
            @portfolioId, 
            @secDefId) ;

        INSERT [dbo].[fx_trades] (
            [product_type], 
            [specified_currency_id], 
            [specified_amount], 
            [against_currency_id], 
            [rate], 
            [spot_rate], 
            [tenor], 
            [link_trade_report_id], 
            [link_type], 
            [value_date], 
            [product_id], 
            [trade_capture_id], 
            [against_amount]) 
        VALUES (
            N'OR', 
            (select currency_id from currencies where iso_name='JPY'), 
            CAST(1096330.000000 AS Decimal(18, 6)), 
            (select currency_id from currencies where iso_name='USD'), 
            CAST(109.633000 AS Decimal(18, 6)), 
            CAST(109.627000 AS Decimal(18, 6)), 
            N'EOMQ', 
            N'A201611202JH900', 
            N'Parent', 
            CAST(N'2016-08-31 00:00:00.000' AS DateTime), 
            @productId, 
            SCOPE_IDENTITY(), 
            CAST(10000.000000 AS Decimal(18, 6)));

        INSERT [dbo].[trade_captures] (
            [TradeReportID], 			
            [TradeReportTransType], 
            [ExecID], 
            [ExecType], 
            [OrdStatus], 
            [Symbol], 
            [TradeDate], 
            [Side], 
            [OrderID], 
            [TimeStamp], 
            [OriginationTrader], 
            [TransactTime], 
            [UtcTransactTime], 
            [Exchange], 
            [TradeStartDate], 
            [TradeEndDate], 
            [PortfolioId], 
            [idSecurityDefinition])     
        VALUES (
            N'A201611200C7700', 
            N'NEWT', 
            N'{6}', 
            N'Trade', 
            N'Filled', 
            N'JPY/USD', 
            CAST(N'2016-04-21 00:00:00.000' AS DateTime), 
            N'SELL', 
            N'A201611200C7700', 
            CAST(N'2016-04-21 18:07:46.000' AS DateTime), 
            N'int1fbgc3200gui1', 
            CAST(N'2016-04-21 18:07:46.000' AS DateTime), 
            CAST(N'2016-04-21 18:07:46.000' AS DateTime), 
            N'Currenex', 
            CAST(N'2016-04-21 00:00:00.000' AS DateTime), 
            CAST(N'2016-04-21 00:00:00.000' AS DateTime), 
            @portfolioId, 
            @secDefId) ;

        INSERT [dbo].[fx_trades] (
            [product_type], 
            [specified_currency_id], 
            [specified_amount], 
            [against_currency_id], 
            [rate], 
            [spot_rate], 
            [tenor], 
            [link_trade_report_id], 
            [link_type], 
            [value_date], 
            [product_id], 
            [trade_capture_id], 
            [against_amount]) 
        VALUES (
            N'SP', 
            (select currency_id from currencies where iso_name='USD'), 
            CAST(45640.800000 AS Decimal(18, 6)), 
            (select currency_id from currencies where iso_name='JPY'), 
            CAST(109.551000 AS Decimal(18, 6)), 
            CAST(109.551000 AS Decimal(18, 6)), 
            N'SP', 
            N'A201611200C7500', 
            N'Parent', 
            CAST(N'2016-04-25 00:00:00.000' AS DateTime), 
            @productId, 
            SCOPE_IDENTITY(), 
            CAST(5000000.000000 AS Decimal(18, 6)));

        INSERT [dbo].[trade_captures] (
            [TradeReportID], 			
            [TradeReportTransType], 
            [ExecID], 
            [ExecType], 
            [OrdStatus], 
            [Symbol], 
            [TradeDate], 
            [Side], 
            [OrderID], 
            [TimeStamp], 
            [OriginationTrader], 
            [TransactTime],
            [UtcTransactTime],
            [Exchange], 
            [TradeStartDate], 
            [TradeEndDate], 
            [PortfolioId], 
            [idSecurityDefinition])     
        VALUES (
            N'A201611200C7700', 
            N'NEWT', 
            N'{7}', 
            N'Trade', 
            N'Cancelled', 
            N'JPY/USD', 
            CAST(N'2016-04-21 00:00:00.000' AS DateTime), 
            N'SELL', 
            N'A201611200C7700', 
            CAST(N'2016-04-21 18:08:46.000' AS DateTime), 
            N'int1fbgc3200gui1', 
            CAST(N'2016-04-21 18:09:46.000' AS DateTime), 
            CAST(N'2016-04-21 18:09:46.000' AS DateTime), 
            N'Currenex', 
            CAST(N'2016-04-21 00:00:00.000' AS DateTime), 
            CAST(N'2016-04-21 00:00:00.000' AS DateTime), 
            @portfolioId, 
            @secDefId) ;

        INSERT [dbo].[fx_trades] (
            [product_type], 
            [specified_currency_id], 
            [specified_amount], 
            [against_currency_id], 
            [rate], 
            [spot_rate], 
            [tenor], 
            [link_trade_report_id], 
            [link_type], 
            [value_date], 
            [product_id], 
            [trade_capture_id], 
            [against_amount]) 
        VALUES (
            N'SP', 
            (select currency_id from currencies where iso_name='USD'), 
            CAST(45640.800000 AS Decimal(18, 6)), 
            (select currency_id from currencies where iso_name='JPY'), 
            CAST(109.551000 AS Decimal(18, 6)), 
            CAST(109.551000 AS Decimal(18, 6)), 
            N'SP', 
            N'A201611200C7500', 
            N'Parent', 
            CAST(N'2016-04-25 00:00:00.000' AS DateTime), 
            @productId, 
            SCOPE_IDENTITY(), 
            CAST(5000000.000000 AS Decimal(18, 6)));";

            string fxTradesInsert = string.Format(fxTradesInsertFormat, GetTradeInsertFormatArguments().ToArray());

            _numTradesInserted = SqlServerCommandExecution.ExecuteNonQuery(ConnString, fxTradesInsert)
                                 / 2;
            _jpyCurrencyId = GetYenCurrencyId();
            return _numTradesInserted;
        }

        private static IEnumerable<string> GetTradeInsertFormatArguments()
        {
            foreach (int execIdIndex in Enumerable.Range(0, 8))
            {
                yield return $"FxDataProv-{execIdIndex}";
            }

            yield return SecDefUnderlyingSymbol;
        }
        private static int GetYenCurrencyId()
        {
            return
                (int)
                    SqlServerCommandExecution.ExecuteScalarQuery(
                        ConnString,
                        $"select currency_id from currencies where iso_name = '{CurrencyCodes.JPY}'");
        }

        [TestMethod]
        public void TestReadLastFxTrades_SkippedOneTrade_TradesAreReadIncludingSkipped()
        {
            int skippedFxTradeId = _lastFxTradeId + _numTradesInserted / 2;

            FxTradesDataProviderMssql fxTradesDataProviderMssql = GetFxTradesDataProviderMssql();
            FxTradesData fxTradesData =
                fxTradesDataProviderMssql.ReadLastFxTrades(
                    _lastFxTradeId + _numTradesInserted - 1,
                    _lastTradeChangeId + _numTradesInserted + 1,
                    new List<int> { skippedFxTradeId });

            Assert.IsNotNull(fxTradesData);
            Assert.IsNotNull(fxTradesData.Trades);
            Assert.IsNotNull(fxTradesData.TradeChanges);
            Assert.AreEqual(2, fxTradesData.Trades.Count);
            Assert.AreEqual(0, fxTradesData.TradeChanges.Count);
            Assert.AreEqual(1, fxTradesData.Trades.Count(fxTrade => fxTrade.FxTradeId == skippedFxTradeId));
        }

        [TestMethod]
        public void TestReadLastFxTrades_LastTradeChangeIdIsGeaterThanDbId_ZeroTradeChangesRead()
        {
            FxTradesDataProviderMssql fxTradesDataProviderMssql = GetFxTradesDataProviderMssql();
            FxTradesData fxTradesData =
                fxTradesDataProviderMssql.ReadLastFxTrades(
                    _lastFxTradeId + _numTradesInserted + 1,
                    _lastTradeChangeId + _numTradesInserted + 1,
                    _skippedIds);

            Assert.IsNotNull(fxTradesData);
            Assert.IsNotNull(fxTradesData.Trades);
            Assert.IsNotNull(fxTradesData.TradeChanges);
            Assert.AreEqual(0, fxTradesData.Trades.Count);
            Assert.AreEqual(0, fxTradesData.TradeChanges.Count);
        }

        private FxTradesDataProviderMssql GetFxTradesDataProviderMssql()
        {
            return new FxTradesDataProviderMssql(_endOfDayDateTimeProvider.Object, _productsStore);
        }

        [TestMethod]
        public void TestReadLastFxTrades_ReadTradeChanges_InsertedTradeChangesAreRead()
        {
            FxTradesDataProviderMssql fxTradesDataProviderMssql = GetFxTradesDataProviderMssql();

            FxTradesData fxTradesData =
                fxTradesDataProviderMssql.ReadLastFxTrades(int.MaxValue, _lastTradeChangeId, _skippedIds);

            Assert.IsNotNull(fxTradesData);
            Assert.IsNotNull(fxTradesData.Trades);
            Assert.IsNotNull(fxTradesData.TradeChanges);
            Assert.AreEqual(_numTradesInserted, fxTradesData.TradeChanges.Count);
        }

        [TestMethod]
        public void TestReadLastFxTrades_ReadTradesAndTradeChanges_InsertedDataRead()
        {
            FxTradesDataProviderMssql fxTradesDataProviderMssql = GetFxTradesDataProviderMssql();

            FxTradesData fxTradesData =
                fxTradesDataProviderMssql.ReadLastFxTrades(_lastFxTradeId, _lastTradeChangeId, _skippedIds);

            Assert.IsNotNull(fxTradesData);
            Assert.IsNotNull(fxTradesData.Trades);
            Assert.IsNotNull(fxTradesData.TradeChanges);
            Assert.AreEqual(_numTradesInserted, fxTradesData.Trades.Count);
            Assert.AreEqual(_numTradesInserted, fxTradesData.TradeChanges.Count);
        }

        [TestMethod]
        public void TestReadLastFxTrades_LastFxTradeIdIsSet_InsertedTradesAreRead()
        {
            FxTradesDataProviderMssql fxTradesDataProviderMssql = GetFxTradesDataProviderMssql();

            FxTradesData fxTradesData =
                fxTradesDataProviderMssql.ReadLastFxTrades(_lastFxTradeId, int.MaxValue, _skippedIds);

            Assert.IsNotNull(fxTradesData);
            Assert.IsNotNull(fxTradesData.Trades);
            Assert.IsNotNull(fxTradesData.TradeChanges);
            Assert.AreEqual(_numTradesInserted, fxTradesData.Trades.Count);
        }

        [TestMethod]
        public void TestReadLastFxTrades_LastFxTradeIdIsGeaterThanDbId_ZeroTradesAreRead()
        {
            FxTradesDataProviderMssql fxTradesDataProviderMssql = GetFxTradesDataProviderMssql();
            FxTradesData fxTradesData =
                fxTradesDataProviderMssql.ReadLastFxTrades(_lastFxTradeId + _numTradesInserted + 1, int.MaxValue, _skippedIds);

            Assert.IsNotNull(fxTradesData);
            Assert.IsNotNull(fxTradesData.Trades);
            Assert.IsNotNull(fxTradesData.TradeChanges);
            Assert.AreEqual(0, fxTradesData.Trades.Count);
            Assert.AreEqual(0, fxTradesData.TradeChanges.Count);
        }

        [TestMethod]
        public void TestReadFilledFxTradesForCurrency_FilledAndCancelledTrades_FilledTradesAreRead()
        {
            FxTradesDataProviderMssql fxTradesDataProviderMssql = GetFxTradesDataProviderMssql();
            List<FxTrade> fxTrades = fxTradesDataProviderMssql.ReadFilledFxTradesForCurrency(1);

            fxTrades = fxTrades.Where(x => x.TradeCaptureId > _lastTradeCaptureId).ToList();

            Assert.IsNotNull(fxTrades);
            Assert.IsTrue(fxTrades.Count > 0);
            Assert.AreEqual(_numTradesInserted - 1, fxTrades.Count);
            Assert.IsTrue(fxTrades.All(x => x.TradeCapture.OrdStatus == "Filled"));
        }

        [TestMethod]
        public void TestReadFxTradesByPortfolio_NonExistingPortfolio_ZeroReturned()
        {
            FxTradesDataProviderMssql fxTradesDataProviderMssql = GetFxTradesDataProviderMssql();

            List<FxTrade> fxTrades =
                fxTradesDataProviderMssql.ReadFxTradesByPortfolio(_jpyCurrencyId, _nonExistingPortfolioId);

            Assert.IsNotNull(fxTrades);
            Assert.AreEqual(0, fxTrades.Count);
        }

        [TestMethod]
        public void TestReadFxTradesByPortfolio_TradesExistForParams_TradesReturnedSuccessfully()
        {
            FxTradesDataProviderMssql fxTradesDataProviderMssql = GetFxTradesDataProviderMssql();

            List<FxTrade> fxTrades =
                fxTradesDataProviderMssql.ReadFxTradesByPortfolio(_jpyCurrencyId, _lastPortfolioId);

            Assert.IsNotNull(fxTrades);
            Assert.AreEqual(NumOfTradesInLastPortfolio, fxTrades.Count);
        }

        [TestMethod]
        public void TestReadLastFxTrades_LastFxTradeIdIsZero_SomeTradesAreRead()
        {
            FxTradesDataProviderMssql fxTradesDataProviderMssql = GetFxTradesDataProviderMssql();

            FxTradesData fxTradesData =
                fxTradesDataProviderMssql.ReadLastFxTrades(_lastFxTradeId,
                _lastTradeChangeId,
                _skippedIds,
                MaxFxTradesReadPackageSize);

            Assert.IsNotNull(fxTradesData);
            Assert.AreEqual(_numTradesInserted, fxTradesData.Trades.Count);
        }

        [TestMethod]
        public void TestReadLastFxTrades_LastFxTradeIdIsMaxInt_ZeroTradesAreRead()
        {
            FxTradesDataProviderMssql fxTradesDataProviderMssql = GetFxTradesDataProviderMssql();
            FxTradesData fxTradesData = fxTradesDataProviderMssql.ReadLastFxTrades(
                _lastFxTradeId + _numTradesInserted + 1,
                _lastTradeChangeId,
                _skippedIds);

            Assert.IsNotNull(fxTradesData);
            Assert.AreEqual(0, fxTradesData.Trades.Count);
        }

        [TestMethod]
        public void TestReadFilledSpotFxTradesForPeriod_OnlySpotTradeOnLastDayOfMonth_TradeIsRead()
        {
            SetupEndOfDayDataProvider();
            SetDateAndTimeToAMonthWithANonWeekendLastDay(InternalTime.LocalNow());

            int portfolioId = GetLastPortfolioId();
            int secDefId = GetSecurityDefinitionId();
            (int from, int to) currencyIds = GetCurrencyIds(new Tuple<string, string>("USD", "JPY"));
            int newFxTradeId = AddFxTrade(
                portfolioId,
                secDefId,
                currencyIds,
                FxProductTypes.Spot,
                TradeOrderStatus.Filled);

            FxTradesDataProviderMssql fxTradesDataProviderMssql = GetFxTradesDataProviderMssql();
            List<FxTrade> fxTrades = fxTradesDataProviderMssql.ReadFilledSpotFxTradesForPeriod(
                InternalTime.LocalToday(),
                InternalTime.LocalToday());

            DeleteFxTrade(newFxTradeId);

            Assert.IsNotNull(fxTrades);
            Assert.AreEqual(1, fxTrades.Count);
            Assert.AreEqual(newFxTradeId, fxTrades.First().FxTradeId);
        }

        [TestMethod]
        public void TestReadFilledSpotFxTradesForPeriod_CancelledTradesExcluded_FilledTradeIsRead()
        {
            SetupEndOfDayDataProvider();
            SetDateAndTimeToAMonthWithANonWeekendLastDay(InternalTime.LocalNow());

            int portfolioId = GetLastPortfolioId();
            int secDefId = GetSecurityDefinitionId();
            (int from, int to) currencyIds = GetCurrencyIds(new Tuple<string, string>("USD", "JPY"));
            int newFilledFxTradeId = AddFxTrade(
                portfolioId,
                secDefId,
                currencyIds,
                FxProductTypes.Spot,
                TradeOrderStatus.Filled);
            int newCancelledFxTradeId = AddFxTrade(
                portfolioId,
                secDefId,
                currencyIds,
                FxProductTypes.Spot,
                TradeOrderStatus.Cancelled);

            FxTradesDataProviderMssql fxTradesDataProviderMssql = GetFxTradesDataProviderMssql();
            List<FxTrade> fxTrades = fxTradesDataProviderMssql.ReadFilledSpotFxTradesForPeriod(
                InternalTime.LocalToday(),
                InternalTime.LocalToday());

            DeleteFxTrade(newFilledFxTradeId);
            DeleteFxTrade(newCancelledFxTradeId);

            Assert.IsNotNull(fxTrades);
            Assert.AreEqual(1, fxTrades.Count);
            Assert.AreEqual(newFilledFxTradeId, fxTrades.First().FxTradeId);
        }

        private void SetupEndOfDayDataProvider()
        {
            _endOfDayDateTimeProvider.Setup(x => x.GetUtcDateRangeAccordingToEodTimes(It.IsAny<DateRange>()))
                                     .Returns<DateRange>(
                                         dateRange =>
                                         {
                                             DateTime endDate = dateRange.HasEndDate()
                                                 ? dateRange.End.AddDays(1).AddMilliseconds(-1)
                                                 : dateRange.End;

                                             return new DateRange(dateRange.Start, endDate);
                                         });
        }

        private void SetDateAndTimeToAMonthWithANonWeekendLastDay(DateTime baseDate)
        {
            int year = baseDate.Year;
            int month = baseDate.Month;
            int daysInMonth = DateTime.DaysInMonth(year, month);
            DateTime lastDayOfMonth = new DateTime(year, month, daysInMonth);

            if (lastDayOfMonth.IsWeekendDay())
            {
                SetDateAndTimeToAMonthWithANonWeekendLastDay(baseDate.AddMonths(1));
            }
            else
            {
                SystemTimeForTest.SupercedeNow(
                    () =>
                        new DateTime(
                            year,
                            month,
                            daysInMonth,
                            baseDate.Hour,
                            baseDate.Minute,
                            baseDate.Second,
                            baseDate.Millisecond));
            }
        }

        private int GetLastPortfolioId()
        {
            using (MandaraEntities dbContext = CreateMandaraProductsDbContext())
            {
                return dbContext.Portfolios.Max(portfolio => portfolio.PortfolioId);
            }
        }

        private static MandaraEntities CreateMandaraProductsDbContext()
        {
            return new MandaraEntities(MandaraEntities.DefaultConnStrName, nameof(FxTradesDataProviderMssqlTests));
        }

        private int GetSecurityDefinitionId()
        {
            using (MandaraEntities dbContext = CreateMandaraProductsDbContext())
            {
                return
                    dbContext.SecurityDefinitions.First(secDef => secDef.UnderlyingSymbol == SecDefUnderlyingSymbol)
                             .SecurityDefinitionId;
            }
        }

        private SecurityDefinition GetSecurityDefinition()
        {
            using (MandaraEntities dbContext = CreateMandaraProductsDbContext())
            {
                return
                    dbContext.SecurityDefinitions.First(secDef => secDef.UnderlyingSymbol == SecDefUnderlyingSymbol);
            }
        }

        private (int from, int to) GetCurrencyIds(Tuple<string, string> currencyIsoNames)
        {
            using (MandaraEntities dbContext = CreateMandaraProductsDbContext())
            {
                int currencyId1 = dbContext.Currencies.First(curr => curr.IsoName == currencyIsoNames.Item1).CurrencyId;
                int currencyId2 = dbContext.Currencies.First(curr => curr.IsoName == currencyIsoNames.Item2).CurrencyId;

                return (currencyId1, currencyId2);
            }
        }

        private int AddFxTrade(
            int portfolioId,
            int secDefId,
            (int from, int to) currencyIds,
            string fxTradeType,
            string orderStatus)
        {
            DateTime now = InternalTime.LocalNow();

            TradeCapture newTrade = new TradeCapture()
            {
                TradeReportID = "A201611200C7700",
                TradeReportTransType = "NEWT",
                ExecID = GuidExtensions.NumericGuid(30),
                ExecType = "Trade",
                OrdStatus = orderStatus,
                Symbol = "JPY/USD",
                TradeDate = now.Date,
                Side = "SELL",
                OrderID = "A201611200C7700",
                TimeStamp = now,
                OriginationTrader = "int1fbgc3200gui1",
                TransactTime = now,
                UtcTransactTime = now.ToUniversalTime(),
                Exchange = "Currenex",
                TradeStartDate = now.Date,
                TradeEndDate = now.Date,
                PortfolioId = portfolioId,
                SecurityDefinitionId = secDefId,
            };

            FxTrade newFxTrade = new FxTrade()
            {
                ProductType = fxTradeType,
                SpecifiedCurrencyId = currencyIds.from,
                SpecifiedAmount = 45640.800000M,
                AgainstCurrencyId = currencyIds.to,
                AgainstAmount = 5000000.000000M,
                Rate = 109.551000M,
                SpotRate = 109.551000M,
                Tenor = fxTradeType,
                LinkTradeReportId = "A201611200C7500",
                LinkType = "Parent",
                ValueDate = now.Date.NextBusinessDay(),
                ProductId = GetSecurityDefinition().product_id.Value,
                TradeCapture = newTrade,
            };

            using (MandaraEntities dbContext = CreateMandaraProductsDbContext())
            {
                dbContext.TradeCaptures.Add(newTrade);
                dbContext.FxTrades.Add(newFxTrade);

                dbContext.SaveChanges();
            }

            return newFxTrade.FxTradeId;
        }

        private static void DeleteFxTrade(int fxTradeId)
        {
            using (MandaraEntities dbContext = CreateMandaraProductsDbContext())
            {
                DbEntityEntry<FxTrade> fxTradeEntry =
                    dbContext.Entry(dbContext.FxTrades.First(fxTrade => fxTrade.FxTradeId == fxTradeId));
                DbEntityEntry<TradeCapture> tradeEntry =
                    dbContext.Entry(
                        dbContext.TradeCaptures.First(
                            tradeCap => tradeCap.TradeId == fxTradeEntry.Entity.TradeCaptureId));

                tradeEntry.State = EntityState.Deleted;
                fxTradeEntry.State = EntityState.Deleted;
                dbContext.SaveChanges();
            }
        }

        [TestMethod]
        public void TestReadFxTradesForPeriod_OnlyForwardTradeOnLastDayOfMonth_TradeIsRead()
        {
            SetupEndOfDayDataProvider();
            SetDateAndTimeToAMonthWithANonWeekendLastDay(InternalTime.LocalNow());

            int portfolioId = GetLastPortfolioId();
            int secDefId = GetSecurityDefinitionId();
            (int from, int to) currencyIds = GetCurrencyIds(new Tuple<string, string>("USD", "JPY"));
            int firstNewFxTradeId = AddFxTrade(
                portfolioId,
                secDefId,
                currencyIds,
                FxProductTypes.Forward,
                TradeOrderStatus.Filled);
            int secondNewFxTradeId = AddFxTrade(
                portfolioId,
                secDefId,
                currencyIds,
                FxProductTypes.Spot,
                TradeOrderStatus.Cancelled);

            FxTradesDataProviderMssql fxTradesDataProviderMssql = GetFxTradesDataProviderMssql();
            List<FxTrade> allFx = fxTradesDataProviderMssql.ReadFilledFxTradesForCurrency(1);
            List<FxTrade> fxTrades = fxTradesDataProviderMssql.ReadFxTradesForPeriod(
                InternalTime.LocalToday(),
                InternalTime.LocalToday());

            DeleteFxTrade(firstNewFxTradeId);
            DeleteFxTrade(secondNewFxTradeId);

            Assert.IsNotNull(fxTrades);
            Assert.AreEqual(_numTradesInserted, allFx.Count);
            Assert.AreEqual(2, fxTrades.Count);
            Assert.AreEqual(firstNewFxTradeId, fxTrades.First().FxTradeId);
            Assert.AreEqual(secondNewFxTradeId, fxTrades.Last().FxTradeId);
        }
    }
}