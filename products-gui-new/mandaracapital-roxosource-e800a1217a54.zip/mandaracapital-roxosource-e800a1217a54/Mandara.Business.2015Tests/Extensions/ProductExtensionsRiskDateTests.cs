﻿using System;
using Mandara.Date;
using Mandara.Date.Time;
using Mandara.Entities;
using Mandara.Test.DateAndTime;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Mandara.Business.Extensions
{
    [TestClass]
    public class ProductExtensionsRiskDateTests
    {
        
        [TestMethod]
        public void TestRiskDate_FuturesProductWithExpiry_RiskDateIsExpiryTimeHoursBeforePresent()
        {
            DateTime now = DateTime.Now.AddHours(-1);
            const int futuresExpiresHourOfDay = 17;

            Product futures = new Product()
            {
                Type = ProductType.Futures,
                FuturesExpireTime = InternalTime.LocalToday().AddHours(futuresExpiresHourOfDay),
            };

            DateTime riskDate = futures.RiskDate(now);
            DateTime expectedRiskDate = now.AddHours(-futuresExpiresHourOfDay);

            Assert.IsTrue(
                EqualDownToSeconds(expectedRiskDate, riskDate),
                $"Expected {expectedRiskDate.ToShortDateAndTime()} to equal {riskDate.ToShortDateAndTime()}");
        }

        private static bool EqualDownToSeconds(DateTime lhs, DateTime rhs) => lhs.Year == rhs.Year
                                                                              && lhs.Month == rhs.Month
                                                                              && lhs.Day == rhs.Day
                                                                              && lhs.Hour == rhs.Hour
                                                                              && lhs.Minute == rhs.Minute
                                                                              && lhs.Second == rhs.Second;

        [TestMethod]
        public void TestRiskDate_FuturesProductWithoutExpiry_RiskDateIsNow()
        {
            DateTime now = DateTime.Now.AddHours(-1);

            Product futures = new Product() { Type = ProductType.Futures, };

            DateTime riskDate = futures.RiskDate(now);

            Assert.IsTrue(
                EqualDownToSeconds(now, riskDate),
                $"Expected {now.ToShortDateAndTime()} to equal {riskDate.ToShortDateAndTime()}");
        }

        [TestMethod]
        public void TestRiskDate_SwapProductWithoutRollOff_RiskDateIsNow()
        {
            DateTime now = DateTime.Now.AddHours(-1);

            Product swap = new Product() { Type = ProductType.Swap, };

            DateTime riskDate = swap.RiskDate(now);

            Assert.IsTrue(
                EqualDownToSeconds(now, riskDate),
                $"Expected {now.ToShortDateAndTime()} to equal {riskDate.ToShortDateAndTime()}");
        }

        [TestMethod]
        public void TestRiskDate_MocProductWithLocalTimeZone_RiskDateIsRollOffHoursBeforeNow()
        {
            DateTime now = DateTime.Now.AddHours(-1);
            const int rollOffHourOfDay = 17;

            Product swap = new Product()
            {
                // An MOC is a swap marked as being a TAS
                Type = ProductType.Swap, IsTasDb = true, RolloffTime = DateTime.MinValue.AddHours(rollOffHourOfDay),
            };

            DateTime riskDate = swap.RiskDate(now);
            DateTime expectedRiskDate = now.AddHours(-rollOffHourOfDay);

            Assert.IsTrue(
                EqualDownToSeconds(expectedRiskDate, riskDate),
                $"Expected {expectedRiskDate.ToShortDateAndTime()} to equal {riskDate.ToShortDateAndTime()}");
        }

        [TestMethod]
        public void TestRiskDate_MocProductWithForeignTimeZone_RiskDateIsLocalRollOffHoursBeforeNow()
        {
            DateTime now = DateTime.Now.AddHours(-1);
            const int rollOffHourOfDay = 17;
            TimeZoneInfo singaporeTime = TimeZoneInfo.FindSystemTimeZoneById("Singapore Standard Time");

            Product swap = new Product()
            {
                Type = ProductType.Swap,
                IsTasDb = true,
                RolloffTime = DateTime.MinValue.AddHours(rollOffHourOfDay),
                TimezoneId = singaporeTime.Id
            };

            DateTime riskDate = swap.RiskDate(now);

            DateTime expectedRiskDate =
                now.ToUniversalTime().AddHours(-(rollOffHourOfDay - singaporeTime.BaseUtcOffset.Hours));

            Assert.IsTrue(
                EqualDownToSeconds(expectedRiskDate, riskDate),
                $"Expected {expectedRiskDate.ToShortDateAndTime()} to equal {riskDate.ToShortDateAndTime()}");
        }

        [TestMethod]
        public void TestRiskDate_MopsProductWithLocalRollOffTime_RiskDateIsRollOffHoursBeforeNow()
        {
            DateTime now = DateTime.Now.AddHours(-1);
            const int rollOffHourOfDay = 17;

            Product swap = new Product()
            {
                Type = ProductType.Futures,
                IsMopsDb = true,
                RolloffTime = DateTime.MinValue.AddHours(rollOffHourOfDay),
            };

            DateTime riskDate = swap.RiskDate(now);
            DateTime expectedRiskDate = now;

            Assert.IsTrue(
                EqualDownToSeconds(expectedRiskDate, riskDate),
                $"Expected {expectedRiskDate.ToShortDateAndTime()} to equal {riskDate.ToShortDateAndTime()}");
        }

        [TestMethod]
        public void TestRiskDate_MopsProductWithForeignRollOffTime_RiskDateIsRollOffHoursBeforeNow()
        {
            DateTime now = DateTime.Now.AddHours(-1);
            const int rollOffHourOfDay = 17;
            TimeZoneInfo singaporeTime = TimeZoneInfo.FindSystemTimeZoneById("Singapore Standard Time");

            Product swap = new Product()
            {
                Type = ProductType.Futures,
                IsMopsDb = true,
                RolloffTime = DateTime.MinValue.AddHours(rollOffHourOfDay),
                TimezoneId = singaporeTime.Id
            };

            DateTime riskDate = swap.RiskDate(now);
            DateTime expectedRiskDate = now;

            Assert.IsTrue(
                EqualDownToSeconds(expectedRiskDate, riskDate),
                $"Expected {expectedRiskDate.ToShortDateAndTime()} to equal {riskDate.ToShortDateAndTime()}");
        }

        [TestMethod]
        public void TestRiskDate_MinuteMarkerProductWithLocalRollOffTime_RiskDateIsRollOffHoursBeforeNow()
        {
            DateTime now = DateTime.Now.AddHours(-1);
            const int rollOffHourOfDay = 17;

            Product swap = new Product()
            {
                Type = ProductType.Futures,
                IsMmDb = true,
                RolloffTime = DateTime.MinValue.AddHours(rollOffHourOfDay),
            };

            DateTime riskDate = swap.RiskDate(now);
            DateTime expectedRiskDate = now;

            Assert.IsTrue(
                EqualDownToSeconds(expectedRiskDate, riskDate),
                $"Expected {expectedRiskDate.ToShortDateAndTime()} to equal {riskDate.ToShortDateAndTime()}");
        }

        [TestMethod]
        public void TestRiskDate_MinuteMarkerProductWithForeignRollOffTime_RiskDateIsRollOffHoursBeforeNow()
        {
            DateTime now = DateTime.Now.AddHours(-1);
            const int rollOffHourOfDay = 17;
            TimeZoneInfo singaporeTime = TimeZoneInfo.FindSystemTimeZoneById("Singapore Standard Time");

            Product swap = new Product()
            {
                Type = ProductType.Futures,
                IsMmDb = true,
                RolloffTime = DateTime.MinValue.AddHours(rollOffHourOfDay),
                TimezoneId = singaporeTime.Id
            };

            DateTime riskDate = swap.RiskDate(now);
            DateTime expectedRiskDate = now;

            Assert.IsTrue(
                EqualDownToSeconds(expectedRiskDate, riskDate),
                $"Expected {expectedRiskDate.ToShortDateAndTime()} to equal {riskDate.ToShortDateAndTime()}");
        }

        [TestMethod]
        public void TestRiskDate_CalendarDaySwapOnFridayWithNoRollOff_RiskDateIsFollowingSunday()
        {
            DateTime now = Friday().AddHours(-1);

            Product swap = new Product()
            {
                Type = ProductType.Swap,
                IsCalendarDaySwap = true,
            };

            DateTime riskDate = swap.RiskDate(now);
            DateTime expectedRiskDate = now.AddDays(ProductExtensions.CalendarDaySwapDaysOffsetFromFriday).Date;

            Assert.IsTrue(
                EqualDownToSeconds(expectedRiskDate, riskDate),
                $"Expected {expectedRiskDate.ToShortDateAndTime()} to equal {riskDate.ToShortDateAndTime()}");
        }

        private static DateTime Friday()
        {
            switch (DateTime.Now.DayOfWeek)
            {
                case DayOfWeek.Friday:
                {
                    return DateTime.Now;
                }

                case DayOfWeek.Saturday:
                {
                    return DateTime.Now.AddDays(6);
                }

                default:
                {
                    return DateTime.Now.AddDays(-(DateTime.Now.DayOfWeek - DayOfWeek.Friday));
                }
            }
        }

        [TestMethod]
        public void TestRiskDate_CalendarDaySwapOnFridayBeforeRollOff_RiskDateIsThursdayNight()
        {
            const int rollOffHourOfDay = 17;
            DateTime now = Friday().Date.AddHours(rollOffHourOfDay - 1);

            Product swap = new Product()
            {
                Type = ProductType.Swap,
                IsCalendarDaySwap = true,
                RolloffTime = DateTime.MinValue.AddHours(rollOffHourOfDay),
            };

            DateTime riskDate = swap.RiskDate(now);
            DateTime expectedRiskDate = now.AddHours(-rollOffHourOfDay);

            Assert.IsTrue(
                EqualDownToSeconds(expectedRiskDate, riskDate),
                $"Expected {expectedRiskDate.ToShortDateAndTime()} to equal {riskDate.ToShortDateAndTime()}");
        }

        [TestMethod]
        public void TestRiskDate_CalendarDaySwapOnFridayAfterRollOff_RiskDateIsFollowingSunday()
        {
            const int rollOffHourOfDay = 17;
            DateTime now = Friday().Date.AddHours(rollOffHourOfDay + 1);

            Product swap = new Product()
            {
                Type = ProductType.Swap,
                IsCalendarDaySwap = true,
                RolloffTime = DateTime.MinValue.AddHours(rollOffHourOfDay),
            };

            DateTime riskDate = swap.RiskDate(now);
            DateTime expectedRiskDate = now.AddDays(ProductExtensions.CalendarDaySwapDaysOffsetFromFriday).Date;

            Assert.IsTrue(
                EqualDownToSeconds(expectedRiskDate, riskDate),
                $"Expected {expectedRiskDate.ToShortDateAndTime()} to equal {riskDate.ToShortDateAndTime()}");
        }
    }
}