﻿using Mandara.Entities;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Ninject.Extensions.Logging;
using System;

namespace Mandara.Business.Extensions
{
    [TestClass]
    public class ProductExtensionsTimeToUtcTests
    {
        private const string _utcName = "UTC";
        private const string _gmtName = "GMT Standard Time";
        private const string _euName = "Central European Standard Time";
        private const int _summerGmtOffset = -1;
        private const int _summerEuOffset = -2;
        private static readonly DateTime _summerTransactTime = new DateTime(2016, 8, 1, 12, 0, 0);
        private static readonly DateTime _winterTransactTime = new DateTime(2016, 2, 1, 12, 0, 0);
        private readonly Mock<ILogger> _log = new Mock<ILogger>();

        [TestMethod]
        public void TestConvertTransactTimeToUtc_UtcProductGivenSummerTransactTime_TransactTimeUnchanged()
        {
            DateTime convertedDateTime =
                ProductExtensions.ConvertTransactTimeToUtc(
                    _summerTransactTime,
                    CreateProductWithExchangeTimeZone(_utcName),
                    _log.Object);

            Assert.AreEqual(_summerTransactTime, convertedDateTime);
        }

        [TestMethod]
        public void TestConvertTransactTimeToUtc_UtcProductGivenWinterTransactTime_TransactTimeUnchanged()
        {
            DateTime convertedDateTime =
                ProductExtensions.ConvertTransactTimeToUtc(
                    _winterTransactTime,
                    CreateProductWithExchangeTimeZone(_utcName),
                    _log.Object);

            Assert.AreEqual(_winterTransactTime, convertedDateTime);
        }

        [TestMethod]
        public void TestConvertTransactTimeToUtc_GmtProductGivenSummerTransactTime_TransactTimeAdjusted()
        {
            DateTime convertedDateTime =
                ProductExtensions.ConvertTransactTimeToUtc(
                    _summerTransactTime,
                    CreateProductWithExchangeTimeZone(_gmtName),
                    _log.Object);

            Assert.AreEqual(_summerTransactTime.AddHours(_summerGmtOffset), convertedDateTime);
        }

        [TestMethod]
        public void TestConvertTransactTimeToUtc_GmtProductGivenWinterTransactTime_TransactTimeUnchanged()
        {
            DateTime convertedDateTime =
                ProductExtensions.ConvertTransactTimeToUtc(
                    _winterTransactTime,
                    CreateProductWithExchangeTimeZone(_gmtName),
                    _log.Object);

            Assert.AreEqual(_winterTransactTime, convertedDateTime);
        }

        [TestMethod]
        public void TestConvertTransactTimeToUtc_EuProductGivenSummerTransactTime_TransactTimeAdjusted()
        {
            DateTime convertedDateTime =
                ProductExtensions.ConvertTransactTimeToUtc(
                    _summerTransactTime,
                    CreateProductWithExchangeTimeZone(_euName),
                    _log.Object);

            Assert.AreEqual(_summerTransactTime.AddHours(_summerEuOffset), convertedDateTime);
        }

        [TestMethod]
        public void TestConvertTransactTimeToUtc_NullProductPassed_UtcNowReturned()
        {
            DateTime convertedDateTime =
                ProductExtensions.ConvertTransactTimeToUtc(
                    _summerTransactTime,
                    null,
                    _log.Object);

            Assert.IsTrue(convertedDateTime > DateTime.UtcNow.AddMinutes(-1) && convertedDateTime <= DateTime.UtcNow);
        }

        private Product CreateProductWithExchangeTimeZone(string timeZoneId)
        {
            return new Product()
            {
                Exchange = new Exchange()
                {
                    TimeZoneId = timeZoneId
                }
            };
        }
    }
}
