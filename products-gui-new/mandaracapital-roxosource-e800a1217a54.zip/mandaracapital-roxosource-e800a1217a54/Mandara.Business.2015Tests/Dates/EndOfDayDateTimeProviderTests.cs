﻿using Mandara.Business.DataInterface;
using Mandara.Date;
using Mandara.Date.Time;
using Mandara.Extensions.Option;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using Mandara.Test.DateAndTime;
using Optional;

namespace Mandara.Business.Dates
{
    [TestClass]
    public class EndOfDayDateTimeProviderTests
    {
        private static DateTime _fridayEodTime;
        private static DateTime _saturdayEodTime;
        private static DateTime _sundayEodTime;
        private static DateTime _mondayEodTime;
        private static DateTime _wednesdayEodTime;
        private static DateTime _monday;
        private static DateTime _tuesday;
        private static DateTime _now;

        private EndOfDayDateTimeProvider _endOfDayDateTimes;

        [ClassInitialize]
        public static void SetUpDates(TestContext _)
        {
            DateTime today = DateTime.Today;

            switch (today.DayOfWeek)
            {
                case DayOfWeek.Monday:
                {
                    _monday = today.Date;
                }
                break;

                case DayOfWeek.Sunday:
                {
                    _monday = today.AddDays(1).Date;
                }
                break;

                default:
                {
                    _monday = today.AddDays(-(int)today.DayOfWeek + 1);
                }
                break;
            }

            _now = _monday.AddHours(12);
            _tuesday = _monday.AddDays(1);
            _fridayEodTime = _monday.AddDays(-3).AddHours(20);
            _saturdayEodTime = _monday.AddDays(-2).AddHours(20);
            _sundayEodTime = _monday.AddDays(-1).AddHours(20);
            _mondayEodTime = _monday.AddHours(20);
            _wednesdayEodTime = _monday.AddDays(2).AddHours(20);
        }

        [TestInitialize]
        public void TestInitialise()
        {
            Mock<IPnlEodTimesDataProvider> pnlEoDDataProvider = SetUpMockPnLEoDDataProvider();

            _endOfDayDateTimes = new EndOfDayDateTimeProvider(pnlEoDDataProvider.Object);
            SystemTimeForTest.SupercedeNow(() => _now);
        }

        private static Mock<IPnlEodTimesDataProvider> SetUpMockPnLEoDDataProvider()
        {
            Mock<IPnlEodTimesDataProvider> pnlEodDataProvMock = new Mock<IPnlEodTimesDataProvider>();

            pnlEodDataProvMock.Setup(x => x.GetPnlEodTimes(It.IsAny<int>())).Returns(GetEodTimesDict());
            return pnlEodDataProvMock;
        }

        [TestCleanup]
        public void CleanUpAfterTest()
        {
            SystemTimeForTest.Reset();
        }

        [TestMethod]
        public void TestGetLiveUtcEodDateRange_FromFridayEodToTuesdayReturned()
        {
            DateRange liveUtcEodDateRange = _endOfDayDateTimes.GetLiveUtcEodDateRange();

            Assert.IsTrue(liveUtcEodDateRange.HasStartDate());
            Assert.IsTrue(liveUtcEodDateRange.HasEndDate());
            Assert.AreEqual(_fridayEodTime.ToUniversalTime(), liveUtcEodDateRange.Start);
            Assert.AreEqual(_tuesday.ToUniversalTime(), liveUtcEodDateRange.End);
        }

        [TestMethod]
        public void TestGetDateRangeAccordingToEodTimes_DefaultDateRange_DefaultDateRangeReturned()
        {
            DateRange eodDateRange = _endOfDayDateTimes.GetUtcDateRangeAccordingToEodTimes(DateRange.Default);

            Assert.IsTrue(eodDateRange.IsDefault());
        }

        [TestMethod]
        public void TestGetDateRangeAccordingToEodTimes_FromDefaultStartToMonday_DefaultStartToMondayEodReturned()
        {
            DateRange eodDateRange =
                _endOfDayDateTimes.GetUtcDateRangeAccordingToEodTimes(new DateRange(DateRange.DefaultStart, _monday));

            Assert.IsFalse(eodDateRange.HasStartDate());
            Assert.IsTrue(eodDateRange.HasEndDate());
            Assert.AreEqual(_mondayEodTime.ToUniversalTime(), eodDateRange.End);
        }

        [TestMethod]
        public void TestGetDateRangeAccordingToEodTimes_FromMondayToDefaultEnd_DefaultStartToMondayEodReturned()
        {
            DateRange eodDateRange =
                _endOfDayDateTimes.GetUtcDateRangeAccordingToEodTimes(new DateRange(_monday, DateRange.DefaultEnd));

            Assert.IsTrue(eodDateRange.HasStartDate());
            Assert.IsFalse(eodDateRange.HasEndDate());
            Assert.AreEqual(_fridayEodTime.ToUniversalTime(), eodDateRange.Start);
        }

        [TestMethod]
        public void TestGetDateRangeAccordingToEodTimes_FromTuesdayToWednesday_FromMondayEodToWednesdayReturned()
        {
            DateRange dateRange = new DateRange(_tuesday, _tuesday.AddDays(1));
            DateRange eodDateRange = _endOfDayDateTimes.GetUtcDateRangeAccordingToEodTimes(dateRange);

            Assert.IsTrue(eodDateRange.HasStartDate());
            Assert.IsTrue(eodDateRange.HasEndDate());
            Assert.AreEqual(_mondayEodTime.ToUniversalTime(), eodDateRange.Start);
            Assert.AreEqual(dateRange.End.ToUniversalTime(), eodDateRange.End);
        }

        [TestMethod]
        public void TestGetDateRangeAccordingToEodTimes_FromSundayToMonday_PrevDaysEodReturned()
        {
            DateRange eodDateRange =
                _endOfDayDateTimes.GetUtcDateRangeAccordingToEodTimes(new DateRange(_monday.AddDays(-1), _monday));

            Assert.IsTrue(eodDateRange.HasStartDate());
            Assert.IsTrue(eodDateRange.HasEndDate());
            Assert.AreEqual(_fridayEodTime.ToUniversalTime(), eodDateRange.Start);
            Assert.AreEqual(_mondayEodTime.ToUniversalTime(), eodDateRange.End);
        }

        [TestMethod]
        public void TestGetPrevBusinessDayEodDatetime_ForMondayWhenFridayEodExist_FridayEodTimeReturned()
        {
            DateTime eodDatetime = _endOfDayDateTimes.GetPrevBusinessDayEod(_mondayEodTime).ValueOr(DateTime.MinValue);

            Assert.AreEqual(_fridayEodTime, eodDatetime);
        }

        [TestMethod]
        public void TestGetPrevBusinessDayEodDatetime_ForFridayWhenNoPrevEodDate_EodTimeNotFound()
        {
            Option<DateTime> eodDatetime = _endOfDayDateTimes.GetPrevBusinessDayEod(_fridayEodTime);

            Assert.IsFalse(eodDatetime.HasValue);
        }

        [TestMethod]
        public void
            TestGetPrevBusinessDayEodDatetime_ForWednesdayWhenNoTuesdayEodButMondayEodExist_MondayEodTimeReturned()
        {
            DateTime eodDatetime = _endOfDayDateTimes.GetPrevBusinessDayEod(_wednesdayEodTime)
                                                     .ValueOr(DateTime.MinValue);

            Assert.AreEqual(_mondayEodTime, eodDatetime);
        }

        private static Dictionary<DateTime, DateTime> GetEodTimesDict()
        {
            return new Dictionary<DateTime, DateTime>
            {
                { _fridayEodTime.Date, _fridayEodTime },
                { _saturdayEodTime.Date, _saturdayEodTime },
                { _sundayEodTime.Date, _sundayEodTime },
                { _mondayEodTime.Date, _mondayEodTime },
            };
        }
    }
}