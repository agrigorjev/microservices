﻿using Mandara.Business.Bus.Messages.TradeAdd;
using Mandara.Business.Contracts;
using Mandara.Business.TradeAdd;
using Mandara.Data;
using Mandara.Date.Time;
using Mandara.Entities;
using Mandara.Extensions.Option;
using Mandara.Test.EntityBuilders;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Mandara.Business.Bus
{
    [TestClass()]
    public class TradeAddHandlerConverterTests
    {
        private readonly Mock<ITradeAddHandlerConverterProvider> _tradeAddConverterProvider =
            new Mock<ITradeAddHandlerConverterProvider>();
        private readonly Mock<IOfficialProductToInstrument> _mockOfficialProdToInstrument =
            new Mock<IOfficialProductToInstrument>();
        private readonly Mock<IProductsStorage> _mockProductsStore = new Mock<IProductsStorage>();
        private readonly Mock<ISecurityDefinitionsStorage> _mockSecDefStore = new Mock<ISecurityDefinitionsStorage>();
        private DateTime _tradeDate;
        private DateTime _tradeTime;
        private OfficialProduct _dummyOffProd;
        private TradeCapture _baseTrade;
        private readonly ProductBuilder _prodBuilder = new ProductBuilder();
        private ITradeAddHandlerConverter _tradeAddConverter;

        [TestInitialize]
        public void PrepareTestEnvironment()
        {
            PrepareTestData();
            CreateTradeAddConverter();
        }

        private void PrepareTestData()
        {
            _tradeDate = InternalTime.LocalToday();
            _tradeTime = InternalTime.LocalNow();
            _dummyOffProd = CreateOfficialProduct();

            SetUpMockProductsStore(_dummyOffProd);
            SetUpMockOfficialProductToInstrument(_dummyOffProd);
            _baseTrade = CreateManualSwapTradeCapture(_tradeDate, _tradeTime, _dummyOffProd);
            SetUpMockSecurityDefinitionStore(_baseTrade.SecurityDefinition);
        }

        private static OfficialProduct CreateOfficialProduct()
        {
            OfficialProductBuilder offProdBuilder = new OfficialProductBuilder();
            Currency dummyCurrency = new Currency() { CurrencyId = 1, IsoName = "AHC" };

            return offProdBuilder.BuildOfficialProduct(1, "DummyConvertOffProd", dummyCurrency, "convOff");
        }

        private void SetUpMockProductsStore(OfficialProduct dummyOffProd)
        {
            _mockProductsStore.Setup(prodStore => prodStore.TryGetOfficialProduct(It.IsAny<int>())).Returns<int>(
                (offProdId) =>
                {
                    OfficialProduct offProd = null;

                    if (1 == offProdId)
                    {
                        offProd = dummyOffProd;
                    }

                    return new TryGetRef<OfficialProduct>(offProd);
                });
        }

        private void SetUpMockSecurityDefinitionStore(SecurityDefinition secDef)
        {
            _mockSecDefStore.Setup(secDefStore => secDefStore.TryGetSecurityDefinition(It.IsAny<int>()))
                            .Returns<int>(
                                secDefId =>
                                {
                                    if (secDefId == secDef.SecurityDefinitionId)
                                    {
                                        return new TryGetRef<SecurityDefinition>(secDef);
                                    }

                                    return new TryGetRef<SecurityDefinition>((SecurityDefinition)null);
                                });
        }

        private void SetUpMockOfficialProductToInstrument(OfficialProduct dummyOffProd)
        {
            Exchange dummyExch = new Exchange() { ExchangeId = 1, Name = "ConvExch", CalendarId = 1, };
            _mockOfficialProdToInstrument.Setup(
                prodToInstr => prodToInstr.ConvertOfficialProductToInstrument(It.IsAny<OfficialProduct>()))
                                         .Returns(
                                             new Instrument()
                                             {
                                                 Id = 1,
                                                 AvailableUnits = new List<int>() { ProductBuilder.Kiloton.UnitId },
                                                 Name = "ConvInstrument",
                                                 Currency = dummyOffProd.Currency.IsoName,
                                                 Exchanges = new List<string>() { dummyExch.Name },
                                                 HasBalmo = false,
                                                 HasDailyDiffs = false,
                                                 HasDailySwaps = false,
                                                 HasFutures = true,
                                                 HasMm = false,
                                                 HasMops = false,
                                                 HasTas = true,
                                                 IsCalcPnlFromLegs = false,
                                             });
        }

        private TradeCapture CreateManualSwapTradeCapture(DateTime tradeDate, DateTime tradeTime, OfficialProduct dummyOffProd)
        {
            Product dummyProd = _prodBuilder.Build(1, ProductType.Swap, "DummyConvertProduct", dummyOffProd);
            SecurityDefinition dummySecDef = new SecurityDefinition()
            {
                SecurityDefinitionId = 1,
                Product = dummyProd,
                StripName = InternalTime.LocalNow().AddMonths(2).ToString("MMMyy"),
            };
            Portfolio dummyPortfolio = new Portfolio()
            {
                PortfolioId = 1,
                IsErrorBook = false,
                Name = "ConvPortfolio",
                CreatedAt = InternalTime.UtcNow().AddDays(-10),
                CreatedBy = "TradeAddHdlConvTests",
            };

            TradeCapture manualSwap = new TradeCaptureBuilder().Build(1, dummySecDef, 10.0M);

            manualSwap.TradeDate = tradeDate;
            manualSwap.TimeStamp = tradeTime;
            manualSwap.TransactTime = tradeTime;
            manualSwap.TradeType = (int)TradeTypeControl.Manual;
            manualSwap.Side = TradeCaptureSide.Buy.GetDescription();
            manualSwap.Price = 50.0M;
            manualSwap.Portfolio = dummyPortfolio;
            return manualSwap;
        }

        private void CreateTradeAddConverter()
        {
            _tradeAddConverter = new TradeAddHandlerConverter(
                _tradeAddConverterProvider.Object,
                _mockOfficialProdToInstrument.Object);
        }

        [TestMethod()]
        public void TestConvertTradeCaptureToTradeAddDetails_NonDuplicateMode_TradeIdsAndTimesCopiedToTradeAdd()
        {
            TradeAddDetails tradeAdd = _tradeAddConverter.ConvertTradeCaptureToTradeAddDetails(
                OfficialProductFromSecDefId,
                (nonFxTradeId) => new TryGetRef<FxTrade>(),
                new List<TradeCapture>() { _baseTrade },
                _tradeAddConverter.GetActionSetTradeDetailsFromParent(false)).Value;

            Assert.AreEqual(1, tradeAdd.TradeCaptureIds.Count);
            Assert.AreEqual(1, tradeAdd.TradeCaptureIds.First());
            Assert.AreEqual(null, tradeAdd.GroupId);
            Assert.AreEqual(_tradeDate, tradeAdd.TradeDate);
            Assert.AreEqual(_tradeTime.ToUniversalTime(), tradeAdd.TimestampUtc);
            Assert.AreEqual(_tradeTime.ToUniversalTime(), tradeAdd.TransactTimeUtc);
        }

        private TryGetResult<OfficialProduct> OfficialProductFromSecDefId(int secDefId)
        {
            TryGetResult<SecurityDefinition> secDef = _mockSecDefStore.Object.TryGetSecurityDefinition(secDefId);

            if (secDef.HasValue)
            {
                return _mockProductsStore.Object.TryGetOfficialProduct(secDef.Value.Product.OfficialProductId);
            }

            return new TryGetRef<OfficialProduct>((OfficialProduct)null);
        }

        [TestMethod()]
        public void TestConvertTradeCaptureToTradeAddDetails_DuplicateMode_TradeIdsAndTimesNotPresentInTradeAdd()
        {
            TradeAddDetails tradeAdd = _tradeAddConverter.ConvertTradeCaptureToTradeAddDetails(
                OfficialProductFromSecDefId,
                (nonFxTradeId) => new TryGetRef<FxTrade>(),
                new List<TradeCapture>() { _baseTrade },
                _tradeAddConverter.GetActionSetTradeDetailsFromParent(true)).Value;

            Assert.AreEqual(null, tradeAdd.TradeCaptureIds);
            Assert.AreEqual(null, tradeAdd.GroupId);
            Assert.AreEqual(null, tradeAdd.TradeDate);
            Assert.AreEqual(null, tradeAdd.TimestampUtc);
            Assert.AreEqual(null, tradeAdd.TransactTimeUtc);
        }
    }
}