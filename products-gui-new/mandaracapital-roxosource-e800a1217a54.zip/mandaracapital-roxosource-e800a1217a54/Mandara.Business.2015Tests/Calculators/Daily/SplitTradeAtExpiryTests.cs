﻿using Mandara.Business.OldCode;
using Mandara.Entities;
using Mandara.Extensions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Mandara.Business.Calculators.Daily
{
    /// <summary>
    /// Summary description for SplitTradeAtExpiryTests
    /// </summary>
    [TestClass]
    public class SplitTradeAtExpiryTests
    {
        private static readonly DateTime BaseDate = new DateTime(2018, 10, 29);

        private const int AddDaysForWeek = 4;
        private const int DaysBeforeExpiry = 2;
        private const int DaysAfterExpriy = AddDaysForWeek - DaysBeforeExpiry;

        private static readonly List<DateTime> FullWeek =
            EnumerateDateRange.Range(BaseDate, BaseDate.AddDays(AddDaysForWeek)).ToList();
        private static readonly DateTime ExpiryDate = BaseDate.AddDays(DaysBeforeExpiry);
        private static readonly List<DateTime> OnlyBeforeExpiry =
            EnumerateDateRange.Range(BaseDate, ExpiryDate.AddDays(-1)).ToList();
        private static readonly List<DateTime> AfterAndIncludingExpiry =
            EnumerateDateRange.Range(ExpiryDate, ExpiryDate.AddDays(DaysAfterExpriy)).ToList();
        private static readonly List<DateTime> StrictlyAfterExpiry =
            EnumerateDateRange.Range(ExpiryDate.AddDays(1), ExpiryDate.AddDays(DaysAfterExpriy)).ToList();

        private const decimal TradeQuantity = 10M;
        private const decimal CalculationQuantity = TradeQuantity * 100M;
        private SourceDetail _trade;
        private CalculationContext _context;

        [TestInitialize]
        public void PrepareTradeAndContext()
        {
            CreateTrade();
            CreateCalculationContext();
        }

        private void CreateTrade()
        {
            _trade = new SourceDetail()
            {
                TradeCapture =
                    new TradeCapture()
                    {
                        Quantity = TradeQuantity,
                        TradeStartDate = FullWeek.First(),
                        TradeEndDate = FullWeek.Last(),
                    },
                Quantity = 1M,
                BusinessDays1 = FullWeek,
            };
        }

        private void CreateCalculationContext()
        {
            _context = new CalculationContext() { Quantity = CalculationQuantity, };
        }

        [TestMethod]
        public void TestSplitTrade_ExpiryDuringRange_SplitAtExpiryDate()
        {
            SplitTradeAtExpiry tradeSplit = new SplitTradeAtExpiry(_trade, _context, ExpiryDate);
            decimal percentageBeforeExp = (decimal)DaysBeforeExpiry / FullWeek.Count;

            Assert.AreEqual(DaysBeforeExpiry, tradeSplit.DaysBeforeExpiry.Count());
            Assert.AreEqual(BaseDate, tradeSplit.DaysBeforeExpiry.First());
            Assert.AreEqual(ExpiryDate.AddDays(-1), tradeSplit.DaysBeforeExpiry.Last());
            Assert.AreEqual(1 + DaysAfterExpriy, tradeSplit.DaysFromExpiry.Count());
            Assert.AreEqual(ExpiryDate, tradeSplit.DaysFromExpiry.First());
            Assert.AreEqual(FullWeek.Last(), tradeSplit.DaysFromExpiry.Last());
            Assert.AreEqual(percentageBeforeExp * TradeQuantity, tradeSplit.TradeQuantityBeforeExpiry);
            Assert.AreEqual((1 - percentageBeforeExp) * TradeQuantity, tradeSplit.TradeQuantityFromExpiry);
            Assert.AreEqual(percentageBeforeExp * CalculationQuantity, tradeSplit.CalculationQuantityBeforeExpiry);
            Assert.AreEqual((1 - percentageBeforeExp) * CalculationQuantity, tradeSplit.CalculationQuantityFromExpiry);
        }

        [TestMethod]
        public void TestSplitTrade_ExpiryAfterRange_OnlyBeforeExpiryPresent()
        {
            _trade.BusinessDays1 = OnlyBeforeExpiry;
            _trade.TradeCapture.TradeEndDate = OnlyBeforeExpiry.Last();
            SplitTradeAtExpiry tradeSplit = new SplitTradeAtExpiry(_trade, _context, ExpiryDate);

            Assert.AreEqual(DaysBeforeExpiry, tradeSplit.DaysBeforeExpiry.Count());
            Assert.AreEqual(BaseDate, tradeSplit.DaysBeforeExpiry.First());
            Assert.AreEqual(ExpiryDate.AddDays(-1), tradeSplit.DaysBeforeExpiry.Last());
            Assert.AreEqual(0, tradeSplit.DaysFromExpiry.Count());
            Assert.AreEqual(TradeQuantity, tradeSplit.TradeQuantityBeforeExpiry);
            Assert.AreEqual(0M, tradeSplit.TradeQuantityFromExpiry);
            Assert.AreEqual(CalculationQuantity, tradeSplit.CalculationQuantityBeforeExpiry);
            Assert.AreEqual(0M, tradeSplit.CalculationQuantityFromExpiry);
        }

        [TestMethod]
        public void TestSplitTrade_ExpiryBeforeRange_OnlyAfterExpiryPresent()
        {
            _trade.BusinessDays1 = StrictlyAfterExpiry;
            _trade.TradeCapture.TradeEndDate = StrictlyAfterExpiry.Last();
            SplitTradeAtExpiry tradeSplit = new SplitTradeAtExpiry(_trade, _context, ExpiryDate);

            Assert.AreEqual(0, tradeSplit.DaysBeforeExpiry.Count());
            Assert.AreEqual(StrictlyAfterExpiry.Count, tradeSplit.DaysFromExpiry.Count());
            Assert.AreEqual(StrictlyAfterExpiry.First(), tradeSplit.DaysFromExpiry.First());
            Assert.AreEqual(StrictlyAfterExpiry.Last(), tradeSplit.DaysFromExpiry.Last());
            Assert.AreEqual(0M, tradeSplit.TradeQuantityBeforeExpiry);
            Assert.AreEqual(TradeQuantity, tradeSplit.TradeQuantityFromExpiry);
            Assert.AreEqual(0M, tradeSplit.CalculationQuantityBeforeExpiry);
            Assert.AreEqual(CalculationQuantity, tradeSplit.CalculationQuantityFromExpiry);
        }

        [TestMethod]
        public void TestSplitTrade_RangeStartsAtExpiry_OnlyAfterExpiryPresent()
        {
            _trade.BusinessDays1 = AfterAndIncludingExpiry;
            _trade.TradeCapture.TradeEndDate = AfterAndIncludingExpiry.Last();
            SplitTradeAtExpiry tradeSplit = new SplitTradeAtExpiry(_trade, _context, ExpiryDate);

            Assert.AreEqual(0, tradeSplit.DaysBeforeExpiry.Count());
            Assert.AreEqual(AfterAndIncludingExpiry.Count, tradeSplit.DaysFromExpiry.Count());
            Assert.AreEqual(AfterAndIncludingExpiry.First(), tradeSplit.DaysFromExpiry.First());
            Assert.AreEqual(AfterAndIncludingExpiry.Last(), tradeSplit.DaysFromExpiry.Last());
            Assert.AreEqual(0M, tradeSplit.TradeQuantityBeforeExpiry);
            Assert.AreEqual(TradeQuantity, tradeSplit.TradeQuantityFromExpiry);
            Assert.AreEqual(0M, tradeSplit.CalculationQuantityBeforeExpiry);
            Assert.AreEqual(CalculationQuantity, tradeSplit.CalculationQuantityFromExpiry);
        }

        [TestMethod]
        public void TestSplitTrade_OnlyExpiryInRange_OnlyAfterExpiryPresent()
        {
            _trade.BusinessDays1 = new List<DateTime>() { ExpiryDate };
            _trade.TradeCapture.TradeStartDate = ExpiryDate;
            _trade.TradeCapture.TradeEndDate = ExpiryDate;
            SplitTradeAtExpiry tradeSplit = new SplitTradeAtExpiry(_trade, _context, ExpiryDate);

            Assert.AreEqual(0, tradeSplit.DaysBeforeExpiry.Count());
            Assert.AreEqual(1, tradeSplit.DaysFromExpiry.Count());
            Assert.AreEqual(ExpiryDate, tradeSplit.DaysFromExpiry.First());
            Assert.AreEqual(ExpiryDate, tradeSplit.DaysFromExpiry.Last());
            Assert.AreEqual(0M, tradeSplit.TradeQuantityBeforeExpiry);
            Assert.AreEqual(TradeQuantity, tradeSplit.TradeQuantityFromExpiry);
            Assert.AreEqual(0M, tradeSplit.CalculationQuantityBeforeExpiry);
            Assert.AreEqual(CalculationQuantity, tradeSplit.CalculationQuantityFromExpiry);
        }

        [TestMethod]
        public void TestSplitTrade_OneDayBeforeAndExpiry_DataSplitInHalf()
        {
            _trade.BusinessDays1 = new List<DateTime>() { ExpiryDate.AddDays(-1), ExpiryDate };
            _trade.TradeCapture.TradeStartDate = _trade.BusinessDays1.First();
            _trade.TradeCapture.TradeEndDate = ExpiryDate;
            SplitTradeAtExpiry tradeSplit = new SplitTradeAtExpiry(_trade, _context, ExpiryDate);

            Assert.AreEqual(1, tradeSplit.DaysBeforeExpiry.Count());
            Assert.AreEqual(_trade.BusinessDays1.First(), tradeSplit.DaysBeforeExpiry.First());
            Assert.AreEqual(_trade.BusinessDays1.First(), tradeSplit.DaysBeforeExpiry.Last());
            Assert.AreEqual(1, tradeSplit.DaysFromExpiry.Count());
            Assert.AreEqual(ExpiryDate, tradeSplit.DaysFromExpiry.First());
            Assert.AreEqual(ExpiryDate, tradeSplit.DaysFromExpiry.Last());
            Assert.AreEqual(TradeQuantity / 2M, tradeSplit.TradeQuantityBeforeExpiry);
            Assert.AreEqual(TradeQuantity / 2M, tradeSplit.TradeQuantityFromExpiry);
            Assert.AreEqual(CalculationQuantity / 2M, tradeSplit.CalculationQuantityBeforeExpiry);
            Assert.AreEqual(CalculationQuantity / 2M, tradeSplit.CalculationQuantityFromExpiry);
        }
    }
}
