﻿using Mandara.Entities.Enums;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Globalization;
using Mandara.Date.Time;

namespace Mandara.Business.Calculators
{
    [TestClass()]
    public class ContractSizeCalculatorTests
    {
        [TestMethod()]
        public void Test_ApplyContractSizeMultiplier_Daily()
        {
            decimal baseAmount = 10.0M;
            DateTime now = SystemTime.Now();
            int daysInMonth = GetDaysInMonth(now);
            decimal unitBasedAmount =
                ContractSizeCalculator.ApplyContractSizeMultiplier(
                    baseAmount,
                    ContractSizeMultiplier.Daily,
                    now);

            Assert.AreEqual(daysInMonth * baseAmount, unitBasedAmount);
        }

        private int GetDaysInMonth(DateTime date)
        {
            return DateTime.DaysInMonth(date.Year, date.Month);
        }

        [TestMethod()]
        public void Test_ApplyContractSizeMultiplier_Hourly()
        {
            decimal baseAmount = 10.0M;
            DateTime now = new DateTime(2016, 3, 5);//SystemTime.Now();
            int hoursInMonth = GetHoursInMonth(now);
            decimal adjustedAmount =
                ContractSizeCalculator.ApplyContractSizeMultiplier(
                    baseAmount,
                    ContractSizeMultiplier.Hourly,
                    now);

            Assert.AreEqual(hoursInMonth * baseAmount, adjustedAmount);
        }

        private int GetHoursInMonth(DateTime date)
        {
            int daysInMonth = GetDaysInMonth(date);
            TimeZoneInfo timeZoneInfo = TimeZoneInfo.Local;

            if (!timeZoneInfo.SupportsDaylightSavingTime)
            {
                return daysInMonth * 24;
            }

            TimeZone currentTimeZone = TimeZone.CurrentTimeZone;
            DaylightTime daylightSavingsBoundaries = currentTimeZone.GetDaylightChanges(date.Year);

            if (daylightSavingsBoundaries.Start.Month == date.Month)
            {
                return daysInMonth * 24 - 1;
            }
            else if (daylightSavingsBoundaries.End.Month == date.Month)
            {
                return daysInMonth * 24 + 1;
            }

            return daysInMonth * 24;
        }
    }
}