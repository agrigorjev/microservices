﻿using Mandara.Extensions.Option;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace Mandara.Business.Calculators
{
    [TestClass]
    public class StartDateFromStripNameCalculatorTests
    {

        [TestMethod]
        public void TestStripToStartDateCalculator_CalStripGiven_JanFirstResultGiven()
        {
            TryGetResult<DateTime> startDate = StartDateFromStripNameCalculator.StripToStartDate("Cal17");
            Assert.IsTrue(startDate.HasValue);
            Assert.AreEqual(new DateTime(2017, 1, 1), startDate.Value);
            Assert.IsTrue(StartDateFromStripNameCalculator.IsQOrCal("Cal17"));
        }

        [TestMethod]
        public void TestStripToStartDateCalculator_QStripGiven_JanFirstResultGiven()
        {
            TryGetResult<DateTime> startDate = StartDateFromStripNameCalculator.StripToStartDate("Q117");
            Assert.IsTrue(startDate.HasValue);
            Assert.AreEqual(new DateTime(2017, 1, 1), startDate.Value);
            Assert.IsTrue(StartDateFromStripNameCalculator.IsQOrCal("Q117"));
        }

        [TestMethod]
        public void TestStripToStartDateCalculator_QStripGiven_SepFirstResultGiven()
        {
            TryGetResult<DateTime> startDate = StartDateFromStripNameCalculator.StripToStartDate("Q416");
            Assert.IsTrue(startDate.HasValue);
            Assert.AreEqual(new DateTime(2016, 10, 1), startDate.Value);
            Assert.IsTrue(StartDateFromStripNameCalculator.IsQOrCal("Q416"));
        }

        [TestMethod]
        public void TestStripToStartDateCalculator_MonthlyStripGiven_JanFirstResultGiven()
        {
            TryGetResult<DateTime> startDate = StartDateFromStripNameCalculator.StripToStartDate("F19");
            Assert.IsTrue(startDate.HasValue);
            Assert.AreEqual(new DateTime(2019, 1, 1), startDate.Value);
            Assert.IsFalse(StartDateFromStripNameCalculator.IsQOrCal("F19"));
        }

        [TestMethod]
        public void TestStripToStartDateCalculator_MonthlyStripGiven_DecFirstResultGiven()
        {
            TryGetResult<DateTime> startDate = StartDateFromStripNameCalculator.StripToStartDate("Z18");
            Assert.IsTrue(startDate.HasValue);
            Assert.AreEqual(new DateTime(2018, 12, 1), startDate.Value);
            Assert.IsFalse(StartDateFromStripNameCalculator.IsQOrCal("Z18"));
        }

        [TestMethod]
        public void TestStripToStartDateCalculator_IncorrectStripGivenWithCorrectCharacterCount_NoValueReturned()
        {
            TryGetResult<DateTime> startDate = StartDateFromStripNameCalculator.StripToStartDate("T17");
            Assert.IsFalse(startDate.HasValue);
            Assert.IsFalse(StartDateFromStripNameCalculator.IsQOrCal("T17"));
        }

        [TestMethod]
        public void TestStripToStartDateCalculator_IncorrectStripGivenWithCorrectMonthButIncorrectYear_NoValueReturned()
        {
            TryGetResult<DateTime> startDate = StartDateFromStripNameCalculator.StripToStartDate("Z2017");
            Assert.IsFalse(startDate.HasValue);
            Assert.IsFalse(StartDateFromStripNameCalculator.IsQOrCal("Z2017"));
        }

        [TestMethod]
        public void TestStripToStartDateCalculator_IncorrectStripGivenWithQuarter5_NoValueReturned()
        {
            TryGetResult<DateTime> startDate = StartDateFromStripNameCalculator.StripToStartDate("Q517");
            Assert.IsFalse(startDate.HasValue);
            Assert.IsFalse(StartDateFromStripNameCalculator.IsQOrCal("Q517"));
        }

        [TestMethod]
        public void TestStripToStartDateCalculator_IncorrectStripGivenWithQuarter0_NoValueReturned()
        {
            TryGetResult<DateTime> startDate = StartDateFromStripNameCalculator.StripToStartDate("Q017");
            Assert.IsFalse(startDate.HasValue);
            Assert.IsFalse(StartDateFromStripNameCalculator.IsQOrCal("Q017"));
        }

        [TestMethod]
        public void TestStripToStartDateCalculator_NullStripGiven_NoValueReturned()
        {
            TryGetResult<DateTime> startDate = StartDateFromStripNameCalculator.StripToStartDate(null);
            Assert.IsFalse(startDate.HasValue);
            Assert.IsFalse(StartDateFromStripNameCalculator.IsQOrCal(null));
        }

        [TestMethod]
        public void TestStripToStartDateCalculator_EmptyStripGiven_NoValueReturned()
        {
            TryGetResult<DateTime> startDate = StartDateFromStripNameCalculator.StripToStartDate("");
            Assert.IsFalse(startDate.HasValue);
            Assert.IsFalse(StartDateFromStripNameCalculator.IsQOrCal(""));
        }

        [TestMethod]
        public void TestStripToStartDateCalculator_NegativeYearStrip_NoValueReturned()
        {
            TryGetResult<DateTime> startDate = StartDateFromStripNameCalculator.StripToStartDate("Cal-1");
            Assert.IsFalse(startDate.HasValue);
            Assert.IsFalse(StartDateFromStripNameCalculator.IsQOrCal("Cal-1"));
        }


    }
}
