﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Linq;
using Mandara.Business.OldCode;
using Mandara.Date;
using Mandara.Date.Time;
using Mandara.Entities;
using Mandara.Test.DateAndTime;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MoreLinq;

namespace Mandara.Business.Calculators.Prices
{
    [TestClass]
    public class SnapshotPriceGetterTests
    {
        private static DataTable _prices;
        private const int NumMonths = 12;
        private const int FirstMonth = 72;
        private const string EpochColumn = "sdate";
        private const string Month = "rdate";
        private static SnapshotPriceGetter _snapshotPrices;

        [ClassInitialize]
        public static void SetUpPrices(TestContext ignore)
        {
            DateTime snapshotDate = DateTime.Now;

            SystemTimeForTest.SupercedeNow(() => snapshotDate);
            _prices = new DataTable("dummyprices");

            CreatePriceRows(CreatePriceColumns());
            _snapshotPrices = new SnapshotPriceGetter(_prices, snapshotDate);
        }

        private static List<string> CreatePriceColumns()
        {
            List<string> columns = Enumerable.Range(1, 10).Select(GetPriceColumn).ToList();

            DataColumn epoch = _prices.Columns.Add(EpochColumn);

            epoch.DataType = typeof(int);
            // _prices.Columns["sdate"] = EpochConverter.ToEpochTime(InternalTime.LocalNow());

            DataColumn monthOffset = _prices.Columns.Add(Month);

            monthOffset.DataType = typeof(int);
            _prices.PrimaryKey = new[] { epoch, monthOffset };

            columns.ForEach(
                colName =>
                {
                    DataColumn priceCol = _prices.Columns.Add(colName);
                    priceCol.DataType = typeof(double);
                });

            return columns;
        }

        private static string GetPriceColumn(int productNumber)
        {
            return $"r{productNumber}";
        }

        private static void CreatePriceRows(List<string> columns)
        {
            int snapshotDate = EpochConverter.ToEpochTime(InternalTime.LocalNow());

            Enumerable.Range(FirstMonth, NumMonths)
                      .ForEach(
                          month =>
                          {
                              DataRow monthPrices = _prices.NewRow();

                              monthPrices[EpochColumn] = snapshotDate;
                              monthPrices[Month] = month;
                              columns.ForEach(priceCol => monthPrices[priceCol] = month);
                              _prices.Rows.Add(monthPrices);
                          });
        }

        [ClassCleanup]
        public static void ResetSystemTime()
        {
            SystemTimeForTest.Reset();
        }

        [TestMethod]
        public void TestGetProductPrice_MonthlyContract_PriceIsTheMonthOffset()
        {
            int productNumber = 1;

            Enumerable.Range(0, NumMonths).ForEach(
                monthOffset =>
                {
                    Assert.AreEqual(
                        (monthOffset + FirstMonth),
                        _snapshotPrices.GetProductPrice(
                            productNumber,
                            InternalTime.LocalNow().FirstDayOfMonth().AddMonths(monthOffset),
                            ProductDateType.MonthYear,
                            GetPriceColumn(productNumber),
                            null,
                            null));
                });
        }

        [TestMethod]
        public void TestGetProductPrice_MonthlyButTooEarly_PriceIsZero()
        {
            int productNumber = 1;

            Assert.AreEqual(
                0M,
                _snapshotPrices.GetProductPrice(
                    productNumber,
                    InternalTime.LocalNow().FirstDayOfMonth().AddMonths(-1),
                    ProductDateType.MonthYear,
                    GetPriceColumn(productNumber),
                    null,
                    null));
        }

        [TestMethod]
        public void TestGetProductPrice_QuarterlyContract_PriceIsTheQuarterAverage()
        {
            int productNumber = 1;

            Enumerable.Range(0, NumMonths / 3).ForEach(
                monthOffset =>
                {
                    Assert.AreEqual(
                        (monthOffset * 3 + FirstMonth + 1M),
                        _snapshotPrices.GetProductPrice(
                            productNumber,
                            InternalTime.LocalNow().FirstDayOfMonth().AddMonths(monthOffset * 3),
                            ProductDateType.Quarter,
                            GetPriceColumn(productNumber),
                            null,
                            null));
                });
        }

        [TestMethod]
        public void TestGetProductPrice_CalContract_PriceIsThe12MonthAverage()
        {
            int productNumber = 1;

            Assert.AreEqual(
                ((decimal)Enumerable.Range(FirstMonth, NumMonths).Average()),
                _snapshotPrices.GetProductPrice(
                    productNumber,
                    InternalTime.LocalNow().FirstDayOfMonth(),
                    ProductDateType.Year,
                    GetPriceColumn(productNumber),
                    null,
                    null));
        }

        [TestMethod]
        public void TestGetProductPrice_CustomContract_PriceIsTheContractLengthAverage()
        {
            int productNumber = 1;

            Enumerable.Range(0, NumMonths).ForEach(
                monthOffset =>
                {
                    DateTime productMonth = InternalTime.LocalNow().FirstDayOfMonth();

                    Assert.AreEqual(
                        ((decimal)Enumerable.Range(FirstMonth, monthOffset + 1).Average()),
                        _snapshotPrices.GetProductPrice(
                            productNumber,
                            InternalTime.LocalNow().FirstDayOfMonth(),
                            ProductDateType.Custom,
                            GetPriceColumn(productNumber),
                            productMonth,
                            productMonth.AddMonths(monthOffset)));
                });
        }
    }
}