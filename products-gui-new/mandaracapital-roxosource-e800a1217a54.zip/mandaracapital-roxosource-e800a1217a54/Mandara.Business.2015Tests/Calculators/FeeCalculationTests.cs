﻿using Mandara.Entities;
using Mandara.Test.EntityBuilders;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Mandara.Business.Calculators
{
    [TestClass]
    public class FeeCalculatorTests
    {
        private const int TradeQuantity = 15;

        private readonly OfficialProductBuilder _officialProductBuilder = new OfficialProductBuilder();
        private ProductBuilder _productBuilder;
        private readonly TradeCaptureBuilder _tradeCaptureBuilder = new TradeCaptureBuilder();

        private TradeCapture _trade;
        private Product _product;
        private SecurityDefinition _securityDefinition;
        private FeeCalculator _feeCalculator;

        // These values may change if the current calculation changes, but that depends on how the calculation changse.
        private const decimal ExpectedKtDefContractSzNonSpreadParentRebate = 435M;
        private const decimal ExpectedKt100ContractNonSpreadParentRebate = 448.5M;
        private const decimal ExpectedBblDefContractSzNonSpreadParentRebate = 448.65M;
        private const decimal ExpectedGlDefContractSzNonSpreadParentRebate = 450M;

        [TestInitialize]
        public void Initialize()
        {
            _productBuilder = new ProductBuilder();
            OfficialProduct feeCalcOfficialProd = _officialProductBuilder.BuildOfficialProduct(
                1,
                "FeeCalcTestOffProd",
                new Currency() { CurrencyId = 1000, IsoName = "FCT" },
                "fct");
            _product = _productBuilder.Build(1, ProductType.Swap, "FeeCalcTest Product", feeCalcOfficialProd);
            _securityDefinition = SecurityDefinitionBuilder.Build("Jan17/Feb17", _product, "fctsymbol");
            _securityDefinition.Product = _product;
            _feeCalculator = new FeeCalculator();

            _trade = _tradeCaptureBuilder.Build(1, _securityDefinition, -TradeQuantity);
        }

        private void ExecuteNonSpreadParentTest(decimal expectedIceSpreadRebate, decimal contractSize)
        {
            Assert.AreEqual(_product.Exchange.Name,Exchange.IceExchangeName);
            _product.ContractSize = contractSize;
            _feeCalculator.CalculateFeesForStandardTradeInclRebate(_trade, _product);
            Assert.AreEqual(expectedIceSpreadRebate, _trade.IceSpreadRebate);
        }

        [TestMethod]
        public void TestCalculateFees_NoSpreadForKilotonUnitWithDefaultContractSize_RebateIsCorrect()
        {
            ExecuteNonSpreadParentTest(ExpectedKtDefContractSzNonSpreadParentRebate, ProductBuilder.DefaultContractSize);
        }

        [TestMethod]
        public void TestCalculateFees_NoSpreadKilotonUnitWithContractSize100_RebateIsCorrect()
        {
            ExecuteNonSpreadParentTest(ExpectedKt100ContractNonSpreadParentRebate, 100);
        }

        [TestMethod]
        public void TestCalculateFees_NoSpreadBarrelUnitWithDefaultContractSize_RebateIsCorrect()
        {
            _product.Unit = ProductBuilder.Barrel;
            ExecuteNonSpreadParentTest(ExpectedBblDefContractSzNonSpreadParentRebate, ProductBuilder.DefaultContractSize);
        }

        [TestMethod]
        public void TestCalculateFees_NoSpreadGallonUnitWithDefaultContractSize_RebateIsCorrect()
        {
            _product.Unit = ProductBuilder.Gallon;
            ExecuteNonSpreadParentTest(ExpectedGlDefContractSzNonSpreadParentRebate, ProductBuilder.DefaultContractSize);
        }
    }
}

