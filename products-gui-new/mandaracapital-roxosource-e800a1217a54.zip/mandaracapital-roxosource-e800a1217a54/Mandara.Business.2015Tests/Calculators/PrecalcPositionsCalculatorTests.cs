﻿using Mandara.Business.Contracts;
using Mandara.Business.OldCode;
using Mandara.Entities;
using Mandara.Entities.Calculation;
using Mandara.Entities.EntityPieces;
using Mandara.Entities.Enums;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Reflection;

namespace Mandara.Business.Calculators
{
    [TestClass]
    public class PrecalcPositionsCalculatorTests
    {
        private Mock<IProductsStorage> _productsStorageMock;
        private Mock<PricingPrePositionsManager> _pricingPositionsMock;
        private Mock<ITradeCaptureConverter> _tradeCaptureConverterMock;
        private PrecalcPositionsCalculator _precalcPositionsCalc;
        private static Product _product;
        private SecurityDefinition _monthSd;
        private SecurityDefinition _quarterSd;
        private TradeCapture _monthTrade;
        private TradeCapture _quarterTrade;
        private SourceDetail _monthDetail;
        private SourceDetail _quarterDetail;
        private List<PricingCalculationDetail> _monthPrecalcs;
        private List<PricingCalculationDetail> _quarterPrecalcs;

        [ClassInitialize]
        public static void ClassInitialise(TestContext testContext)
        {
            _product = new Product
            {
                ProductId = 1,
                OfficialProduct =
                   new OfficialProduct
                   {
                       OfficialProductId = 2,
                       Currency = new Currency { CurrencyId = 3, IsoName = CurrencyCodes.USD }
                   }
            };
        }

        [TestInitialize]
        public void TestInitialise()
        {
            _productsStorageMock = new Mock<IProductsStorage>();
            _pricingPositionsMock = new Mock<PricingPrePositionsManager>();
            _tradeCaptureConverterMock = new Mock<ITradeCaptureConverter>();

            _precalcPositionsCalc = new PrecalcPositionsCalculator(
                _productsStorageMock.Object,
                _pricingPositionsMock.Object,
                _tradeCaptureConverterMock.Object);

            SetCalcCacheInitializationState(true);

            _monthSd = new SecurityDefinition
            {
                SecurityDefinitionId = 0,
                StripName = "Jan17",
                Product = _product
            };

            _quarterSd = new SecurityDefinition
            {
                SecurityDefinitionId = 0,
                StripName = "Q2 17",
                Product = _product
            };

            _monthTrade = new TradeCapture
            {
                TradeId = 0,
                SecurityDefinition = _monthSd,
                Price = 10M,
                Quantity = 12M
            };

            _monthDetail = new SourceDetail
            {
                ProductDate = new DateTime(2017, 1, 1),
                DateType = ProductDateType.MonthYear,
                Quantity = _monthTrade.Quantity,
                Product = _monthSd.Product
            };

            _quarterTrade = new TradeCapture
            {
                TradeId = 0,
                SecurityDefinition = _quarterSd,
                Price = 20M,
                Quantity = 4M
            };

            _quarterDetail = new SourceDetail
            {
                ProductDate = new DateTime(2017, 4, 1),
                DateType = ProductDateType.Quarter,
                Quantity = _quarterTrade.Quantity,
                Product = _quarterSd.Product
            };

            _monthPrecalcs = new List<PricingCalculationDetail>
            {
                new PricingCalculationDetail
                {
                    Amount = 1M,
                    CalculationDate = new DateTime(2017, 01, 01),
                    Period = new DateTime(2017, 01, 01),
                    ProductReference = _product
                }
            };

            _quarterPrecalcs = new List<PricingCalculationDetail>
            {
                new PricingCalculationDetail
                {
                    Amount = 1M,
                    CalculationDate = new DateTime(2017, 04, 01),
                    Period = new DateTime(2017, 04, 01),
                    ProductReference = _product
                },
                new PricingCalculationDetail
                {
                    Amount = 2M,
                    CalculationDate = new DateTime(2017, 05, 01),
                    Period = new DateTime(2017, 05, 01),
                    ProductReference = _product
                },
                new PricingCalculationDetail
                {
                    Amount = 3M,
                    CalculationDate = new DateTime(2017, 06, 01),
                    Period = new DateTime(2017, 06, 01),
                    ProductReference = _product
                }
            };

            _pricingPositionsMock.Setup(
                x =>
                    x.CalculateTasReport(
                        new DateTime(2017, 01, 01),
                        It.IsAny<DateTime>(),
                        It.IsAny<List<SourceDetail>>(),
                        It.IsAny<CalculationCache>())).Returns(_monthPrecalcs);

            _pricingPositionsMock.Setup(
                x =>
                    x.CalculateTasReport(
                        new DateTime(2017, 04, 01),
                        It.IsAny<DateTime>(),
                        It.IsAny<List<SourceDetail>>(),
                        It.IsAny<CalculationCache>())).Returns(_quarterPrecalcs);

            _tradeCaptureConverterMock.Setup(
                x =>
                    x.ConvertTradeCaptureToSourceDetail(
                        It.Is<TradePieces>(t => t.Trade == _monthTrade)))
                    .Returns(_monthDetail);

            _tradeCaptureConverterMock.Setup(
                x =>
                    x.ConvertTradeCaptureToSourceDetail(
                        It.Is<TradePieces>(t => t.Trade == _quarterTrade)))
                    .Returns(_quarterDetail);
        }

        private void SetCalcCacheInitializationState(bool isInitialized)
        {
            FieldInfo calcCacheInitializedField = typeof(PrecalcPositionsCalculator).GetField(
                "_calcCacheInitialized",
                BindingFlags.NonPublic | BindingFlags.Instance);
            calcCacheInitializedField.SetValue(_precalcPositionsCalc, isInitialized);
        }

        [TestMethod]
        public void Test_CalculatePrecalcPositionsForTwoManualTrades_PrecalcPositionsCalculatedCorrectlyForEachTrade()
        {
            _precalcPositionsCalc.CalculatePrecalcPositions(_monthTrade, _monthSd);
            _precalcPositionsCalc.CalculatePrecalcPositions(_quarterTrade, _quarterSd);

            AssertPrecalcsMatch(_monthPrecalcs, _monthTrade.PrecalcPositions);
            AssertPrecalcsMatch(_quarterPrecalcs, _quarterTrade.PrecalcPositions);
        }

        [TestMethod]
        public void Test_CalculatePrecalcPositionsForTwoNonManualTrades_PrecalcPositionsCalculatedCorrectlyForEachTrade()
        {
            _monthSd.SecurityDefinitionId = 3;
            _quarterSd.SecurityDefinitionId = 4;
            _monthTrade.TradeId = 5;
            _quarterTrade.TradeId = 6;

            _precalcPositionsCalc.CalculatePrecalcPositions(_monthTrade, _monthSd);
            _precalcPositionsCalc.CalculatePrecalcPositions(_quarterTrade, _quarterSd);

            AssertPrecalcsMatch(_monthPrecalcs, _monthTrade.PrecalcPositions);
            AssertPrecalcsMatch(_quarterPrecalcs, _quarterTrade.PrecalcPositions);
        }

        private void AssertPrecalcsMatch(List<PricingCalculationDetail> details, List<PrecalcDetail> actualPrecalcs)
        {
            if (details == null || actualPrecalcs == null)
            {
                Assert.Fail("Precalcs doesn't match, all should be not null");
            }

            List<PrecalcDetail> expectedPrecalcs =
                PrecalcPositionsCalculator.ConvertPricingDetailsToPrecalDetails(details);

            Assert.AreEqual(expectedPrecalcs.Count, actualPrecalcs.Count);

            for (int i = 0; i < expectedPrecalcs.Count; i++)
            {
                PrecalcDetail expected = expectedPrecalcs[i];
                PrecalcDetail actual = actualPrecalcs[i];

                Assert.AreEqual(expected.Product.ProductId, actual.Product.ProductId);
                Assert.AreEqual(expected.Month, actual.Month);
                Assert.AreEqual(expected.DaysPositions.Count, actual.DaysPositions.Count);
            }
        }
    }
}