﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Globalization;
using System.Linq;
using Mandara.Date.Time;

namespace Mandara.Business.Calculators
{
    [TestClass()]
    public class HoursInMonthCalculatorTests
    {
        [TestMethod()]
        public void Test_HoursInMonth_DefaultTimeZone()
        {
            DateTime now = SystemTime.Now();

            foreach (int month in Enumerable.Range(1, 12))
            {
                int daysInMonth = DateTime.DaysInMonth(now.Year, month);
                decimal hoursInMonth = HoursInMonthCalculator.HoursInMonth(now.Year, month);
                int offset;

                if (3 == month)
                {
                    offset = -1;
                }
                else if (10 == month)
                {
                    offset = 1;
                }
                else
                {
                    offset = 0;
                }

                Assert.AreEqual(daysInMonth * 24 + offset, hoursInMonth);
            }
        }

        [TestMethod()]
        public void Test_HoursInMonth_LocalTimeZone()
        {
            DateTime now = SystemTime.Now();
            TimeZone timeZone = TimeZone.CurrentTimeZone;
            DaylightTime daylightSavingsBoundaries = timeZone.GetDaylightChanges(now.Year);
            int daylightSavingsStartMonth = daylightSavingsBoundaries.Start.Month;
            int daylightSavingsEndMonth = daylightSavingsBoundaries.End.Month;

            foreach (int month in Enumerable.Range(1, 12))
            {
                int daysInMonth = DateTime.DaysInMonth(now.Year, month);
                decimal hoursInMonth = HoursInMonthCalculator.HoursInMonth(now.Year, month, TimeZoneInfo.Local);
                int offset;

                if (daylightSavingsStartMonth == month)
                {
                    offset = -1;
                }
                else if (daylightSavingsEndMonth == month)
                {
                    offset = 1;
                }
                else
                {
                    offset = 0;
                }

                Assert.AreEqual(daysInMonth * 24 + offset, hoursInMonth);
            }
        }

        [TestMethod()]
        public void Test_HoursInMonth_NonDaylightSavingsTimeZone()
        {
            DateTime now = SystemTime.Now();
            TimeZoneInfo timeZoneInfo = TimeZoneInfo.GetSystemTimeZones().First(tz => !tz.SupportsDaylightSavingTime);

            foreach (int month in Enumerable.Range(1, 12))
            {
                int daysInMonth = DateTime.DaysInMonth(now.Year, month);
                decimal hoursInMonth = HoursInMonthCalculator.HoursInMonth(now.Year, month, timeZoneInfo);

                Assert.AreEqual(daysInMonth * 24, hoursInMonth);
            }
        }
    }
}