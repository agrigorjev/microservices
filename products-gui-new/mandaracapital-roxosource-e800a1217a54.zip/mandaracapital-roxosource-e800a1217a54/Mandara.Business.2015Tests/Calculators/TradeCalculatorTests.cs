﻿using Mandara.Date.Time;
using Mandara.Entities;
using Mandara.Entities.Enums;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Mandara.Business.Calculators
{
    [TestClass()]
    public class TradeCalculatorTests
    {
        [TestMethod()]
        public void Test_MonthlyQuantityTimeSpread_GetTradeStripPeriods_ContainsSingleMonths()
        {
            DateTime today = SystemTime.Today();
            int daysBackTo1stOfMonth = 1 - today.Day;
            DateTime strip1Date = today.AddDays(daysBackTo1stOfMonth);
            string strip1Name = strip1Date.ToString("MMMyy");
            DateTime strip2Date = strip1Date.AddMonths(1);
            string strip2Name = strip2Date.ToString("MMMyy");

            Product testProduct =
                new Product()
                {
                    ProductId = 1,
                    Type = ProductType.Diff,
                    ContractSize = 1000,
                    ContractSizeMultiplierDb = (int)ContractSizeMultiplier.Monthly,
                };

            SecurityDefinition securityDefinition =
                new SecurityDefinition()
                {
                    StripName = String.Format("{0}/{1}", strip1Name, strip2Name),
                    Strip1DateType = ProductDateType.MonthYear,
                    Strip2DateType = ProductDateType.MonthYear,
                    SecurityDefinitionId = 1,
                    Product = testProduct,
                };

            TradeCapture trade =
                new TradeCapture()
                {
                    SecurityDefinition = securityDefinition,
                    TradeStartDate = strip1Date,
                };

            List<List<int>> stripPeriodsRemaining = TradeCalculator.GetTradeStripPeriods(trade, today);

            Assert.AreEqual(2, stripPeriodsRemaining.Count);

            Assert.AreEqual(1, stripPeriodsRemaining[0].Count);
            Assert.AreEqual(1, stripPeriodsRemaining[0].First());
            Assert.AreEqual(1, stripPeriodsRemaining[1].Count);
            Assert.AreEqual(1, stripPeriodsRemaining[1].First());
        }

        [TestMethod()]
        public void Test_MonthlyQuantityCurrentQuarterTimeSpread_GetTradeStripPeriods_ContainsSingleMonths()
        {
            DateTime today = SystemTime.Today();
            int daysBackTo1stOfMonth = 1 - today.Day;
            DateTime strip1Date = today.AddDays(daysBackTo1stOfMonth);
            int currentQuarterNumber = GetCurrentQuarter(strip1Date);
            string strip1Name = GetQuarterStrip(currentQuarterNumber, strip1Date.Year);
            string strip2Name = GetNextQuarterStrip(currentQuarterNumber, strip1Date);

            Product testProduct =
                new Product()
                {
                    ProductId = 1,
                    Type = ProductType.Diff,
                    ContractSize = 1000,
                    ContractSizeMultiplierDb = (int)ContractSizeMultiplier.Monthly,
                };

            SecurityDefinition securityDefinition =
                new SecurityDefinition()
                {
                    StripName = String.Format("{0}/{1}", strip1Name, strip2Name),
                    Strip1DateType = ProductDateType.Quarter,
                    Strip2DateType = ProductDateType.Quarter,
                    SecurityDefinitionId = 1,
                    Product = testProduct,
                };

            TradeCapture trade =
                new TradeCapture()
                {
                    SecurityDefinition = securityDefinition,
                    TradeStartDate = strip1Date,
                };

            List<List<int>> stripPeriodsRemaining = TradeCalculator.GetTradeStripPeriods(trade, today);

            Assert.AreEqual(2, stripPeriodsRemaining.Count);

            int monthsLeftInStrip1Quarter = GetMonthsLeftInQuarter(currentQuarterNumber, today);

            Assert.AreEqual(monthsLeftInStrip1Quarter, stripPeriodsRemaining[0].Count);
            stripPeriodsRemaining[0].ForEach(periods => Assert.AreEqual(1, periods));
            Assert.AreEqual(monthsLeftInStrip1Quarter, stripPeriodsRemaining[1].Count);
            stripPeriodsRemaining[1].ForEach(periods => Assert.AreEqual(1, periods));
        }

        private int GetCurrentQuarter(DateTime baseDate)
        {
            return (int)Math.Ceiling((decimal)baseDate.Month / 3.0M);
        }

        private int GetNextQuarter(int baseQuarter)
        {
            return baseQuarter == 4 ? 1 : baseQuarter + 1;
        }

        private string GetQuarterStrip(int quarterNumber, int year)
        {
            return String.Format("Q{0}{1}", quarterNumber, year - 2000);
        }

        private int GetMonthsLeftInQuarter(int quarter, DateTime baseDate)
        {
            // The quarters start in months 1, 4, 7 and 10
            int quarterStartMonth = (quarter - 1) * 3 + 1;
            // The quarters end in months 3, 6, 9 and 12
            int quarterEndMonth = quarterStartMonth + 2;

            // If the base date month is after the quarter end then the quarter is assumed to be in the future, so it
            // has 3 months to go.  Similarly, if the base month is before the quarter start then the quarter is assumed
            // to be in the future, so it has 3 months to go.
            if (baseDate.Month > quarterEndMonth || baseDate.Month < quarterStartMonth)
            {
                return 3;
            }

            return quarterEndMonth + 1 - baseDate.Month;
        }

        private string GetNextQuarterStrip(int currentQuarterNumber, DateTime baseDate)
        {
            int nextQuarterNumber = GetNextQuarter(currentQuarterNumber);
            int baseYear = baseDate.Year;
            int year = nextQuarterNumber > currentQuarterNumber ? baseYear : baseYear + 1;

            return GetQuarterStrip(nextQuarterNumber, year);
        }

        [TestMethod()]
        public void Test_MonthlyQuantityNextQuarterTimeSpread_GetTradeStripPeriods_ContainsSingleMonths()
        {
            DateTime today = SystemTime.Today();
            int currentQuarterNumber = GetCurrentQuarter(today);
            int strip1QuarterNumber = GetNextQuarter(currentQuarterNumber);
            DateTime strip1Date = GetStartOfQuarter(currentQuarterNumber, strip1QuarterNumber);
            string strip1Name = GetQuarterStrip(strip1QuarterNumber, strip1Date.Year);
            string strip2Name = GetNextQuarterStrip(strip1QuarterNumber, strip1Date);

            Product testProduct =
                new Product()
                {
                    ProductId = 1,
                    Type = ProductType.Diff,
                    ContractSize = 1000,
                    ContractSizeMultiplierDb = (int)ContractSizeMultiplier.Monthly,
                };

            SecurityDefinition securityDefinition =
                new SecurityDefinition()
                {
                    StripName = String.Format("{0}/{1}", strip1Name, strip2Name),
                    Strip1DateType = ProductDateType.Quarter,
                    Strip2DateType = ProductDateType.Quarter,
                    SecurityDefinitionId = 1,
                    Product = testProduct,
                };

            TradeCapture trade =
                new TradeCapture()
                {
                    SecurityDefinition = securityDefinition,
                    TradeStartDate = strip1Date,
                };

            List<List<int>> stripPeriodsRemaining = TradeCalculator.GetTradeStripPeriods(trade, today);

            Assert.AreEqual(2, stripPeriodsRemaining.Count);

            int monthsLeftInStrip1Quarter = GetMonthsLeftInQuarter(strip1QuarterNumber, today);

            Assert.AreEqual(monthsLeftInStrip1Quarter, stripPeriodsRemaining[0].Count);
            stripPeriodsRemaining[0].ForEach(periods => Assert.AreEqual(1, periods));
            Assert.AreEqual(monthsLeftInStrip1Quarter, stripPeriodsRemaining[1].Count);
            stripPeriodsRemaining[1].ForEach(periods => Assert.AreEqual(1, periods));
        }

        private DateTime GetStartOfQuarter(int currentQuarterNumber, int targetQuarterNumber)
        {
            bool nextYear = currentQuarterNumber == 4 && targetQuarterNumber < 4;
            int year = nextYear ? SystemTime.Today().Year + 1 : SystemTime.Today().Year;
            int firstMonthOfQuarter = (targetQuarterNumber - 1) * 3 + 1;

            return new DateTime(year, firstMonthOfQuarter, 1);
        }

        [TestMethod()]
        public void Test_DailyQuantityTimeSpread_GetTradeStripPeriods_ContainsMonthlyDayCounts()
        {
            DateTime today = SystemTime.Today();
            int daysBackTo1stOfMonth = 1 - today.Day;
            DateTime strip1Date = today.AddDays(daysBackTo1stOfMonth);
            string strip1Name = strip1Date.ToString("MMMyy");
            int daysInStrip1Month = DateTime.DaysInMonth(strip1Date.Year, strip1Date.Month);
            DateTime strip2Date = strip1Date.AddMonths(1);
            string strip2Name = strip2Date.ToString("MMMyy");
            int daysInStrip2Month = DateTime.DaysInMonth(strip2Date.Year, strip2Date.Month);

            Product testProduct =
                new Product()
                {
                    ProductId = 1,
                    Type = ProductType.Diff,
                    ContractSize = 1000,
                    ContractSizeMultiplierDb = (int)ContractSizeMultiplier.Daily,
                };

            SecurityDefinition securityDefinition =
                new SecurityDefinition()
                {
                    StripName = String.Format("{0}/{1}", strip1Name, strip2Name),
                    Strip1DateType = ProductDateType.MonthYear,
                    Strip2DateType = ProductDateType.MonthYear,
                    SecurityDefinitionId = 1,
                    Product = testProduct,
                };

            TradeCapture trade =
                new TradeCapture()
                {
                    SecurityDefinition = securityDefinition,
                    TradeStartDate = strip1Date,
                };

            List<List<int>> stripPeriodsRemaining = TradeCalculator.GetTradeStripPeriods(trade, today);

            Assert.AreEqual(2, stripPeriodsRemaining.Count);

            Assert.AreEqual(1, stripPeriodsRemaining[0].Count);
            Assert.AreEqual(daysInStrip1Month, stripPeriodsRemaining[0].First());
            Assert.AreEqual(1, stripPeriodsRemaining[1].Count);
            Assert.AreEqual(daysInStrip2Month, stripPeriodsRemaining[1].First());
        }

        [TestMethod()]
        public void Test_DailyQuantityQuarterTimeSpread_GetTradeStripPeriods_ContainsMonthlyDayCounts()
        {
            DateTime today = SystemTime.Today();
            int currentQuarterNumber = GetCurrentQuarter(today);
            DateTime strip1Date = GetStartOfQuarter(currentQuarterNumber, currentQuarterNumber);
            string strip1Name = GetQuarterStrip(currentQuarterNumber, strip1Date.Year);
            int monthsLeftInStrip1Quarter = GetMonthsLeftInQuarter(currentQuarterNumber, today);
            List<int> remainingMonthCountIndexes = Enumerable.Range(0, monthsLeftInStrip1Quarter).ToList();
            int currentMonthIndex = 3 - monthsLeftInStrip1Quarter;
            IEnumerable<int> daysInStrip1Months =
                GetDaysInStripMonths(
                    currentMonthIndex,
                    monthsLeftInStrip1Quarter,
                    strip1Date);
            DateTime strip2Date = strip1Date.AddMonths(3);
            string strip2Name = GetNextQuarterStrip(currentQuarterNumber, strip1Date);
            IEnumerable<int> daysInStrip2Months =
                GetDaysInStripMonths(
                    currentMonthIndex,
                    monthsLeftInStrip1Quarter,
                    strip2Date);

            Product testProduct =
                new Product()
                {
                    ProductId = 1,
                    Type = ProductType.Diff,
                    ContractSize = 1000,
                    ContractSizeMultiplierDb = (int)ContractSizeMultiplier.Daily,
                };

            SecurityDefinition securityDefinition =
                new SecurityDefinition()
                {
                    StripName = String.Format("{0}/{1}", strip1Name, strip2Name),
                    Strip1DateType = ProductDateType.Quarter,
                    Strip2DateType = ProductDateType.Quarter,
                    SecurityDefinitionId = 1,
                    Product = testProduct,
                };

            TradeCapture trade =
                new TradeCapture()
                {
                    SecurityDefinition = securityDefinition,
                    TradeStartDate = strip1Date,
                };

            List<List<int>> stripPeriodsRemaining = TradeCalculator.GetTradeStripPeriods(trade, today);

            Assert.AreEqual(2, stripPeriodsRemaining.Count);
            Assert.AreEqual(monthsLeftInStrip1Quarter, stripPeriodsRemaining[0].Count);
            remainingMonthCountIndexes.ForEach(
                index => Assert.AreEqual(daysInStrip1Months.ElementAt(index), stripPeriodsRemaining[0][index]));
            Assert.AreEqual(monthsLeftInStrip1Quarter, stripPeriodsRemaining[1].Count);
            remainingMonthCountIndexes.ForEach(
                index => Assert.AreEqual(daysInStrip2Months.ElementAt(index), stripPeriodsRemaining[1][index]));
        }

        private IEnumerable<int> GetDaysInStripMonths(int currentMonthIndex, int monthsLeftInStrip, DateTime stripDate)
        {
            return
                Enumerable.Range(currentMonthIndex, monthsLeftInStrip).Select(
                    index =>
                    {
                        DateTime strip1Month = stripDate.AddMonths(index);

                        return DateTime.DaysInMonth(strip1Month.Year, strip1Month.Month);
                    });
        }

        [TestMethod()]
        public void Test_DailyQuantityNextQuarterTimeSpread_GetTradeStripPeriods_ContainsSingleMonths()
        {
            DateTime today = SystemTime.Today();
            int currentQuarterNumber = GetCurrentQuarter(today);
            int strip1QuarterNumber = (currentQuarterNumber % 4) + 1;
            DateTime strip1Date = GetStartOfQuarter(currentQuarterNumber, strip1QuarterNumber);
            string strip1Name = GetQuarterStrip(strip1QuarterNumber, strip1Date.Year);
            int monthsLeftInStrip1Quarter = GetMonthsLeftInQuarter(strip1QuarterNumber, today);
            List<int> remainingMonthCountIndexes = Enumerable.Range(0, monthsLeftInStrip1Quarter).ToList();
            int currentMonthIndex = 3 - monthsLeftInStrip1Quarter;
            IEnumerable<int> daysInStrip1Months =
                GetDaysInStripMonths(
                    currentMonthIndex,
                    monthsLeftInStrip1Quarter,
                    strip1Date);
            DateTime strip2Date = strip1Date.AddMonths(3);
            string strip2Name = GetNextQuarterStrip(strip1QuarterNumber, strip1Date);
            IEnumerable<int> daysInStrip2Months =
                GetDaysInStripMonths(
                    currentMonthIndex,
                    monthsLeftInStrip1Quarter,
                    strip2Date);

            Product testProduct =
                new Product()
                {
                    ProductId = 1,
                    Type = ProductType.Diff,
                    ContractSize = 1000,
                    ContractSizeMultiplierDb = (int)ContractSizeMultiplier.Daily,
                };

            SecurityDefinition securityDefinition =
                new SecurityDefinition()
                {
                    StripName = String.Format("{0}/{1}", strip1Name, strip2Name),
                    Strip1DateType = ProductDateType.Quarter,
                    Strip2DateType = ProductDateType.Quarter,
                    SecurityDefinitionId = 1,
                    Product = testProduct,
                };

            TradeCapture trade =
                new TradeCapture()
                {
                    SecurityDefinition = securityDefinition,
                    TradeStartDate = strip1Date,
                };

            List<List<int>> stripPeriodsRemaining = TradeCalculator.GetTradeStripPeriods(trade, today);

            Assert.AreEqual(2, stripPeriodsRemaining.Count);
            Assert.AreEqual(monthsLeftInStrip1Quarter, stripPeriodsRemaining[0].Count);
            remainingMonthCountIndexes.ForEach(
                index => Assert.AreEqual(daysInStrip1Months.ElementAt(index), stripPeriodsRemaining[0][index]));
            Assert.AreEqual(monthsLeftInStrip1Quarter, stripPeriodsRemaining[1].Count);
            remainingMonthCountIndexes.ForEach(
                index => Assert.AreEqual(daysInStrip2Months.ElementAt(index), stripPeriodsRemaining[1][index]));
        }
    }
}