﻿using Mandara.Business.Model;
using Mandara.Business.Services.Prices;
using Mandara.Entities;
using Mandara.Entities.Calculation;
using Mandara.Entities.Enums;
using Mandara.Entities.Services;
using Mandara.Extensions.Option;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;

namespace Mandara.Business.Calculators
{

    public class TestSnapshotPrices : ISnapshotPricesProvider
    {
        private int _timesPriceRequested;

        public TestSnapshotPrices(DateTime snapshotTime)
        {
            PriceTimestamp = snapshotTime;
            _timesPriceRequested = 0;
        }
        public IEnumerable<TimeSpan> TodayTimestamps { get; }
        public TryGetResult<decimal> TryGetFxPrice(DateTime valueDate, Currency currency1, Currency currency2)
        {
            throw new NotImplementedException();
        }

        public TryGetResult<Money> TryGetProductPrice(
            int productId,
            DateTime productDate,
            ProductDateType priceDateType,
            string mappingColumn,
            int officialProductId,
            DateTime? tradeStartDate = null,
            DateTime? tradeEndDate = null)
        {
            _timesPriceRequested++;
            return
                new TryGetVal<Money>(
                    new Money(
                        PricingEndTimeFutureLivePriceCalculatorTests.TestPrice * _timesPriceRequested,
                        CurrencyCodes.USD));
        }

        public TryGetResult<Money>[] GetProductPricesByMonth(
            int productId,
            DateTime productDate,
            ProductDateType priceDateType,
            string mappingColumn,
            int officialProductId,
            DateTime? tradeStartDate = null,
            DateTime? tradeEndDate = null)
        {
            _timesPriceRequested++;
            return
                new TryGetResult<Money>[]
                {
                    new TryGetVal<Money>(
                        new Money(
                            PricingEndTimeFutureLivePriceCalculatorTests.TestPrice*_timesPriceRequested,
                            CurrencyCodes.USD))
                };
        }

        public DateTime? PriceTimestamp { get; private set; }
        public void UpdatePrices(DateTime snapshotDateTime)
        {
        }
    }

    [TestClass]
    public class PricingEndTimeFutureLivePriceCalculatorTests
    {
        private readonly DateTime _noonRiskDate = new DateTime(2017, 1, 31, 12, 0, 0);
        private readonly DateTime _morningTime = new DateTime(1900, 1, 1, 11, 0, 0);
        private readonly DateTime _afternoonTime = new DateTime(1900, 1, 1, 19, 30, 00);
        public const decimal TestPrice = 20M;
        private readonly Mock<IPricesProvider> _priceProvider = new Mock<IPricesProvider>();
        private ISnapshotPricesProvider _snapshotPriceProvider;

        [TestInitialize]
        public void Initialize()
        {
            _snapshotPriceProvider = new TestSnapshotPrices(_noonRiskDate);
            SetUpProviders();
        }

        private void SetUpProviders()
        {
            _priceProvider.Setup(x => x.TodayTimestamps).Returns(new List<TimeSpan>() { _morningTime.TimeOfDay });

        }

        private Product SetUpProduct(DateTime pricingEnd, DateTime expiry)
        {
            return new Product()
            {
                Name = "test",
                OfficialProduct = new OfficialProduct()
                {
                    Currency = new Currency()
                    {
                        IsoName = CurrencyCodes.USD
                    }
                },
                PricingEndTime = pricingEnd,
                FuturesExpireTime = expiry
            };
        }

        private TradeCapture SetUpTradeCapture(string stripName)
        {
            Product product = SetUpProduct(_morningTime, _afternoonTime);

            SecurityDefinition secDef = new SecurityDefinition()
            {
                Product = product,
                StripName = stripName
            };

            return new TradeCapture()
            {
                SecurityDefinition = secDef,
            };
        }

        private CalculationDetailModel SetUpCalculationDetailModel(Product product, int year, int month)
        {
            return new CalculationDetailModel(
                new DetailedPositionIdentifier(), 
                product,
                product,
                year,
                month,
                0M,
                0,
                new CoeffEntityId(0, 0));
        }

        [TestMethod]
        public void TestFutureExpirePriceRetrieval_TradePriceAfterPricingEndTImeRequested_SnapshotPriceReturned()
        {
            TradeCapture trade = SetUpTradeCapture("Jan11");
            LivePrice livePrice = PricingEndTimeFutureLivePriceCalculator.GetFuturesLivePriceForPricingEndTime(
                trade,
                _noonRiskDate,
                _priceProvider.Object,
                _snapshotPriceProvider);

            Assert.AreEqual(TestPrice, livePrice.TradeLivePrice.Value);
        }

        [TestMethod]
        public void TestFutureExpirePriceRetrieval_TradePriceAfterPricingEndTimeRequestedTwice_PriceProviderUsedOnce()
        {
            TradeCapture trade = SetUpTradeCapture("Jan12");
            LivePrice livePrice1 = PricingEndTimeFutureLivePriceCalculator.GetFuturesLivePriceForPricingEndTime(
                trade,
                _noonRiskDate,
                _priceProvider.Object,
                _snapshotPriceProvider);
            LivePrice livePrice2 = PricingEndTimeFutureLivePriceCalculator.GetFuturesLivePriceForPricingEndTime(
                trade,
                _noonRiskDate,
                _priceProvider.Object,
                _snapshotPriceProvider);


            Assert.AreEqual(TestPrice, livePrice1.TradeLivePrice.Value);
            Assert.AreEqual(TestPrice, livePrice2.TradeLivePrice.Value);
        }

        [TestMethod]
        public void TestFutureExpirePriceRetrieval_ThreeTradesPricesAfterPricingEndTimeRequested_PriceProviderUsedTwice()
        {
            TradeCapture trade1 = SetUpTradeCapture("Jan13");
            TradeCapture trade2 = SetUpTradeCapture("Feb13");
            TradeCapture trade3 = SetUpTradeCapture("Jan13");

            LivePrice livePrice1 = PricingEndTimeFutureLivePriceCalculator.GetFuturesLivePriceForPricingEndTime(
                trade1,
                _noonRiskDate,
                _priceProvider.Object,
                _snapshotPriceProvider);
            LivePrice livePrice2 = PricingEndTimeFutureLivePriceCalculator.GetFuturesLivePriceForPricingEndTime(
                trade2,
                _noonRiskDate,
                _priceProvider.Object,
                _snapshotPriceProvider);
            LivePrice livePrice3 = PricingEndTimeFutureLivePriceCalculator.GetFuturesLivePriceForPricingEndTime(
                trade3,
                _noonRiskDate,
                _priceProvider.Object,
                _snapshotPriceProvider);


            Assert.AreEqual(TestPrice, livePrice1.TradeLivePrice.Value);
            Assert.AreEqual(TestPrice * 2, livePrice2.TradeLivePrice.Value);
            Assert.AreEqual(TestPrice, livePrice3.TradeLivePrice.Value);
        }

        [TestMethod]
        public void TestFutureExpirePriceRetrieval_PositionPriceAfterPricingEndTImeRequested_SnapshotPriceReturned()
        {
            Product product = SetUpProduct(_morningTime, _afternoonTime);
            CalculationDetailModel model = SetUpCalculationDetailModel(product, 2011, 1);
            TryGetResult<Money> livePrice = PricingEndTimeFutureLivePriceCalculator.GetFuturesLivePriceForPricingEndTime(
                model,
                product,
                _noonRiskDate,
                _priceProvider.Object,
                _snapshotPriceProvider);

            Assert.AreEqual(TestPrice, livePrice.Value);
        }

        [TestMethod]
        public void TestFutureExpirePriceRetrieval_PositionPriceAfterPricingEndTimeRequestedTwice_PriceProviderUsedOnce()
        {
            Product product = SetUpProduct(_morningTime, _afternoonTime);
            CalculationDetailModel model = SetUpCalculationDetailModel(product, 2012, 1);
            TryGetResult<Money> livePrice1 = PricingEndTimeFutureLivePriceCalculator.GetFuturesLivePriceForPricingEndTime(
                model,
                product,
                _noonRiskDate,
                _priceProvider.Object,
                _snapshotPriceProvider);
            TryGetResult<Money> livePrice2 = PricingEndTimeFutureLivePriceCalculator.GetFuturesLivePriceForPricingEndTime(
                model,
                product,
                _noonRiskDate,
                _priceProvider.Object,
                _snapshotPriceProvider);


            Assert.AreEqual(TestPrice, livePrice1.Value);
            Assert.AreEqual(TestPrice, livePrice2.Value);
        }

        [TestMethod]
        public void TestFutureExpirePriceRetrieval_ThreePositionsPricesAfterPricingEndTimeRequested_PriceProviderUsedTwice()
        {
            Product product = SetUpProduct(_morningTime, _afternoonTime);
            CalculationDetailModel model1 = SetUpCalculationDetailModel(product, 2013, 1);
            CalculationDetailModel model2 = SetUpCalculationDetailModel(product, 2013, 2);
            CalculationDetailModel model3 = SetUpCalculationDetailModel(product, 2013, 1);

            TryGetResult<Money> livePrice1 = PricingEndTimeFutureLivePriceCalculator.GetFuturesLivePriceForPricingEndTime(
                model1,
                product,
                _noonRiskDate,
                _priceProvider.Object,
                _snapshotPriceProvider);
            TryGetResult<Money> livePrice2 = PricingEndTimeFutureLivePriceCalculator.GetFuturesLivePriceForPricingEndTime(
                model2,
                product,
                _noonRiskDate,
                _priceProvider.Object,
                _snapshotPriceProvider);
            TryGetResult<Money> livePrice3 = PricingEndTimeFutureLivePriceCalculator.GetFuturesLivePriceForPricingEndTime(
                model3,
                product,
                _noonRiskDate,
                _priceProvider.Object,
                _snapshotPriceProvider);


            Assert.AreEqual(TestPrice, livePrice1.Value);
            Assert.AreEqual(TestPrice * 2, livePrice2.Value);
            Assert.AreEqual(TestPrice, livePrice3.Value);
        }
    }
}
