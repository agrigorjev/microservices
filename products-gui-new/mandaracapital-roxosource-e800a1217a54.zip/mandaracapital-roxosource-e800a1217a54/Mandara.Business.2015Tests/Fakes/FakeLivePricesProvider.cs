﻿using Mandara.Business.Calculators;
using Mandara.Business.Services.Prices;
using Mandara.Entities;
using Mandara.Extensions.Option;
using System;
using System.Collections.Generic;
using Mandara.Test.FxSetUp;

namespace Mandara.Business.Fakes
{
    public class FakeLivePricesProvider : ILivePricesProvider
    {
        public IEnumerable<TimeSpan> TodayTimestamps { get; private set; }

        public TryGetResult<decimal> TryGetFxPrice(DateTime valueDate, Currency currency1, Currency currency2)
        {
            decimal price = 109M;
            return new TryGetVal<decimal>((amount) => false) { Value = price };
        }

        public TryGetResult<Money> TryGetProductPrice(
            int productId,
            DateTime productDate,
            ProductDateType priceDateType,
            string mappingColumn,
            int officialProductId,
            DateTime? tradeStartDate = null,
            DateTime? tradeEndDate = null)
        {
            Money price = Money.Default;
            bool hasValue = false;

            if (officialProductId == TocomTestData.DubaiSettlementOfficialProductId)
            {
                price = new Money(40, "USD");
                hasValue = true;
            }
            else
            {
                switch (productDate.Month)
                {
                    case 6:
                    {
                        price = new Money(24000, "JPY");
                        hasValue = true;
                    }
                    break;

                    case 7:
                    {
                        price = new Money(25000, "JPY");
                        hasValue = true;
                    }
                    break;

                    default:
                    {
                        price = new Money(26000, "JPY");
                        hasValue = true;
                    }
                    break;
                }
            }

            // Note that the test for default allows zero to be a valid value.  This could cause trouble - a zero
            // exchange rate must technically be wrong since it doesn't make sense to have a rate of zero.
            return new TryGetVal<Money>((amount) => !hasValue) { Value = price };
        }

        public IPricesProvider GetFixedLivePrices()
        {
            throw new NotImplementedException();
        }

        public void UpdatePrices()
        {
            throw new NotImplementedException();
        }

        public TryGetResult<Money>[] GetProductPricesByMonth(int productId, DateTime productDate, ProductDateType priceDateType, string mappingColumn, int officialProductId, DateTime? tradeStartDate = default(DateTime?), DateTime? tradeEndDate = default(DateTime?))
        {
            throw new NotImplementedException();
        }
    }
}
