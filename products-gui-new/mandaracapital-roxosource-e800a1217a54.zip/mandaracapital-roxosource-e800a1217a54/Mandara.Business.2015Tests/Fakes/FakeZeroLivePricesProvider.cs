﻿using Mandara.Business.Services.Prices;
using Mandara.Entities;
using Mandara.Extensions.Option;
using System;
using System.Collections.Generic;

namespace Mandara.Business.Fakes
{
    public class FakeZeroLivePricesProvider : ILivePricesProvider
    {
        public IEnumerable<TimeSpan> TodayTimestamps { get; private set; }

        public TryGetResult<decimal> TryGetFxPrice(DateTime valueDate, Currency currency1, Currency currency2)
        {
            decimal price = 0M;
            return new TryGetVal<decimal>((amount) => false) { Value = price };
        }

        public TryGetResult<Money> TryGetProductPrice(
            int productId,
            DateTime productDate,
            ProductDateType priceDateType,
            string mappingColumn,
            int officialProductId,
            DateTime? tradeStartDate = null,
            DateTime? tradeEndDate = null)
        {
            Money price = Money.CurrencyDefault("USD");
            bool hasValue = true;

            // Note that the test for default allows zero to be a valid value.  This could cause trouble - a zero
            // exchange rate must technically be wrong since it doesn't make sense to have a rate of zero.
            return new TryGetVal<Money>(amount => !hasValue) { Value = price };
        }

        public IPricesProvider GetFixedLivePrices()
        {
            throw new NotImplementedException();
        }

        public void UpdatePrices()
        {
            throw new NotImplementedException();
        }

        public TryGetResult<Money>[] GetProductPricesByMonth(
            int productId,
            DateTime productDate,
            ProductDateType priceDateType,
            string mappingColumn,
            int officialProductId,
            DateTime? tradeStartDate = default(DateTime?),
            DateTime? tradeEndDate = default(DateTime?))
        {
            throw new NotImplementedException();
        }
    }
}
