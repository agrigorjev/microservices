﻿using Mandara.Entities.Entities;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Ninject.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Mandara.Business.Fx
{
    [TestClass()]
    public class CurrencyIdToFXOfficialProductMapperTests
    {
        private Mock<ILogger> _mockLogger = new Mock<ILogger>();
        private List<FxOfficialProductPnLMap> _fxOfficialProductPnLMaps = new List<FxOfficialProductPnLMap>();
        private readonly List<int> CurrencyIds = new List<int>() { 1, 2, 3 };
        private const int InvalidCurrencyID = 100;
        private readonly List<int> OfficialProductIds = new List<int>() { 2, 1, 5 };
        private readonly List<int> HolidayCalendarIds = new List<int>() { 3, 3, 1 };

        [TestMethod()]
        public void Test_NewMapper_MappingIsEmpty()
        {
            CurrencyIdToFXOfficialProductMapper mapper = new CurrencyIdToFXOfficialProductMapper(_mockLogger.Object);

            Assert.AreEqual(false, mapper.HasMappingData());
        }

        [TestMethod()]
        public void Test_ResetMapperWithNullData_MappingIsEmpty()
        {
            CurrencyIdToFXOfficialProductMapper mapper = new CurrencyIdToFXOfficialProductMapper(_mockLogger.Object);

            mapper.ResetData(null);
            Assert.AreEqual(false, mapper.HasMappingData());
        }

        [TestMethod()]
        public void Test_MapperIsMissingRequestedCurrency_DefaultFxOfficialProductPnLMapReturned()
        {
            CurrencyIdToFXOfficialProductMapper mapper = new CurrencyIdToFXOfficialProductMapper(_mockLogger.Object);
            List<FxOfficialProductPnLMap> maps = GetTestFxOfficialProductPnLMaps();

            mapper.ResetData(maps);

            FxOfficialProductPnLMap invalidCurrencyIDMap =
                mapper.GetOfficialProductAndHolidayCalendarIDsForCurrency(
                    CurrencyIdToFXOfficialProductMapperTests.InvalidCurrencyID);

            Assert.AreEqual(true, mapper.HasMappingData());
            Assert.AreEqual(CurrencyIdToFXOfficialProductMapperTests.InvalidCurrencyID, invalidCurrencyIDMap.CurrencyId);
            Assert.AreEqual(FxOfficialProductPnLMap.DefaultId, invalidCurrencyIDMap.OfficialProductId);
            Assert.AreEqual(FxOfficialProductPnLMap.DefaultId, invalidCurrencyIDMap.HolidayCalendarId);
        }

        private List<FxOfficialProductPnLMap> GetTestFxOfficialProductPnLMaps()
        {
            if (CurrencyIds.Count != OfficialProductIds.Count || CurrencyIds.Count != HolidayCalendarIds.Count)
            {
                throw new InvalidOperationException(
                    "Cannot construct FxOfficialProductPnLMaps - there must be matching numbers of currency, "
                        + "official product and holiday calendar IDs defined.");
            }

            List<FxOfficialProductPnLMap> fxOfficialProductPnLMaps = new List<FxOfficialProductPnLMap>();

            foreach (int index in Enumerable.Range(0, CurrencyIds.Count))
            {
                fxOfficialProductPnLMaps.Add(ConstructOfficialProductPnLMap(index));
            }

            return fxOfficialProductPnLMaps;
        }

        private FxOfficialProductPnLMap ConstructOfficialProductPnLMap(int validDataIndex)
        {
            return new FxOfficialProductPnLMap()
            {
                CurrencyId = CurrencyIds[validDataIndex],
                OfficialProductId = OfficialProductIds[validDataIndex],
                HolidayCalendarId = HolidayCalendarIds[validDataIndex]
            };
        }

        [TestMethod()]
        public void Test_MapperHasRequestedCurrency_FxOfficialProductPnLMapReturned()
        {
            CurrencyIdToFXOfficialProductMapper mapper = new CurrencyIdToFXOfficialProductMapper(_mockLogger.Object);
            List<FxOfficialProductPnLMap> maps = GetTestFxOfficialProductPnLMaps();

            mapper.ResetData(maps);

            Assert.AreEqual(true, mapper.HasMappingData());

            CurrencyIds.ForEach(
                currencyId =>
                {
                    int dataIndex = CurrencyIds.IndexOf(currencyId);
                    FxOfficialProductPnLMap currencyIDMap =
                        mapper.GetOfficialProductAndHolidayCalendarIDsForCurrency(currencyId);

                    Assert.AreEqual(currencyId, currencyIDMap.CurrencyId);
                    Assert.AreEqual(OfficialProductIds[dataIndex], currencyIDMap.OfficialProductId);
                    Assert.AreEqual(HolidayCalendarIds[dataIndex], currencyIDMap.HolidayCalendarId);
                });
        }
    }
}