﻿namespace Mandara.Bus.HistoricalService
{
    using System;

    [Serializable]
    public class HistoricalPriceRequest
    {
        public Guid RequestID { get; set; }
        public String Product { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }
}
