﻿using Mandara.Bus.Common;

namespace Mandara.Bus.HistoricalService
{
    class Program
    {
        static void Main(string[] args)
        {
            ServiceHelper.RunService(new HistoricalService());   
        }
    }
}
