﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;

namespace Mandara.Bus.HistoricalService
{
    using System.IO;
    using System.Runtime.Serialization;
    using System.Runtime.Serialization.Formatters.Binary;
    using System.Threading;
    using com.latencybusters.lbm;
    using com.latencybusters.lbm.sdm;
    using Mandara.Bus.Common;

    partial class HistoricalService : BusServiceBase
    {
        static LBMContext lbmContext;
        static LBMReceiver lbmReceiver;
        static Queue<LBMMessage> MessageQueue = new Queue<LBMMessage>();
        static Object _queueLock = new Object();

        public HistoricalService()
        {
            InitializeComponent();
        }

        public override void Start()
        {
            if (Config.LBMConfigurationFilePath != null)
                LBM.setConfiguration(Config.LBMConfigurationFilePath);

            lbmContext = new LBMContext();
            LBMTopic lbmTopic = new LBMTopic(lbmContext, Config.HistoricalRequestsSource);
            lbmReceiver = new LBMReceiver(lbmContext, lbmTopic, onReceive, null, null);

            BackgroundWorker worker = new BackgroundWorker();
            worker.DoWork += DoSendResponse;
            worker.RunWorkerAsync();
        }

        static void DoSendResponse(object sender, DoWorkEventArgs e)
        {
            while (true)
            {
                if (MessageQueue.Count == 0)
                {
                    Thread.Sleep(100);
                    continue;
                }

                LBMMessage msg = null;
                lock (_queueLock)
                {
                    msg = MessageQueue.Dequeue();
                }

                IFormatter formatter = new BinaryFormatter();
                Stream stream = new MemoryStream(msg.data());
                HistoricalPriceRequest hpRequest = (HistoricalPriceRequest)formatter.Deserialize(stream);
                stream.Close();

                Console.WriteLine(String.Format("Request received. ID: {0}, Product: {1}, Start Date: {2}, End Date: {3}",
                    hpRequest.RequestID, hpRequest.Product, hpRequest.StartDate, hpRequest.EndDate));

                String response = "Acknowledge " + hpRequest.RequestID;
                ASCIIEncoding enc = new ASCIIEncoding();
                Byte[] responseData = enc.GetBytes(response);
                msg.respond(responseData, responseData.Length, 0);
                msg.dispose();

                PriceSender priceSender = new PriceSender(lbmContext, hpRequest, Config.HistoricalResponsesSource);
                priceSender.SendPricesAsync();
            }
        }

        private static Int32 onReceive(Object cbArgs, LBMMessage theMessage)
        {
            switch (theMessage.type())
            {
                case LBM.MSG_DATA:

                    LBMSDMessage SDMsg = new LBMSDMessage();
                    SDMsg.parse(theMessage.data());
                    LBMSDMField priceField = SDMsg.locate("Price");
                    Double price = ((LBMSDMFieldDouble)priceField).get();

                    String topic = theMessage.topicName();
                    System.Console.WriteLine(
                                    "Received "
                                    + theMessage.length()
                                    + " bytes on topic "
                                    + topic
                                    + ": '"
                                    + price
                                    + "'");

                    break;

                case LBM.MSG_BOS:
                    System.Console.WriteLine("[" + theMessage.topicName() + "][" + theMessage.source() + "], Beginning of Transport Session");
                    break;

                case LBM.MSG_EOS:
                    System.Console.WriteLine("[" + theMessage.topicName() + "][" + theMessage.source() + "], End of Transport Session");
                    break;

                case LBM.MSG_REQUEST:
                    System.Console.WriteLine("[" + theMessage.topicName() + "][" + theMessage.source() + "], REQUEST");
                    lock (_queueLock)
                    {
                        MessageQueue.Enqueue(theMessage);
                    }
                    break;

                default:
                    System.Console.WriteLine("unexpected event: " + theMessage.type());
                    System.Environment.Exit(1);
                    break;
            }

            //theMessage.dispose();
            return 0;
        }

        protected override void OnStop()
        {
            lbmReceiver.close();
            lbmContext.close();
        }
    }
}
