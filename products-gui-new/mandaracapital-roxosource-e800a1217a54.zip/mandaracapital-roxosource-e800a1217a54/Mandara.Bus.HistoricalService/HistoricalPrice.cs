﻿namespace Mandara.Bus.HistoricalService
{
    using System;

    [Serializable]
    public class HistoricalPrice
    {
        public DateTime Date { get; set; }
        public Double Price { get; set; }
    }
}
