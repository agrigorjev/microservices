﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Mandara.Bus.Common;
using com.latencybusters.lbm;
using System.ComponentModel;
using Mandara.Business;
using com.latencybusters.lbm.sdm;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace Mandara.Bus.HistoricalService
{
    public class PriceSender
    {
        LBMContext Context;
        HistoricalPriceRequest Request { get; set; }
        String ResponseTopic { get; set; }

        public PriceSender(LBMContext context, HistoricalPriceRequest request, String topic)
        {
            Context = context;
            Request = request;
            ResponseTopic = topic;
        }

        public void SendPricesAsync()
        {
            BackgroundWorker worker = new BackgroundWorker();
            worker.DoWork += new DoWorkEventHandler(SendPriceResponse);
            worker.RunWorkerAsync();
        }

        void SendPriceResponse(object sender, DoWorkEventArgs e)
        {
            Console.WriteLine("Start sending prices for request: " + Request.RequestID);

            PriceManager manager = new PriceManager();
            List<Object> prices = manager.GetProductForAnalysis(Request.Product, Request.StartDate, Request.EndDate, Entities.Enums.PricePrecisionType.Minute, 72, true, new TimeSpan(6, 0, 0), new TimeSpan(21, 0, 0), 0);

            String topicName = String.Format(ResponseTopic, Request.RequestID);
            LBMTopic topic = new LBMTopic(Context, topicName, new LBMSourceAttributes());
            LBMSource lbmSource = new LBMSource(Context, topic);
            IFormatter formatter = new BinaryFormatter();

            DateTime lastDate = DateTime.MinValue;
            foreach (Object obj in prices)
            {
                if (obj is DateTime)
                {
                    lastDate = (DateTime)obj;
                    continue;
                }

                Double price = (Double)obj;
                HistoricalPrice historicalPrice = new HistoricalPrice
                    {
                        Date = lastDate,
                        Price = price
                    };

                MemoryStream stream = new MemoryStream();
                formatter.Serialize(stream, historicalPrice);
                Byte[] message = stream.ToArray();
                stream.Close();

                lbmSource.send(message, message.Length, 0);

            }
            
            lbmSource.close();
            Console.WriteLine("Finished sending prices for request: " + Request.RequestID);
        }
    }
}
