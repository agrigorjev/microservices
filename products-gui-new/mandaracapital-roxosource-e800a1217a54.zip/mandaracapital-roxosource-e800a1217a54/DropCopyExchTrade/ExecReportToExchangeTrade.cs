﻿using FIXMessageMapping;
using Mandara.Data;
using Mandara.Date;
using Mandara.Date.Time;
using Mandara.Entities;
using Mandara.Entities.Enums;
using NLog;
using Optional;
using QuickFix.Fields;
using QuickFix.FIX44;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DropCopyExchTrade
{
    public class FixExecReportToExchangeTradeCaptureMap : IFixExecutionReportMapper
    {
        private const int DefaultNumOfCycles = 1;
        private readonly ILogger _logger;

        public FixExecReportToExchangeTradeCaptureMap(ILogger log)
        {
            _logger = log;
        }

        public Option<T> Map<T>(ExecutionReport execReport, string clearingFirmName) where T : class
        {
            List<string> validationErrors = ValidateExecReportForExchangeTrade(execReport);

            if (validationErrors.Any())
            {
                _logger.Error(
                    "ExecReportToExchangeTrade.MapToTradeCapture: {0} - {1}",
                    CommonExecutionReportMapping.BuildExecRptIdentifiersMessage(execReport),
                    string.Join("; ", validationErrors));
                return Option.None<T>();
            }

            TradeCapture mappedTrade = ConstructBaseTradeCapture(execReport, clearingFirmName);

            SetStartAndEndDates<T>(execReport, mappedTrade);
            mappedTrade.SecurityIDSource = ReturnSecurityIdSourceFromExecReport(execReport);
            mappedTrade.NumOfLots = GetNumOfLotsFromReport(execReport);

            return Option.Some(mappedTrade as T);
        }

        private static List<string> ValidateExecReportForExchangeTrade(ExecutionReport execRpt)
        {
            List<string> errorMessages = CommonExecutionReportMapping.ValidateExecutionReport(execRpt);

            if (!execRpt.IsSetOrderID())
            {
                errorMessages.Add("OrderID is not set");
            }

            if (!execRpt.IsSetClOrdID())
            {
                errorMessages.Add("ClOrdID is not set");
            }

            if (!execRpt.IsSetExecID())
            {
                errorMessages.Add("ExecID is not set");
            }

            if (!execRpt.IsSetExecType())
            {
                errorMessages.Add("ExecType is not set");
            }

            if (!execRpt.IsSetOrdStatus())
            {
                errorMessages.Add("OrdStatus is not set");
            }

            if (!execRpt.IsSetSymbol())
            {
                errorMessages.Add("Symbol is not set");
            }

            if (!execRpt.IsSetLastQty())
            {
                errorMessages.Add("LastQty is not set");
            }

            if (!execRpt.IsSetLastPx())
            {
                errorMessages.Add("LastPx is not set");
            }

            if (!execRpt.IsSetSecurityExchange())
            {
                errorMessages.Add("SecurityExchange is not set");
            }

            return errorMessages;
        }

        private static string BuildExecRptIdentifiersMessage(ExecutionReport execRpt)
        {
            string orderId = execRpt.IsSetOrderID() ? execRpt.OrderID.getValue() : "unknown";
            string clOrdId = execRpt.IsSetClOrdID() ? execRpt.ClOrdID.getValue() : "unknown";
            string tradeDate = execRpt.IsSetTradeDate() ? execRpt.TradeDate.getValue() : "unknown";

            return string.Format(
                "Order ID = {0}, Clearing Order ID = {1}, Trade Date = {2}",
                orderId,
                clOrdId,
                tradeDate);
        }

        private TradeCapture ConstructBaseTradeCapture(ExecutionReport execReport, string clearingFirmName)
        {
            DateTime transactionTime = execReport.TransactTime.getValue();
            string origClOrdID = execReport.IsSetField(new OrigClOrdID()) ? execReport.OrigClOrdID.getValue() : null;
            string side = GetTradeSide(execReport);

            TradeCapture mappedTrade = new TradeCapture
            {
                OriginationTrader = "DummyTrader",
                TimeStamp = GetSendingTime(execReport),
                OrderID = execReport.OrderID.getValue(),
                ClOrdID = execReport.ClOrdID.getValue(),
                ExecID = execReport.ExecID.getValue(),
                ExecType = GetExecutionType(execReport),
                OrdStatus = GetOrderStatus(execReport),
                Symbol = GetSymbol(execReport),
                Side = side,
                Quantity = GetQuantity(execReport, side),
                Price = execReport.LastPx.getValue(),
                TransactTime = transactionTime,
                OrigTradeID = origClOrdID,
                TradeType = 0,
                Exchange = execReport.SecurityExchange.getValue(),
                OriginationFirm = GetOriginationFirm(execReport),
                ClearingFirm = clearingFirmName,
                TradeDate = transactionTime.Date,
                NumOfCycles = DefaultNumOfCycles,
                SecurityID = GetSecurityId(execReport)
            };

            return mappedTrade;
        }

        private decimal GetQuantity(ExecutionReport execReport, string side)
        {
            decimal quantity = execReport.LastQty.getValue();

            if (String.Equals(side, TradeCaptureSide.Sell.ToString(), StringComparison.InvariantCultureIgnoreCase)
                && quantity > 0M)
            {
                return -quantity;
            }

            return quantity;
        }

        private static DateTime GetSendingTime(ExecutionReport execReport)
        {
            if (execReport.Header.IsSetField(new SendingTime().Tag))
            {
                return execReport.Header.GetDateTime(new SendingTime().Tag);
            }

            return SystemTime.Now();
        }

        private string GetSecurityId(ExecutionReport execReport)
        {
            throw new NotImplementedException();
            //if (execReport.IsSetField(Tags.MndLocalTradingCode))
            //{
            //    return execReport.GetString(Tags.MndLocalTradingCode);
            //}

            //_logger.Warn(
            //    "FixExecReportToTradeCaptureMape: Failure getting SecurityId from message, using symbol value "
            //    + "instead");
            //return execReport.Symbol.getValue();
        }

        private static void SetStartAndEndDates<T>(ExecutionReport execReport, TradeCapture mappedTrade) where T : class
        {
            //TODO trade start, end days parsed from MaturityMonthYear. Check logic when start trading spreads IRM-523
            DateRange tradeStartAndEndDate = GetStartAndEndDate(execReport);
            mappedTrade.TradeStartDate = tradeStartAndEndDate.IsDefault()
                ? default(DateTime?)
                : tradeStartAndEndDate.Start;
            mappedTrade.TradeEndDate = tradeStartAndEndDate.IsDefault() ? default(DateTime?) : tradeStartAndEndDate.End;
        }

        private static DateRange GetStartAndEndDate(ExecutionReport execReport)
        {
            if (!execReport.IsSetMaturityMonthYear())
            {
                return DateRange.Default;
            }

            DateTime tradeStartDate = MappingCommon.GetMaturityMonthYearAsADate(execReport);

            if (DateTime.MinValue == tradeStartDate)
            {
                return DateRange.Default;
            }

            return new DateRange(tradeStartDate, tradeStartDate.AddMonths(1).AddDays(-1));
        }

        private string GetSymbol(ExecutionReport execReport)
        {
            throw new NotImplementedException();
            //return execReport.GetString(Tags.MndLocalCode);
        }

        private string GetOriginationFirm(ExecutionReport execReport)
        {
            if (execReport.Header.IsSetField(new OnBehalfOfCompID().Tag))
            {
                return execReport.Header.GetString(new OnBehalfOfCompID().Tag);
            }

            _logger.Warn(
                "FixExecReportToTradeCaptureMape: Failure getting OriginationFirm from message, using null value "
                + "instead");
            return null;
        }

        private static string GetTradeSide(ExecutionReport execReport)
        {
            string side;

            switch (execReport.Side.getValue())
            {
                case Side.BUY:
                {
                    side = TradeCaptureSide.Buy.ToString();
                }
                break;

                case Side.SELL:
                {
                    side = TradeCaptureSide.Sell.ToString();
                }
                break;

                default:
                {
                    // TODO: Add message validation so that this point is not reached...
                    return execReport.Side.getValue().ToString();
                }
            }

            return side;
        }

        private static string GetOrderStatus(ExecutionReport execReport)
        {
            string orderStatus;

            switch (execReport.OrdStatus.getValue())
            {
                case OrdStatus.PARTIALLY_FILLED:
                case OrdStatus.FILLED:
                {
                    orderStatus = TradeOrderStatus.Filled;
                }
                break;

                default:
                {
                    orderStatus = execReport.OrdStatus.getValue().ToString();
                }
                break;
            }

            return orderStatus;
        }

        private static string GetExecutionType(ExecutionReport execReport)
        {
            string executionType;

            switch (execReport.ExecType.getValue())
            {
                case ExecType.FILL:
                {
                    executionType = "FILL";
                }
                break;

                case ExecType.PARTIAL_FILL:
                {
                    executionType = "PARTIAL";
                }
                break;

                default:
                {
                    throw new InvalidFieldValueException(
                    "FixExecReportToExchangeTradeCaptureMap: Cannot map trade, invalid Exec Type.",
                    "ExecType",
                    execReport.ExecType.getValue().ToString());
                }
            }

            return executionType;
        }

        private int GetNumOfLotsFromReport(ExecutionReport execReport)
        {
            return Math.Abs((int)execReport.LastQty.getValue());
        }

        private string ReturnSecurityIdSourceFromExecReport(ExecutionReport execReport)
        {
            Func<ExecutionReport, ILogger, string> securityIdSourceCalculator =
                SecurityIDSourceMapper.GetSecurityIdSourceCalculationMethod(execReport.SecurityExchange.getValue());

            return (securityIdSourceCalculator(execReport, _logger));
        }
    }
}