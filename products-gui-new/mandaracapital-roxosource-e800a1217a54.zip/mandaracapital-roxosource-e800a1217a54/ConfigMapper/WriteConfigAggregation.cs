﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace ConfigMapper
{
    public class WriteConfigAggregation : IHostedService
    {
        private readonly ILogger<WriteConfigAggregation> _logger;
        private readonly IHostApplicationLifetime _appLifetime;
        private readonly IConfiguration _configAggregator;
        private readonly System.Configuration.Configuration _configFile;

        public WriteConfigAggregation(
            ILogger<WriteConfigAggregation> logger, 
            IHostApplicationLifetime appLifetime, 
            IConfiguration configAggregator,
            System.Configuration.Configuration configFile)
        {
            _logger = logger;
            _appLifetime = appLifetime;
            _configAggregator = configAggregator;
            _configFile = configFile;
        }
        
        public Task StartAsync(CancellationToken cancellationToken)
        {
            _appLifetime.ApplicationStarted.Register(() =>
            Task.Run(() => 
            {
                try
                {
                    OverwriteConfig(_configAggregator, _configFile);
                }
                catch (Exception e)
                {
                    _logger.LogError("Could not write aggregated config");
                }
                finally
                {
                    _appLifetime.StopApplication();
                }

            }));

            return Task.CompletedTask;
        }

        public Task StopAsync(CancellationToken cancellationToken) { return Task.CompletedTask; }

        public void OverwriteConfig(IConfiguration config, System.Configuration.Configuration configFile)
        {
            configFile.AppSettings.Settings.Clear();
            foreach (var setting in config.AsEnumerable())
            {
                configFile.AppSettings.Settings.Add(setting.Key, setting.Value);
            }

            configFile.Save();
        }
    }
}