﻿using Azure.Extensions.AspNetCore.Configuration.Secrets;
using Azure.Identity;
using Azure.Security.KeyVault.Secrets;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.UserSecrets;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using NLog;
using NLog.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//required for as running in framework rather than core
[assembly: UserSecretsId("56910eaf-2b04-4c9c-b523-5edc33905a43")]

namespace ConfigMapper
{

    class Program
	{
		private static ILogger _logger = LogManager.GetCurrentClassLogger();

		public const string MapToKey = "MapConfigTo";

		static async Task Main(string[] args)
		{
			AppDomain.CurrentDomain.UnhandledException += CurrentDomain_UnhandledException;
			await CreateHostBuilder(args)
				.RunConsoleAsync();
		}

		static void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
		{
			throw e.ExceptionObject as Exception;
		}

		public static IHostBuilder CreateHostBuilder(string[] args) =>
			Host.CreateDefaultBuilder(args)
				.ConfigureAppConfiguration((context, config) => ConfigureAppConfiguration(args.FirstOrDefault(), context, config))
				.ConfigureServices((context, services) => { ConfigureServices(context.Configuration, services); });

		private static void ConfigureAppConfiguration(string getConfigurationFor, HostBuilderContext context, IConfigurationBuilder builder)
		{
			string exePath = string.IsNullOrWhiteSpace(getConfigurationFor) 
				? "Mandara.IRM.Server.2015.exe" 
				: getConfigurationFor;
			string env = context.HostingEnvironment.EnvironmentName;
			_logger.Info("Running configuration for {0} in env {1}", exePath, env);

            //string path = System.IO.Path.GetFullPath(exePath);

            //Already part of default
            //if (context.HostingEnvironment.IsDevelopment())
            //{
            //    builder.AddUserSecrets<WriteConfigAggregation>();
            //}

            builder
				//.AddEnvironmentVariables()
				//.AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
				//.AddJsonFile($"appsettings.{env}.json",
				//	optional: true, reloadOnChange: true)
				.Add(new LegacyConfigProvider(exePath));
           
            builder           
            //.ConfigureKeyVault()
            .ConfigureAzureAppConfiguration()
			.AddInMemoryCollection(new Dictionary<string, string> { { MapToKey, exePath } });
        }

		private static void ConfigureServices(IConfiguration configuration, IServiceCollection services)
		{
			services
				.AddLogging(builder => builder.AddNLog())
				.AddServices(configuration)
				.AddHostedService<WriteConfigAggregation>();
		}

	}

	public static class ConfigurationBuilderExtensions
	{
		private const string KeyVaultKey = "KeyVault:BaseUrl";
		private const string AzureAppConfigKey = "AzureAppConfig";
		public static IConfigurationBuilder ConfigureKeyVault(this IConfigurationBuilder builder)
		{
			IConfigurationRoot config = builder.Build();
			string endpoint = config.GetConnectionString(KeyVaultKey);//Environment.GetEnvironmentVariable("KEYVAULT_ENDPOINT");

			if (endpoint is null)
			{
				return builder;
			}

			var getSecrets = new SecretClient(new Uri(endpoint), new DefaultAzureCredential());
			builder.AddAzureKeyVault(getSecrets, new KeyVaultSecretManager());
			// config.AddAzureKeyVault(new Uri(keyVault), new DefaultKeyVaultSecretManager());
			return builder;
		}

		public static IConfigurationBuilder ConfigureAzureAppConfiguration(this IConfigurationBuilder builder)
		{
			IConfigurationRoot config = builder.Build();
			string appConfigConnString = config.GetConnectionString(AzureAppConfigKey);
			//string? endpoint = Environment.GetEnvironmentVariable("APPCONFIG_ENDPOINT");

			if (appConfigConnString is null)
			{
				return builder;
			}

			string keyFilter = "irm:*";

			builder.AddAzureAppConfiguration(options =>
			{
				options.Connect(appConfigConnString)
					.Select(keyFilter);
			});

			return builder;
		}

	}

	public static class ConfigureServicesExtensions
	{
		public static IServiceCollection AddServices(this IServiceCollection services, IConfiguration configuration)
		{
			services.AddSingleton(sp => 
				System.Configuration.ConfigurationManager.OpenExeConfiguration(configuration.GetValue<string>(Program.MapToKey)));
			
			return services;
		}

	}
}
