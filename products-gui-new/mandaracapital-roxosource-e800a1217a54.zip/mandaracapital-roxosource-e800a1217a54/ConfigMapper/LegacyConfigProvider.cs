﻿using System;
using System.Configuration;
using Microsoft.Extensions.Configuration;

namespace ConfigMapper
{
    public class LegacyConfigProvider : ConfigurationProvider, IConfigurationSource
    {
        private readonly string _exePath;

        public LegacyConfigProvider(string forExe)
        {
            _exePath = forExe;
        }
        
        public override void Load()
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(_exePath);
            foreach (ConnectionStringSettings connectionString in config.ConnectionStrings.ConnectionStrings)
            {
                Data[$"ConnectionStrings:{connectionString.Name}"] = connectionString.ConnectionString;
            }

            foreach (string settingKey in config.AppSettings.Settings.AllKeys)
            {
                Data[settingKey] = config.AppSettings.Settings[settingKey].Value;
            }
        }
        
        public IConfigurationProvider Build(IConfigurationBuilder builder)
        {
            return this;
        }
    }
}