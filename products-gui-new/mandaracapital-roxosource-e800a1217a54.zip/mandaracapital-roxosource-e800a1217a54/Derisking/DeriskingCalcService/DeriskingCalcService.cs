﻿using System.ServiceProcess;
using Mandara.Bus.Common.Server;
using Mandara.Business.Bus;
using Mandara.Business.Bus.Commands.Base;
using Mandara.Business.Bus.Handlers.Base;
using Mandara.DeriskingCalcService.Bus;
using com.latencybusters.lbm;

namespace Mandara.DeriskingCalcService
{
    public partial class DeriskingCalcService : ServerBase
    {
        private static DeriskingCalcService _instance;
        private BusClient _busClient;
        public static DeriskingCalcService Instance { get { return _instance; } }

        public BusClient BusClient
        {
            get { return _busClient; }
            set { _busClient = value; }
        }

        public DeriskingCalcService()
        {
            _instance = this;
            BusClient = new BusClient();
        }

        public override void Start()
        {
            base.Start();
        }

        protected override string ServerName
        {
            get { return "Derisking Service"; }
        }

        public override void Stop()
        {
            BusClient.Stop();
            base.Stop();
        }

        protected override ServerInformaticaHelperBase CreateInformaticaHelper(LBMContext lbmContext, HandlerManager handlerManager)
        {
            return new DeriskingInformaticaHelper(lbmContext, handlerManager);
        }
    }
}
