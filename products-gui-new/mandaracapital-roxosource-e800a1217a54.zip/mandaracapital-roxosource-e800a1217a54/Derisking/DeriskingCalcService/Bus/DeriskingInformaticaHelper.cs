﻿using Mandara.Bus.Common.Server;
using Mandara.Bus.Common.Server.Handlers;
using Mandara.Business.Bus.Commands.Base;
using Mandara.Business.Bus.Handlers.Base;
using Mandara.Business.Bus.Messages.Derisking;
using com.latencybusters.lbm;

namespace Mandara.DeriskingCalcService.Bus
{
    class DeriskingInformaticaHelper : ServerInformaticaHelperBase
    {
        public DeriskingInformaticaHelper(LBMContext lbmContext, HandlerManager handlerManager)
            : base(lbmContext, handlerManager) { }

        public override void CreateSources()
        {
            base.CreateSources();

            AddSource(ErrorsTopicName);

            AddSnapshotCommand(DeriskingCalcTopicName, typeof(DeriskingCalcSnapshotCommand));
        }

        public override void CreateReceivers()
        {
            base.CreateReceivers();

            AddReceiver(DeriskingCalcTopicName, typeof(SnapshotHandler<DeriskingCalcSnapshotMessage>));
//            AddReceiver(DeriskingCalcTopicName, typeof (DeriskingCalcHandler));
        }
    }
}
