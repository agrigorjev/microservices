﻿using Mandara.Bus.Common.Server.Commands;
using com.latencybusters.lbm;
using Mandara.Business.Bus;
using Mandara.Business.Bus.Handlers.Base;
using Mandara.Business.Bus.Messages.Base;

namespace Mandara.Bus.Common.Server.Handlers
{
    /// <summary>
    /// Service class to redirect handle for proper processing
    /// </summary>
    /// <typeparam name="T">Type of snapshot request message</typeparam>
    public class SnapshotHandler<T> : IHandler where T : SnapshotMessageBase
    {
        /// <summary>
        /// Performs deserialization of request message and add command for process message to queue
        /// </summary>
        /// <param name="topicName">Topic name (All snapshot request topics)</param>
        /// <param name="lbmMessage">Snapshot request message</param>
        public void Handle(string topicName, LBMMessage lbmMessage)
        {
            T message = null;

            switch (lbmMessage.type())
            {
                case LBM.MSG_BOS:
                    break;

                case LBM.MSG_EOS:
                    break;

                case LBM.MSG_REQUEST:
                    message = JsonHelper.Deserialize<T>(lbmMessage.data());
                    break;

                default:
                    break;
            }

            if (message == null)
            {
                lbmMessage.dispose();
                return;
            }

            DeriskingCalcService.DeriskingCalcService.Instance.CommandManager.AddCommand
                (new SnapshotResolveCommand(topicName, message, lbmMessage));
        }
    }
}
