﻿using System;
using System.Configuration;
using Mandara.Business.Bus.Commands.Base;
using Mandara.Business.Bus.Messages.Derisking;
using Mandara.DeriskingCalcEngine;
using Mandara.Entities;

namespace Mandara.DeriskingCalcService.Bus
{
    public class DeriskingCalcSnapshotCommand : SnapshotCommandBase
    {
        private static bool _busClientStarted = false;

        public override void DoExecute()
        {
            if (!_busClientStarted)
            {
                lock (DeriskingCalcService.Instance.BusClient)
                {
                    if (!_busClientStarted)
                    {
                        _busClientStarted = true;
                        DeriskingCalcService.Instance.BusClient.Start(turnOnMatchingDummies: false, turnOnErrorsReceiver: false);
                    }
                }
            }

            DeriskingCalcSnapshotMessage snapshotMessage = Message as DeriskingCalcSnapshotMessage;


            DeriskingCalculator calc = new DeriskingCalculator(DeriskingCalcService.Instance.BusClient);

            Solution baseSolution = null;
            Solution optimalSolution = null;

            int maxNumOfThreads = 8;

            int configNumOfThreads;
            if (int.TryParse(ConfigurationManager.AppSettings["MaxNumberOfThreads_Int"], out configNumOfThreads))
            {
                if (configNumOfThreads > 0 && configNumOfThreads < 100)
                    maxNumOfThreads = configNumOfThreads;
            }


            string responseString = null;

            try
            {
                calc.MinimizeVar(snapshotMessage.NumOfPicks, (int)snapshotMessage.ConfidenceLevel, maxNumOfThreads, snapshotMessage.PortfolioId, out baseSolution, out optimalSolution);

                foreach (TradeScenario scenario in optimalSolution.TradeScenarios)
                {
                    scenario.Product = new Product
                                           {
                                               Name = scenario.Product.OfficialProduct.Name,
                                               PositionFactor = scenario.Product.PositionFactor
                                           };
                }
            }
            catch (Exception ex)
            {
                responseString = ex.Message;
            }

            if (baseSolution != null && optimalSolution != null)
            {
                DeriskingCalcSnapshotMessage responseMessage = new DeriskingCalcSnapshotMessage
                                                                   {
                                                                       Var = Convert.ToDecimal(baseSolution.VarValue),
                                                                       MinVar =
                                                                           Convert.ToDecimal(optimalSolution.VarValue),
                                                                       Trades = optimalSolution.TradeScenarios,
                                                                       SnapshotId = snapshotMessage.SnapshotId
                                                                   };

                DeliveryContext.SnapshotData.AddMessage(responseMessage);
            }
            else
            {
                DeriskingCalcSnapshotMessage responseMessage = new DeriskingCalcSnapshotMessage()
                                                                   {
                                                                       ResponseString = responseString,
                                                                       SnapshotId = snapshotMessage.SnapshotId
                                                                   };

                DeliveryContext.SnapshotData.AddMessage(responseMessage);
            }

            SendPackage();
        }         
    }
}