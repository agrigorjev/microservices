﻿using System;
using System.Linq;
using System.ServiceProcess;

namespace Mandara.DeriskingCalcService
{
    class Program
    {
        static void Main(string[] args)
        {
            DeriskingCalcService service = new DeriskingCalcService();

            if (Environment.GetCommandLineArgs().Contains("-console"))
            {
                Console.CancelKeyPress += (x, y) => service.Stop();
                service.Start();
                Console.WriteLine("Running service, press a key to stop");
                Console.ReadKey();
                service.Stop();
                Console.WriteLine("Service stopped");
            }
            else
            {
                ServiceBase.Run(service);
            }
        }
    }
}
