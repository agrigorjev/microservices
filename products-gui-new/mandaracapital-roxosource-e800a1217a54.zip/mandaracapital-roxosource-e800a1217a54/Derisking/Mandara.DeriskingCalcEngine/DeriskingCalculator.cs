﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Kw.Combinatorics;
using Mandara.Business;
using Mandara.Business.Bus;
using Mandara.Entities;
using Mandara.Entities.Calculation;
using Mandara.VarCalcEngine;
using Mandara.VarCalcEngine.Impl;
using Mandara.VarCalcEngine.Interfaces;
using Roxosoft.Common.TaskSchedulers;
using Product = Mandara.Entities.Product;

namespace Mandara.DeriskingCalcEngine
{
    /// <summary>
    /// Provides methods for VaR optimization.
    /// </summary>
    public class DeriskingCalculator
    {
        private readonly BusClient _busClient;
        private readonly IPricesGetter _pricesGetter;

        public DeriskingCalculator()
        {
        }

        public DeriskingCalculator(BusClient busClient)
        {
            _busClient = busClient;
        }

        public DeriskingCalculator(IPricesGetter pricesGetter)
        {
            _pricesGetter = pricesGetter;
        }

        public DeriskingCalculator(BusClient busClient, IPricesGetter pricesGetter)
        {
            _busClient = busClient;
            _pricesGetter = pricesGetter;
        }

        /// <summary>
        /// Calculates VaR for all solutions combinations and returns an optimal one.
        /// </summary>
        /// <param name="numOfPicks">Number of scenarios in each solution.</param>
        /// <param name="confidenceLevel">Given confidence level for optimization.</param>
        /// <param name="maxNumOfThreads">Maximum allowed number of threads for optimization.</param>
        /// <param name="portfolioId">Identifier of the portfolio for optimization.</param>
        /// <param name="baseSolution">Output base VaR value for the selected portfolio.</param>
        /// <param name="optimalSolution">Output optimal solution for VaR minimizaztion.</param>
        public void MinimizeVar(int numOfPicks, int confidenceLevel, int maxNumOfThreads, int portfolioId,
                                out Solution baseSolution, out Solution optimalSolution)
        {
            List<TradeScenario> tradeScenarios = GetTradeScenarios();
            Dictionary<int, Solution> solutions = GetPossibleSolutions(tradeScenarios, numOfPicks);

            Dictionary<int, List<CalculationDetail>> scenarioImpactMap = CalculateTradeScenariosImpacts(tradeScenarios);

            CalculateSolutionsImpact(solutions.Values, maxNumOfThreads, scenarioImpactMap);

            Solution baseSolutionVar = new Solution { SolutionId = -1 }; // init base positions solution
            solutions.Add(baseSolutionVar.SolutionId, baseSolutionVar); 

            ConcurrentDictionary<int, Solution> results = new ConcurrentDictionary<int, Solution>();

            VarCalculator varCalculator = ComposeVarCalculator(confidenceLevel, portfolioId);

            LimitedConcurrencyLevelTaskScheduler scheduler = new LimitedConcurrencyLevelTaskScheduler(maxNumOfThreads);
            ParallelOptions options = new ParallelOptions { TaskScheduler = scheduler };

            Parallel.ForEach(solutions.Values, options,
                             s =>
                                 {
                                     s.VarValue = varCalculator.CalculateVar(s.Impact);

                                     if (!results.TryAdd(s.SolutionId, s))
                                     {
                                         throw new Exception(
                                             string.Format(
                                                 "Could not add Solution to the Results dict, solution id [{0}]",
                                                 s.SolutionId));
                                     }
                                 });

            if (!results.TryRemove(-1, out baseSolution))
            {
                throw new Exception("Could not get base solution from the results dict.");
            }

            optimalSolution = results.Values.OrderByDescending(s => s.VarValue).First();

            Dictionary<int, Product> map = tradeScenarios.Select(ts => ts.Product).Distinct().ToDictionary(k => k.ProductId, v => v);

            foreach (TradeScenario tradeScenario in optimalSolution.TradeScenarios)
            {
                tradeScenario.Product = map[tradeScenario.ProductId];
            }
        }

        

        public Dictionary<int, List<CalculationDetail>> CalculateTradeScenariosImpacts(List<TradeScenario> tradeScenarios)
        {
            CalculationManager calculationManager = new CalculationManager();
            CalculationCache calculationCache = new CalculationCache();
            calculationCache.Initialize();

            Dictionary<int, List<CalculationDetail>> map = new Dictionary<int, List<CalculationDetail>>();

            DateTime riskDate = DateTime.Now;
            using (MandaraEntities cxt = new MandaraEntities())
            {
                foreach (TradeScenario tradeScenario in tradeScenarios)
                {
                    List<SourceDetail> sourceDetails = ConvertToSourceDetails(new List<TradeScenario> {tradeScenario});

                    List<CalculationError> calcErrors;

                    List<CalculationDetail> impact =
                        calculationManager.CalculatePositions(calculationCache, cxt, sourceDetails, riskDate,
                                                              SourceDataType.OpenPositions, out calcErrors);

                    map.Add(tradeScenario.TradeScenarioId, impact);
                }
            }

            return map;
        }

        private VarCalculator ComposeVarCalculator(int confidenceLevel, int portfolioId)
        {
            IVarCache varCache = new DbVarCache();

            IPricesGetter pricesGetter = new CachedPricesDecorator(new DummyMiaPricesDecorator(_pricesGetter ?? new DbPricesGetter()));
            IPositionsGetter positionsGetter = new LivePositionsGetter(_busClient, varCache);

            return new VarCalculator(pricesGetter, positionsGetter, varCache, confidenceLevel, portfolioId);
        }

        /// <summary>
        /// Calculate position impact for all possible solutions.
        /// </summary>
        /// <param name="solutions">Solutions for which position impact is calculated.</param>
        /// <param name="maxNumOfThreads">Maximum allowed number of threads for calculating solutions impact.</param>
        public void CalculateSolutionsImpact(IEnumerable<Solution> solutions, int maxNumOfThreads)
        {
            CalculationManager calculationManager = new CalculationManager();
            CalculationCache calculationCache = new CalculationCache();
            calculationCache.Initialize();

            LimitedConcurrencyLevelTaskScheduler scheduler = new LimitedConcurrencyLevelTaskScheduler(maxNumOfThreads);
            ParallelOptions options = new ParallelOptions {TaskScheduler = scheduler};

            DateTime riskDate = DateTime.Now;
            using (MandaraEntities cxt = new MandaraEntities())
            {
                Parallel.ForEach(solutions, options,
                                 s =>
                                     {
                                         List<SourceDetail> sourceDetails = ConvertToSourceDetails(s.TradeScenarios);

                                         List<CalculationError> calcErrors;

                                         s.Impact = calculationManager.CalculatePositions(calculationCache, cxt,
                                                                                          sourceDetails, riskDate,
                                                                                          SourceDataType.OpenPositions,
                                                                                          out calcErrors);
                                     });
            }
        }

        public void CalculateSolutionsImpact(IEnumerable<Solution> solutions, int maxNumOfThreads, Dictionary<int, List<CalculationDetail>> scenarioImpactMap)
        {
            LimitedConcurrencyLevelTaskScheduler scheduler = new LimitedConcurrencyLevelTaskScheduler(maxNumOfThreads);
            ParallelOptions options = new ParallelOptions { TaskScheduler = scheduler };

            Parallel.ForEach(solutions, options,
                                s =>
                                {
                                    s.Impact = new List<CalculationDetail>();

                                    foreach (TradeScenario scenario in s.TradeScenarios)
                                    {
                                        List<CalculationDetail> clones = Clone(scenarioImpactMap[scenario.TradeScenarioId]);

                                        if (scenario.Quantity < 0) // sell
                                        {
                                            clones.ForEach(cd => cd.AmountInner *= -1);
                                        }

                                        s.Impact.AddRange(clones);
                                    }
                                });
        }

        private List<CalculationDetail> Clone(List<CalculationDetail> calculationDetails)
        {
            List<CalculationDetail> clones = new List<CalculationDetail>();

            foreach (CalculationDetail cd in calculationDetails)
            {
                CalculationDetail clone = new CalculationDetail
                                              {
                                                  DetailId = cd.DetailId,
                                                  CalculationDate = cd.CalculationDate,
                                                  ProductCategory = cd.ProductCategory,
                                                  AmountInner = cd.AmountInner,
                                                  PositionFactor = cd.PositionFactor,
                                              };

                clones.Add(clone);
            }

            return clones;
        }

        /// <summary>
        /// Build a dictionary of possible solutions from the provided base scenarios.
        /// </summary>
        /// <param name="scenarios">Scenarios from which solutions are generated.</param>
        /// <param name="numOfPicks">Number of scenarios in each solution.</param>
        /// <returns>Dictionary of possible solutions.</returns>
        public Dictionary<int, Solution> GetPossibleSolutions(List<TradeScenario> scenarios, int numOfPicks)
        {
            if (scenarios == null)
                throw new ArgumentNullException("scenarios", "scenarios should not be null");

            int numOfChoices = scenarios.Count;

            if (numOfPicks <= 0 || numOfPicks > numOfChoices)
            {
                throw new ArgumentOutOfRangeException("numOfPicks", numOfPicks,
                                                      string.Format(
                                                          "Number of picks should be greater than 0 and less or equal to the number of trade scenarios [{0}]",
                                                          numOfChoices));
            }

            Dictionary<int, Solution> dictionary = new Dictionary<int, Solution>();

            Combination comb = new Combination(numOfChoices, numOfPicks);

            int buySellNum = (int) Math.Pow(2, numOfPicks);

            int solutionId = 1;

            foreach (Combination row in comb.GetRows())
            {
                Solution solution = new Solution
                                        {
                                            SolutionId = solutionId++,
                                            TradeScenarios = new List<TradeScenario>()
                                        };

                dictionary.Add(solution.SolutionId, solution);

                foreach (int val in row)
                {
                    solution.TradeScenarios.Add(scenarios[val]);
                }

                for (int powerIdx = 1; powerIdx < buySellNum; powerIdx++)
                {
                    List<TradeScenario> clonedScenarios = Clone(solution.TradeScenarios);
                    int bitmap = powerIdx;

                    for (int pick = 0; pick < numOfPicks; pick++)
                    {
                        bool isSellTrade = (bitmap & 1) == 1;

                        if (isSellTrade)
                        {
                            TradeScenario clonedScenario = clonedScenarios[pick];
                            clonedScenario.Quantity *= -1;
                        }

                        bitmap = bitmap >> 1;
                    }

                    Solution subSolution = new Solution
                                               {
                                                   SolutionId = solutionId++,
                                                   TradeScenarios = clonedScenarios
                                               };

                    dictionary.Add(subSolution.SolutionId, subSolution);
                }
            }

            return dictionary;
        }

        private List<TradeScenario> Clone(List<TradeScenario> tradeScenarios)
        {
            List<TradeScenario> clones = new List<TradeScenario>();

            foreach (TradeScenario scenario in tradeScenarios)
            {
                TradeScenario clone = new TradeScenario
                                         {
                                             TradeScenarioId = scenario.TradeScenarioId,
                                             ProductId = scenario.ProductId,
                                             Strip1DateType = scenario.Strip1DateType,
                                             Strip1DateIndex = scenario.Strip1DateIndex,
                                             Strip2DateType = scenario.Strip2DateType,
                                             Strip2DateIndex = scenario.Strip2DateIndex,
                                             Quantity = scenario.Quantity,
                                         };

                clones.Add(clone);
            }

            return clones;
        }

        /// <summary>
        /// Get all trade scenarios from the database.
        /// </summary>
        /// <returns>List of trade scenarios.</returns>
        public List<TradeScenario> GetTradeScenarios()
        {
            return TradeScenarioManager.GetTradeScenarios();
        }

        private List<SourceDetail> ConvertToSourceDetails(List<TradeScenario> tradeScenarios)
        {
            List<SourceDetail> sourceDetails = new List<SourceDetail>();

            DateTime transactTime = DateTime.Now;
            DateTime maturityDate = DateTime.Now;

            foreach (TradeScenario scenario in tradeScenarios)
            {
                SourceDetail sourceDetail
                    = new SourceDetail
                          {
                              SourceDetailId = scenario.TradeScenarioId,
                              StripName = scenario.AbsoluteStripName,
                              IsTimeSpread = scenario.IsTimeSpread,
                              Quantity = scenario.Quantity,
                              TransactTime = transactTime,
                              MaturityDate = maturityDate,
                              ProductId = scenario.ProductId,
                          };

                sourceDetail.ProductDate = sourceDetail.ProductDate1 = scenario.Strip1.AbsoluteDate;
                sourceDetail.DateType = sourceDetail.DateType1 = (ProductDateType) scenario.Strip1DateType;

                if (scenario.IsTimeSpread)
                {
                    sourceDetail.ProductDate2 = scenario.Strip2.Value.AbsoluteDate;
                    sourceDetail.DateType2 = (ProductDateType) scenario.Strip2DateType.Value;
                }

                sourceDetails.Add(sourceDetail);
            }

            return sourceDetails;
        }
    }
}