﻿using System;
using System.Collections.Generic;
using Mandara.VarCalcEngine.Interfaces;

namespace Mandara.DeriskingCalcEngine.Tests
{
    public class FakePricesGetter : IPricesGetter
    {
        public Dictionary<DateTime, Dictionary<string, decimal>> GetPrices(List<string> pricesColumns, DateTime startDate, DateTime endDate, TimeSpan time)
        {
            int numOfDays = (int)endDate.Subtract(startDate).TotalDays;

            if (numOfDays <= 0)
                throw new ArgumentException("StartDate should be greater than EndDate");


            Dictionary<DateTime, Dictionary<string, decimal>> result =
                    new Dictionary<DateTime, Dictionary<string, decimal>>();

            for (int i = 0; i <= numOfDays; i++)
            {
                DateTime datetime = startDate.AddDays(i).Add(time);

                if (datetime.DayOfWeek == DayOfWeek.Saturday || datetime.DayOfWeek == DayOfWeek.Sunday)
                    continue; // skip weekends

                Dictionary<string, decimal> prices = new Dictionary<string, decimal>();

                for (int m = 0; m < 34; m++)
                {
                    foreach (string mappingColumn in pricesColumns)
                    {
                        prices.Add(string.Format("{0}_{1}", m, mappingColumn), datetime.Day);
                    }
                }

                result.Add(datetime, prices);
            }

            return result;
        }
    }
}