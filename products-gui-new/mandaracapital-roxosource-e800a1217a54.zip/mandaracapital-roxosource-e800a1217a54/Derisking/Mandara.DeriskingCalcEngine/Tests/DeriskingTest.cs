using System;
using System.Collections.Generic;
using System.Linq;
using Kw.Combinatorics;
using Mandara.Business.Bus;
using Mandara.Entities;
using Mandara.Entities.Calculation;
using Mandara.VarCalcEngine.Impl;
using NUnit.Framework;
using SharpTestsEx;

namespace Mandara.DeriskingCalcEngine.Tests
{
    [TestFixture]
    public class DeriskingTest
    {
        [Test]
        public void Could_calculate_combinations_at_n_2_and_k_1()
        {
            // A A
            Combination combination = new Combination(2, 1);

            // A
            combination.Should().Not.Be.Null();

            var rowsList = combination.GetRows().ToList();
            rowsList.Count.Should().Be.EqualTo(2);
        }

        [Test]
        public void Could_read_trade_scenarios_from_database()
        {
            // Arrange
            DeriskingCalculator calc = new DeriskingCalculator();

            // Act
            List<TradeScenario> tradeScenarios = calc.GetTradeScenarios();

            // Assert
            tradeScenarios.Should().Not.Be.Null();
        }

        [Test]
        public void Could_calculate_trade_scenarios_combinations_for_n_3()
        {
            // A
            DeriskingCalculator calc = new DeriskingCalculator();
            List<TradeScenario> tradeScenarios = new List<TradeScenario>
                {
                    new TradeScenario()
                        {
                            Product = new Entities.Product() { ProductId = 12, Name = "ICE 180SING SW" },
                            Strip1DateType = 0, // m
                            Strip1DateIndex = 1,
                            Quantity = 10
                        },
                    new TradeScenario()
                        {
                            Product = new Entities.Product() { ProductId = 18, Name = "ICE BRENT CRD" },
                            Strip1DateType = 3, // q
                            Strip1DateIndex = 1,
                            Quantity = 8
                        },
                    new TradeScenario()
                        {
                            Product = new Entities.Product() { ProductId = 22, Name = "ICE WTISCRUDE" },
                            Strip1DateType = 0, // m
                            Strip1DateIndex = 2,
                            Strip2DateType = 0, // m
                            Strip2DateIndex = 3,
                            Quantity = 4
                        },
                };

            // A
            Dictionary<int, Solution> solutions = calc.GetPossibleSolutions(tradeScenarios, 2);

            // A
            solutions.Should().Not.Be.Null();
            solutions.Values.Count.Should().Be.EqualTo(12);
        }

        [Test]
        public void Could_calculate_trade_scenarios_combinations_for_n_11_k_5()
        {
            // A
            DeriskingCalculator calc = new DeriskingCalculator();
            List<TradeScenario> tradeScenarios = new List<TradeScenario>
                {
                    new TradeScenario()
                        {
                            Product = new Entities.Product() { ProductId = 12, Name = "ICE 180SING SW" },
                            Strip1DateType = 0, // m
                            Strip1DateIndex = 1,
                            Quantity = 10
                        },
                    new TradeScenario()
                        {
                            Product = new Entities.Product() { ProductId = 18, Name = "ICE BRENT CRD" },
                            Strip1DateType = 3, // q
                            Strip1DateIndex = 1,
                            Quantity = 8
                        },
                    new TradeScenario()
                        {
                            Product = new Entities.Product() { ProductId = 22, Name = "ICE WTISCRUDE" },
                            Strip1DateType = 0, // m
                            Strip1DateIndex = 2,
                            Strip2DateType = 0, // m
                            Strip2DateIndex = 3,
                            Quantity = 4
                        },
                    new TradeScenario()
                        {
                            Product = new Entities.Product() { ProductId = 12, Name = "ICE 180SING SW" },
                            Strip1DateType = 0, // m
                            Strip1DateIndex = 1,
                            Quantity = 10
                        },
                    new TradeScenario()
                        {
                            Product = new Entities.Product() { ProductId = 18, Name = "ICE BRENT CRD" },
                            Strip1DateType = 3, // q
                            Strip1DateIndex = 1,
                            Quantity = 8
                        },
                    new TradeScenario()
                        {
                            Product = new Entities.Product() { ProductId = 22, Name = "ICE WTISCRUDE" },
                            Strip1DateType = 0, // m
                            Strip1DateIndex = 2,
                            Strip2DateType = 0, // m
                            Strip2DateIndex = 3,
                            Quantity = 4
                        },
                    new TradeScenario()
                        {
                            Product = new Entities.Product() { ProductId = 12, Name = "ICE 180SING SW" },
                            Strip1DateType = 0, // m
                            Strip1DateIndex = 1,
                            Quantity = 10
                        },
                    new TradeScenario()
                        {
                            Product = new Entities.Product() { ProductId = 18, Name = "ICE BRENT CRD" },
                            Strip1DateType = 3, // q
                            Strip1DateIndex = 1,
                            Quantity = 8
                        },
                    new TradeScenario()
                        {
                            Product = new Entities.Product() { ProductId = 22, Name = "ICE WTISCRUDE" },
                            Strip1DateType = 0, // m
                            Strip1DateIndex = 2,
                            Strip2DateType = 0, // m
                            Strip2DateIndex = 3,
                            Quantity = 4
                        },
                    new TradeScenario()
                        {
                            Product = new Entities.Product() { ProductId = 12, Name = "ICE 180SING SW" },
                            Strip1DateType = 0, // m
                            Strip1DateIndex = 1,
                            Quantity = 10
                        },
                    new TradeScenario()
                        {
                            Product = new Entities.Product() { ProductId = 18, Name = "ICE BRENT CRD" },
                            Strip1DateType = 3, // q
                            Strip1DateIndex = 1,
                            Quantity = 8
                        },
                };

            // A
            Dictionary<int, Solution> solutions = calc.GetPossibleSolutions(tradeScenarios, 5);

            // A
            solutions.Should().Not.Be.Null();
            solutions.Values.Count.Should().Be.EqualTo(14784);
        }

        [Test]
        public void Could_calculate_trade_scenarios_combinations_for_n_11_k_6()
        {
            // A
            DeriskingCalculator calc = new DeriskingCalculator();
            List<TradeScenario> tradeScenarios = new List<TradeScenario>
                {
                    new TradeScenario()
                        {
                            Product = new Entities.Product() { ProductId = 12, Name = "ICE 180SING SW" },
                            Strip1DateType = 0, // m
                            Strip1DateIndex = 1,
                            Quantity = 10
                        },
                    new TradeScenario()
                        {
                            Product = new Entities.Product() { ProductId = 18, Name = "ICE BRENT CRD" },
                            Strip1DateType = 3, // q
                            Strip1DateIndex = 1,
                            Quantity = 8
                        },
                    new TradeScenario()
                        {
                            Product = new Entities.Product() { ProductId = 22, Name = "ICE WTISCRUDE" },
                            Strip1DateType = 0, // m
                            Strip1DateIndex = 2,
                            Strip2DateType = 0, // m
                            Strip2DateIndex = 3,
                            Quantity = 4
                        },
                    new TradeScenario()
                        {
                            Product = new Entities.Product() { ProductId = 12, Name = "ICE 180SING SW" },
                            Strip1DateType = 0, // m
                            Strip1DateIndex = 1,
                            Quantity = 10
                        },
                    new TradeScenario()
                        {
                            Product = new Entities.Product() { ProductId = 18, Name = "ICE BRENT CRD" },
                            Strip1DateType = 3, // q
                            Strip1DateIndex = 1,
                            Quantity = 8
                        },
                    new TradeScenario()
                        {
                            Product = new Entities.Product() { ProductId = 22, Name = "ICE WTISCRUDE" },
                            Strip1DateType = 0, // m
                            Strip1DateIndex = 2,
                            Strip2DateType = 0, // m
                            Strip2DateIndex = 3,
                            Quantity = 4
                        },
                    new TradeScenario()
                        {
                            Product = new Entities.Product() { ProductId = 12, Name = "ICE 180SING SW" },
                            Strip1DateType = 0, // m
                            Strip1DateIndex = 1,
                            Quantity = 10
                        },
                    new TradeScenario()
                        {
                            Product = new Entities.Product() { ProductId = 18, Name = "ICE BRENT CRD" },
                            Strip1DateType = 3, // q
                            Strip1DateIndex = 1,
                            Quantity = 8
                        },
                    new TradeScenario()
                        {
                            Product = new Entities.Product() { ProductId = 22, Name = "ICE WTISCRUDE" },
                            Strip1DateType = 0, // m
                            Strip1DateIndex = 2,
                            Strip2DateType = 0, // m
                            Strip2DateIndex = 3,
                            Quantity = 4
                        },
                    new TradeScenario()
                        {
                            Product = new Entities.Product() { ProductId = 12, Name = "ICE 180SING SW" },
                            Strip1DateType = 0, // m
                            Strip1DateIndex = 1,
                            Quantity = 10
                        },
                    new TradeScenario()
                        {
                            Product = new Entities.Product() { ProductId = 18, Name = "ICE BRENT CRD" },
                            Strip1DateType = 3, // q
                            Strip1DateIndex = 1,
                            Quantity = 8
                        },
                };

            // A
            Dictionary<int, Solution> solutions = calc.GetPossibleSolutions(tradeScenarios, 6);

            // A
            solutions.Should().Not.Be.Null();
            solutions.Values.Count.Should().Be.EqualTo(29568);
        }

        [Test]
        public void Could_calculate_solutions_impact_for_n_3_k_2()
        {
            // A
            DeriskingCalculator calc = new DeriskingCalculator();
            List<TradeScenario> tradeScenarios = new List<TradeScenario>
                {
                    new TradeScenario()
                        {
                            TradeScenarioId = 1,
                            Product = new Entities.Product() { ProductId = 12, Name = "ICE 180SING SW" },
                            Strip1DateType = 0, // m
                            Strip1DateIndex = 1,
                            Quantity = 10
                        },
                    new TradeScenario()
                        {
                            TradeScenarioId = 2,
                            Product = new Entities.Product() { ProductId = 18, Name = "ICE BRENT CRD" },
                            Strip1DateType = 3, // q
                            Strip1DateIndex = 1,
                            Quantity = 8
                        },
                    new TradeScenario()
                        {
                            TradeScenarioId = 3,
                            Product = new Entities.Product() { ProductId = 22, Name = "ICE WTISCRUDE" },
                            Strip1DateType = 0, // m
                            Strip1DateIndex = 2,
                            Strip2DateType = 0, // m
                            Strip2DateIndex = 3,
                            Quantity = 4
                        },
                };
            Dictionary<int, Solution> solutions = calc.GetPossibleSolutions(tradeScenarios, 2);
            List<Solution> list = solutions.Values.ToList();

            // A
            calc.CalculateSolutionsImpact(list, 8);

            // A
            foreach (Solution solution in list)
            {
                solution.Impact.Should().Not.Be.Null();
            }
        }

        [Test]
        public void Could_calculate_solutions_impact_for_n_11_k_5()
        {
            // A
            DeriskingCalculator calc = new DeriskingCalculator();
            List<TradeScenario> tradeScenarios = new List<TradeScenario>
                {
                    new TradeScenario()
                        {
                            TradeScenarioId = 1,
                            Product = new Entities.Product() { ProductId = 12, Name = "ICE 180SING SW" },
                            Strip1DateType = 0, // m
                            Strip1DateIndex = 1,
                            Quantity = 10
                        },
                    new TradeScenario()
                        {
                            TradeScenarioId = 2,
                            Product = new Entities.Product() { ProductId = 18, Name = "ICE BRENT CRD" },
                            Strip1DateType = 3, // q
                            Strip1DateIndex = 1,
                            Quantity = 8
                        },
                    new TradeScenario()
                        {
                            TradeScenarioId = 3,
                            Product = new Entities.Product() { ProductId = 22, Name = "ICE WTISCRUDE" },
                            Strip1DateType = 0, // m
                            Strip1DateIndex = 2,
                            Strip2DateType = 0, // m
                            Strip2DateIndex = 3,
                            Quantity = 4
                        },
                    new TradeScenario()
                        {
                            TradeScenarioId = 4,
                            Product = new Entities.Product() { ProductId = 12, Name = "ICE 180SING SW" },
                            Strip1DateType = 0, // m
                            Strip1DateIndex = 1,
                            Quantity = 10
                        },
                    new TradeScenario()
                        {
                            TradeScenarioId = 5,
                            Product = new Entities.Product() { ProductId = 18, Name = "ICE BRENT CRD" },
                            Strip1DateType = 3, // q
                            Strip1DateIndex = 1,
                            Quantity = 8
                        },
                    new TradeScenario()
                        {
                            TradeScenarioId = 6,
                            Product = new Entities.Product() { ProductId = 22, Name = "ICE WTISCRUDE" },
                            Strip1DateType = 0, // m
                            Strip1DateIndex = 2,
                            Strip2DateType = 0, // m
                            Strip2DateIndex = 3,
                            Quantity = 4
                        },
                    new TradeScenario()
                        {
                            TradeScenarioId = 7,
                            Product = new Entities.Product() { ProductId = 12, Name = "ICE 180SING SW" },
                            Strip1DateType = 0, // m
                            Strip1DateIndex = 1,
                            Quantity = 10
                        },
                    new TradeScenario()
                        {
                            TradeScenarioId = 8,
                            Product = new Entities.Product() { ProductId = 18, Name = "ICE BRENT CRD" },
                            Strip1DateType = 3, // q
                            Strip1DateIndex = 1,
                            Quantity = 8
                        },
                    new TradeScenario()
                        {
                            TradeScenarioId = 9,
                            Product = new Entities.Product() { ProductId = 22, Name = "ICE WTISCRUDE" },
                            Strip1DateType = 0, // m
                            Strip1DateIndex = 2,
                            Strip2DateType = 0, // m
                            Strip2DateIndex = 3,
                            Quantity = 4
                        },
                    new TradeScenario()
                        {
                            TradeScenarioId = 10,
                            Product = new Entities.Product() { ProductId = 12, Name = "ICE 180SING SW" },
                            Strip1DateType = 0, // m
                            Strip1DateIndex = 1,
                            Quantity = 10
                        },
                    new TradeScenario()
                        {
                            TradeScenarioId = 11,
                            Product = new Entities.Product() { ProductId = 18, Name = "ICE BRENT CRD" },
                            Strip1DateType = 3, // q
                            Strip1DateIndex = 1,
                            Quantity = 8
                        },
                };
            Dictionary<int, Solution> solutions = calc.GetPossibleSolutions(tradeScenarios, 5);
            List<Solution> list = solutions.Values.ToList();

            // A
            calc.CalculateSolutionsImpact(list, 8);

            // A
            foreach (Solution solution in list)
            {
                solution.Impact.Should().Not.Be.Null();
            }
        }

        [Test]
        public void Could_calculate_solutions_impact_for_n_11_k_6()
        {
            // A
            DeriskingCalculator calc = new DeriskingCalculator();
            List<TradeScenario> tradeScenarios = new List<TradeScenario>
                {
                    new TradeScenario()
                        {
                            TradeScenarioId = 1,
                            Product = new Entities.Product() { ProductId = 12, Name = "ICE 180SING SW" },
                            Strip1DateType = 0, // m
                            Strip1DateIndex = 1,
                            Quantity = 10
                        },
                    new TradeScenario()
                        {
                            TradeScenarioId = 2,
                            Product = new Entities.Product() { ProductId = 18, Name = "ICE BRENT CRD" },
                            Strip1DateType = 3, // q
                            Strip1DateIndex = 1,
                            Quantity = 8
                        },
                    new TradeScenario()
                        {
                            TradeScenarioId = 3,
                            Product = new Entities.Product() { ProductId = 22, Name = "ICE WTISCRUDE" },
                            Strip1DateType = 0, // m
                            Strip1DateIndex = 2,
                            Strip2DateType = 0, // m
                            Strip2DateIndex = 3,
                            Quantity = 4
                        },
                    new TradeScenario()
                        {
                            TradeScenarioId = 4,
                            Product = new Entities.Product() { ProductId = 12, Name = "ICE 180SING SW" },
                            Strip1DateType = 0, // m
                            Strip1DateIndex = 1,
                            Quantity = 10
                        },
                    new TradeScenario()
                        {
                            TradeScenarioId = 5,
                            Product = new Entities.Product() { ProductId = 18, Name = "ICE BRENT CRD" },
                            Strip1DateType = 3, // q
                            Strip1DateIndex = 1,
                            Quantity = 8
                        },
                    new TradeScenario()
                        {
                            TradeScenarioId = 6,
                            Product = new Entities.Product() { ProductId = 22, Name = "ICE WTISCRUDE" },
                            Strip1DateType = 0, // m
                            Strip1DateIndex = 2,
                            Strip2DateType = 0, // m
                            Strip2DateIndex = 3,
                            Quantity = 4
                        },
                    new TradeScenario()
                        {
                            TradeScenarioId = 7,
                            Product = new Entities.Product() { ProductId = 12, Name = "ICE 180SING SW" },
                            Strip1DateType = 0, // m
                            Strip1DateIndex = 1,
                            Quantity = 10
                        },
                    new TradeScenario()
                        {
                            TradeScenarioId = 8,
                            Product = new Entities.Product() { ProductId = 18, Name = "ICE BRENT CRD" },
                            Strip1DateType = 3, // q
                            Strip1DateIndex = 1,
                            Quantity = 8
                        },
                    new TradeScenario()
                        {
                            TradeScenarioId = 9,
                            Product = new Entities.Product() { ProductId = 22, Name = "ICE WTISCRUDE" },
                            Strip1DateType = 0, // m
                            Strip1DateIndex = 2,
                            Strip2DateType = 0, // m
                            Strip2DateIndex = 3,
                            Quantity = 4
                        },
                    new TradeScenario()
                        {
                            TradeScenarioId = 10,
                            Product = new Entities.Product() { ProductId = 12, Name = "ICE 180SING SW" },
                            Strip1DateType = 0, // m
                            Strip1DateIndex = 1,
                            Quantity = 10
                        },
                    new TradeScenario()
                        {
                            TradeScenarioId = 11,
                            Product = new Entities.Product() { ProductId = 18, Name = "ICE BRENT CRD" },
                            Strip1DateType = 3, // q
                            Strip1DateIndex = 1,
                            Quantity = 8
                        },
                };
            Dictionary<int, Solution> solutions = calc.GetPossibleSolutions(tradeScenarios, 6);
            List<Solution> list = solutions.Values.ToList();

            // A
            calc.CalculateSolutionsImpact(list, 8);

            // A
            foreach (Solution solution in list)
            {
                solution.Impact.Should().Not.Be.Null();
            }
        }

        [Test]
        public void Could_calculate_solutions_impact_for_n_11_k_6_via_scenarios_impact()
        {
            // A
            DeriskingCalculator calc = new DeriskingCalculator();
            List<TradeScenario> tradeScenarios = new List<TradeScenario>
                {
                    new TradeScenario()
                        {
                            TradeScenarioId = 1,
                            Product = new Entities.Product() { ProductId = 12, Name = "ICE 180SING SW" },
                            Strip1DateType = 0, // m
                            Strip1DateIndex = 1,
                            Quantity = 10
                        },
                    new TradeScenario()
                        {
                            TradeScenarioId = 2,
                            Product = new Entities.Product() { ProductId = 18, Name = "ICE BRENT CRD" },
                            Strip1DateType = 3, // q
                            Strip1DateIndex = 1,
                            Quantity = 8
                        },
                    new TradeScenario()
                        {
                            TradeScenarioId = 3,
                            Product = new Entities.Product() { ProductId = 22, Name = "ICE WTISCRUDE" },
                            Strip1DateType = 0, // m
                            Strip1DateIndex = 2,
                            Strip2DateType = 0, // m
                            Strip2DateIndex = 3,
                            Quantity = 4
                        },
                    new TradeScenario()
                        {
                            TradeScenarioId = 4,
                            Product = new Entities.Product() { ProductId = 12, Name = "ICE 180SING SW" },
                            Strip1DateType = 0, // m
                            Strip1DateIndex = 1,
                            Quantity = 10
                        },
                    new TradeScenario()
                        {
                            TradeScenarioId = 5,
                            Product = new Entities.Product() { ProductId = 18, Name = "ICE BRENT CRD" },
                            Strip1DateType = 3, // q
                            Strip1DateIndex = 1,
                            Quantity = 8
                        },
                    new TradeScenario()
                        {
                            TradeScenarioId = 6,
                            Product = new Entities.Product() { ProductId = 22, Name = "ICE WTISCRUDE" },
                            Strip1DateType = 0, // m
                            Strip1DateIndex = 2,
                            Strip2DateType = 0, // m
                            Strip2DateIndex = 3,
                            Quantity = 4
                        },
                    new TradeScenario()
                        {
                            TradeScenarioId = 7,
                            Product = new Entities.Product() { ProductId = 12, Name = "ICE 180SING SW" },
                            Strip1DateType = 0, // m
                            Strip1DateIndex = 1,
                            Quantity = 10
                        },
                    new TradeScenario()
                        {
                            TradeScenarioId = 8,
                            Product = new Entities.Product() { ProductId = 18, Name = "ICE BRENT CRD" },
                            Strip1DateType = 3, // q
                            Strip1DateIndex = 1,
                            Quantity = 8
                        },
                    new TradeScenario()
                        {
                            TradeScenarioId = 9,
                            Product = new Entities.Product() { ProductId = 22, Name = "ICE WTISCRUDE" },
                            Strip1DateType = 0, // m
                            Strip1DateIndex = 2,
                            Strip2DateType = 0, // m
                            Strip2DateIndex = 3,
                            Quantity = 4
                        },
                    new TradeScenario()
                        {
                            TradeScenarioId = 10,
                            Product = new Entities.Product() { ProductId = 12, Name = "ICE 180SING SW" },
                            Strip1DateType = 0, // m
                            Strip1DateIndex = 1,
                            Quantity = 10
                        },
                    new TradeScenario()
                        {
                            TradeScenarioId = 11,
                            Product = new Entities.Product() { ProductId = 18, Name = "ICE BRENT CRD" },
                            Strip1DateType = 3, // q
                            Strip1DateIndex = 1,
                            Quantity = 8
                        },
                };


            Dictionary<int, Solution> solutions = calc.GetPossibleSolutions(tradeScenarios, 6);
            List<Solution> list = solutions.Values.ToList();

            var map = calc.CalculateTradeScenariosImpacts(tradeScenarios);

            // A
            calc.CalculateSolutionsImpact(list, 8, map);

            // A
            foreach (Solution solution in list)
            {
                solution.Impact.Should().Not.Be.Null();
            }
        }

        [Test]
        public void Could_minimize_var_for_k_5()
        {
            // A
            DeriskingCalculator calc = new DeriskingCalculator(new FakePricesGetter());
            Solution baseSolution;
            Solution optimalSolution;

            // A
            calc.MinimizeVar(5, 95, 8, 0, out baseSolution, out optimalSolution);

            // A
            baseSolution.Should().Not.Be.Null();
            optimalSolution.Should().Not.Be.Null();
        }

        [Test]
        public void Could_minimize_var_for_k_6()
        {
            // A
            DeriskingCalculator calc = new DeriskingCalculator(new FakePricesGetter());
            Solution baseSolution;
            Solution optimalSolution;

            // A
            calc.MinimizeVar(6, 95, 8, 0, out baseSolution, out optimalSolution);

            // A
            baseSolution.Should().Not.Be.Null();
            optimalSolution.Should().Not.Be.Null();

            foreach (TradeScenario tradeScenario in optimalSolution.TradeScenarios)
            {
                tradeScenario.Product.Name.Should().Not.Be.NullOrEmpty();
            }
        }

        [Test]
        public void Could_minimize_var_for_k_2()
        {
            // A
            BusClient busClient = new BusClient();
            busClient.Start();

            DeriskingCalculator calc = new DeriskingCalculator(busClient, new FakePricesGetter());
            Solution baseSolution;
            Solution optimalSolution;

            // A
            calc.MinimizeVar(2, 95, 8, 0, out baseSolution, out optimalSolution);

            // A
            baseSolution.Should().Not.Be.Null();
            optimalSolution.Should().Not.Be.Null();
            
            busClient.Stop();
        }

        [Test]
        public void Could_minimize_var_for_k_1()
        {
            // A
            DeriskingCalculator calc = new DeriskingCalculator(new FakePricesGetter());
            Solution baseSolution;
            Solution optimalSolution;

            // A
            calc.MinimizeVar(1, 95, 8, 0, out baseSolution, out optimalSolution);

            // A
            baseSolution.Should().Not.Be.Null();
            optimalSolution.Should().Not.Be.Null();
        }

        [Test]
        public void Dummy_mia_prices_could_be_replaced()
        {
            // A
            List<decimal> dummyPrices = ReadDummyPricesFromAppConfig();
            DummyMiaPricesDecorator dummyMiaPricesDecorator = new DummyMiaPricesDecorator(new FakePricesGetter());

            // A
            var prices = dummyMiaPricesDecorator.GetPrices(new List<string> {"r1"}, new DateTime(2012, 10, 01), new DateTime(2012, 10, 31), new TimeSpan(16, 30, 00));

            // A
            foreach (KeyValuePair<DateTime, Dictionary<string, decimal>> pair in prices)
            {
                foreach (KeyValuePair<string, decimal> columnPrice in pair.Value)
                {
                    dummyPrices.ForEach(dp => columnPrice.Value.Should().Not.Be.EqualTo(dp));
                }
            }
        }

        private List<decimal> ReadDummyPricesFromAppConfig()
        {
            string dummyMiaPricesString = "15|42";

            List<decimal> dummyPrices = new List<decimal>();

            foreach (string priceString in dummyMiaPricesString.Split('|'))
            {
                decimal pr;
                if (decimal.TryParse(priceString, out pr))
                    dummyPrices.Add(pr);
            }

            return dummyPrices;
        }
    }
}