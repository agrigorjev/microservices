﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using com.latencybusters.lbm;
using Mandara.Bus.Common;
using Mandara.Bus.HistoricalService;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace Mandara.Bus.HistoricalClient
{

    class Program
    {
        static LBMContext lbmContext;

        static void Main(string[] args)
        {
            if (Config.LBMConfigurationFilePath != null)
                LBM.setConfiguration(Config.LBMConfigurationFilePath);

            lbmContext = new LBMContext();

            Console.WriteLine("Application queries historical data for 2011 year for a given product");
            Console.Write("Enter product name: ");
            //String product = Console.ReadLine().Trim();
            String product = "Dubai";
            Console.WriteLine(product);

            HistoricalPriceRequest hpRequest = new HistoricalPriceRequest
                {
                    RequestID = Guid.NewGuid(),
                    Product = product,
                    StartDate = new DateTime(2011, 01, 01),
                    EndDate = new DateTime(2011, 12, 31)
                };

            Console.WriteLine("Request ID: " + hpRequest.RequestID);

            LBMTopic lbmTopic = new LBMTopic(lbmContext, String.Format(Config.HistoricalResponsesSource, hpRequest.RequestID));
            LBMReceiver lbmReceiver = new LBMReceiver(lbmContext, lbmTopic, onReceive, null, null);


            IFormatter formatter = new BinaryFormatter();
            MemoryStream stream = new MemoryStream();
            formatter.Serialize(stream, hpRequest);
            Byte[] message = stream.ToArray();
            stream.Close();

            LBMRequest req = new LBMRequest(message, message.Length);
            req.addResponseCallback(new LBMResponseCallback(onResponse));

            lbmContext.send(Config.HistoricalRequestsSource, req, 0);

            Console.ReadLine();

            lbmReceiver.close();
            req.close();
            lbmContext.close();
        }

        static int onResponse(object cbArg, LBMRequest req, LBMMessage msg)
        {
            switch (msg.type())
            {
                case LBM.MSG_RESPONSE:
                        System.Console.Out.WriteLine("Response ["
                                + msg.source()
                                + "]["
                                + msg.sequenceNumber()
                                + "], "
                                + msg.data().Length
                                + " bytes");
                    break;
                default:
                    System.Console.Out.WriteLine("Unknown message type "
                            + msg.type()
                            + "["
                            + msg.source()
                            + "]");
                    break;
            }
            msg.dispose();
            return 0;
        }

        private static Int32 onReceive(Object cbArgs, LBMMessage theMessage)
        {
            switch (theMessage.type())
            {
                case LBM.MSG_DATA:

                    IFormatter formatter = new BinaryFormatter();
                    Stream stream = new MemoryStream(theMessage.data());
                    HistoricalPrice historicalPrice = (HistoricalPrice)formatter.Deserialize(stream);
                    stream.Close();

                    Console.WriteLine(String.Format("Price received. Date: {0}, price: {1}",
                        historicalPrice.Date, historicalPrice.Price));

                    break;

                case LBM.MSG_BOS:
                    System.Console.WriteLine("[" + theMessage.topicName() + "][" + theMessage.source() + "], Beginning of Transport Session");
                    break;

                case LBM.MSG_EOS:
                    System.Console.WriteLine("[" + theMessage.topicName() + "][" + theMessage.source() + "], End of Transport Session");
                    break;
                default:
                    System.Console.WriteLine("unexpected event: " + theMessage.type());
                    System.Environment.Exit(1);
                    break;
            }
            theMessage.dispose();
            return 0;
        }
    }
}
