﻿using NLog;
using Optional;
using Optional.Unsafe;
using QuickFix;
using QuickFix.Fields;
using System;
using QuickFix.FIX44;
using Message = QuickFix.Message;

namespace DropCopyFeedHandler
{
    public class FIXApplication : IApplication
    {
        public delegate void SessionCreated(object sender, FIXSessionArgs args);
        public event SessionCreated OnSessionCreated;

        public delegate void LogonComplete(object sender, FIXSessionArgs args);
        public event LogonComplete OnLogonComplete;

        public delegate void LogoutComplete(object sender, FIXSessionArgs args);
        public event LogoutComplete OnLogoutComplete;

        public delegate void FIXAppMessageReceived(object sender, FIXMessageArgs args);
        public event FIXAppMessageReceived OnFIXAppMessageReceived;

        public delegate void FIXAppOnLogin(object sender, FIXMessageArgs args);
        public event FIXAppMessageReceived OnFIXAppLogin;

        private readonly ILogger _logger = LogManager.GetCurrentClassLogger();

        public void ToAdmin(Message message, SessionID sessionID)
        {

            Option<MsgType> msgType = GetMessageType(message);
            LogMessage(message,msgType);

            if (msgType.HasValue)
            {
                switch (msgType.ValueOrFailure().getValue())
                {
                    case MsgType.HEARTBEAT:
                        {
                            _logger.Info("FIXApplication: Send Heartbeat.");
                        }
                        break;
                    case MsgType.LOGON:
                        {
                            OnFIXAppLogin?.Invoke(this, new FIXMessageArgs(message, sessionID));
                        }
                        break;
                }
            }
        }

        private void LogMessage(Message message, Option<MsgType> msgType)
        {
            if (msgType.HasValue && msgType.ValueOrFailure().getValue().Equals(MsgType.LOGON))
            {
                _logger.Trace("FIXApplication: Sending login message");
            }
            else
            {
                _logger.Trace("FIXApplication: Sending ToAdmin message: {0}", message);
            }
        }

        private static Option<MsgType> GetMessageType(Message message)
        {
            MsgType msgTypeField = message.Header.GetField(new MsgType()) as MsgType;

            return null == msgTypeField ? Option.None<MsgType>() : Option.Some(msgTypeField);
        }

        public void FromAdmin(Message message, SessionID sessionId)
        {
            _logger.Trace("FIXApplication: Received FromAdmin message: {0}", message);
        }

        public void ToApp(Message message, SessionID sessionId)
        {
            _logger.Trace("FIXApplication: Sending ToApp message: {0}", message);
        }

        public void FromApp(Message message, SessionID sessionID)
        {
            Option<MsgType> msgType = GetMessageType(message);

            switch (msgType.ValueOrFailure().getValue())
            {
                case MsgType.EXECUTIONREPORT:
                    {
                    OnFIXAppMessageReceived?.Invoke(this, new FIXMessageArgs(message, sessionID));
                    }
                    break;

                default:
                    {
                        _logger.Info(
                            "FIXApplication: Application-level message with type {0} received in session {1} is "
                                + "not handled by the MIDAS IRM Feed.\n{2}",
                            msgType.ValueOrFailure(),
                            sessionID,
                            message);
                    }
                    break;
            }
        }

        public void OnCreate(SessionID sessionID)
        {
            _logger.Info("FIXApplication: Session created with ID {0}", sessionID);

            OnSessionCreated?.Invoke(this, new FIXSessionArgs(sessionID));
        }

        public void OnLogout(SessionID sessionID)
        {
            OnLogoutComplete?.Invoke(this, new FIXSessionArgs(sessionID));
        }

        public void OnLogon(SessionID sessionID)
        {
            OnLogonComplete?.Invoke(this, new FIXSessionArgs(sessionID));
        }
    }

    public class FIXSessionArgs : EventArgs
    {
        public SessionID SessionId { get; }

        public FIXSessionArgs(SessionID id)
        {
            SessionId = id;
        }
    }

    public class FIXMessageArgs : EventArgs
    {
        public Message FIXMessage { get; }
        public SessionID SessionId { get; }

        public FIXMessageArgs(Message msg, SessionID id)
        {
            FIXMessage = msg;
            SessionId = id;
        }
    }

}
