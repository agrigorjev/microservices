﻿using NLog;
using System.Reflection;
using Topshelf;
using Topshelf.HostConfigurators;
using Topshelf.ServiceConfigurators;

namespace DropCopyFeedHandler
{
    public abstract class DropCopyServiceStarter
    {
        private static readonly ILogger Logger = LogManager.GetCurrentClassLogger();

        public void CreateService(string svcName)
        {
            HostFactory.Run(hostConfig => SetUpServiceConfigurator(hostConfig, svcName));
        }

        private void SetUpServiceConfigurator(HostConfigurator svcHost, string svcName)
        {
            svcHost.UseNLog();

            svcHost.Service<IDropCopyService>(SetUpDropCopyFeedSvcExecution);
            svcHost.RunAsLocalSystem();

            string svcTitle = GetServerTitle(svcName);

            svcHost.SetServiceName(svcName);
            svcHost.SetDisplayName(svcTitle);
            Logger.Info("Starting {0}", svcTitle);
        }

        private void SetUpDropCopyFeedSvcExecution(ServiceConfigurator<IDropCopyService> dropCopySvcConfig)
        {
            dropCopySvcConfig.ConstructUsing(name => GetDropCopyService());

            dropCopySvcConfig.WhenStarted(
                delegate (IDropCopyService dropCopySvc, HostControl hostControl)
                {
                    dropCopySvc.Start(hostControl);

                    if (dropCopySvc.IsBusy())
                    {
                        Logger.Info("The service has started and is initialising.");
                        return true;
                    }

                    Logger.Info("The service startup failed.");
                    return false;
                });

            dropCopySvcConfig.WhenStopped(dropCopySvc => dropCopySvc.Stop());
        }

        protected abstract IDropCopyService GetDropCopyService();

        private static string GetServerTitle(string svcName)
        {
            return $"{svcName} - v.{Assembly.GetEntryAssembly().GetName().Version}";
        }
    }
}
