﻿using Mandara.Extensions.AppSettings;
using Mandara.Extensions.Option;
using System;

namespace DropCopyFeedHandler.Configuration
{
    public class DropCopyAppSettingsReader
    {
        public const string ServiceName = "DropyCopy Feed";
        public const string DropCopyServiceUserName = "UserName";

        private static string _userName;

        protected static string GetSetting(string settingName, string defaultVal)
        {
            TryGetResult<String> appSettingVal = AppSettings.TryGetValue(settingName);

            return appSettingVal.HasValue ? appSettingVal.Value : defaultVal;
        }

        public static string UserName => _userName ?? GetSetting(DropCopyServiceUserName, String.Empty);
    }
}