﻿namespace DropCopyFeedHandler.StorageInterface
{
    /// <summary>
    /// Implement this interface for storing trades received under the FIX protocol.  Implementers expect that the input
    /// they receive is already mapped from the QuickFix/n ExecutionReport class to a type that is ready for storage.
    /// </summary>
    public interface IFixTradeStorer
    {
        /// <summary>
        /// Store data  for a generic data type.  Implementations are free to provide storage to whatever medium is 
        /// necessary.
        /// </summary>
        /// <typeparam name="T">The type of the entity to store.</typeparam>
        /// <param name="entityToStore">The entity that has to be stored.</param>
        /// <returns><code>true</code> if storing the entity is successful, otherwise <code>false</code>.</returns>
        bool Store<T>(T entityToStore) where T : class;
    }
}
