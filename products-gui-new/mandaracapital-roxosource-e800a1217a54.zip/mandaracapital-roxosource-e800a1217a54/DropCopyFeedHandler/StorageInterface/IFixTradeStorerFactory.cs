﻿namespace DropCopyFeedHandler.StorageInterface
{
    /// <summary>
    /// Create instances of trade storer classes.  This interface exists largely to facilitate unit testing by making it
    /// possible to create dummy storer classes.
    /// </summary>
    public interface IFixTradeStorerFactory
    {
        /// <summary>
        /// Create a class to store trades that were actually executed on an exchange to make them available for IRM.
        /// </summary>
        /// <returns></returns>
        IFixTradeStorer GetExchangeTradeStorer();
        /// <summary>
        /// Create a class to store trades that were internal transfers to make them available for IRM.
        /// </summary>
        /// <returns></returns>
        IFixTradeStorer GetTransferTradeStorer();
    }
}
