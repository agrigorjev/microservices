﻿using QuickFix;
using QuickFix.Transport;
using System;

namespace DropCopyFeedHandler.FIXEndpoints
{
    public class Initiator : EndPoint<SocketInitiator>, IDisposable
    {
        public bool LoggedOn { get; private set; }

        public Initiator(MessageCracker cracker, Action<FIXMessageArgs> loginAction)
            : base(cracker,loginAction)
        {
        }

        public Initiator(MessageCracker cracker): this(cracker, message => { })
        {
        }

        protected override SocketInitiator ConstructEndPoint(
            SessionSettings settings,
            IMessageStoreFactory msgStoreFactory,
            ILogFactory logFactory)
        {
            return new SocketInitiator(CreateFIXApplication(), msgStoreFactory, settings, logFactory);
        }

        protected override void Start()
        {
            logger.Info("Initiator: Starting QuickFIX initiator.");
            endpoint.Start();
        }

        protected override void Stop()
        {
            logger.Info("Initiator: Stopping QuickFIX initiator.");
            endpoint.Stop();
        }

        protected override void OnLogon(object sender, FIXSessionArgs args)
        {
            if (args.SessionId != initialSession.SessionID)
            {
                logger.Info("Initiator: Received logon notification for unknown session ID {0}", args.SessionId);
                return;
            }

            LoggedOn = true;
            logger.Info("Initiator: Initiator has logged on with session ID {0}...", args.SessionId);
        }

        protected override void OnLogout(object sender, FIXSessionArgs args)
        {
            if (!LoggedOn)
            {
                logger.Info(
                    "Initiator: Received logout notification for session {0} when not logged on.",
                    args.SessionId);
                return;
            }

            if (args.SessionId != initialSession.SessionID)
            {
                logger.Info("Initiator: Received logout notification for unknown session ID {0}", args.SessionId);
                return;
            }

            LoggedOn = false;
            logger.Info("Initiator: Initiator has logged out from session ID {0}...", args.SessionId);
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected void Dispose(bool isDisposing)
        {
            if (isDisposing && (msgCracker is IDisposable))
            {
                (msgCracker as IDisposable).Dispose();
                msgCracker = null;
            }
        }
    }
}
