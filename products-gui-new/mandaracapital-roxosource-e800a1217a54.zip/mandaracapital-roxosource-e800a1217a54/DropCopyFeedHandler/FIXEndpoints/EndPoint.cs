﻿using NLog;
using QuickFix;
using System;
using System.IO;

namespace DropCopyFeedHandler.FIXEndpoints
{
    public abstract class EndPoint<T>
    {
        public bool IsRunning { get; protected set; }
        protected MessageCracker msgCracker;
        protected IApplication fixApplication;
        protected T endpoint;
        protected Session initialSession;
        protected readonly ILogger logger = LogManager.GetCurrentClassLogger();

        private Action<FIXMessageArgs> _loginAction;

        protected EndPoint(MessageCracker cracker, Action<FIXMessageArgs> loginAction)
        {
            msgCracker = cracker;
            _loginAction = loginAction;
        }

        protected abstract T ConstructEndPoint(
            SessionSettings settings,
            IMessageStoreFactory msgStoreFactory,
            ILogFactory logFactory);

        public virtual void StartEndPoint(string configFileName)
        {
            if (!File.Exists(configFileName))
            {
                throw new FileNotFoundException($"Endpoint: Configuration file {configFileName} does not exist.");
            }

            if (IsRunning)
            {
                return;
            }

            SessionSettings sessionSet = new SessionSettings(configFileName);
            IMessageStoreFactory msgStoreFactory = new FileStoreFactory(sessionSet);
            ILogFactory logFactory = new FileLogFactory(sessionSet);

            try
            {
                endpoint = ConstructEndPoint(sessionSet, msgStoreFactory, logFactory);
                Start();
                IsRunning = true;
                logger.Info("Endpoint started");
            }
            catch (ConfigError configErr)
            {
                logger.Error(configErr, "Endpoint: The configuration file is not valid: {0}");
            }
            catch (Exception ex)
            {
                logger.Error(ex, "Endpoint: Exception during start-up of the endpoint: {0}");
            }
        }

        protected IApplication CreateFIXApplication()
        {
            FIXApplication app = new FIXApplication();

            app.OnSessionCreated += OnSessionCreated;
            app.OnLogonComplete += OnLogon;
            app.OnLogoutComplete += OnLogout;
            app.OnFIXAppMessageReceived += OnMessageReceived;
            app.OnFIXAppLogin += FIXAppLogin;
            fixApplication = app;
            return fixApplication;
        }

        private void FIXAppLogin(object sender, FIXMessageArgs args)
        {
            _loginAction.Invoke(args);
        }

        protected abstract void Start();

        protected virtual void OnSessionCreated(object sender, FIXSessionArgs args)
        {
            initialSession = Session.LookupSession(args.SessionId);
        }

        protected abstract void OnLogon(object sender, FIXSessionArgs args);

        private void OnMessageReceived(object sender, FIXMessageArgs args)
        {
            msgCracker.Crack(args.FIXMessage, args.SessionId);
        }

        public virtual void StopEndPoint()
        {
            if (IsRunning)
            {
                Stop();
                IsRunning = false;
            }
        }

        protected abstract void Stop();

        protected abstract void OnLogout(object sender, FIXSessionArgs args);
    }
}
