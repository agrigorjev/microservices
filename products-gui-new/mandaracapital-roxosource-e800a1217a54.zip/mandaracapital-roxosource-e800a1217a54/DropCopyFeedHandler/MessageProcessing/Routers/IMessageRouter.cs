using QuickFix.FIX44;

namespace DropCopyFeedHandler.MessageProcessing.Routers
{
    /// <summary>
    /// Routes <see cref="ExecutionReport"/> through the steps after receipt until the trade data is saved.  The steps
    /// include at least mapping and saving, though a given router implementation is not necessarily responsible for
    /// ensuring all steps are executed, but must at least pass the message on to something that is responsible.
    /// </summary>
    public interface IMessageRouter
    {
        /// <summary>
        /// Execute the steps required to take a received ExecutionReport to the point of being saved or pass it on to
        /// sommething that is.
        /// </summary>
        /// <param name="execRpt">The <see cref="ExecutionReport"/> to handle.</param>
        void RouteToDestination(ExecutionReport execRpt);
    }
}