using NLog;
using QuickFix.FIX44;

namespace DropCopyFeedHandler.MessageProcessing.Routers
{
    public abstract class BaseMessageRouter : IMessageRouter
    {
        protected readonly ILogger logger = LogManager.GetCurrentClassLogger();

        protected BaseMessageRouter()
        {
            LoadConfigurationValues();
        }

        protected virtual void LoadConfigurationValues()
        {
        }

        public abstract void RouteToDestination(ExecutionReport execRpt);

        protected abstract bool IsExchangeTrade(ExecutionReport execRpt);
    }
}