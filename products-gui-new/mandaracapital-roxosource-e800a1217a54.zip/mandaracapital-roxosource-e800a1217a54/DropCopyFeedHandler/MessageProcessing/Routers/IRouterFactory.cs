﻿namespace DropCopyFeedHandler.MessageProcessing.Routers
{
    /// <summary>
    /// This factory is able to return instances of message routers.  Message routers do not all conform to a single
    /// interface so this interface has at least one factory function for each message type that must be routed after
    /// receipt.
    /// </summary>
    public interface IRouterFactory
    {
        /// <summary>
        /// Return an <see cref="IMessageRouter"/> instance.  The factory must know whether it can return new
        /// instances or must always return the same instance.
        /// </summary>
        /// <returns></returns>
        IMessageRouter GetExecutionReportRouter();
    }
}
