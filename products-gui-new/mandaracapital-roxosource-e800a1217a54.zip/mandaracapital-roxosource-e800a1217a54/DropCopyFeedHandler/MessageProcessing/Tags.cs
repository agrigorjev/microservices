﻿namespace DropCopyFeedHandler.MessageProcessing
{
    public static class Tags
    {
        public const int TrnDestination = 16501;
        public const int MndOrdType = 18400;
        public const int MndMaturityDate = 18401;
        public const int MndExchInstrID = 18402;
        public const int MndLocalTradingCode = 18403;
        public const int MndExpirationDate = 18404;
        public const int MndLocalCode = 18405;
        public const int MndOrdQty = 18407;

        //TT group Tag
        public const int TTNumberOfLink = 16112;
        //TT repeated tags
        public const int TTLinkId = 16113;
        public const int TTLinkType = 16114;
        //TT maturity
        public const int TTFlatMaturity = 18223;
        public const int TTLegMaturity = 18224;

    }
}
