﻿using DropCopyFeedHandler.MessageProcessing.Routers;
using NLog;
using QuickFix;
using QuickFix.Fields;
using QuickFix.FIX44;
using System;
using System.Collections.Concurrent;
using System.Threading;
using System.Threading.Tasks;

namespace DropCopyFeedHandler.MessageProcessing
{
    public class ClientMessageCracker : MessageCracker, IDisposable
    {
        private ILogger _logger = LogManager.GetCurrentClassLogger();
        private readonly IMessageRouter _executionReportRouter;

        private readonly BlockingCollection<ExecutionReport> _execReportQueue =
            new BlockingCollection<ExecutionReport>(new ConcurrentQueue<ExecutionReport>());
        private readonly ManualResetEventSlim _allowExecReportQueueToEmpty = new ManualResetEventSlim(false);
        private bool _disposed;
        private Task _msgHandler;

        public void SupersedeLogger(ILogger newLogger)
        {
            _logger = newLogger ?? _logger;
        }

        public ClientMessageCracker(IMessageRouter execRptRouter)
        {
            _executionReportRouter = execRptRouter;
            StartMsgHandler();
        }

        private void StartMsgHandler()
        {
            _msgHandler = new TaskFactory().StartNew(HandleExecutionReports);
        }

        public void OnMessage(ExecutionReport execRpt, SessionID sessionId)
        {
            if (_execReportQueue.IsAddingCompleted)
            {
                _logger.Error(
                    $"Received {execRpt.ToShortString()} after shutdown was begun.  The message has not been processed.");
                return;
            }

            _logger.Info("ClientMessageCracker: Received execution report [{0}]", execRpt.ToShortString());

            if (IsFillOrPartialFill(execRpt))
            {
                try
                {
                    _logger.Info("ClientMessageCracker: Queuing execution report [{0}]", execRpt.ToShortString());
                    _execReportQueue.Add(execRpt);
                }
                catch (Exception ex)
                {
                    _logger.Error(
                        ex,
                        "ClientMessageCracker: Unhandled exception for ExecutionReport, ExecID:{0}",
                        execRpt.ExecID.getValue());
                }
            }
        }

        private bool IsFillOrPartialFill(ExecutionReport execReport)
        {
            if (!execReport.IsSetExecType())
            {
                _logger.Warn(
                    "ClientMessageCracker: ExecType not set for the ExecutionReport with ExecId:{0}.  " +
                    "The message can not be routed",
                    execReport.ExecID.getValue());
                return false;
            }

            switch (execReport.ExecType.getValue())
            {
                case ExecType.FILL:
                case ExecType.PARTIAL_FILL:
                    {
                        return true;
                    }
                case ExecType.TRADE:
                {
                    return execReport.IsSetOrdStatus() &&
                           (execReport.OrdStatus.Obj == OrdStatus.FILLED
                            || execReport.OrdStatus.Obj == OrdStatus.PARTIALLY_FILLED);
                }
            }
            return false;
        }

        private void HandleExecutionReports()
        {
            try
            {
                while (!_execReportQueue.IsCompleted)
                {
                    TryProcessExecutionReport();
                }
            }
            finally
            {
                _allowExecReportQueueToEmpty.Set();
            }
        }

        private void TryProcessExecutionReport()
        {
            ExecutionReport execRpt = null;

            try
            {
                execRpt = _execReportQueue.Take();

                _logger.Info(
                    "ClientMessageCracker: Processing execution report [{0}] from queue",
                    execRpt.ToShortString());
                _executionReportRouter.RouteToDestination(execRpt);
            }
            catch (InvalidOperationException invalidOp)
            {
                if (_execReportQueue.IsCompleted)
                {
                    return;
                }

                _logger.Error(
                    invalidOp,
                    "ClientMessageCracker.HandleExecutionReports: Error taking ExecutionReport from processing queue.");
            }
            catch (Exception unexpected)
            {
                _logger.Error(unexpected,
                    "ClientMessageCracker.HandleExecutionReports: Error processing ExecutionReport [{0}].",
                    null != execRpt ? execRpt.ToShortString() : "unknown");
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected void Dispose(bool isDisposing)
        {
            if (isDisposing && !_disposed)
            {
                _disposed = true;
                StopExecutionReportProcessing();
            }
        }

        private void StopExecutionReportProcessing()
        {
            if (!_msgHandler.IsCanceled
                && !_msgHandler.IsCompleted
                && !_msgHandler.IsFaulted)
            {
                _logger.Info("Enqueuing final execution report and waiting for reports on the queue to be processed.");
                _execReportQueue.CompleteAdding();
                _allowExecReportQueueToEmpty.Wait();
            }
        }
    }
}
