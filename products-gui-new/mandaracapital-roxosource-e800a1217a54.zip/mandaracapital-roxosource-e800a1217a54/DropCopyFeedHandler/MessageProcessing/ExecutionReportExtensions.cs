﻿using System;
using System.Collections.Generic;
using System.Linq;
using QuickFix.Fields;
using QuickFix.FIX44;
using System.Text;
using QuickFix;
using Tags = DropCopyFeedHandler.MessageProcessing.Tags;

namespace DropCopyFeedHandler.MessageProcessing
{
    public static class ExecutionReportExtensions
    {
        public static int msgTypeTag = new MsgType().Tag;
        public static int msgSeqNumTag = new MsgSeqNum().Tag;
        public static int execIdTag = new ExecID().Tag;
        public static int freeTextTag = new Text().Tag;
        private static StringField TTLinkTypeCross = new StringField(Tags.TTLinkType,"X");

        public static int GetSequenceNumber(this ExecutionReport execRpt)
        {
            return execRpt.Header.GetInt(msgSeqNumTag);
        }

        public static bool IsLinkTrade(this ExecutionReport execReport)
        {
            return execReport.IsSetField(Tags.TTNumberOfLink) &&
                execReport.GetGroup(Tags.TTNumberOfLink).Any(x => x.GroupHasStringField(TTLinkTypeCross));
        }

        public static string LinkId(this ExecutionReport execReport)
        {
            return IsLinkTrade(execReport)
                ? execReport.GetGroup(Tags.TTNumberOfLink).Where(x=>x.GroupHasStringField(TTLinkTypeCross))
                    .Select(x => x.GetStringOrEmpty(Tags.TTLinkId)).First() 
                : "";
        }

        private static string GetStringOrEmpty(this Group group, int tag)
        {
            return group.IsSetField(tag) ? group.GetString(tag) : "";
        }

        public static string ToShortString(this ExecutionReport execRpt)
        {
            int seqNum = execRpt.GetSequenceNumber();
            StringBuilder shortExecRptDesc = new StringBuilder();

            shortExecRptDesc.AppendFormat(
                "MsgType= [{0}]; ExecID = [{1}]; SeqNum = [{2}], LinkStatus=[{3}], LinkId=[{4}]",
                execRpt.Header.GetString(msgTypeTag),
                execRpt.GetString(execIdTag),
                seqNum,
                execRpt.IsLinkTrade(),
                execRpt.LinkId());

            if (execRpt.IsSetField(freeTextTag))
            {
                shortExecRptDesc.AppendFormat("; Text = [{0}]", execRpt.GetString(freeTextTag));
            }

            return shortExecRptDesc.ToString();
        }

        public static string ToShortString(this QuickFix.FIX42.ExecutionReport execRpt)
        {
            int seqNum = 0;
            StringBuilder shortExecRptDesc = new StringBuilder();

            shortExecRptDesc.AppendFormat(
                "MsgType= [{0}]; ExecID = [{1}]; SeqNum = [{2}]",
                execRpt.Header.GetString(msgTypeTag),
                execRpt.GetString(execIdTag),
                seqNum);

            if (execRpt.IsSetField(freeTextTag))
            {
                shortExecRptDesc.AppendFormat("; Text = [{0}]", execRpt.GetString(freeTextTag));
            }

            return shortExecRptDesc.ToString();
        }

        public static IEnumerable<Group> GetGroup(this ExecutionReport execRpt, int groupTag)
        {
            if (execRpt.IsSetField(groupTag))
            {
                int numberInGroup = execRpt.GetInt(groupTag);
                for (int i = 1; i <= numberInGroup; i++)
                {
                    yield return execRpt.GetGroup(i, groupTag);
                }
            }
        }

        public static bool GroupHasStringField(this Group group, StringField field)
        {
            return group.IsSetField(field) && group.GetString(field.Tag).Equals(field.Obj);
        }

    }
}
