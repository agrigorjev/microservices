using Topshelf;

namespace DropCopyFeedHandler
{
    /// <summary>
    /// This is the entry point for the general DropCopy feed handler Service.  It's responsible for starting up 
    /// whatever is needed to connect to and handle messages from a DropCopy FIX message source and making sure those 
    /// things are shut down when the service must stop running.
    /// 
    /// The service is generally only a client of a remote source, so it will only be expected to start up an initiator.
    /// However, custom implementations may start up an acceptor if they choose (and even shut down the initiator).
    /// </summary>
    public interface IDropCopyService
    {
        /// <summary>
        /// The main purpose of this method is to start up an initiator.  Any other service startup code may be added.
        /// </summary>
        /// <param name="hostCtrl">The TopShelf HostControl instance.  This can be used to shut down the service if 
        /// necessary.</param>
        void Start(HostControl hostCtrl);

        /// <summary>
        /// Stop whatever resources were started up.  This usually means only stopping the initiator.
        /// </summary>
        void Stop();

        /// <summary>
        /// The service can be asked whether it's busy or not.  The service is busy if it's initialising, running or in
        /// the process of shutting down.  It is not busy in cases such as initialisation having failed even to begin.
        /// </summary>
        /// <returns></returns>
        bool IsBusy();
    }
}