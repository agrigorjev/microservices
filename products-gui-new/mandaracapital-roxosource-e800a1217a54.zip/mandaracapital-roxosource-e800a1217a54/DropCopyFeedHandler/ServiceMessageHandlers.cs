﻿using DropCopyFeedHandler.MessageProcessing;
using DropCopyFeedHandler.MessageProcessing.Routers;
using FIXMessageMapping;
using System;

namespace DropCopyFeedHandler
{
    public class ServiceMessageHandlers : IDisposable
    {
        public MapperFactory MapperCreator { get; }
        //public IFixTradeStorerFactory TradeStoreFactory { get; }
        public IMessageRouter Router { get; }
        //new RouterFactory(mapFactory, tradeStoreFactory, _executionContext).GetExecutionReportRouter();
        public ClientMessageCracker Cracker { get; private set; }

        public Action<FIXMessageArgs> OnLoginSendingAction { get; private set; }

        public ServiceMessageHandlers(MapperFactory mapFactory, IMessageRouter router, ClientMessageCracker cracker,Action<FIXMessageArgs> loginAction)
        {
            if (null == mapFactory || null == router || null == cracker)
            {
                throw new ArgumentNullException("ServiceData: At least one argument is null and all are required.");
            }

            MapperCreator = mapFactory;
            Router = router;
            Cracker = cracker;
            OnLoginSendingAction = loginAction;
        }

        public void Dispose()
        {
            try
            {
                Cracker?.Dispose();
                Cracker = null;
            }
            catch (ObjectDisposedException)
            {
                Cracker = null;
            }
        }
    }
}
