﻿using DropCopyFeedHandler.FIXEndpoints;
using Ninject.Extensions.Logging;
using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Topshelf;

namespace DropCopyFeedHandler
{
    public abstract class DropCopyService : IDropCopyService, IDisposable
    {
        protected Initiator initiator;
        protected bool isRunning;
        protected readonly ILogger logger = new NLogLoggerFactory().GetCurrentClassLogger();
        protected Task initialisation;
        protected bool isInitialising;
        protected ServiceMessageHandlers serviceMsgHandlers;
        protected const string initiatorConfig = "./config/initiator.cfg";

        public async void Start(HostControl hostCtrl)
        {
            if (!File.Exists(initiatorConfig))
            {
                logger.Error("Initiator configuration file '{0}' does not exist.", initiatorConfig);
                hostCtrl.Stop();
                return;
            }

            initialisation = Task.Factory.StartNew(
                () =>
                {
                    StartUpDropCopyService();
                });

            try
            {
                isInitialising = true;
                await initialisation;
                isInitialising = false;
                logger.Info("Initialisation complete.");
            }
            catch (Exception startupEx)
            {
                isInitialising = false;
                logger.Error(startupEx, "Error during startup.  Shutting down the service.");
                hostCtrl.Stop();
            }
        }

        protected abstract ServiceMessageHandlers GetServiceMessageHandlers();

        protected virtual void StartUpDropCopyService()
        {
            serviceMsgHandlers = GetServiceMessageHandlers();
            logger.Info("Connecting initiator to remote acceptor");
            RunInitiator(initiatorConfig, serviceMsgHandlers);
            isRunning = true;
            logger.Info("Initialisation complete");
        }

        protected void RunInitiator(string configFileName, ServiceMessageHandlers svcMsgHandlers)
        {
            initiator = new Initiator(svcMsgHandlers.Cracker,svcMsgHandlers.OnLoginSendingAction);
            initiator.StartEndPoint(configFileName);
        }

        public virtual void Stop()
        {
            if (null != initialisation && !(initialisation.IsFaulted || initialisation.IsCanceled))
            {
                logger.Info(
                    "A request to stop the service has been received.  The system must wait for initialisation to "
                        + "complete.");

                try
                {
                    initialisation?.Wait();
                }
                catch (AggregateException aggrEx)
                {
                    logger.Error(aggrEx, "");
                }
            }

            isRunning = false;
            StopInitiator();
        }

        private void LogUnexpectedAggregateException(AggregateException aggrEx)
        {
            if (!(aggrEx.InnerExceptions[0] is TaskCanceledException))
            {
                string errMsg = aggrEx.InnerExceptions.Aggregate(
                                          new StringBuilder(aggrEx.Message),
                                          (exMsg, inner) => exMsg.AppendFormat("\n    -> {0}", inner.Message))
                                      .ToString();

                logger.Error(aggrEx, errMsg);
            }
        }

        protected void StopInitiator()
        {
            initiator?.StopEndPoint();
            initiator?.Dispose();
            initiator = null;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected void Dispose(bool isDisposing)
        {
            if (isDisposing)
            {
                if (null != initiator)
                {
                    EnsureInitialisationIsCompleteForDispose();
                    initiator.Dispose();
                    initiator = null;
                }
                else
                {
                    serviceMsgHandlers?.Dispose();
                }
            }
        }

        protected void EnsureInitialisationIsCompleteForDispose()
        {
            if (!initialisation.IsCompleted && !initialisation.IsFaulted)
            {
                logger.Info("Ensure that initialisation has completed so that the service shuts down cleanly.");

                try
                {
                    Stop();
                    initialisation?.Wait();
                }
                catch (AggregateException aggrEx)
                {
                    LogUnexpectedAggregateException(aggrEx);
                }
            }
        }

        public bool IsBusy()
        {
            return isRunning || isInitialising;
        }
    }
}
