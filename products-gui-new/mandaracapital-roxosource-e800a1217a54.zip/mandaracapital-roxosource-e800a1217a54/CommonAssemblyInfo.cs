﻿using System.Reflection;

[assembly: AssemblyCompany("Mandara Capital")]
[assembly: AssemblyCopyright("© Mandara 2018")]

[assembly: AssemblyVersion("0001.0002")]
