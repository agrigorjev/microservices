﻿using Mandara.Business.AsyncServices.Base;
using Mandara.Business.Bus.Commands;
using Mandara.Business.Bus.Commands.Base;
using Mandara.Entities.ErrorDetails;
using Mandara.Entities.ErrorReporting;
using Ninject.Extensions.Logging;
using System;
using System.Collections.Generic;

namespace Mandara.Bus.Common.Server.AsyncServices
{
    /// <summary>
    /// Async service used to log errors in the errors queue and then send them to the clients.
    /// </summary>
    public class SendErrorsService : BusAsyncService
    {
        private readonly List<string> _topicNames;

        public SendErrorsService(CommandManager commandManager, ILogger log, List<string> topicNames)
            : base(commandManager, log)
        {
            _topicNames = topicNames;
            // service check for new errors every one second
            SleepTime = TimeSpan.FromSeconds(1);
        }

        private const int PackMaxSize = 25;
        protected override void DoWork()
        {
            if (ErrorReportingHelper.GlobalQueue.Count == 0)
                return;

            List<Error> errors = new List<Error>();
            while (ErrorReportingHelper.GlobalQueue.Count > 0 && errors.Count < PackMaxSize)
            {
                Error error = ErrorReportingHelper.GlobalQueue.Dequeue() as Error;

                if (error == null)
                    continue;

                // log error
                ErrorDetails errorDetails = ErrorDetails.Create(error.Object);
                ExceptionDetails exceptionDetails = errorDetails as ExceptionDetails;
                _log.Error(exceptionDetails != null ? exceptionDetails.FullText : error.Message);

                errors.Add(error);
            }

            if (errors.Count > 0)
            {
                // send errors to the clients
                RunCommand(new SendErrorCommand(errors, _topicNames));
            }
        }
    }
}