using Mandara.Bus.Common.Server.Commands;
using Mandara.Business.AsyncServices.Base;
using Mandara.Business.Bus.Commands.Base;
using Ninject.Extensions.Logging;
using System;

namespace Mandara.Bus.Common.Server.AsyncServices
{
    public class HeartbeatService : BusAsyncService
    {
        public HeartbeatService(CommandManager commandManager, ILogger log)
            : base(commandManager, log)
        {
            SleepTime = TimeSpan.FromSeconds(10);
        }

        protected override void DoWork()
        {
            RunCommand(new HeartbeatCommand());
        }
    }
}