﻿using Mandara.Business.AsyncServices.Base;
using Mandara.Entities.ErrorDetails;
using Mandara.Entities.ErrorReporting;
using Ninject.Extensions.Logging;
using System;

namespace Mandara.Bus.Common.Server.AsyncServices
{
    /// <summary>
    /// Async service used to log errors in the errors queue.
    /// </summary>
    public class LogErrorsService : AsyncService
    {
        public LogErrorsService(ILogger log)
            : base(log)
        {
            // service check for new errors every one second
            SleepTime = TimeSpan.FromSeconds(1);
        }

        protected override void DoWork()
        {
            if (ErrorReportingHelper.GlobalQueue.Count == 0)
                return;

            while (ErrorReportingHelper.GlobalQueue.Count > 0)
            {
                Error error = ErrorReportingHelper.GlobalQueue.Dequeue() as Error;

                if (error == null)
                    continue;

                // log error
                ErrorDetails errorDetails = ErrorDetails.Create(error.Object);
                ExceptionDetails exceptionDetails = errorDetails as ExceptionDetails;

                if (exceptionDetails != null)
                {
                    _log.Error(error.Message + Environment.NewLine + exceptionDetails.FullText);
                }
                else
                {
                    _log.Error(error.Message);
                }
            }
        }
    }
}