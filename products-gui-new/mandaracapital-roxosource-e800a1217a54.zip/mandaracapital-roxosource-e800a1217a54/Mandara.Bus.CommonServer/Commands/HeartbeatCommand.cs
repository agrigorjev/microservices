﻿using Mandara.Business.Bus;
using Mandara.Business.Bus.Commands.Base;
using Mandara.Business.Bus.Messages;

namespace Mandara.Bus.Common.Server.Commands
{
    /// <summary>
    /// Command used to inform clients that server is still alive
    /// </summary>
    public class HeartbeatCommand : BusCommandBase
    {
        public HeartbeatCommand()
        {
            TopicName = InformaticaHelper.HeartbeatTopicName;
        }

        public override void Execute()
        {
            SendMessage(HeartbeatMessage.EmptyMessage);
        }
    }
}