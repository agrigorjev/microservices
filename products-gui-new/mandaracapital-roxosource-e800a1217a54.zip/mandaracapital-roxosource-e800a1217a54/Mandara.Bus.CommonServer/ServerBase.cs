﻿using System;
using System.Configuration;
using System.IO;
using System.ServiceProcess;
using System.Threading;
using System.Threading.Tasks;
using com.latencybusters.lbm;
using Mandara.Business.AsyncServices.Base;
using Mandara.Business.Bus.Commands.Base;
using Mandara.Business.Bus.Handlers.Base;
using Mandara.Entities.ErrorReporting;
using Ninject.Extensions.Logging;

namespace Mandara.Bus.Common.Server
{
    public abstract class ServerBase : ServiceBase
    {
        protected readonly ILogger _logger;
        private LBMContext _lbmContext;

        private string LBMConfigurationFilePath => ConfigurationManager.AppSettings["LBMConfigurationFilePath"];

        private ServerInformaticaHelperBase _informaticaHelper;
        public ServerInformaticaHelperBase InformaticaHelper => _informaticaHelper;

        private CommandManager _commandManager;
        public CommandManager CommandManager => _commandManager;

        private AsyncServiceManager _serviceManager;

        public ServerBase(ILogger log)
        {
            _logger = log;
        }

        protected override void OnStart(string[] args)
        {
            Start();
        }

        public virtual void Start()
        {
            Task.Factory.StartNew(Initialize).ContinueWith(HandleError, TaskContinuationOptions.OnlyOnFaulted);
        }

        protected abstract string ServerName { get; }
        private void HandleError(Task task)
        {
            if (task.Exception != null)
            {
                _logger.ErrorException(ServerName + " encountered an error.", task.Exception);
                var error = new Error(
                    ServerName,
                    ErrorType.Exception,
                    ServerName + " encountered an error.",
                    null,
                    task.Exception,
                    ErrorLevel.Critical);
                ErrorReportingHelper.GlobalQueue.Enqueue(error);
            }

        }
        protected override void OnStop()
        {
            Stop();
        }

        public new virtual void Stop()
        {
            try
            {
                _serviceManager?.Stop();
                _commandManager?.Stop();
                _informaticaHelper?.CloseSources();
                _informaticaHelper?.CloseReceivers();
                Thread.Sleep(1000);
                _lbmContext?.close();
            }
            catch (Exception ex)
            {
                _logger.ErrorException("Exception during service stop.", ex);
            }
        }

        private void UMSLogger(int loglevel, string message)
        {
            string level;

            switch (loglevel)
            {
                case LBM.LOG_ALERT: level = "Alert"; break;

                case LBM.LOG_CRIT: level = "Critical"; break;

                case LBM.LOG_DEBUG: level = "Debug"; break;

                case LBM.LOG_EMERG: level = "Emergency"; break;

                case LBM.LOG_ERR: level = "Error"; break;

                case LBM.LOG_INFO: level = "Info"; break;

                case LBM.LOG_NOTICE: level = "Note"; break;

                case LBM.LOG_WARNING: level = "Warning"; break;

                default: level = "Unknown"; break;

            }


            _logger.Trace(string.Format("UMS Logger: [{0}]: {1}", level, message));
        }

        protected virtual void Initialize()
        {
            _logger.Info("Initializer started");

            if (LBMConfigurationFilePath != null)
            {
                if (File.Exists(LBMConfigurationFilePath))
                {
                    LBM.setConfiguration(LBMConfigurationFilePath);
                }
            }

            LBM lbm = new LBM();
            lbm.setLogger(UMSLogger);

            _lbmContext = new LBMContext();

            _commandManager = new CommandManager();
            _commandManager.Start();

            _informaticaHelper = CreateInformaticaHelper(_lbmContext, new HandlerManager());
            _informaticaHelper.CreateSources();
            _informaticaHelper.CreateReceivers();

            _serviceManager = new AsyncServiceManager();
            _serviceManager.AddRange(CreateAsyncServices());
            _serviceManager.Start();

            _logger.Info("Initializer finished");
        }

        protected abstract ServerInformaticaHelperBase CreateInformaticaHelper(LBMContext lbmContext, HandlerManager handlerManager);

        protected virtual AsyncService[] CreateAsyncServices()
        {
            return new AsyncService[]
                       {
                       };
        }
    }
}
