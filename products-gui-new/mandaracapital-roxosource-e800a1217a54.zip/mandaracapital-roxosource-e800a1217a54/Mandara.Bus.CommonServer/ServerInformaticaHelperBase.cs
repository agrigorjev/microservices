﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using Mandara.Business.Bus;
using Mandara.Business.Bus.Commands;
using Mandara.Business.Bus.Commands.Base;
using Mandara.Business.Bus.Handlers.Base;
using Mandara.Business.Bus.Messages.Base;
using Mandara.IRM.Server.Bus;
using com.latencybusters.lbm;

namespace Mandara.Bus.Common.Server
{
    public class ServerInformaticaHelperBase : InformaticaHelper
    {
        private readonly Dictionary<string, Type> _snapshotCommands = new Dictionary<string, Type>();
        private readonly Dictionary<string, TempTopicQueue> _tempTopicsQueues = new Dictionary<string, TempTopicQueue>();
        private readonly ConcurrentDictionary<Guid, LBMSource> _temporarySources = new ConcurrentDictionary<Guid, LBMSource>();

        private readonly ConcurrentDictionary<Guid, SnapshotDeliveryContext> _snapshotDeliveryContextEntries = new ConcurrentDictionary<Guid, SnapshotDeliveryContext>();

        protected ServerInformaticaHelperBase(LBMContext lbmContext, HandlerManager handlerManager) : base(lbmContext, handlerManager)
        {
        }

        public override SnapshotDeliveryCommand GetSnapshotDeliveryCommand(Guid snapshotId, SnapshotMessageBase message)
        {
            SnapshotDeliveryContext context;
            _snapshotDeliveryContextEntries.TryGetValue(snapshotId, out context);

            LBMSource source;
            _temporarySources.TryGetValue(snapshotId, out source);

            var result = new SnapshotDeliveryCommand()
            {
                LbmTemporarySource = source,
                TopicName = context.TopicName,
                DeliveryContext = context,
                SupportsGuaranteedDelivery = true,
                Message = message
            };

            return result;
        }

        public override void CloseSources()
        {
            foreach (LBMSource lbmSource in _temporarySources.Values)
            {
                if (lbmSource != null && !lbmSource.isClosed())
                    lbmSource.close();
            }

            _temporarySources.Clear();

            foreach (KeyValuePair<string, TempTopicQueue> pair in _tempTopicsQueues)
            {
                if (pair.Value != null)
                    pair.Value.Clear();
            }

            _tempTopicsQueues.Clear();

            _snapshotCommands.Clear();

            base.CloseSources();
        }

        public override SnapshotCommandBase GetSnapshotCommand(string topicName, ref SnapshotMessageBase message)
        {
            Type commandType = null;
            TempTopicQueue tempTopicQueue = null;

            _snapshotCommands.TryGetValue(topicName, out commandType);
            _tempTopicsQueues.TryGetValue(topicName, out tempTopicQueue);

            if (commandType != null && tempTopicQueue != null)
            {
                message.SnapshotId = tempTopicQueue.DequeueId();
                var snapshotDeliveryContext = new SnapshotDeliveryContext(topicName, message.SnapshotId.Value, new SnapshotData());
                _snapshotDeliveryContextEntries.TryAdd(snapshotDeliveryContext.SnapshotId, snapshotDeliveryContext);

                LBMSource lbmTemporarySource = tempTopicQueue.GetLbmSource(message.SnapshotId.Value);
                _temporarySources.TryAdd(snapshotDeliveryContext.SnapshotId, lbmTemporarySource);

                SnapshotCommandBase snapshotCommandBase = (SnapshotCommandBase)Activator.CreateInstance(commandType);
                snapshotCommandBase.Message = message;
                snapshotCommandBase.LbmTemporarySource = lbmTemporarySource;
                snapshotCommandBase.TopicName = topicName;
                snapshotCommandBase.DeliveryContext = snapshotDeliveryContext;
                snapshotCommandBase.SupportsGuaranteedDelivery = message.UseGuaranteedDelivery;

                return snapshotCommandBase;
            }

            return null;
        }

        protected void AddSnapshotCommand(string topicName, Type commandType)
        {
            if (!typeof(ICommand).IsAssignableFrom(commandType))
                throw new ArgumentException("Should inherit from ICommand", "commandType");

            TempTopicQueue tempTopicQueue = new TempTopicQueue(LbmContext, topicName);
            _tempTopicsQueues.Add(topicName, tempTopicQueue);
            _snapshotCommands.Add(topicName, commandType);
        }
    }
}