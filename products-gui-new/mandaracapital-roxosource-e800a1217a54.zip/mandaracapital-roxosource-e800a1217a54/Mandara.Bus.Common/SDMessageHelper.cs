﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using com.latencybusters.lbm.sdm;

namespace Mandara.Bus.Common
{
    public class SDMessageHelper
    {
        public static LBMSDMessage CreateSDMessage(Int64 sequence, Double price)
        {
            LBMSDMessage SDMsg = null;
            try
            {
                SDMsg = new LBMSDMessage();

                LBMSDMFieldInt64 seqfield = new LBMSDMFieldInt64("Sequence Number", sequence);
                SDMsg.add(seqfield);

                LBMSDMFieldDouble priceField = new LBMSDMFieldDouble("Price", price);
                SDMsg.add(priceField);
            }
            catch (LBMSDMException sdme)
            {
                System.Console.Out.WriteLine("Failed to create the SDM message:" + sdme);
            }

            return SDMsg;
        }

    }
}
