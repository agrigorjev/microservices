﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;

namespace Mandara.Bus.Common
{
    public class Config
    {
        public static String PriceSource
        {
            get
            {
                return ConfigurationManager.AppSettings["PriceSource"] ?? "DEV/PP";
            }
        }

        public static String CalculatedPriceSource
        {
            get
            {
                return ConfigurationManager.AppSettings["CalculatedPriceSource"] ?? "DEV/CP";
            }
        }

        public static String HistoricalRequestsSource
        {
            get
            {
                return ConfigurationManager.AppSettings["HistoricalRequestsSource"] ?? "DEV/HP/Requests";
            }
        }

        public static String HistoricalResponsesSource
        {
            get
            {
                return ConfigurationManager.AppSettings["HistoricalResponsesSource"] ?? "DEV/HP/Responses";
            }
        }

        public static String LBMConfigurationFilePath
        {
            get
            {
                return ConfigurationManager.AppSettings["LBMConfigurationFilePath"];
            }
        }
    }
}
