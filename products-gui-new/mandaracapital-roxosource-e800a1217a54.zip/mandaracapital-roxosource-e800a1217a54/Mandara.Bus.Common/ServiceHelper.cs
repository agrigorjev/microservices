﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Mandara.Bus.Common
{
    using System.ServiceProcess;

    public class ServiceHelper
    {
        public static void RunService(BusServiceBase service)
        {
            if (Environment.GetCommandLineArgs().Contains("-console"))
            {
                Console.CancelKeyPress += (x, y) => service.Stop();
                service.Start();
                Console.WriteLine("Running service, press a key to stop");
                Console.ReadKey();
                service.Stop();
                Console.WriteLine("Service stopped");
            }
            else
            {
                ServiceBase.Run(service);
            }
        }
    }
}
