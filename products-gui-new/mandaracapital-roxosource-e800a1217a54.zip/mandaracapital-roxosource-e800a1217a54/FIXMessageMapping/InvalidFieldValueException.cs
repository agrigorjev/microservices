﻿using System;

namespace FIXMessageMapping
{
    public class InvalidFieldValueException : Exception
    {
        public InvalidFieldValueException(string message)
        : base(message)
        {

        }

        public InvalidFieldValueException(string message, Exception innerEx)
        : base(message, innerEx)
        {

        }

        public InvalidFieldValueException(string msgPrefix, string fieldName)
        : base($"{msgPrefix} - Field [{fieldName}] has an invalid value.")
        {

        }

        public InvalidFieldValueException(string msgPrefix, string fieldName, Exception innerEx)
        : base($"{msgPrefix} - Field [{fieldName}] has an invalid value.", innerEx)
        {

        }

        public InvalidFieldValueException(string msgPrefix, string fieldName, string invalidValue)
        : base($"{msgPrefix} - Field [{fieldName}] has an invalid value, [{invalidValue}].")
        {

        }

        public InvalidFieldValueException(string msgPrefix, string fieldName, string invalidValue, Exception innerEx)
            : base(
                $"{msgPrefix} - Field [{fieldName}] has an invalid value, [{invalidValue}].",
                innerEx)
        {

        }
    }
}
