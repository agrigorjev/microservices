﻿using QuickFix.FIX44;
using System.Collections.Generic;

namespace FIXMessageMapping
{
    public class CommonExecutionReportMapping
    {
        public static string BuildExecRptIdentifiersMessage(ExecutionReport execRpt)
        {
            string orderId = execRpt.IsSetOrderID() ? execRpt.OrderID.getValue() : "unknown";
            string clOrdId = execRpt.IsSetClOrdID() ? execRpt.ClOrdID.getValue() : "unknown";
            string tradeDate = execRpt.IsSetTradeDate() ? execRpt.TradeDate.getValue() : "unknown";

            return $"Order ID = {orderId}, Clearing Order ID = {clOrdId}, Trade Date = {tradeDate}";
        }

        public static List<string> ValidateExecutionReport(ExecutionReport execRpt)
        {
            List<string> errors = new List<string>();

            if (execRpt == null)
            {
                errors.Add("The Execution Report is missing...");
                return errors;
            }

            if (!execRpt.IsSetSide())
            {
                errors.Add("Side is not set");
            }

            if (!execRpt.IsSetTransactTime())
            {
                errors.Add("TransactTime is not set");
            }

            return errors;
        }
    }
}
