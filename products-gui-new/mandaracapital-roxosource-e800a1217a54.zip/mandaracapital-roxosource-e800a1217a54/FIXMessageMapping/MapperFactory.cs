﻿using Optional;
using System;
using System.Collections.Generic;

namespace FIXMessageMapping
{
    /// <summary>
    /// Create instances of ExecutionReport mapper classes.  For a mapper to be available the type first has to be 
    /// registered with the factory.
    /// </summary>
    public class MapperFactory
    {
        private readonly Dictionary<Type, IFixExecutionReportMapper> _executionReportMappers =
            new Dictionary<Type, IFixExecutionReportMapper>();

        public MapperFactory AddMapper(Type mapperType, IFixExecutionReportMapper mapper)
        {
            if (!_executionReportMappers.ContainsKey(mapperType))
            {
                _executionReportMappers.Add(mapperType, mapper);
            }

            return this;
        }

        /// <summary>
        /// Try to get a mapper by name.  There may be no mapper associated with the name, so an Option is returned.
        /// </summary>
        /// <returns>Returns an <seealso cref="Optional.Option"/>.  If there is a mapper associated with the name then
        /// Some is returned, otherwise None.</returns>
        public Option<IFixExecutionReportMapper> GetMapper(Type mapperType)
        {
            IFixExecutionReportMapper mapper;

            if (_executionReportMappers.TryGetValue(mapperType, out mapper))
            {
                return Option.Some(mapper);
            }

            return Option.None<IFixExecutionReportMapper>();
        }
    }
}
