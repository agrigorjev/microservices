﻿using NLog;
using QuickFix.FIX44;
using System;
using System.Collections.Generic;

namespace FIXMessageMapping
{
    public class SecurityIDSourceMapper
    {
        public static readonly string IceSecurityIdSource = "8";
        private static readonly Dictionary<string, Func<ExecutionReport, ILogger, string>>
            SecurityIdSourceFunctions = new Dictionary<string, Func<ExecutionReport, ILogger, string>>();
        public const string NymexExchangeName = "NYMEX";
        public const string IceExchangeName = "ICE-EU";

        static SecurityIDSourceMapper()
        {
            SetUpSecurityIdSourceMethodMapper();
        }

        private static void SetUpSecurityIdSourceMethodMapper()
        {
            SecurityIdSourceFunctions.Add(NymexExchangeName, GetNymexSecurityIdSourceFromExecReport);
            SecurityIdSourceFunctions.Add(IceExchangeName, GetIceSecurityIdSourceFromExecReport);
        }

        public static Func<ExecutionReport, ILogger, string> GetSecurityIdSourceCalculationMethod(
            string securityExchange)
        {
            Func<ExecutionReport, ILogger, string> securityIdSourceFunction;

            if (!SecurityIdSourceFunctions.TryGetValue(securityExchange, out securityIdSourceFunction))
            {
                securityIdSourceFunction = GetDefaultSecurityIdSourceFromExecReport;
            }

            return securityIdSourceFunction;
        }

        public static string GetNymexSecurityIdSourceFromExecReport(ExecutionReport execReport, ILogger log)
        {
            string symbol = execReport.Symbol.getValue();

            try
            {
                if (symbol.Length == 1)
                {
                    return symbol;
                }

                return symbol.Substring(0, 2);

            }
            catch (Exception e)
            {
                log.Error(
                    e,
                    "Error mapping execution report Symbol to SecurityIdSource, likely substring(0,2) of symbol out "
                        + "of range, Symbol: {0}",
                    symbol);

                return GetDefaultSecurityIdSourceFromExecReport(execReport, log);
            }
        }

        private static string GetIceSecurityIdSourceFromExecReport(ExecutionReport execReport, ILogger log)
        {
            return IceSecurityIdSource;
        }

        private static string GetDefaultSecurityIdSourceFromExecReport(ExecutionReport execReport, ILogger log)
        {
            log.Warn("Mapping empty SecurityIdSource to TradeCapture, ExecId:{0}, Exchange:{1}",
                execReport.ExecID, execReport.SecurityExchange);

            return String.Empty;
        }
    }
}
