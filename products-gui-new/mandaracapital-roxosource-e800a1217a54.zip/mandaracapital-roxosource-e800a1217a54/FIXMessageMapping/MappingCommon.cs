﻿using QuickFix.FIX44;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text.RegularExpressions;
using Mandara.Date;

namespace FIXMessageMapping
{
    public class MappingCommon
    {
        private const string ShortMaturityMonthYearPattern = "20(1[6-9]|[2-9][0-9])(0[0-9]|1[0-2])";
        private const string LongMaturityMonthYearPattern = "20(1[6-9]|[2-9][0-9])(0[0-9]|1[0-2])([0-2][0-9]|3[01])";
        public static Regex maturityMonthYearPattern =
            new Regex(
                String.Format(
                    "^((?<{0}>{1})|(?<{2}>{3}))$",
                    ShortMaturityMonthYearPatternName,
                    ShortMaturityMonthYearPattern,
                    LongMaturityMonthYearPatternName,
                    LongMaturityMonthYearPattern));
        private const string ShortMaturityMonthYearPatternName = "short";
        private const string LongMaturityMonthYearPatternName = "long";

        public static readonly string ShortMaturityMonthYearFormat = $"{Formats.FullYear}{Formats.SortableMonth}";
        private const string LongMaturityMonthYearFormat = Formats.SortableShortDate;
        public static readonly string DateAndTime =
            $"{Formats.SortableShortDate}-{Formats.TwentyFourHourFormat(':')}";

        private static readonly Dictionary<string, string> MaturityMonthFormats = new Dictionary<string, string>()
        {
            { ShortMaturityMonthYearPatternName, ShortMaturityMonthYearFormat },
            { LongMaturityMonthYearPatternName, LongMaturityMonthYearFormat }
        };


        private static string GetMaturityMonthYearFormat(Match maturityMatch)
        {
            string maturityMonthYearFormat = String.Empty;

            if (maturityMatch.Groups[ShortMaturityMonthYearPatternName].Success)
            {
                maturityMonthYearFormat = MaturityMonthFormats[ShortMaturityMonthYearPatternName];
            }
            else if (maturityMatch.Groups[LongMaturityMonthYearPatternName].Success)
            {
                maturityMonthYearFormat = MaturityMonthFormats[LongMaturityMonthYearPatternName];
            }

            return maturityMonthYearFormat;
        }

        public static string GetMaturityMonthFormatOptions()
        {
            return String.Join(" or ", MaturityMonthFormats.Values);
        }

        public static DateTime GetMaturityMonthYearAsADate(ExecutionReport execRpt)
        {
            string maturityMonth = execRpt.MaturityMonthYear.getValue();
            return GetMaturityMonthYearAsADate(maturityMonth);
        }

        public static DateTime GetMaturityMonthYearAsADate(string maturityMonth)
        {

            Match maturityMatch = maturityMonthYearPattern.Match(maturityMonth);
            DateTime maturityDate;
            string maturityMonthYearFormat = GetMaturityMonthYearFormat(maturityMatch);
            DateTime.TryParseExact(
                maturityMonth,
                maturityMonthYearFormat,
                CultureInfo.InvariantCulture,
                DateTimeStyles.None,
                out maturityDate);

            return maturityDate;
        }

    }
}
