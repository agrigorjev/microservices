﻿using Optional;
using QuickFix.FIX44;

namespace FIXMessageMapping
{
    /// <summary> 
    /// Interface responsible for mapping fields received from Execution Report as part of FIX feed to TradeCapture to 
    /// be processed by Trade Transfer Service and further used by IRM Service.
    /// </summary>
    public interface IFixExecutionReportMapper
    {
        /// <summary>
        /// Map FIX ExecutionReport object to TradeCapture Object
        /// </summary>
        /// <typeparam name="T">The type expected in the map output.  This allows for different mapping outputs from
        /// the same input type.</typeparam>
        /// <param name="execReport">The input <see cref="ExecutionReport"/></param>
        /// <returns>An <see cref="Option&lt;T&gt;"/> that either contains a successfully mapped instance of T or
        /// nothing.</returns>
        Option<T> Map<T>(ExecutionReport execReport, string clearingFirm) where T : class;
    }
}
