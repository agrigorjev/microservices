﻿namespace Mandara.Business.DataInterface
{
    public interface IFxPrices
    {
    }
}
