﻿namespace Mandara.Business.OldCode
{
    public enum LegType
    {
        Leg1,
        Leg2
    }
}