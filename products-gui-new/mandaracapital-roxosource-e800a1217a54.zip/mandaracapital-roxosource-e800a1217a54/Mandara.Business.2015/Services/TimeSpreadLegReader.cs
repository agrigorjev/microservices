﻿using Mandara.Business.Contracts;
using Mandara.Entities;
using Mandara.Entities.Trades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity;
using System.Text;
using System.Threading.Tasks;
using Ninject.Extensions.Logging;

namespace Mandara.Business.Services
{
    public class TimeSpreadLegReader : ITimeSpreadLegReader
    {
        private readonly ILogger _logger;

        public TimeSpreadLegReader(ILogger logger)
        {
            _logger = logger;
        }

        public DailyTimeSpreadLegsDates ReadDailyTimeSpreadLegsDates(TradeCaptureUniqueKey parentTradeUniqueKey)
        {
            var spreadTradeCaptures = GetFullSpreadTrades(parentTradeUniqueKey);
            if (spreadTradeCaptures.Count != 3)
            {
                _logger.Warn("Incorrect number of trade captures for a time spread trade.");
                return DailyTimeSpreadLegsDates.Default;
            }

            var parentTrade = spreadTradeCaptures.FirstOrDefault(x => x.LegRefID == null || x.LegRefID == x.ExecID);
            if (parentTrade == null)
            {
                _logger.Warn("Parent trade not found for a time spread trade.");
                return DailyTimeSpreadLegsDates.Default;
            }

            var leg1Trade = spreadTradeCaptures.FirstOrDefault(x => x.LegRefID != null && x.Side == parentTrade.Side);
            var leg2Trade = spreadTradeCaptures.FirstOrDefault(x => x.LegRefID != null && x.Side != parentTrade.Side);
            if (leg1Trade?.TradeStartDate == null || leg1Trade?.TradeEndDate == null ||
                leg2Trade?.TradeStartDate == null || leg2Trade?.TradeEndDate == null)
            {
                _logger.Warn("Cannot find legs for a time spread trade, or trade start and/or end date is missing.");
                return DailyTimeSpreadLegsDates.Default;
            }

            return new DailyTimeSpreadLegsDates
            {
                Leg1Dates = (leg1Trade.TradeStartDate.Value, leg1Trade.TradeEndDate.Value),
                Leg2Dates = (leg2Trade.TradeStartDate.Value, leg2Trade.TradeEndDate.Value)
            };
        }

        private List<TradeCapture> GetFullSpreadTrades(TradeCaptureUniqueKey parentTradeUniqueKey)
        {
            List<TradeCapture> spreadGroup;

            using (MandaraEntities dbContext = new MandaraEntities(MandaraEntities.DefaultConnStrName, nameof(TradesRepository)))
            {
                spreadGroup =
                    dbContext.TradeCaptures.Include(x => x.Portfolio)
                       .Include(x => x.SellBook)
                       .Include(x => x.BuyBook)
                       .Include(x => x.TradeGroup)
                       .Include(x => x.SecurityDefinition)
                       .Include(x => x.SecurityDefinition.Product)
                       .Where(
                           x => x.Exchange == parentTradeUniqueKey.Exchange &&
                               (x.ExecID == parentTradeUniqueKey.ExecID) && (x.TradeDate == parentTradeUniqueKey.TradeDate)
                               && ((x.ClOrdID == parentTradeUniqueKey.ClOrdID) || (x.ClOrdID == null)))
                       .ToList();
            }

            return spreadGroup;
        }
    }
}
