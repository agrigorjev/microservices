﻿using Mandara.Business.Contracts;
using Mandara.Entities;
using Mandara.Entities.EntitiesCustomization;
using Mandara.Entities.EntityPieces;
using Ninject.Extensions.Logging;

namespace Mandara.Business.Trades
{
    public class TradeCaptureConverter : ITradeCaptureConverter
    {
        private readonly ILogger _log = new NLogLoggerFactory().GetCurrentClassLogger();

        public readonly ITimeSpreadLegReader _timeSpreadLegReader;

        public TradeCaptureConverter(ITimeSpreadLegReader timeSpreadLegReader)
        {
            _timeSpreadLegReader = timeSpreadLegReader;
        }

        public SourceDetail ConvertTradeCaptureToSourceDetail(TradeCapture trade, Product product = null)
        {
            if (trade == null)
            {
                _log.Trace("ConvertTradeCaptureToSourceDetail: No trade...");
                return null;
            }

            _log.Trace(
                "ConvertTradeCaptureToSourceDetail: Product passed in is null (so use trade's SecDef product)? {0}",
                product == null);
            product = product ?? trade.SecurityDefinition.Product;

            Strip strip = Strip.Default;

            if (product != null)
            {
                _log.Trace(
                    "ConvertTradeCaptureToSourceDetail: Product is not null, so parsing the strip data from the trade");
                strip = StripParser.Parse(trade, product);
            }

            if (strip.IsDefault())
            {
                _log.Trace(
                    "ConvertTradeCaptureToSourceDetail: The trade didn't have strip data to parse...");
                return null;
            }

            SourceDetail sourceDetail = new SourceDetail
            {
                SourceDetailId = trade.TradeId,
                StripName = trade.SecurityDefinition.StripName,
                IsTimeSpread = strip.IsTimeSpread,
                InstrumentDescription = trade.SecurityDefinition.UnderlyingSecurityDesc,
                Product = product,
                Quantity = trade.Quantity.Value,
                TradePrice = trade.Price.Value,
                TransactTime = trade.TransactTime,
                MaturityDate = trade.SecurityDefinition.UnderlyingMaturityDateAsDate,
                TradeCapture = trade,
                PortfolioId = trade.Portfolio != null ? trade.Portfolio.PortfolioId : (int?)null,
                TradeCaptureId = trade.TradeId,
                ProductId = product.ProductId,
                UseExpiryCalendar = product.UseExpiryCalendar.HasValue && product.UseExpiryCalendar.Value,
            };

            sourceDetail.ProductDate = sourceDetail.ProductDate1 = strip.Part1.StartDate;
            sourceDetail.DateType = sourceDetail.DateType1 = strip.Part1.DateType;

            if (strip.IsTimeSpread)
            {
                sourceDetail.ProductDate2 = strip.Part2.StartDate;
                sourceDetail.DateType2 = strip.Part2.DateType;
            }

            if (trade.TradeEndDate.HasValue)
                sourceDetail.TradeEndDate = trade.TradeEndDate.Value;

            if (strip.IsTimeSpread && strip.Part1.DateType == ProductDateType.Daily)
            {
                sourceDetail.DailyTimeSpreadLegsDates = _timeSpreadLegReader.ReadDailyTimeSpreadLegsDates(trade.UniqueKey);
            }

            return sourceDetail;
        }

        public SourceDetail ConvertTradeCaptureToSourceDetail(TradePieces trade)
        {
            if (trade.Strip.IsDefault())
            {
                return null;
            }

            TradeCapture capture = trade.Trade;
            SecurityDefinition secDef = trade.Security.SecurityDef;
            Product product = trade.Security.Product;

            SourceDetail sourceDetail = new SourceDetail
            {
                SourceDetailId = capture.TradeId,
                StripName = secDef.StripName,
                IsTimeSpread = capture.Strip.IsTimeSpread,
                InstrumentDescription = secDef.UnderlyingSecurityDesc,
                Product = product,
                Quantity = capture.Quantity.Value,
                TradePrice = capture.Price.Value,
                TransactTime = capture.TransactTime,
                MaturityDate = secDef.UnderlyingMaturityDateAsDate,
                TradeCapture = capture,
                PortfolioId = capture.Portfolio?.PortfolioId,
                TradeCaptureId = capture.TradeId,
                ProductId = secDef.product_id.Value,
                UseExpiryCalendar = product.UseExpiryCalendar.HasValue && product.UseExpiryCalendar.Value,
            };

            sourceDetail.ProductDate = sourceDetail.ProductDate1 = trade.Strip.Part1.StartDate;
            sourceDetail.DateType = sourceDetail.DateType1 = trade.Strip.Part1.DateType;

            if (trade.Strip.IsTimeSpread)
            {
                sourceDetail.ProductDate2 = trade.Strip.Part2.StartDate;
                sourceDetail.DateType2 = trade.Strip.Part2.DateType;
            }

            if (capture.TradeEndDate.HasValue)
            {
                sourceDetail.TradeEndDate = capture.TradeEndDate.Value;
            }

            if (trade.Strip.IsTimeSpread && trade.Strip.Part1.DateType == ProductDateType.Daily)
            {
                sourceDetail.DailyTimeSpreadLegsDates = _timeSpreadLegReader.ReadDailyTimeSpreadLegsDates(trade.UniqueKey);
            }

            return sourceDetail;
        }
    }
}
