namespace Mandara.Business.Bus
{
    public enum ServerState
    {
        Initialization,
        ResetSignal,
        Reinitialization,
        OK
    }
}