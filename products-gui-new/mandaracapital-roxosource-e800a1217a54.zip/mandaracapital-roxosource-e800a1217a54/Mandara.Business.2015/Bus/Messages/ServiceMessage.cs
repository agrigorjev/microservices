﻿namespace Mandara.Business.Bus.Messages
{
    using Mandara.Business.Bus.Messages.Base;

    public class ServiceMessage : MessageBase
    {
    }
}
