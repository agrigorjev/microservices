﻿using Mandara.Entities.Trades;

namespace Mandara.Business.Contracts
{
    public interface ITimeSpreadLegReader
    {
        DailyTimeSpreadLegsDates ReadDailyTimeSpreadLegsDates(TradeCaptureUniqueKey parentTradeUniqueKey);
    }
}
