﻿using Mandara.Entities;
using Mandara.Entities.EntityPieces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mandara.Business.Contracts
{
    public interface ITradeCaptureConverter
    {
        SourceDetail ConvertTradeCaptureToSourceDetail(TradeCapture tradeCapture, Product product = null);
        SourceDetail ConvertTradeCaptureToSourceDetail(TradePieces trade);
    }
}
